<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-05 05:45:30 --> Config Class Initialized
INFO - 2025-05-05 05:45:30 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:45:30 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:45:30 --> Utf8 Class Initialized
INFO - 2025-05-05 05:45:30 --> URI Class Initialized
DEBUG - 2025-05-05 05:45:30 --> No URI present. Default controller set.
INFO - 2025-05-05 05:45:30 --> Router Class Initialized
INFO - 2025-05-05 05:45:30 --> Output Class Initialized
INFO - 2025-05-05 05:45:30 --> Security Class Initialized
DEBUG - 2025-05-05 05:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:45:30 --> Input Class Initialized
INFO - 2025-05-05 05:45:30 --> Language Class Initialized
INFO - 2025-05-05 05:45:30 --> Loader Class Initialized
INFO - 2025-05-05 05:45:30 --> Helper loaded: form_helper
INFO - 2025-05-05 05:45:30 --> Helper loaded: url_helper
INFO - 2025-05-05 05:45:30 --> Database Driver Class Initialized
INFO - 2025-05-05 05:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:45:31 --> Form Validation Class Initialized
INFO - 2025-05-05 05:45:31 --> Controller Class Initialized
INFO - 2025-05-05 05:45:31 --> Final output sent to browser
DEBUG - 2025-05-05 05:45:31 --> Total execution time: 0.8240
INFO - 2025-05-05 05:45:35 --> Config Class Initialized
INFO - 2025-05-05 05:45:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:45:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:45:35 --> Utf8 Class Initialized
INFO - 2025-05-05 05:45:35 --> URI Class Initialized
INFO - 2025-05-05 05:45:35 --> Router Class Initialized
INFO - 2025-05-05 05:45:35 --> Output Class Initialized
INFO - 2025-05-05 05:45:35 --> Security Class Initialized
DEBUG - 2025-05-05 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:45:35 --> Input Class Initialized
INFO - 2025-05-05 05:45:35 --> Language Class Initialized
INFO - 2025-05-05 05:45:35 --> Loader Class Initialized
INFO - 2025-05-05 05:45:35 --> Helper loaded: form_helper
INFO - 2025-05-05 05:45:35 --> Helper loaded: url_helper
INFO - 2025-05-05 05:45:35 --> Database Driver Class Initialized
INFO - 2025-05-05 05:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:45:35 --> Form Validation Class Initialized
INFO - 2025-05-05 05:45:35 --> Controller Class Initialized
INFO - 2025-05-05 05:45:35 --> Config Class Initialized
INFO - 2025-05-05 05:45:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:45:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:45:35 --> Utf8 Class Initialized
INFO - 2025-05-05 05:45:35 --> URI Class Initialized
INFO - 2025-05-05 05:45:35 --> Router Class Initialized
INFO - 2025-05-05 05:45:35 --> Output Class Initialized
INFO - 2025-05-05 05:45:35 --> Security Class Initialized
DEBUG - 2025-05-05 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:45:35 --> Input Class Initialized
INFO - 2025-05-05 05:45:35 --> Language Class Initialized
INFO - 2025-05-05 05:45:35 --> Loader Class Initialized
INFO - 2025-05-05 05:45:35 --> Helper loaded: form_helper
INFO - 2025-05-05 05:45:35 --> Helper loaded: url_helper
INFO - 2025-05-05 05:45:35 --> Database Driver Class Initialized
INFO - 2025-05-05 05:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:45:35 --> Form Validation Class Initialized
INFO - 2025-05-05 05:45:35 --> Controller Class Initialized
INFO - 2025-05-05 05:45:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/login.php
INFO - 2025-05-05 05:45:35 --> Final output sent to browser
DEBUG - 2025-05-05 05:45:35 --> Total execution time: 0.0605
INFO - 2025-05-05 05:45:36 --> Config Class Initialized
INFO - 2025-05-05 05:45:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:45:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:45:36 --> Utf8 Class Initialized
INFO - 2025-05-05 05:45:36 --> URI Class Initialized
INFO - 2025-05-05 05:45:36 --> Router Class Initialized
INFO - 2025-05-05 05:45:36 --> Output Class Initialized
INFO - 2025-05-05 05:45:36 --> Security Class Initialized
DEBUG - 2025-05-05 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:45:36 --> Input Class Initialized
INFO - 2025-05-05 05:45:36 --> Language Class Initialized
INFO - 2025-05-05 05:45:36 --> Loader Class Initialized
INFO - 2025-05-05 05:45:36 --> Helper loaded: form_helper
INFO - 2025-05-05 05:45:36 --> Helper loaded: url_helper
INFO - 2025-05-05 05:45:36 --> Database Driver Class Initialized
INFO - 2025-05-05 05:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:45:36 --> Form Validation Class Initialized
INFO - 2025-05-05 05:45:36 --> Controller Class Initialized
INFO - 2025-05-05 05:45:36 --> Config Class Initialized
INFO - 2025-05-05 05:45:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:45:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:45:36 --> Utf8 Class Initialized
INFO - 2025-05-05 05:45:36 --> URI Class Initialized
INFO - 2025-05-05 05:45:36 --> Router Class Initialized
INFO - 2025-05-05 05:45:36 --> Output Class Initialized
INFO - 2025-05-05 05:45:36 --> Security Class Initialized
DEBUG - 2025-05-05 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:45:36 --> Input Class Initialized
INFO - 2025-05-05 05:45:36 --> Language Class Initialized
INFO - 2025-05-05 05:45:36 --> Loader Class Initialized
INFO - 2025-05-05 05:45:36 --> Helper loaded: form_helper
INFO - 2025-05-05 05:45:36 --> Helper loaded: url_helper
INFO - 2025-05-05 05:45:36 --> Database Driver Class Initialized
INFO - 2025-05-05 05:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:45:36 --> Form Validation Class Initialized
INFO - 2025-05-05 05:45:36 --> Controller Class Initialized
INFO - 2025-05-05 05:45:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:45:36 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:45:36 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:45:36 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-05 05:45:36 --> Final output sent to browser
DEBUG - 2025-05-05 05:45:36 --> Total execution time: 0.2267
INFO - 2025-05-05 05:45:39 --> Config Class Initialized
INFO - 2025-05-05 05:45:39 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:45:39 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:45:39 --> Utf8 Class Initialized
INFO - 2025-05-05 05:45:39 --> URI Class Initialized
INFO - 2025-05-05 05:45:39 --> Router Class Initialized
INFO - 2025-05-05 05:45:39 --> Output Class Initialized
INFO - 2025-05-05 05:45:39 --> Security Class Initialized
DEBUG - 2025-05-05 05:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:45:39 --> Input Class Initialized
INFO - 2025-05-05 05:45:39 --> Language Class Initialized
INFO - 2025-05-05 05:45:39 --> Loader Class Initialized
INFO - 2025-05-05 05:45:39 --> Helper loaded: form_helper
INFO - 2025-05-05 05:45:39 --> Helper loaded: url_helper
INFO - 2025-05-05 05:45:39 --> Database Driver Class Initialized
INFO - 2025-05-05 05:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:45:39 --> Form Validation Class Initialized
INFO - 2025-05-05 05:45:39 --> Controller Class Initialized
INFO - 2025-05-05 05:45:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:45:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:45:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:45:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-05 05:45:39 --> Final output sent to browser
DEBUG - 2025-05-05 05:45:39 --> Total execution time: 0.0737
INFO - 2025-05-05 05:45:40 --> Config Class Initialized
INFO - 2025-05-05 05:45:40 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:45:40 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:45:40 --> Utf8 Class Initialized
INFO - 2025-05-05 05:45:40 --> URI Class Initialized
INFO - 2025-05-05 05:45:40 --> Router Class Initialized
INFO - 2025-05-05 05:45:40 --> Output Class Initialized
INFO - 2025-05-05 05:45:40 --> Security Class Initialized
DEBUG - 2025-05-05 05:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:45:40 --> Input Class Initialized
INFO - 2025-05-05 05:45:40 --> Language Class Initialized
INFO - 2025-05-05 05:45:40 --> Loader Class Initialized
INFO - 2025-05-05 05:45:40 --> Helper loaded: form_helper
INFO - 2025-05-05 05:45:40 --> Helper loaded: url_helper
INFO - 2025-05-05 05:45:40 --> Database Driver Class Initialized
INFO - 2025-05-05 05:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:45:40 --> Form Validation Class Initialized
INFO - 2025-05-05 05:45:40 --> Controller Class Initialized
INFO - 2025-05-05 05:45:40 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:45:40 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:45:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:45:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-05 05:45:40 --> Final output sent to browser
DEBUG - 2025-05-05 05:45:40 --> Total execution time: 0.0864
INFO - 2025-05-05 05:45:41 --> Config Class Initialized
INFO - 2025-05-05 05:45:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:45:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:45:41 --> Utf8 Class Initialized
INFO - 2025-05-05 05:45:41 --> URI Class Initialized
INFO - 2025-05-05 05:45:41 --> Router Class Initialized
INFO - 2025-05-05 05:45:41 --> Output Class Initialized
INFO - 2025-05-05 05:45:41 --> Security Class Initialized
DEBUG - 2025-05-05 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:45:41 --> Input Class Initialized
INFO - 2025-05-05 05:45:41 --> Language Class Initialized
INFO - 2025-05-05 05:45:41 --> Loader Class Initialized
INFO - 2025-05-05 05:45:41 --> Helper loaded: form_helper
INFO - 2025-05-05 05:45:41 --> Helper loaded: url_helper
INFO - 2025-05-05 05:45:41 --> Database Driver Class Initialized
INFO - 2025-05-05 05:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:45:41 --> Form Validation Class Initialized
INFO - 2025-05-05 05:45:41 --> Controller Class Initialized
INFO - 2025-05-05 05:45:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:45:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:45:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:45:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 05:45:41 --> Final output sent to browser
DEBUG - 2025-05-05 05:45:41 --> Total execution time: 0.1093
INFO - 2025-05-05 05:45:46 --> Config Class Initialized
INFO - 2025-05-05 05:45:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:45:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:45:46 --> Utf8 Class Initialized
INFO - 2025-05-05 05:45:46 --> URI Class Initialized
INFO - 2025-05-05 05:45:46 --> Router Class Initialized
INFO - 2025-05-05 05:45:46 --> Output Class Initialized
INFO - 2025-05-05 05:45:46 --> Security Class Initialized
DEBUG - 2025-05-05 05:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:45:46 --> Input Class Initialized
INFO - 2025-05-05 05:45:46 --> Language Class Initialized
INFO - 2025-05-05 05:45:46 --> Loader Class Initialized
INFO - 2025-05-05 05:45:46 --> Helper loaded: form_helper
INFO - 2025-05-05 05:45:46 --> Helper loaded: url_helper
INFO - 2025-05-05 05:45:46 --> Database Driver Class Initialized
INFO - 2025-05-05 05:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:45:46 --> Form Validation Class Initialized
INFO - 2025-05-05 05:45:46 --> Controller Class Initialized
INFO - 2025-05-05 05:45:46 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:45:46 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:45:46 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:45:46 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:45:46 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-05 05:45:46 --> Final output sent to browser
DEBUG - 2025-05-05 05:45:46 --> Total execution time: 0.1843
INFO - 2025-05-05 05:47:09 --> Config Class Initialized
INFO - 2025-05-05 05:47:09 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:47:09 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:47:09 --> Utf8 Class Initialized
INFO - 2025-05-05 05:47:09 --> URI Class Initialized
INFO - 2025-05-05 05:47:09 --> Router Class Initialized
INFO - 2025-05-05 05:47:09 --> Output Class Initialized
INFO - 2025-05-05 05:47:09 --> Security Class Initialized
DEBUG - 2025-05-05 05:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:47:09 --> Input Class Initialized
INFO - 2025-05-05 05:47:09 --> Language Class Initialized
INFO - 2025-05-05 05:47:09 --> Loader Class Initialized
INFO - 2025-05-05 05:47:09 --> Helper loaded: form_helper
INFO - 2025-05-05 05:47:09 --> Helper loaded: url_helper
INFO - 2025-05-05 05:47:09 --> Database Driver Class Initialized
INFO - 2025-05-05 05:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:47:09 --> Form Validation Class Initialized
INFO - 2025-05-05 05:47:09 --> Controller Class Initialized
INFO - 2025-05-05 05:47:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:47:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:47:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:47:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:47:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-05 05:47:09 --> Final output sent to browser
DEBUG - 2025-05-05 05:47:09 --> Total execution time: 0.0378
INFO - 2025-05-05 05:47:12 --> Config Class Initialized
INFO - 2025-05-05 05:47:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:47:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:47:12 --> Utf8 Class Initialized
INFO - 2025-05-05 05:47:12 --> URI Class Initialized
INFO - 2025-05-05 05:47:12 --> Router Class Initialized
INFO - 2025-05-05 05:47:12 --> Output Class Initialized
INFO - 2025-05-05 05:47:12 --> Security Class Initialized
DEBUG - 2025-05-05 05:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:47:12 --> Input Class Initialized
INFO - 2025-05-05 05:47:12 --> Language Class Initialized
INFO - 2025-05-05 05:47:12 --> Loader Class Initialized
INFO - 2025-05-05 05:47:12 --> Helper loaded: form_helper
INFO - 2025-05-05 05:47:12 --> Helper loaded: url_helper
INFO - 2025-05-05 05:47:12 --> Database Driver Class Initialized
INFO - 2025-05-05 05:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:47:12 --> Form Validation Class Initialized
INFO - 2025-05-05 05:47:12 --> Controller Class Initialized
INFO - 2025-05-05 05:47:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:47:12 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:47:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:47:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-05 05:47:12 --> Final output sent to browser
DEBUG - 2025-05-05 05:47:12 --> Total execution time: 0.0252
INFO - 2025-05-05 05:47:13 --> Config Class Initialized
INFO - 2025-05-05 05:47:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:47:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:47:13 --> Utf8 Class Initialized
INFO - 2025-05-05 05:47:13 --> URI Class Initialized
INFO - 2025-05-05 05:47:13 --> Router Class Initialized
INFO - 2025-05-05 05:47:13 --> Output Class Initialized
INFO - 2025-05-05 05:47:13 --> Security Class Initialized
DEBUG - 2025-05-05 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:47:13 --> Input Class Initialized
INFO - 2025-05-05 05:47:13 --> Language Class Initialized
INFO - 2025-05-05 05:47:13 --> Loader Class Initialized
INFO - 2025-05-05 05:47:13 --> Helper loaded: form_helper
INFO - 2025-05-05 05:47:13 --> Helper loaded: url_helper
INFO - 2025-05-05 05:47:13 --> Database Driver Class Initialized
INFO - 2025-05-05 05:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:47:13 --> Form Validation Class Initialized
INFO - 2025-05-05 05:47:13 --> Controller Class Initialized
INFO - 2025-05-05 05:47:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:47:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:47:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:47:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-05 05:47:13 --> Final output sent to browser
DEBUG - 2025-05-05 05:47:13 --> Total execution time: 0.0263
INFO - 2025-05-05 05:47:14 --> Config Class Initialized
INFO - 2025-05-05 05:47:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:47:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:47:14 --> Utf8 Class Initialized
INFO - 2025-05-05 05:47:14 --> URI Class Initialized
INFO - 2025-05-05 05:47:14 --> Router Class Initialized
INFO - 2025-05-05 05:47:14 --> Output Class Initialized
INFO - 2025-05-05 05:47:14 --> Security Class Initialized
DEBUG - 2025-05-05 05:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:47:14 --> Input Class Initialized
INFO - 2025-05-05 05:47:14 --> Language Class Initialized
INFO - 2025-05-05 05:47:14 --> Loader Class Initialized
INFO - 2025-05-05 05:47:14 --> Helper loaded: form_helper
INFO - 2025-05-05 05:47:14 --> Helper loaded: url_helper
INFO - 2025-05-05 05:47:14 --> Database Driver Class Initialized
INFO - 2025-05-05 05:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:47:14 --> Form Validation Class Initialized
INFO - 2025-05-05 05:47:14 --> Controller Class Initialized
INFO - 2025-05-05 05:47:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:47:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:47:14 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:47:14 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-05 05:47:14 --> Final output sent to browser
DEBUG - 2025-05-05 05:47:14 --> Total execution time: 0.0310
INFO - 2025-05-05 05:47:16 --> Config Class Initialized
INFO - 2025-05-05 05:47:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:47:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:47:16 --> Utf8 Class Initialized
INFO - 2025-05-05 05:47:16 --> URI Class Initialized
INFO - 2025-05-05 05:47:16 --> Router Class Initialized
INFO - 2025-05-05 05:47:16 --> Output Class Initialized
INFO - 2025-05-05 05:47:16 --> Security Class Initialized
DEBUG - 2025-05-05 05:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:47:16 --> Input Class Initialized
INFO - 2025-05-05 05:47:16 --> Language Class Initialized
INFO - 2025-05-05 05:47:16 --> Loader Class Initialized
INFO - 2025-05-05 05:47:16 --> Helper loaded: form_helper
INFO - 2025-05-05 05:47:16 --> Helper loaded: url_helper
INFO - 2025-05-05 05:47:16 --> Database Driver Class Initialized
INFO - 2025-05-05 05:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:47:16 --> Form Validation Class Initialized
INFO - 2025-05-05 05:47:16 --> Controller Class Initialized
INFO - 2025-05-05 05:47:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:47:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:47:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:47:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 05:47:16 --> Final output sent to browser
DEBUG - 2025-05-05 05:47:16 --> Total execution time: 0.0306
INFO - 2025-05-05 05:47:21 --> Config Class Initialized
INFO - 2025-05-05 05:47:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:47:21 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:47:21 --> Utf8 Class Initialized
INFO - 2025-05-05 05:47:21 --> URI Class Initialized
INFO - 2025-05-05 05:47:21 --> Router Class Initialized
INFO - 2025-05-05 05:47:21 --> Output Class Initialized
INFO - 2025-05-05 05:47:21 --> Security Class Initialized
DEBUG - 2025-05-05 05:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:47:21 --> Input Class Initialized
INFO - 2025-05-05 05:47:21 --> Language Class Initialized
INFO - 2025-05-05 05:47:21 --> Loader Class Initialized
INFO - 2025-05-05 05:47:21 --> Helper loaded: form_helper
INFO - 2025-05-05 05:47:21 --> Helper loaded: url_helper
INFO - 2025-05-05 05:47:21 --> Database Driver Class Initialized
INFO - 2025-05-05 05:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:47:21 --> Form Validation Class Initialized
INFO - 2025-05-05 05:47:21 --> Controller Class Initialized
INFO - 2025-05-05 05:47:21 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:47:21 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:47:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:47:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 05:47:21 --> Final output sent to browser
DEBUG - 2025-05-05 05:47:21 --> Total execution time: 0.0304
INFO - 2025-05-05 05:47:27 --> Config Class Initialized
INFO - 2025-05-05 05:47:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:47:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:47:27 --> Utf8 Class Initialized
INFO - 2025-05-05 05:47:27 --> URI Class Initialized
INFO - 2025-05-05 05:47:27 --> Router Class Initialized
INFO - 2025-05-05 05:47:27 --> Output Class Initialized
INFO - 2025-05-05 05:47:27 --> Security Class Initialized
DEBUG - 2025-05-05 05:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:47:27 --> Input Class Initialized
INFO - 2025-05-05 05:47:27 --> Language Class Initialized
INFO - 2025-05-05 05:47:27 --> Loader Class Initialized
INFO - 2025-05-05 05:47:27 --> Helper loaded: form_helper
INFO - 2025-05-05 05:47:27 --> Helper loaded: url_helper
INFO - 2025-05-05 05:47:27 --> Database Driver Class Initialized
INFO - 2025-05-05 05:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:47:27 --> Form Validation Class Initialized
INFO - 2025-05-05 05:47:27 --> Controller Class Initialized
INFO - 2025-05-05 05:47:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:47:27 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 05:47:27 --> Query error: Table 'ppdb_mansaba.kop_sekolah' doesn't exist - Invalid query: SELECT *
FROM `kop_sekolah`
INFO - 2025-05-05 05:47:27 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 05:48:35 --> Config Class Initialized
INFO - 2025-05-05 05:48:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:48:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:48:35 --> Utf8 Class Initialized
INFO - 2025-05-05 05:48:35 --> URI Class Initialized
INFO - 2025-05-05 05:48:35 --> Router Class Initialized
INFO - 2025-05-05 05:48:35 --> Output Class Initialized
INFO - 2025-05-05 05:48:35 --> Security Class Initialized
DEBUG - 2025-05-05 05:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:48:35 --> Input Class Initialized
INFO - 2025-05-05 05:48:35 --> Language Class Initialized
INFO - 2025-05-05 05:48:35 --> Loader Class Initialized
INFO - 2025-05-05 05:48:35 --> Helper loaded: form_helper
INFO - 2025-05-05 05:48:35 --> Helper loaded: url_helper
INFO - 2025-05-05 05:48:35 --> Database Driver Class Initialized
INFO - 2025-05-05 05:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:48:35 --> Form Validation Class Initialized
INFO - 2025-05-05 05:48:35 --> Controller Class Initialized
INFO - 2025-05-05 05:48:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:48:35 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 05:48:35 --> Query error: Table 'ppdb_mansaba.kop_sekolah' doesn't exist - Invalid query: SELECT *
FROM `kop_sekolah`
INFO - 2025-05-05 05:48:35 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 05:51:08 --> Config Class Initialized
INFO - 2025-05-05 05:51:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:51:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:51:08 --> Utf8 Class Initialized
INFO - 2025-05-05 05:51:08 --> URI Class Initialized
INFO - 2025-05-05 05:51:08 --> Router Class Initialized
INFO - 2025-05-05 05:51:08 --> Output Class Initialized
INFO - 2025-05-05 05:51:08 --> Security Class Initialized
DEBUG - 2025-05-05 05:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:51:08 --> Input Class Initialized
INFO - 2025-05-05 05:51:08 --> Language Class Initialized
INFO - 2025-05-05 05:51:08 --> Loader Class Initialized
INFO - 2025-05-05 05:51:08 --> Helper loaded: form_helper
INFO - 2025-05-05 05:51:08 --> Helper loaded: url_helper
INFO - 2025-05-05 05:51:08 --> Database Driver Class Initialized
INFO - 2025-05-05 05:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:51:08 --> Form Validation Class Initialized
INFO - 2025-05-05 05:51:08 --> Controller Class Initialized
INFO - 2025-05-05 05:51:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:51:08 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 05:51:08 --> Query error: Table 'ppdb_mansaba.kop_sekolah' doesn't exist - Invalid query: SELECT *
FROM `kop_sekolah`
INFO - 2025-05-05 05:51:08 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 05:51:09 --> Config Class Initialized
INFO - 2025-05-05 05:51:09 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:51:09 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:51:09 --> Utf8 Class Initialized
INFO - 2025-05-05 05:51:09 --> URI Class Initialized
INFO - 2025-05-05 05:51:09 --> Router Class Initialized
INFO - 2025-05-05 05:51:09 --> Output Class Initialized
INFO - 2025-05-05 05:51:09 --> Security Class Initialized
DEBUG - 2025-05-05 05:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:51:09 --> Input Class Initialized
INFO - 2025-05-05 05:51:09 --> Language Class Initialized
INFO - 2025-05-05 05:51:09 --> Loader Class Initialized
INFO - 2025-05-05 05:51:09 --> Helper loaded: form_helper
INFO - 2025-05-05 05:51:09 --> Helper loaded: url_helper
INFO - 2025-05-05 05:51:09 --> Database Driver Class Initialized
INFO - 2025-05-05 05:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:51:09 --> Form Validation Class Initialized
INFO - 2025-05-05 05:51:09 --> Controller Class Initialized
INFO - 2025-05-05 05:51:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:51:09 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 05:51:09 --> Query error: Table 'ppdb_mansaba.kop_sekolah' doesn't exist - Invalid query: SELECT *
FROM `kop_sekolah`
INFO - 2025-05-05 05:51:09 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 05:53:46 --> Config Class Initialized
INFO - 2025-05-05 05:53:46 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:53:46 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:53:46 --> Utf8 Class Initialized
INFO - 2025-05-05 05:53:46 --> URI Class Initialized
INFO - 2025-05-05 05:53:46 --> Router Class Initialized
INFO - 2025-05-05 05:53:46 --> Output Class Initialized
INFO - 2025-05-05 05:53:46 --> Security Class Initialized
DEBUG - 2025-05-05 05:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:53:46 --> Input Class Initialized
INFO - 2025-05-05 05:53:46 --> Language Class Initialized
INFO - 2025-05-05 05:53:46 --> Loader Class Initialized
INFO - 2025-05-05 05:53:46 --> Helper loaded: form_helper
INFO - 2025-05-05 05:53:46 --> Helper loaded: url_helper
INFO - 2025-05-05 05:53:46 --> Database Driver Class Initialized
INFO - 2025-05-05 05:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:53:46 --> Form Validation Class Initialized
INFO - 2025-05-05 05:53:46 --> Controller Class Initialized
INFO - 2025-05-05 05:53:46 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:53:46 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 05:53:46 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2025-05-05 05:53:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 05:57:00 --> Config Class Initialized
INFO - 2025-05-05 05:57:00 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:57:00 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:57:00 --> Utf8 Class Initialized
INFO - 2025-05-05 05:57:00 --> URI Class Initialized
INFO - 2025-05-05 05:57:00 --> Router Class Initialized
INFO - 2025-05-05 05:57:00 --> Output Class Initialized
INFO - 2025-05-05 05:57:00 --> Security Class Initialized
DEBUG - 2025-05-05 05:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:57:00 --> Input Class Initialized
INFO - 2025-05-05 05:57:00 --> Language Class Initialized
INFO - 2025-05-05 05:57:00 --> Loader Class Initialized
INFO - 2025-05-05 05:57:00 --> Helper loaded: form_helper
INFO - 2025-05-05 05:57:00 --> Helper loaded: url_helper
INFO - 2025-05-05 05:57:00 --> Database Driver Class Initialized
INFO - 2025-05-05 05:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:57:00 --> Form Validation Class Initialized
INFO - 2025-05-05 05:57:00 --> Controller Class Initialized
INFO - 2025-05-05 05:57:00 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:57:00 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 05:57:00 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2025-05-05 05:57:00 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 05:57:01 --> Config Class Initialized
INFO - 2025-05-05 05:57:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:57:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:57:01 --> Utf8 Class Initialized
INFO - 2025-05-05 05:57:01 --> URI Class Initialized
INFO - 2025-05-05 05:57:01 --> Router Class Initialized
INFO - 2025-05-05 05:57:01 --> Output Class Initialized
INFO - 2025-05-05 05:57:01 --> Security Class Initialized
DEBUG - 2025-05-05 05:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:57:01 --> Input Class Initialized
INFO - 2025-05-05 05:57:01 --> Language Class Initialized
INFO - 2025-05-05 05:57:01 --> Loader Class Initialized
INFO - 2025-05-05 05:57:01 --> Helper loaded: form_helper
INFO - 2025-05-05 05:57:01 --> Helper loaded: url_helper
INFO - 2025-05-05 05:57:01 --> Database Driver Class Initialized
INFO - 2025-05-05 05:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:57:01 --> Form Validation Class Initialized
INFO - 2025-05-05 05:57:01 --> Controller Class Initialized
INFO - 2025-05-05 05:57:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:57:01 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:57:01 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:57:01 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 05:57:01 --> Final output sent to browser
DEBUG - 2025-05-05 05:57:01 --> Total execution time: 0.0288
INFO - 2025-05-05 05:57:05 --> Config Class Initialized
INFO - 2025-05-05 05:57:05 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:57:05 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:57:05 --> Utf8 Class Initialized
INFO - 2025-05-05 05:57:05 --> URI Class Initialized
INFO - 2025-05-05 05:57:05 --> Router Class Initialized
INFO - 2025-05-05 05:57:05 --> Output Class Initialized
INFO - 2025-05-05 05:57:05 --> Security Class Initialized
DEBUG - 2025-05-05 05:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:57:05 --> Input Class Initialized
INFO - 2025-05-05 05:57:05 --> Language Class Initialized
INFO - 2025-05-05 05:57:05 --> Loader Class Initialized
INFO - 2025-05-05 05:57:05 --> Helper loaded: form_helper
INFO - 2025-05-05 05:57:05 --> Helper loaded: url_helper
INFO - 2025-05-05 05:57:05 --> Database Driver Class Initialized
INFO - 2025-05-05 05:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:57:05 --> Form Validation Class Initialized
INFO - 2025-05-05 05:57:05 --> Controller Class Initialized
INFO - 2025-05-05 05:57:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:57:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:57:05 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:57:05 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 05:57:05 --> Final output sent to browser
DEBUG - 2025-05-05 05:57:05 --> Total execution time: 0.0283
INFO - 2025-05-05 05:57:07 --> Config Class Initialized
INFO - 2025-05-05 05:57:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:57:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:57:07 --> Utf8 Class Initialized
INFO - 2025-05-05 05:57:07 --> URI Class Initialized
INFO - 2025-05-05 05:57:07 --> Router Class Initialized
INFO - 2025-05-05 05:57:07 --> Output Class Initialized
INFO - 2025-05-05 05:57:07 --> Security Class Initialized
DEBUG - 2025-05-05 05:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:57:07 --> Input Class Initialized
INFO - 2025-05-05 05:57:07 --> Language Class Initialized
INFO - 2025-05-05 05:57:07 --> Loader Class Initialized
INFO - 2025-05-05 05:57:07 --> Helper loaded: form_helper
INFO - 2025-05-05 05:57:07 --> Helper loaded: url_helper
INFO - 2025-05-05 05:57:07 --> Database Driver Class Initialized
INFO - 2025-05-05 05:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:57:07 --> Form Validation Class Initialized
INFO - 2025-05-05 05:57:07 --> Controller Class Initialized
INFO - 2025-05-05 05:57:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:57:07 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 05:57:07 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 05:57:07 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 05:57:07 --> Final output sent to browser
DEBUG - 2025-05-05 05:57:07 --> Total execution time: 0.0323
INFO - 2025-05-05 05:58:48 --> Config Class Initialized
INFO - 2025-05-05 05:58:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 05:58:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 05:58:48 --> Utf8 Class Initialized
INFO - 2025-05-05 05:58:48 --> URI Class Initialized
INFO - 2025-05-05 05:58:48 --> Router Class Initialized
INFO - 2025-05-05 05:58:48 --> Output Class Initialized
INFO - 2025-05-05 05:58:48 --> Security Class Initialized
DEBUG - 2025-05-05 05:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 05:58:48 --> Input Class Initialized
INFO - 2025-05-05 05:58:48 --> Language Class Initialized
INFO - 2025-05-05 05:58:48 --> Loader Class Initialized
INFO - 2025-05-05 05:58:48 --> Helper loaded: form_helper
INFO - 2025-05-05 05:58:48 --> Helper loaded: url_helper
INFO - 2025-05-05 05:58:48 --> Database Driver Class Initialized
INFO - 2025-05-05 05:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 05:58:48 --> Form Validation Class Initialized
INFO - 2025-05-05 05:58:48 --> Controller Class Initialized
INFO - 2025-05-05 05:58:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 05:58:48 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 05:58:48 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2025-05-05 05:58:48 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:00:38 --> Config Class Initialized
INFO - 2025-05-05 06:00:38 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:00:38 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:00:38 --> Utf8 Class Initialized
INFO - 2025-05-05 06:00:38 --> URI Class Initialized
INFO - 2025-05-05 06:00:38 --> Router Class Initialized
INFO - 2025-05-05 06:00:38 --> Output Class Initialized
INFO - 2025-05-05 06:00:38 --> Security Class Initialized
DEBUG - 2025-05-05 06:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:00:38 --> Input Class Initialized
INFO - 2025-05-05 06:00:38 --> Language Class Initialized
INFO - 2025-05-05 06:00:38 --> Loader Class Initialized
INFO - 2025-05-05 06:00:38 --> Helper loaded: form_helper
INFO - 2025-05-05 06:00:38 --> Helper loaded: url_helper
INFO - 2025-05-05 06:00:38 --> Database Driver Class Initialized
INFO - 2025-05-05 06:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:00:38 --> Form Validation Class Initialized
INFO - 2025-05-05 06:00:38 --> Controller Class Initialized
INFO - 2025-05-05 06:00:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:00:38 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:00:38 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:00:38 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:00:51 --> Config Class Initialized
INFO - 2025-05-05 06:00:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:00:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:00:51 --> Utf8 Class Initialized
INFO - 2025-05-05 06:00:51 --> URI Class Initialized
INFO - 2025-05-05 06:00:51 --> Router Class Initialized
INFO - 2025-05-05 06:00:51 --> Output Class Initialized
INFO - 2025-05-05 06:00:51 --> Security Class Initialized
DEBUG - 2025-05-05 06:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:00:51 --> Input Class Initialized
INFO - 2025-05-05 06:00:51 --> Language Class Initialized
INFO - 2025-05-05 06:00:51 --> Loader Class Initialized
INFO - 2025-05-05 06:00:51 --> Helper loaded: form_helper
INFO - 2025-05-05 06:00:51 --> Helper loaded: url_helper
INFO - 2025-05-05 06:00:51 --> Database Driver Class Initialized
INFO - 2025-05-05 06:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:00:51 --> Form Validation Class Initialized
INFO - 2025-05-05 06:00:51 --> Controller Class Initialized
INFO - 2025-05-05 06:00:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:00:51 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:00:51 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:00:51 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:01:00 --> Config Class Initialized
INFO - 2025-05-05 06:01:00 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:01:00 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:01:00 --> Utf8 Class Initialized
INFO - 2025-05-05 06:01:00 --> URI Class Initialized
INFO - 2025-05-05 06:01:00 --> Router Class Initialized
INFO - 2025-05-05 06:01:00 --> Output Class Initialized
INFO - 2025-05-05 06:01:00 --> Security Class Initialized
DEBUG - 2025-05-05 06:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:01:00 --> Input Class Initialized
INFO - 2025-05-05 06:01:00 --> Language Class Initialized
INFO - 2025-05-05 06:01:00 --> Loader Class Initialized
INFO - 2025-05-05 06:01:00 --> Helper loaded: form_helper
INFO - 2025-05-05 06:01:00 --> Helper loaded: url_helper
INFO - 2025-05-05 06:01:00 --> Database Driver Class Initialized
INFO - 2025-05-05 06:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:01:00 --> Form Validation Class Initialized
INFO - 2025-05-05 06:01:00 --> Controller Class Initialized
INFO - 2025-05-05 06:01:00 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:01:00 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:01:00 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:01:00 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:01:01 --> Config Class Initialized
INFO - 2025-05-05 06:01:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:01:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:01:01 --> Utf8 Class Initialized
INFO - 2025-05-05 06:01:01 --> URI Class Initialized
INFO - 2025-05-05 06:01:01 --> Router Class Initialized
INFO - 2025-05-05 06:01:01 --> Output Class Initialized
INFO - 2025-05-05 06:01:01 --> Security Class Initialized
DEBUG - 2025-05-05 06:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:01:01 --> Input Class Initialized
INFO - 2025-05-05 06:01:01 --> Language Class Initialized
INFO - 2025-05-05 06:01:01 --> Loader Class Initialized
INFO - 2025-05-05 06:01:01 --> Helper loaded: form_helper
INFO - 2025-05-05 06:01:01 --> Helper loaded: url_helper
INFO - 2025-05-05 06:01:01 --> Database Driver Class Initialized
INFO - 2025-05-05 06:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:01:01 --> Form Validation Class Initialized
INFO - 2025-05-05 06:01:01 --> Controller Class Initialized
INFO - 2025-05-05 06:01:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:01:01 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:01:01 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:01:01 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:01:01 --> Config Class Initialized
INFO - 2025-05-05 06:01:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:01:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:01:01 --> Utf8 Class Initialized
INFO - 2025-05-05 06:01:01 --> URI Class Initialized
INFO - 2025-05-05 06:01:01 --> Router Class Initialized
INFO - 2025-05-05 06:01:01 --> Output Class Initialized
INFO - 2025-05-05 06:01:01 --> Security Class Initialized
DEBUG - 2025-05-05 06:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:01:01 --> Input Class Initialized
INFO - 2025-05-05 06:01:01 --> Language Class Initialized
INFO - 2025-05-05 06:01:01 --> Loader Class Initialized
INFO - 2025-05-05 06:01:01 --> Helper loaded: form_helper
INFO - 2025-05-05 06:01:01 --> Helper loaded: url_helper
INFO - 2025-05-05 06:01:01 --> Database Driver Class Initialized
INFO - 2025-05-05 06:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:01:01 --> Form Validation Class Initialized
INFO - 2025-05-05 06:01:01 --> Controller Class Initialized
INFO - 2025-05-05 06:01:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:01:01 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:01:01 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:01:01 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:01:01 --> Config Class Initialized
INFO - 2025-05-05 06:01:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:01:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:01:01 --> Utf8 Class Initialized
INFO - 2025-05-05 06:01:01 --> URI Class Initialized
INFO - 2025-05-05 06:01:01 --> Router Class Initialized
INFO - 2025-05-05 06:01:01 --> Output Class Initialized
INFO - 2025-05-05 06:01:01 --> Security Class Initialized
DEBUG - 2025-05-05 06:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:01:01 --> Input Class Initialized
INFO - 2025-05-05 06:01:01 --> Language Class Initialized
INFO - 2025-05-05 06:01:01 --> Loader Class Initialized
INFO - 2025-05-05 06:01:01 --> Helper loaded: form_helper
INFO - 2025-05-05 06:01:01 --> Helper loaded: url_helper
INFO - 2025-05-05 06:01:01 --> Database Driver Class Initialized
INFO - 2025-05-05 06:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:01:01 --> Form Validation Class Initialized
INFO - 2025-05-05 06:01:01 --> Controller Class Initialized
INFO - 2025-05-05 06:01:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:01:01 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:01:01 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:01:01 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:02:10 --> Config Class Initialized
INFO - 2025-05-05 06:02:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:02:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:02:10 --> Utf8 Class Initialized
INFO - 2025-05-05 06:02:10 --> URI Class Initialized
INFO - 2025-05-05 06:02:10 --> Router Class Initialized
INFO - 2025-05-05 06:02:10 --> Output Class Initialized
INFO - 2025-05-05 06:02:10 --> Security Class Initialized
DEBUG - 2025-05-05 06:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:02:10 --> Input Class Initialized
INFO - 2025-05-05 06:02:10 --> Language Class Initialized
INFO - 2025-05-05 06:02:10 --> Loader Class Initialized
INFO - 2025-05-05 06:02:10 --> Helper loaded: form_helper
INFO - 2025-05-05 06:02:10 --> Helper loaded: url_helper
INFO - 2025-05-05 06:02:10 --> Database Driver Class Initialized
INFO - 2025-05-05 06:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:02:10 --> Form Validation Class Initialized
INFO - 2025-05-05 06:02:10 --> Controller Class Initialized
INFO - 2025-05-05 06:02:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:02:10 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:02:10 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:02:10 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:02:11 --> Config Class Initialized
INFO - 2025-05-05 06:02:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:02:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:02:11 --> Utf8 Class Initialized
INFO - 2025-05-05 06:02:11 --> URI Class Initialized
INFO - 2025-05-05 06:02:11 --> Router Class Initialized
INFO - 2025-05-05 06:02:11 --> Output Class Initialized
INFO - 2025-05-05 06:02:11 --> Security Class Initialized
DEBUG - 2025-05-05 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:02:11 --> Input Class Initialized
INFO - 2025-05-05 06:02:11 --> Language Class Initialized
INFO - 2025-05-05 06:02:11 --> Loader Class Initialized
INFO - 2025-05-05 06:02:11 --> Helper loaded: form_helper
INFO - 2025-05-05 06:02:11 --> Helper loaded: url_helper
INFO - 2025-05-05 06:02:11 --> Database Driver Class Initialized
INFO - 2025-05-05 06:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:02:11 --> Form Validation Class Initialized
INFO - 2025-05-05 06:02:11 --> Controller Class Initialized
INFO - 2025-05-05 06:02:11 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:02:11 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:02:11 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:02:11 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:02:12 --> Config Class Initialized
INFO - 2025-05-05 06:02:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:02:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:02:12 --> Utf8 Class Initialized
INFO - 2025-05-05 06:02:12 --> URI Class Initialized
INFO - 2025-05-05 06:02:12 --> Router Class Initialized
INFO - 2025-05-05 06:02:12 --> Output Class Initialized
INFO - 2025-05-05 06:02:12 --> Security Class Initialized
DEBUG - 2025-05-05 06:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:02:12 --> Input Class Initialized
INFO - 2025-05-05 06:02:12 --> Language Class Initialized
INFO - 2025-05-05 06:02:12 --> Loader Class Initialized
INFO - 2025-05-05 06:02:12 --> Helper loaded: form_helper
INFO - 2025-05-05 06:02:12 --> Helper loaded: url_helper
INFO - 2025-05-05 06:02:12 --> Database Driver Class Initialized
INFO - 2025-05-05 06:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:02:12 --> Form Validation Class Initialized
INFO - 2025-05-05 06:02:12 --> Controller Class Initialized
INFO - 2025-05-05 06:02:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:02:12 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:02:12 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:02:12 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:03:07 --> Config Class Initialized
INFO - 2025-05-05 06:03:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:03:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:03:07 --> Utf8 Class Initialized
INFO - 2025-05-05 06:03:07 --> URI Class Initialized
INFO - 2025-05-05 06:03:07 --> Router Class Initialized
INFO - 2025-05-05 06:03:07 --> Output Class Initialized
INFO - 2025-05-05 06:03:07 --> Security Class Initialized
DEBUG - 2025-05-05 06:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:03:07 --> Input Class Initialized
INFO - 2025-05-05 06:03:07 --> Language Class Initialized
INFO - 2025-05-05 06:03:07 --> Loader Class Initialized
INFO - 2025-05-05 06:03:07 --> Helper loaded: form_helper
INFO - 2025-05-05 06:03:07 --> Helper loaded: url_helper
INFO - 2025-05-05 06:03:07 --> Database Driver Class Initialized
INFO - 2025-05-05 06:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:03:07 --> Form Validation Class Initialized
INFO - 2025-05-05 06:03:07 --> Controller Class Initialized
INFO - 2025-05-05 06:03:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:03:07 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:03:07 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:03:07 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:03:07 --> Config Class Initialized
INFO - 2025-05-05 06:03:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:03:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:03:07 --> Utf8 Class Initialized
INFO - 2025-05-05 06:03:07 --> URI Class Initialized
INFO - 2025-05-05 06:03:07 --> Router Class Initialized
INFO - 2025-05-05 06:03:07 --> Output Class Initialized
INFO - 2025-05-05 06:03:07 --> Security Class Initialized
DEBUG - 2025-05-05 06:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:03:07 --> Input Class Initialized
INFO - 2025-05-05 06:03:07 --> Language Class Initialized
INFO - 2025-05-05 06:03:07 --> Loader Class Initialized
INFO - 2025-05-05 06:03:07 --> Helper loaded: form_helper
INFO - 2025-05-05 06:03:07 --> Helper loaded: url_helper
INFO - 2025-05-05 06:03:07 --> Database Driver Class Initialized
INFO - 2025-05-05 06:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:03:07 --> Form Validation Class Initialized
INFO - 2025-05-05 06:03:07 --> Controller Class Initialized
INFO - 2025-05-05 06:03:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:03:07 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:03:07 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:03:07 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:03:07 --> Config Class Initialized
INFO - 2025-05-05 06:03:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:03:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:03:07 --> Utf8 Class Initialized
INFO - 2025-05-05 06:03:07 --> URI Class Initialized
INFO - 2025-05-05 06:03:07 --> Router Class Initialized
INFO - 2025-05-05 06:03:07 --> Output Class Initialized
INFO - 2025-05-05 06:03:07 --> Security Class Initialized
DEBUG - 2025-05-05 06:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:03:07 --> Input Class Initialized
INFO - 2025-05-05 06:03:07 --> Language Class Initialized
INFO - 2025-05-05 06:03:07 --> Loader Class Initialized
INFO - 2025-05-05 06:03:07 --> Helper loaded: form_helper
INFO - 2025-05-05 06:03:07 --> Helper loaded: url_helper
INFO - 2025-05-05 06:03:07 --> Database Driver Class Initialized
INFO - 2025-05-05 06:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:03:07 --> Form Validation Class Initialized
INFO - 2025-05-05 06:03:07 --> Controller Class Initialized
INFO - 2025-05-05 06:03:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:03:07 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:03:07 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:03:07 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:12:49 --> Config Class Initialized
INFO - 2025-05-05 06:12:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:12:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:12:49 --> Utf8 Class Initialized
INFO - 2025-05-05 06:12:49 --> URI Class Initialized
INFO - 2025-05-05 06:12:49 --> Router Class Initialized
INFO - 2025-05-05 06:12:49 --> Output Class Initialized
INFO - 2025-05-05 06:12:49 --> Security Class Initialized
DEBUG - 2025-05-05 06:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:12:49 --> Input Class Initialized
INFO - 2025-05-05 06:12:49 --> Language Class Initialized
INFO - 2025-05-05 06:12:49 --> Loader Class Initialized
INFO - 2025-05-05 06:12:49 --> Helper loaded: form_helper
INFO - 2025-05-05 06:12:49 --> Helper loaded: url_helper
INFO - 2025-05-05 06:12:49 --> Database Driver Class Initialized
INFO - 2025-05-05 06:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:12:49 --> Form Validation Class Initialized
INFO - 2025-05-05 06:12:49 --> Controller Class Initialized
INFO - 2025-05-05 06:12:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:12:49 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:12:49 --> Query error: Not unique table/alias: 'pendaftaran' - Invalid query: SELECT *
FROM `pendaftaran`, `pendaftaran`
WHERE `id` = '1'
INFO - 2025-05-05 06:12:49 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 06:14:15 --> Config Class Initialized
INFO - 2025-05-05 06:14:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:14:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:14:15 --> Utf8 Class Initialized
INFO - 2025-05-05 06:14:15 --> URI Class Initialized
INFO - 2025-05-05 06:14:15 --> Router Class Initialized
INFO - 2025-05-05 06:14:15 --> Output Class Initialized
INFO - 2025-05-05 06:14:15 --> Security Class Initialized
DEBUG - 2025-05-05 06:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:14:15 --> Input Class Initialized
INFO - 2025-05-05 06:14:15 --> Language Class Initialized
INFO - 2025-05-05 06:14:15 --> Loader Class Initialized
INFO - 2025-05-05 06:14:15 --> Helper loaded: form_helper
INFO - 2025-05-05 06:14:15 --> Helper loaded: url_helper
INFO - 2025-05-05 06:14:15 --> Database Driver Class Initialized
INFO - 2025-05-05 06:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:14:15 --> Form Validation Class Initialized
INFO - 2025-05-05 06:14:15 --> Controller Class Initialized
INFO - 2025-05-05 06:14:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:14:15 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:14:15 --> Severity: error --> Exception: Call to undefined method Pendaftaran_model::get_kop_sekolah() C:\xampp\htdocs\ppdb\application\controllers\Admin.php 530
INFO - 2025-05-05 06:16:39 --> Config Class Initialized
INFO - 2025-05-05 06:16:39 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:16:39 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:16:39 --> Utf8 Class Initialized
INFO - 2025-05-05 06:16:39 --> URI Class Initialized
INFO - 2025-05-05 06:16:39 --> Router Class Initialized
INFO - 2025-05-05 06:16:39 --> Output Class Initialized
INFO - 2025-05-05 06:16:39 --> Security Class Initialized
DEBUG - 2025-05-05 06:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:16:39 --> Input Class Initialized
INFO - 2025-05-05 06:16:39 --> Language Class Initialized
INFO - 2025-05-05 06:16:39 --> Loader Class Initialized
INFO - 2025-05-05 06:16:39 --> Helper loaded: form_helper
INFO - 2025-05-05 06:16:39 --> Helper loaded: url_helper
INFO - 2025-05-05 06:16:39 --> Database Driver Class Initialized
INFO - 2025-05-05 06:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:16:39 --> Form Validation Class Initialized
INFO - 2025-05-05 06:16:39 --> Controller Class Initialized
INFO - 2025-05-05 06:16:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:16:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:16:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-05 06:16:39 --> Final output sent to browser
DEBUG - 2025-05-05 06:16:39 --> Total execution time: 0.0280
INFO - 2025-05-05 06:28:10 --> Config Class Initialized
INFO - 2025-05-05 06:28:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:28:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:28:10 --> Utf8 Class Initialized
INFO - 2025-05-05 06:28:10 --> URI Class Initialized
INFO - 2025-05-05 06:28:10 --> Router Class Initialized
INFO - 2025-05-05 06:28:10 --> Output Class Initialized
INFO - 2025-05-05 06:28:10 --> Security Class Initialized
DEBUG - 2025-05-05 06:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:28:10 --> Input Class Initialized
INFO - 2025-05-05 06:28:10 --> Language Class Initialized
INFO - 2025-05-05 06:28:10 --> Loader Class Initialized
INFO - 2025-05-05 06:28:10 --> Helper loaded: form_helper
INFO - 2025-05-05 06:28:10 --> Helper loaded: url_helper
INFO - 2025-05-05 06:28:10 --> Database Driver Class Initialized
INFO - 2025-05-05 06:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:28:10 --> Form Validation Class Initialized
INFO - 2025-05-05 06:28:10 --> Controller Class Initialized
INFO - 2025-05-05 06:28:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:28:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:28:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-05 06:28:10 --> Config Class Initialized
INFO - 2025-05-05 06:28:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:28:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:28:10 --> Utf8 Class Initialized
INFO - 2025-05-05 06:28:10 --> URI Class Initialized
INFO - 2025-05-05 06:28:10 --> Router Class Initialized
INFO - 2025-05-05 06:28:10 --> Output Class Initialized
INFO - 2025-05-05 06:28:10 --> Security Class Initialized
DEBUG - 2025-05-05 06:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:28:10 --> Input Class Initialized
INFO - 2025-05-05 06:28:10 --> Language Class Initialized
INFO - 2025-05-05 06:28:10 --> Loader Class Initialized
INFO - 2025-05-05 06:28:10 --> Helper loaded: form_helper
INFO - 2025-05-05 06:28:10 --> Helper loaded: url_helper
INFO - 2025-05-05 06:28:10 --> Database Driver Class Initialized
INFO - 2025-05-05 06:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:28:10 --> Form Validation Class Initialized
INFO - 2025-05-05 06:28:10 --> Controller Class Initialized
INFO - 2025-05-05 06:28:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:28:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:28:10 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:28:10 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 06:28:10 --> Final output sent to browser
DEBUG - 2025-05-05 06:28:10 --> Total execution time: 0.0325
INFO - 2025-05-05 06:28:20 --> Config Class Initialized
INFO - 2025-05-05 06:28:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:28:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:28:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:28:20 --> URI Class Initialized
INFO - 2025-05-05 06:28:20 --> Router Class Initialized
INFO - 2025-05-05 06:28:20 --> Output Class Initialized
INFO - 2025-05-05 06:28:20 --> Security Class Initialized
DEBUG - 2025-05-05 06:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:28:20 --> Input Class Initialized
INFO - 2025-05-05 06:28:20 --> Language Class Initialized
INFO - 2025-05-05 06:28:20 --> Loader Class Initialized
INFO - 2025-05-05 06:28:20 --> Helper loaded: form_helper
INFO - 2025-05-05 06:28:20 --> Helper loaded: url_helper
INFO - 2025-05-05 06:28:20 --> Database Driver Class Initialized
INFO - 2025-05-05 06:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:28:20 --> Form Validation Class Initialized
INFO - 2025-05-05 06:28:20 --> Controller Class Initialized
INFO - 2025-05-05 06:28:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:28:20 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 06:28:20 --> Severity: Notice --> Undefined variable: kop C:\xampp\htdocs\ppdb\application\controllers\Admin.php 129
INFO - 2025-05-05 06:28:20 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:28:20 --> Final output sent to browser
DEBUG - 2025-05-05 06:28:20 --> Total execution time: 0.0331
INFO - 2025-05-05 06:31:17 --> Config Class Initialized
INFO - 2025-05-05 06:31:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:31:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:31:17 --> Utf8 Class Initialized
INFO - 2025-05-05 06:31:17 --> URI Class Initialized
INFO - 2025-05-05 06:31:17 --> Router Class Initialized
INFO - 2025-05-05 06:31:17 --> Output Class Initialized
INFO - 2025-05-05 06:31:17 --> Security Class Initialized
DEBUG - 2025-05-05 06:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:31:17 --> Input Class Initialized
INFO - 2025-05-05 06:31:17 --> Language Class Initialized
INFO - 2025-05-05 06:31:17 --> Loader Class Initialized
INFO - 2025-05-05 06:31:17 --> Helper loaded: form_helper
INFO - 2025-05-05 06:31:17 --> Helper loaded: url_helper
INFO - 2025-05-05 06:31:17 --> Database Driver Class Initialized
INFO - 2025-05-05 06:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:31:17 --> Form Validation Class Initialized
INFO - 2025-05-05 06:31:17 --> Controller Class Initialized
INFO - 2025-05-05 06:31:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:31:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:31:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:31:17 --> Final output sent to browser
DEBUG - 2025-05-05 06:31:17 --> Total execution time: 0.0262
INFO - 2025-05-05 06:34:15 --> Config Class Initialized
INFO - 2025-05-05 06:34:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:34:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:34:15 --> Utf8 Class Initialized
INFO - 2025-05-05 06:34:15 --> URI Class Initialized
INFO - 2025-05-05 06:34:15 --> Router Class Initialized
INFO - 2025-05-05 06:34:15 --> Output Class Initialized
INFO - 2025-05-05 06:34:15 --> Security Class Initialized
DEBUG - 2025-05-05 06:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:34:15 --> Input Class Initialized
INFO - 2025-05-05 06:34:15 --> Language Class Initialized
INFO - 2025-05-05 06:34:15 --> Loader Class Initialized
INFO - 2025-05-05 06:34:15 --> Helper loaded: form_helper
INFO - 2025-05-05 06:34:15 --> Helper loaded: url_helper
INFO - 2025-05-05 06:34:15 --> Database Driver Class Initialized
INFO - 2025-05-05 06:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:34:15 --> Form Validation Class Initialized
INFO - 2025-05-05 06:34:15 --> Controller Class Initialized
INFO - 2025-05-05 06:34:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:34:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:34:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:34:15 --> Final output sent to browser
DEBUG - 2025-05-05 06:34:15 --> Total execution time: 0.0324
INFO - 2025-05-05 06:34:17 --> Config Class Initialized
INFO - 2025-05-05 06:34:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:34:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:34:17 --> Utf8 Class Initialized
INFO - 2025-05-05 06:34:17 --> URI Class Initialized
INFO - 2025-05-05 06:34:17 --> Router Class Initialized
INFO - 2025-05-05 06:34:17 --> Output Class Initialized
INFO - 2025-05-05 06:34:17 --> Security Class Initialized
DEBUG - 2025-05-05 06:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:34:17 --> Input Class Initialized
INFO - 2025-05-05 06:34:17 --> Language Class Initialized
INFO - 2025-05-05 06:34:17 --> Loader Class Initialized
INFO - 2025-05-05 06:34:17 --> Helper loaded: form_helper
INFO - 2025-05-05 06:34:17 --> Helper loaded: url_helper
INFO - 2025-05-05 06:34:17 --> Database Driver Class Initialized
INFO - 2025-05-05 06:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:34:17 --> Form Validation Class Initialized
INFO - 2025-05-05 06:34:17 --> Controller Class Initialized
INFO - 2025-05-05 06:34:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:34:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:34:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:34:17 --> Final output sent to browser
DEBUG - 2025-05-05 06:34:17 --> Total execution time: 0.0303
INFO - 2025-05-05 06:34:20 --> Config Class Initialized
INFO - 2025-05-05 06:34:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:34:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:34:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:34:20 --> URI Class Initialized
INFO - 2025-05-05 06:34:20 --> Router Class Initialized
INFO - 2025-05-05 06:34:20 --> Output Class Initialized
INFO - 2025-05-05 06:34:20 --> Security Class Initialized
DEBUG - 2025-05-05 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:34:20 --> Input Class Initialized
INFO - 2025-05-05 06:34:20 --> Language Class Initialized
INFO - 2025-05-05 06:34:20 --> Loader Class Initialized
INFO - 2025-05-05 06:34:20 --> Helper loaded: form_helper
INFO - 2025-05-05 06:34:20 --> Helper loaded: url_helper
INFO - 2025-05-05 06:34:20 --> Database Driver Class Initialized
INFO - 2025-05-05 06:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:34:20 --> Form Validation Class Initialized
INFO - 2025-05-05 06:34:20 --> Controller Class Initialized
INFO - 2025-05-05 06:34:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:34:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:34:20 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:34:20 --> Final output sent to browser
DEBUG - 2025-05-05 06:34:20 --> Total execution time: 0.0277
INFO - 2025-05-05 06:34:20 --> Config Class Initialized
INFO - 2025-05-05 06:34:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:34:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:34:20 --> Utf8 Class Initialized
INFO - 2025-05-05 06:34:20 --> URI Class Initialized
INFO - 2025-05-05 06:34:20 --> Router Class Initialized
INFO - 2025-05-05 06:34:20 --> Output Class Initialized
INFO - 2025-05-05 06:34:20 --> Security Class Initialized
DEBUG - 2025-05-05 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:34:20 --> Input Class Initialized
INFO - 2025-05-05 06:34:20 --> Language Class Initialized
INFO - 2025-05-05 06:34:20 --> Loader Class Initialized
INFO - 2025-05-05 06:34:20 --> Helper loaded: form_helper
INFO - 2025-05-05 06:34:20 --> Helper loaded: url_helper
INFO - 2025-05-05 06:34:20 --> Database Driver Class Initialized
INFO - 2025-05-05 06:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:34:20 --> Form Validation Class Initialized
INFO - 2025-05-05 06:34:20 --> Controller Class Initialized
INFO - 2025-05-05 06:34:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:34:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:34:20 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:34:20 --> Final output sent to browser
DEBUG - 2025-05-05 06:34:20 --> Total execution time: 0.0372
INFO - 2025-05-05 06:34:22 --> Config Class Initialized
INFO - 2025-05-05 06:34:22 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:34:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:34:22 --> Utf8 Class Initialized
INFO - 2025-05-05 06:34:22 --> URI Class Initialized
INFO - 2025-05-05 06:34:22 --> Router Class Initialized
INFO - 2025-05-05 06:34:22 --> Output Class Initialized
INFO - 2025-05-05 06:34:22 --> Security Class Initialized
DEBUG - 2025-05-05 06:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:34:22 --> Input Class Initialized
INFO - 2025-05-05 06:34:22 --> Language Class Initialized
INFO - 2025-05-05 06:34:22 --> Loader Class Initialized
INFO - 2025-05-05 06:34:22 --> Helper loaded: form_helper
INFO - 2025-05-05 06:34:22 --> Helper loaded: url_helper
INFO - 2025-05-05 06:34:22 --> Database Driver Class Initialized
INFO - 2025-05-05 06:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:34:22 --> Form Validation Class Initialized
INFO - 2025-05-05 06:34:22 --> Controller Class Initialized
INFO - 2025-05-05 06:34:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:34:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:34:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:34:22 --> Final output sent to browser
DEBUG - 2025-05-05 06:34:22 --> Total execution time: 0.0290
INFO - 2025-05-05 06:36:08 --> Config Class Initialized
INFO - 2025-05-05 06:36:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:36:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:36:08 --> Utf8 Class Initialized
INFO - 2025-05-05 06:36:08 --> URI Class Initialized
INFO - 2025-05-05 06:36:08 --> Router Class Initialized
INFO - 2025-05-05 06:36:08 --> Output Class Initialized
INFO - 2025-05-05 06:36:08 --> Security Class Initialized
DEBUG - 2025-05-05 06:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:36:08 --> Input Class Initialized
INFO - 2025-05-05 06:36:08 --> Language Class Initialized
INFO - 2025-05-05 06:36:08 --> Loader Class Initialized
INFO - 2025-05-05 06:36:08 --> Helper loaded: form_helper
INFO - 2025-05-05 06:36:08 --> Helper loaded: url_helper
INFO - 2025-05-05 06:36:08 --> Database Driver Class Initialized
INFO - 2025-05-05 06:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:36:08 --> Form Validation Class Initialized
INFO - 2025-05-05 06:36:08 --> Controller Class Initialized
INFO - 2025-05-05 06:36:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:36:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:36:08 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:36:08 --> Final output sent to browser
DEBUG - 2025-05-05 06:36:08 --> Total execution time: 0.0269
INFO - 2025-05-05 06:36:12 --> Config Class Initialized
INFO - 2025-05-05 06:36:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:36:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:36:12 --> Utf8 Class Initialized
INFO - 2025-05-05 06:36:12 --> URI Class Initialized
INFO - 2025-05-05 06:36:12 --> Router Class Initialized
INFO - 2025-05-05 06:36:12 --> Output Class Initialized
INFO - 2025-05-05 06:36:12 --> Security Class Initialized
DEBUG - 2025-05-05 06:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:36:12 --> Input Class Initialized
INFO - 2025-05-05 06:36:12 --> Language Class Initialized
INFO - 2025-05-05 06:36:12 --> Loader Class Initialized
INFO - 2025-05-05 06:36:12 --> Helper loaded: form_helper
INFO - 2025-05-05 06:36:12 --> Helper loaded: url_helper
INFO - 2025-05-05 06:36:12 --> Database Driver Class Initialized
INFO - 2025-05-05 06:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:36:12 --> Form Validation Class Initialized
INFO - 2025-05-05 06:36:12 --> Controller Class Initialized
INFO - 2025-05-05 06:36:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:36:12 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:36:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:36:12 --> Final output sent to browser
DEBUG - 2025-05-05 06:36:12 --> Total execution time: 0.0253
INFO - 2025-05-05 06:37:59 --> Config Class Initialized
INFO - 2025-05-05 06:37:59 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:37:59 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:37:59 --> Utf8 Class Initialized
INFO - 2025-05-05 06:37:59 --> URI Class Initialized
INFO - 2025-05-05 06:37:59 --> Router Class Initialized
INFO - 2025-05-05 06:37:59 --> Output Class Initialized
INFO - 2025-05-05 06:37:59 --> Security Class Initialized
DEBUG - 2025-05-05 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:37:59 --> Input Class Initialized
INFO - 2025-05-05 06:37:59 --> Language Class Initialized
INFO - 2025-05-05 06:37:59 --> Loader Class Initialized
INFO - 2025-05-05 06:37:59 --> Helper loaded: form_helper
INFO - 2025-05-05 06:37:59 --> Helper loaded: url_helper
INFO - 2025-05-05 06:37:59 --> Database Driver Class Initialized
INFO - 2025-05-05 06:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:37:59 --> Form Validation Class Initialized
INFO - 2025-05-05 06:37:59 --> Controller Class Initialized
INFO - 2025-05-05 06:37:59 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:37:59 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:37:59 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:37:59 --> Final output sent to browser
DEBUG - 2025-05-05 06:37:59 --> Total execution time: 0.0338
INFO - 2025-05-05 06:38:02 --> Config Class Initialized
INFO - 2025-05-05 06:38:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:38:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:38:02 --> Utf8 Class Initialized
INFO - 2025-05-05 06:38:02 --> URI Class Initialized
INFO - 2025-05-05 06:38:02 --> Router Class Initialized
INFO - 2025-05-05 06:38:02 --> Output Class Initialized
INFO - 2025-05-05 06:38:02 --> Security Class Initialized
DEBUG - 2025-05-05 06:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:38:02 --> Input Class Initialized
INFO - 2025-05-05 06:38:02 --> Language Class Initialized
INFO - 2025-05-05 06:38:02 --> Loader Class Initialized
INFO - 2025-05-05 06:38:02 --> Helper loaded: form_helper
INFO - 2025-05-05 06:38:02 --> Helper loaded: url_helper
INFO - 2025-05-05 06:38:02 --> Database Driver Class Initialized
INFO - 2025-05-05 06:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:38:02 --> Form Validation Class Initialized
INFO - 2025-05-05 06:38:02 --> Controller Class Initialized
INFO - 2025-05-05 06:38:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:38:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:38:02 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-05 06:38:02 --> Final output sent to browser
DEBUG - 2025-05-05 06:38:02 --> Total execution time: 0.0307
INFO - 2025-05-05 06:38:19 --> Config Class Initialized
INFO - 2025-05-05 06:38:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:38:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:38:19 --> Utf8 Class Initialized
INFO - 2025-05-05 06:38:19 --> URI Class Initialized
DEBUG - 2025-05-05 06:38:19 --> No URI present. Default controller set.
INFO - 2025-05-05 06:38:19 --> Router Class Initialized
INFO - 2025-05-05 06:38:19 --> Output Class Initialized
INFO - 2025-05-05 06:38:19 --> Security Class Initialized
DEBUG - 2025-05-05 06:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:38:19 --> Input Class Initialized
INFO - 2025-05-05 06:38:19 --> Language Class Initialized
INFO - 2025-05-05 06:38:19 --> Loader Class Initialized
INFO - 2025-05-05 06:38:19 --> Helper loaded: form_helper
INFO - 2025-05-05 06:38:19 --> Helper loaded: url_helper
INFO - 2025-05-05 06:38:19 --> Database Driver Class Initialized
INFO - 2025-05-05 06:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:38:19 --> Form Validation Class Initialized
INFO - 2025-05-05 06:38:19 --> Controller Class Initialized
INFO - 2025-05-05 06:38:19 --> Final output sent to browser
DEBUG - 2025-05-05 06:38:19 --> Total execution time: 0.0233
INFO - 2025-05-05 06:38:22 --> Config Class Initialized
INFO - 2025-05-05 06:38:22 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:38:22 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:38:22 --> Utf8 Class Initialized
INFO - 2025-05-05 06:38:22 --> URI Class Initialized
INFO - 2025-05-05 06:38:22 --> Router Class Initialized
INFO - 2025-05-05 06:38:22 --> Output Class Initialized
INFO - 2025-05-05 06:38:22 --> Security Class Initialized
DEBUG - 2025-05-05 06:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:38:22 --> Input Class Initialized
INFO - 2025-05-05 06:38:22 --> Language Class Initialized
INFO - 2025-05-05 06:38:22 --> Loader Class Initialized
INFO - 2025-05-05 06:38:22 --> Helper loaded: form_helper
INFO - 2025-05-05 06:38:22 --> Helper loaded: url_helper
INFO - 2025-05-05 06:38:22 --> Database Driver Class Initialized
INFO - 2025-05-05 06:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:38:22 --> Form Validation Class Initialized
INFO - 2025-05-05 06:38:22 --> Controller Class Initialized
DEBUG - 2025-05-05 06:38:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-05 06:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-05 06:38:22 --> Model "Ppdb_model" initialized
INFO - 2025-05-05 06:38:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-05 06:38:22 --> Final output sent to browser
DEBUG - 2025-05-05 06:38:22 --> Total execution time: 0.0281
INFO - 2025-05-05 06:38:35 --> Config Class Initialized
INFO - 2025-05-05 06:38:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:38:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:38:35 --> Utf8 Class Initialized
INFO - 2025-05-05 06:38:35 --> URI Class Initialized
INFO - 2025-05-05 06:38:35 --> Router Class Initialized
INFO - 2025-05-05 06:38:35 --> Output Class Initialized
INFO - 2025-05-05 06:38:35 --> Security Class Initialized
DEBUG - 2025-05-05 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:38:35 --> Input Class Initialized
INFO - 2025-05-05 06:38:35 --> Language Class Initialized
INFO - 2025-05-05 06:38:35 --> Loader Class Initialized
INFO - 2025-05-05 06:38:35 --> Helper loaded: form_helper
INFO - 2025-05-05 06:38:35 --> Helper loaded: url_helper
INFO - 2025-05-05 06:38:35 --> Database Driver Class Initialized
INFO - 2025-05-05 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:38:35 --> Form Validation Class Initialized
INFO - 2025-05-05 06:38:35 --> Controller Class Initialized
DEBUG - 2025-05-05 06:38:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-05 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-05 06:38:35 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-05 06:38:35 --> POST data: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [tempat_tanggal_lahir_db] => Demak, 15 Agustus 2008
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [no_hp_siswa] => 081234567890
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [alamat_lengkap_db] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_lahir_db] => 2008-08-15
)

INFO - 2025-05-05 06:38:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-05 06:38:35 --> Generated registration number: A-2526/0161
DEBUG - 2025-05-05 06:38:35 --> Form data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-05 06:38:35
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-05 06:38:35 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-05 06:38:35 --> Database config: 1
DEBUG - 2025-05-05 06:38:35 --> Database hostname: localhost
DEBUG - 2025-05-05 06:38:35 --> Database username: root
DEBUG - 2025-05-05 06:38:35 --> Database database: ppdb_mansaba
DEBUG - 2025-05-05 06:38:35 --> Data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-05 06:38:35
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-05 06:38:35 --> Data inserted successfully with ID: 187
INFO - 2025-05-05 06:38:35 --> Final output sent to browser
DEBUG - 2025-05-05 06:38:35 --> Total execution time: 0.0366
INFO - 2025-05-05 06:38:37 --> Config Class Initialized
INFO - 2025-05-05 06:38:37 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:38:37 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:38:37 --> Utf8 Class Initialized
INFO - 2025-05-05 06:38:37 --> URI Class Initialized
DEBUG - 2025-05-05 06:38:37 --> No URI present. Default controller set.
INFO - 2025-05-05 06:38:37 --> Router Class Initialized
INFO - 2025-05-05 06:38:37 --> Output Class Initialized
INFO - 2025-05-05 06:38:37 --> Security Class Initialized
DEBUG - 2025-05-05 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:38:37 --> Input Class Initialized
INFO - 2025-05-05 06:38:37 --> Language Class Initialized
INFO - 2025-05-05 06:38:37 --> Loader Class Initialized
INFO - 2025-05-05 06:38:37 --> Helper loaded: form_helper
INFO - 2025-05-05 06:38:37 --> Helper loaded: url_helper
INFO - 2025-05-05 06:38:37 --> Database Driver Class Initialized
INFO - 2025-05-05 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:38:37 --> Form Validation Class Initialized
INFO - 2025-05-05 06:38:37 --> Controller Class Initialized
INFO - 2025-05-05 06:38:37 --> Final output sent to browser
DEBUG - 2025-05-05 06:38:37 --> Total execution time: 0.0261
INFO - 2025-05-05 06:40:48 --> Config Class Initialized
INFO - 2025-05-05 06:40:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:40:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:40:48 --> Utf8 Class Initialized
INFO - 2025-05-05 06:40:48 --> URI Class Initialized
INFO - 2025-05-05 06:40:48 --> Router Class Initialized
INFO - 2025-05-05 06:40:48 --> Output Class Initialized
INFO - 2025-05-05 06:40:48 --> Security Class Initialized
DEBUG - 2025-05-05 06:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:40:48 --> Input Class Initialized
INFO - 2025-05-05 06:40:48 --> Language Class Initialized
INFO - 2025-05-05 06:40:48 --> Loader Class Initialized
INFO - 2025-05-05 06:40:48 --> Helper loaded: form_helper
INFO - 2025-05-05 06:40:48 --> Helper loaded: url_helper
INFO - 2025-05-05 06:40:48 --> Database Driver Class Initialized
INFO - 2025-05-05 06:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:40:48 --> Form Validation Class Initialized
INFO - 2025-05-05 06:40:48 --> Controller Class Initialized
DEBUG - 2025-05-05 06:40:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-05 06:40:48 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-05 06:40:48 --> Model "Ppdb_model" initialized
INFO - 2025-05-05 06:40:48 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-05 06:40:48 --> Final output sent to browser
DEBUG - 2025-05-05 06:40:48 --> Total execution time: 0.0277
INFO - 2025-05-05 06:41:11 --> Config Class Initialized
INFO - 2025-05-05 06:41:11 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:11 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:11 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:11 --> URI Class Initialized
INFO - 2025-05-05 06:41:11 --> Router Class Initialized
INFO - 2025-05-05 06:41:11 --> Output Class Initialized
INFO - 2025-05-05 06:41:11 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:11 --> Input Class Initialized
INFO - 2025-05-05 06:41:11 --> Language Class Initialized
INFO - 2025-05-05 06:41:11 --> Loader Class Initialized
INFO - 2025-05-05 06:41:11 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:11 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:11 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:11 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:11 --> Controller Class Initialized
INFO - 2025-05-05 06:41:11 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:11 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:11 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:11 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-05 06:41:11 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:11 --> Total execution time: 0.0271
INFO - 2025-05-05 06:41:13 --> Config Class Initialized
INFO - 2025-05-05 06:41:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:13 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:13 --> URI Class Initialized
INFO - 2025-05-05 06:41:13 --> Router Class Initialized
INFO - 2025-05-05 06:41:13 --> Output Class Initialized
INFO - 2025-05-05 06:41:13 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:13 --> Input Class Initialized
INFO - 2025-05-05 06:41:13 --> Language Class Initialized
INFO - 2025-05-05 06:41:13 --> Loader Class Initialized
INFO - 2025-05-05 06:41:13 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:13 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:13 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:13 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:13 --> Controller Class Initialized
INFO - 2025-05-05 06:41:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-05 06:41:13 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:13 --> Total execution time: 0.0292
INFO - 2025-05-05 06:41:15 --> Config Class Initialized
INFO - 2025-05-05 06:41:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:15 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:15 --> URI Class Initialized
INFO - 2025-05-05 06:41:15 --> Router Class Initialized
INFO - 2025-05-05 06:41:15 --> Output Class Initialized
INFO - 2025-05-05 06:41:15 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:15 --> Input Class Initialized
INFO - 2025-05-05 06:41:15 --> Language Class Initialized
INFO - 2025-05-05 06:41:15 --> Loader Class Initialized
INFO - 2025-05-05 06:41:15 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:15 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:15 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:15 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:15 --> Controller Class Initialized
INFO - 2025-05-05 06:41:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-05 06:41:15 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:15 --> Total execution time: 0.0287
INFO - 2025-05-05 06:41:16 --> Config Class Initialized
INFO - 2025-05-05 06:41:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:16 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:16 --> URI Class Initialized
INFO - 2025-05-05 06:41:16 --> Router Class Initialized
INFO - 2025-05-05 06:41:16 --> Output Class Initialized
INFO - 2025-05-05 06:41:16 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:16 --> Input Class Initialized
INFO - 2025-05-05 06:41:16 --> Language Class Initialized
INFO - 2025-05-05 06:41:16 --> Loader Class Initialized
INFO - 2025-05-05 06:41:16 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:16 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:16 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:16 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:16 --> Controller Class Initialized
INFO - 2025-05-05 06:41:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 06:41:16 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:16 --> Total execution time: 0.0276
INFO - 2025-05-05 06:41:18 --> Config Class Initialized
INFO - 2025-05-05 06:41:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:18 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:18 --> URI Class Initialized
INFO - 2025-05-05 06:41:18 --> Router Class Initialized
INFO - 2025-05-05 06:41:18 --> Output Class Initialized
INFO - 2025-05-05 06:41:18 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:18 --> Input Class Initialized
INFO - 2025-05-05 06:41:18 --> Language Class Initialized
INFO - 2025-05-05 06:41:18 --> Loader Class Initialized
INFO - 2025-05-05 06:41:18 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:18 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:18 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:18 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:18 --> Controller Class Initialized
INFO - 2025-05-05 06:41:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-05 06:41:18 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:18 --> Total execution time: 0.0280
INFO - 2025-05-05 06:41:21 --> Config Class Initialized
INFO - 2025-05-05 06:41:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:21 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:21 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:21 --> URI Class Initialized
INFO - 2025-05-05 06:41:21 --> Router Class Initialized
INFO - 2025-05-05 06:41:21 --> Output Class Initialized
INFO - 2025-05-05 06:41:21 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:21 --> Input Class Initialized
INFO - 2025-05-05 06:41:21 --> Language Class Initialized
INFO - 2025-05-05 06:41:21 --> Loader Class Initialized
INFO - 2025-05-05 06:41:21 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:21 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:21 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:21 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:21 --> Controller Class Initialized
INFO - 2025-05-05 06:41:21 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:21 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 06:41:21 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:21 --> Total execution time: 0.0289
INFO - 2025-05-05 06:41:25 --> Config Class Initialized
INFO - 2025-05-05 06:41:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:25 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:25 --> URI Class Initialized
INFO - 2025-05-05 06:41:25 --> Router Class Initialized
INFO - 2025-05-05 06:41:25 --> Output Class Initialized
INFO - 2025-05-05 06:41:25 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:25 --> Input Class Initialized
INFO - 2025-05-05 06:41:25 --> Language Class Initialized
INFO - 2025-05-05 06:41:25 --> Loader Class Initialized
INFO - 2025-05-05 06:41:25 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:25 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:25 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:25 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:25 --> Controller Class Initialized
INFO - 2025-05-05 06:41:25 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:25 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:25 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:25 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 06:41:25 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:25 --> Total execution time: 0.0310
INFO - 2025-05-05 06:41:26 --> Config Class Initialized
INFO - 2025-05-05 06:41:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:26 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:26 --> URI Class Initialized
INFO - 2025-05-05 06:41:26 --> Router Class Initialized
INFO - 2025-05-05 06:41:26 --> Output Class Initialized
INFO - 2025-05-05 06:41:26 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:26 --> Input Class Initialized
INFO - 2025-05-05 06:41:26 --> Language Class Initialized
INFO - 2025-05-05 06:41:26 --> Loader Class Initialized
INFO - 2025-05-05 06:41:26 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:26 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:26 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:26 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:26 --> Controller Class Initialized
INFO - 2025-05-05 06:41:26 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:26 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:26 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:26 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 06:41:26 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:26 --> Total execution time: 0.0290
INFO - 2025-05-05 06:41:29 --> Config Class Initialized
INFO - 2025-05-05 06:41:29 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:29 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:29 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:29 --> URI Class Initialized
INFO - 2025-05-05 06:41:29 --> Router Class Initialized
INFO - 2025-05-05 06:41:29 --> Output Class Initialized
INFO - 2025-05-05 06:41:29 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:29 --> Input Class Initialized
INFO - 2025-05-05 06:41:29 --> Language Class Initialized
INFO - 2025-05-05 06:41:29 --> Loader Class Initialized
INFO - 2025-05-05 06:41:29 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:29 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:29 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:29 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:29 --> Controller Class Initialized
INFO - 2025-05-05 06:41:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-05 06:41:29 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:29 --> Total execution time: 0.0280
INFO - 2025-05-05 06:41:31 --> Config Class Initialized
INFO - 2025-05-05 06:41:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:31 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:31 --> URI Class Initialized
INFO - 2025-05-05 06:41:31 --> Router Class Initialized
INFO - 2025-05-05 06:41:31 --> Output Class Initialized
INFO - 2025-05-05 06:41:31 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:31 --> Input Class Initialized
INFO - 2025-05-05 06:41:31 --> Language Class Initialized
INFO - 2025-05-05 06:41:31 --> Loader Class Initialized
INFO - 2025-05-05 06:41:31 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:31 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:31 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:31 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:31 --> Controller Class Initialized
INFO - 2025-05-05 06:41:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:31 --> Config Class Initialized
INFO - 2025-05-05 06:41:31 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:31 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:31 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:31 --> URI Class Initialized
INFO - 2025-05-05 06:41:31 --> Router Class Initialized
INFO - 2025-05-05 06:41:31 --> Output Class Initialized
INFO - 2025-05-05 06:41:31 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:31 --> Input Class Initialized
INFO - 2025-05-05 06:41:31 --> Language Class Initialized
INFO - 2025-05-05 06:41:31 --> Loader Class Initialized
INFO - 2025-05-05 06:41:31 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:31 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:31 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:31 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:31 --> Controller Class Initialized
INFO - 2025-05-05 06:41:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 06:41:31 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:31 --> Total execution time: 0.0275
INFO - 2025-05-05 06:41:34 --> Config Class Initialized
INFO - 2025-05-05 06:41:34 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:34 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:34 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:34 --> URI Class Initialized
INFO - 2025-05-05 06:41:34 --> Router Class Initialized
INFO - 2025-05-05 06:41:34 --> Output Class Initialized
INFO - 2025-05-05 06:41:34 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:34 --> Input Class Initialized
INFO - 2025-05-05 06:41:34 --> Language Class Initialized
INFO - 2025-05-05 06:41:34 --> Loader Class Initialized
INFO - 2025-05-05 06:41:34 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:34 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:34 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:34 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:34 --> Controller Class Initialized
INFO - 2025-05-05 06:41:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-05 06:41:34 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:34 --> Total execution time: 0.0279
INFO - 2025-05-05 06:41:37 --> Config Class Initialized
INFO - 2025-05-05 06:41:37 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:37 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:37 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:37 --> URI Class Initialized
INFO - 2025-05-05 06:41:37 --> Router Class Initialized
INFO - 2025-05-05 06:41:37 --> Output Class Initialized
INFO - 2025-05-05 06:41:37 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:37 --> Input Class Initialized
INFO - 2025-05-05 06:41:37 --> Language Class Initialized
INFO - 2025-05-05 06:41:37 --> Loader Class Initialized
INFO - 2025-05-05 06:41:37 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:37 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:37 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:37 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:37 --> Controller Class Initialized
INFO - 2025-05-05 06:41:37 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:37 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:37 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:37 --> Config Class Initialized
INFO - 2025-05-05 06:41:37 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:37 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:37 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:37 --> URI Class Initialized
INFO - 2025-05-05 06:41:37 --> Router Class Initialized
INFO - 2025-05-05 06:41:37 --> Output Class Initialized
INFO - 2025-05-05 06:41:37 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:37 --> Input Class Initialized
INFO - 2025-05-05 06:41:37 --> Language Class Initialized
INFO - 2025-05-05 06:41:37 --> Loader Class Initialized
INFO - 2025-05-05 06:41:37 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:37 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:37 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:37 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:37 --> Controller Class Initialized
INFO - 2025-05-05 06:41:37 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:37 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:37 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:37 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 06:41:37 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:37 --> Total execution time: 0.0273
INFO - 2025-05-05 06:41:38 --> Config Class Initialized
INFO - 2025-05-05 06:41:38 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:41:38 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:41:38 --> Utf8 Class Initialized
INFO - 2025-05-05 06:41:38 --> URI Class Initialized
INFO - 2025-05-05 06:41:38 --> Router Class Initialized
INFO - 2025-05-05 06:41:38 --> Output Class Initialized
INFO - 2025-05-05 06:41:38 --> Security Class Initialized
DEBUG - 2025-05-05 06:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:41:38 --> Input Class Initialized
INFO - 2025-05-05 06:41:38 --> Language Class Initialized
INFO - 2025-05-05 06:41:38 --> Loader Class Initialized
INFO - 2025-05-05 06:41:38 --> Helper loaded: form_helper
INFO - 2025-05-05 06:41:38 --> Helper loaded: url_helper
INFO - 2025-05-05 06:41:38 --> Database Driver Class Initialized
INFO - 2025-05-05 06:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:41:38 --> Form Validation Class Initialized
INFO - 2025-05-05 06:41:38 --> Controller Class Initialized
INFO - 2025-05-05 06:41:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:41:38 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:41:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:41:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 06:41:38 --> Final output sent to browser
DEBUG - 2025-05-05 06:41:38 --> Total execution time: 0.0310
INFO - 2025-05-05 06:43:24 --> Config Class Initialized
INFO - 2025-05-05 06:43:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:43:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:43:24 --> Utf8 Class Initialized
INFO - 2025-05-05 06:43:24 --> URI Class Initialized
INFO - 2025-05-05 06:43:24 --> Router Class Initialized
INFO - 2025-05-05 06:43:24 --> Output Class Initialized
INFO - 2025-05-05 06:43:24 --> Security Class Initialized
DEBUG - 2025-05-05 06:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:43:24 --> Input Class Initialized
INFO - 2025-05-05 06:43:24 --> Language Class Initialized
INFO - 2025-05-05 06:43:24 --> Loader Class Initialized
INFO - 2025-05-05 06:43:24 --> Helper loaded: form_helper
INFO - 2025-05-05 06:43:24 --> Helper loaded: url_helper
INFO - 2025-05-05 06:43:24 --> Database Driver Class Initialized
INFO - 2025-05-05 06:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:43:24 --> Form Validation Class Initialized
INFO - 2025-05-05 06:43:24 --> Controller Class Initialized
INFO - 2025-05-05 06:43:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:43:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:43:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:43:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 06:43:24 --> Final output sent to browser
DEBUG - 2025-05-05 06:43:24 --> Total execution time: 0.0479
INFO - 2025-05-05 06:43:49 --> Config Class Initialized
INFO - 2025-05-05 06:43:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:43:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:43:49 --> Utf8 Class Initialized
INFO - 2025-05-05 06:43:49 --> URI Class Initialized
INFO - 2025-05-05 06:43:49 --> Router Class Initialized
INFO - 2025-05-05 06:43:49 --> Output Class Initialized
INFO - 2025-05-05 06:43:49 --> Security Class Initialized
DEBUG - 2025-05-05 06:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:43:49 --> Input Class Initialized
INFO - 2025-05-05 06:43:49 --> Language Class Initialized
INFO - 2025-05-05 06:43:49 --> Loader Class Initialized
INFO - 2025-05-05 06:43:49 --> Helper loaded: form_helper
INFO - 2025-05-05 06:43:49 --> Helper loaded: url_helper
INFO - 2025-05-05 06:43:49 --> Database Driver Class Initialized
INFO - 2025-05-05 06:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:43:49 --> Form Validation Class Initialized
INFO - 2025-05-05 06:43:49 --> Controller Class Initialized
INFO - 2025-05-05 06:43:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:43:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:43:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:43:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 06:43:49 --> Final output sent to browser
DEBUG - 2025-05-05 06:43:49 --> Total execution time: 0.0412
INFO - 2025-05-05 06:44:03 --> Config Class Initialized
INFO - 2025-05-05 06:44:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:44:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:44:03 --> Utf8 Class Initialized
INFO - 2025-05-05 06:44:03 --> URI Class Initialized
INFO - 2025-05-05 06:44:03 --> Router Class Initialized
INFO - 2025-05-05 06:44:03 --> Output Class Initialized
INFO - 2025-05-05 06:44:03 --> Security Class Initialized
DEBUG - 2025-05-05 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:44:03 --> Input Class Initialized
INFO - 2025-05-05 06:44:03 --> Language Class Initialized
INFO - 2025-05-05 06:44:03 --> Loader Class Initialized
INFO - 2025-05-05 06:44:03 --> Helper loaded: form_helper
INFO - 2025-05-05 06:44:03 --> Helper loaded: url_helper
INFO - 2025-05-05 06:44:03 --> Database Driver Class Initialized
INFO - 2025-05-05 06:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:44:03 --> Form Validation Class Initialized
INFO - 2025-05-05 06:44:03 --> Controller Class Initialized
INFO - 2025-05-05 06:44:03 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:44:03 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:44:03 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-05 06:44:03 --> Final output sent to browser
DEBUG - 2025-05-05 06:44:03 --> Total execution time: 0.0332
INFO - 2025-05-05 06:44:10 --> Config Class Initialized
INFO - 2025-05-05 06:44:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:44:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:44:10 --> Utf8 Class Initialized
INFO - 2025-05-05 06:44:10 --> URI Class Initialized
INFO - 2025-05-05 06:44:10 --> Router Class Initialized
INFO - 2025-05-05 06:44:10 --> Output Class Initialized
INFO - 2025-05-05 06:44:10 --> Security Class Initialized
DEBUG - 2025-05-05 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:44:10 --> Input Class Initialized
INFO - 2025-05-05 06:44:10 --> Language Class Initialized
INFO - 2025-05-05 06:44:10 --> Loader Class Initialized
INFO - 2025-05-05 06:44:10 --> Helper loaded: form_helper
INFO - 2025-05-05 06:44:10 --> Helper loaded: url_helper
INFO - 2025-05-05 06:44:10 --> Database Driver Class Initialized
INFO - 2025-05-05 06:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:44:10 --> Form Validation Class Initialized
INFO - 2025-05-05 06:44:10 --> Controller Class Initialized
INFO - 2025-05-05 06:44:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:44:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:44:10 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:44:10 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 06:44:10 --> Final output sent to browser
DEBUG - 2025-05-05 06:44:10 --> Total execution time: 0.0301
INFO - 2025-05-05 06:44:41 --> Config Class Initialized
INFO - 2025-05-05 06:44:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:44:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:44:41 --> Utf8 Class Initialized
INFO - 2025-05-05 06:44:41 --> URI Class Initialized
INFO - 2025-05-05 06:44:41 --> Router Class Initialized
INFO - 2025-05-05 06:44:41 --> Output Class Initialized
INFO - 2025-05-05 06:44:41 --> Security Class Initialized
DEBUG - 2025-05-05 06:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:44:41 --> Input Class Initialized
INFO - 2025-05-05 06:44:41 --> Language Class Initialized
INFO - 2025-05-05 06:44:41 --> Loader Class Initialized
INFO - 2025-05-05 06:44:41 --> Helper loaded: form_helper
INFO - 2025-05-05 06:44:41 --> Helper loaded: url_helper
INFO - 2025-05-05 06:44:41 --> Database Driver Class Initialized
INFO - 2025-05-05 06:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:44:41 --> Form Validation Class Initialized
INFO - 2025-05-05 06:44:41 --> Controller Class Initialized
INFO - 2025-05-05 06:44:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:44:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:44:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:44:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:44:41 --> Final output sent to browser
DEBUG - 2025-05-05 06:44:41 --> Total execution time: 0.0299
INFO - 2025-05-05 06:45:35 --> Config Class Initialized
INFO - 2025-05-05 06:45:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:45:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:45:35 --> Utf8 Class Initialized
INFO - 2025-05-05 06:45:35 --> URI Class Initialized
INFO - 2025-05-05 06:45:35 --> Router Class Initialized
INFO - 2025-05-05 06:45:35 --> Output Class Initialized
INFO - 2025-05-05 06:45:35 --> Security Class Initialized
DEBUG - 2025-05-05 06:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:45:35 --> Input Class Initialized
INFO - 2025-05-05 06:45:35 --> Language Class Initialized
INFO - 2025-05-05 06:45:35 --> Loader Class Initialized
INFO - 2025-05-05 06:45:35 --> Helper loaded: form_helper
INFO - 2025-05-05 06:45:35 --> Helper loaded: url_helper
INFO - 2025-05-05 06:45:35 --> Database Driver Class Initialized
INFO - 2025-05-05 06:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:45:35 --> Form Validation Class Initialized
INFO - 2025-05-05 06:45:35 --> Controller Class Initialized
INFO - 2025-05-05 06:45:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:45:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:45:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:45:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 06:45:35 --> Final output sent to browser
DEBUG - 2025-05-05 06:45:35 --> Total execution time: 0.0363
INFO - 2025-05-05 06:45:41 --> Config Class Initialized
INFO - 2025-05-05 06:45:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:45:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:45:41 --> Utf8 Class Initialized
INFO - 2025-05-05 06:45:41 --> URI Class Initialized
INFO - 2025-05-05 06:45:41 --> Router Class Initialized
INFO - 2025-05-05 06:45:41 --> Output Class Initialized
INFO - 2025-05-05 06:45:41 --> Security Class Initialized
DEBUG - 2025-05-05 06:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:45:41 --> Input Class Initialized
INFO - 2025-05-05 06:45:41 --> Language Class Initialized
INFO - 2025-05-05 06:45:41 --> Loader Class Initialized
INFO - 2025-05-05 06:45:41 --> Helper loaded: form_helper
INFO - 2025-05-05 06:45:41 --> Helper loaded: url_helper
INFO - 2025-05-05 06:45:41 --> Database Driver Class Initialized
INFO - 2025-05-05 06:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:45:41 --> Form Validation Class Initialized
INFO - 2025-05-05 06:45:41 --> Controller Class Initialized
INFO - 2025-05-05 06:45:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:45:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:45:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:45:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:45:41 --> Final output sent to browser
DEBUG - 2025-05-05 06:45:41 --> Total execution time: 0.0286
INFO - 2025-05-05 06:46:17 --> Config Class Initialized
INFO - 2025-05-05 06:46:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:46:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:46:17 --> Utf8 Class Initialized
INFO - 2025-05-05 06:46:17 --> URI Class Initialized
INFO - 2025-05-05 06:46:17 --> Router Class Initialized
INFO - 2025-05-05 06:46:17 --> Output Class Initialized
INFO - 2025-05-05 06:46:17 --> Security Class Initialized
DEBUG - 2025-05-05 06:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:46:17 --> Input Class Initialized
INFO - 2025-05-05 06:46:17 --> Language Class Initialized
INFO - 2025-05-05 06:46:17 --> Loader Class Initialized
INFO - 2025-05-05 06:46:17 --> Helper loaded: form_helper
INFO - 2025-05-05 06:46:17 --> Helper loaded: url_helper
INFO - 2025-05-05 06:46:17 --> Database Driver Class Initialized
INFO - 2025-05-05 06:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:46:17 --> Form Validation Class Initialized
INFO - 2025-05-05 06:46:17 --> Controller Class Initialized
INFO - 2025-05-05 06:46:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:46:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:46:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:46:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:46:17 --> Final output sent to browser
DEBUG - 2025-05-05 06:46:17 --> Total execution time: 0.0342
INFO - 2025-05-05 06:49:08 --> Config Class Initialized
INFO - 2025-05-05 06:49:08 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:49:08 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:49:08 --> Utf8 Class Initialized
INFO - 2025-05-05 06:49:08 --> URI Class Initialized
INFO - 2025-05-05 06:49:08 --> Router Class Initialized
INFO - 2025-05-05 06:49:08 --> Output Class Initialized
INFO - 2025-05-05 06:49:08 --> Security Class Initialized
DEBUG - 2025-05-05 06:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:49:08 --> Input Class Initialized
INFO - 2025-05-05 06:49:08 --> Language Class Initialized
INFO - 2025-05-05 06:49:08 --> Loader Class Initialized
INFO - 2025-05-05 06:49:08 --> Helper loaded: form_helper
INFO - 2025-05-05 06:49:08 --> Helper loaded: url_helper
INFO - 2025-05-05 06:49:08 --> Database Driver Class Initialized
INFO - 2025-05-05 06:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:49:08 --> Form Validation Class Initialized
INFO - 2025-05-05 06:49:08 --> Controller Class Initialized
INFO - 2025-05-05 06:49:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:49:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:49:08 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:49:08 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:49:08 --> Final output sent to browser
DEBUG - 2025-05-05 06:49:08 --> Total execution time: 0.0346
INFO - 2025-05-05 06:49:39 --> Config Class Initialized
INFO - 2025-05-05 06:49:39 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:49:39 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:49:39 --> Utf8 Class Initialized
INFO - 2025-05-05 06:49:39 --> URI Class Initialized
INFO - 2025-05-05 06:49:39 --> Router Class Initialized
INFO - 2025-05-05 06:49:39 --> Output Class Initialized
INFO - 2025-05-05 06:49:39 --> Security Class Initialized
DEBUG - 2025-05-05 06:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:49:39 --> Input Class Initialized
INFO - 2025-05-05 06:49:39 --> Language Class Initialized
INFO - 2025-05-05 06:49:39 --> Loader Class Initialized
INFO - 2025-05-05 06:49:39 --> Helper loaded: form_helper
INFO - 2025-05-05 06:49:39 --> Helper loaded: url_helper
INFO - 2025-05-05 06:49:39 --> Database Driver Class Initialized
INFO - 2025-05-05 06:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:49:39 --> Form Validation Class Initialized
INFO - 2025-05-05 06:49:39 --> Controller Class Initialized
INFO - 2025-05-05 06:49:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:49:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:49:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:49:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:49:39 --> Final output sent to browser
DEBUG - 2025-05-05 06:49:39 --> Total execution time: 0.0310
INFO - 2025-05-05 06:49:42 --> Config Class Initialized
INFO - 2025-05-05 06:49:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:49:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:49:42 --> Utf8 Class Initialized
INFO - 2025-05-05 06:49:42 --> URI Class Initialized
INFO - 2025-05-05 06:49:42 --> Router Class Initialized
INFO - 2025-05-05 06:49:42 --> Output Class Initialized
INFO - 2025-05-05 06:49:42 --> Security Class Initialized
DEBUG - 2025-05-05 06:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:49:42 --> Input Class Initialized
INFO - 2025-05-05 06:49:42 --> Language Class Initialized
ERROR - 2025-05-05 06:49:42 --> 404 Page Not Found: Admin/exportExcelBelumDaftarUlang
INFO - 2025-05-05 06:50:09 --> Config Class Initialized
INFO - 2025-05-05 06:50:09 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:50:09 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:50:09 --> Utf8 Class Initialized
INFO - 2025-05-05 06:50:09 --> URI Class Initialized
INFO - 2025-05-05 06:50:09 --> Router Class Initialized
INFO - 2025-05-05 06:50:09 --> Output Class Initialized
INFO - 2025-05-05 06:50:09 --> Security Class Initialized
DEBUG - 2025-05-05 06:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:50:09 --> Input Class Initialized
INFO - 2025-05-05 06:50:09 --> Language Class Initialized
INFO - 2025-05-05 06:50:09 --> Loader Class Initialized
INFO - 2025-05-05 06:50:09 --> Helper loaded: form_helper
INFO - 2025-05-05 06:50:09 --> Helper loaded: url_helper
INFO - 2025-05-05 06:50:09 --> Database Driver Class Initialized
INFO - 2025-05-05 06:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:50:09 --> Form Validation Class Initialized
INFO - 2025-05-05 06:50:09 --> Controller Class Initialized
INFO - 2025-05-05 06:50:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:50:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:50:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:50:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 06:50:09 --> Final output sent to browser
DEBUG - 2025-05-05 06:50:09 --> Total execution time: 0.0651
INFO - 2025-05-05 06:50:12 --> Config Class Initialized
INFO - 2025-05-05 06:50:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:50:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:50:12 --> Utf8 Class Initialized
INFO - 2025-05-05 06:50:12 --> URI Class Initialized
INFO - 2025-05-05 06:50:12 --> Router Class Initialized
INFO - 2025-05-05 06:50:12 --> Output Class Initialized
INFO - 2025-05-05 06:50:12 --> Security Class Initialized
DEBUG - 2025-05-05 06:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:50:12 --> Input Class Initialized
INFO - 2025-05-05 06:50:12 --> Language Class Initialized
INFO - 2025-05-05 06:50:12 --> Loader Class Initialized
INFO - 2025-05-05 06:50:12 --> Helper loaded: form_helper
INFO - 2025-05-05 06:50:12 --> Helper loaded: url_helper
INFO - 2025-05-05 06:50:12 --> Database Driver Class Initialized
INFO - 2025-05-05 06:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:50:12 --> Form Validation Class Initialized
INFO - 2025-05-05 06:50:12 --> Controller Class Initialized
INFO - 2025-05-05 06:50:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:50:12 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:50:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:50:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 06:50:12 --> Final output sent to browser
DEBUG - 2025-05-05 06:50:12 --> Total execution time: 0.0425
INFO - 2025-05-05 06:52:34 --> Config Class Initialized
INFO - 2025-05-05 06:52:34 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:52:34 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:52:34 --> Utf8 Class Initialized
INFO - 2025-05-05 06:52:34 --> URI Class Initialized
INFO - 2025-05-05 06:52:34 --> Router Class Initialized
INFO - 2025-05-05 06:52:34 --> Output Class Initialized
INFO - 2025-05-05 06:52:34 --> Security Class Initialized
DEBUG - 2025-05-05 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:52:34 --> Input Class Initialized
INFO - 2025-05-05 06:52:34 --> Language Class Initialized
INFO - 2025-05-05 06:52:34 --> Loader Class Initialized
INFO - 2025-05-05 06:52:34 --> Helper loaded: form_helper
INFO - 2025-05-05 06:52:34 --> Helper loaded: url_helper
INFO - 2025-05-05 06:52:34 --> Database Driver Class Initialized
INFO - 2025-05-05 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:52:34 --> Form Validation Class Initialized
INFO - 2025-05-05 06:52:34 --> Controller Class Initialized
INFO - 2025-05-05 06:52:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:52:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:52:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:52:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 06:52:34 --> Final output sent to browser
DEBUG - 2025-05-05 06:52:34 --> Total execution time: 0.0326
INFO - 2025-05-05 06:52:38 --> Config Class Initialized
INFO - 2025-05-05 06:52:38 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:52:38 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:52:38 --> Utf8 Class Initialized
INFO - 2025-05-05 06:52:38 --> URI Class Initialized
INFO - 2025-05-05 06:52:38 --> Router Class Initialized
INFO - 2025-05-05 06:52:38 --> Output Class Initialized
INFO - 2025-05-05 06:52:38 --> Security Class Initialized
DEBUG - 2025-05-05 06:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:52:38 --> Input Class Initialized
INFO - 2025-05-05 06:52:38 --> Language Class Initialized
INFO - 2025-05-05 06:52:38 --> Loader Class Initialized
INFO - 2025-05-05 06:52:38 --> Helper loaded: form_helper
INFO - 2025-05-05 06:52:38 --> Helper loaded: url_helper
INFO - 2025-05-05 06:52:38 --> Database Driver Class Initialized
INFO - 2025-05-05 06:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:52:38 --> Form Validation Class Initialized
INFO - 2025-05-05 06:52:38 --> Controller Class Initialized
INFO - 2025-05-05 06:52:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:52:38 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:52:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:52:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:52:38 --> Final output sent to browser
DEBUG - 2025-05-05 06:52:38 --> Total execution time: 0.0291
INFO - 2025-05-05 06:52:39 --> Config Class Initialized
INFO - 2025-05-05 06:52:39 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:52:39 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:52:39 --> Utf8 Class Initialized
INFO - 2025-05-05 06:52:39 --> URI Class Initialized
INFO - 2025-05-05 06:52:39 --> Router Class Initialized
INFO - 2025-05-05 06:52:39 --> Output Class Initialized
INFO - 2025-05-05 06:52:39 --> Security Class Initialized
DEBUG - 2025-05-05 06:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:52:39 --> Input Class Initialized
INFO - 2025-05-05 06:52:39 --> Language Class Initialized
ERROR - 2025-05-05 06:52:39 --> 404 Page Not Found: Admin/exportExcelBelumDaftarUlang
INFO - 2025-05-05 06:53:14 --> Config Class Initialized
INFO - 2025-05-05 06:53:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:53:14 --> Utf8 Class Initialized
INFO - 2025-05-05 06:53:14 --> URI Class Initialized
INFO - 2025-05-05 06:53:14 --> Router Class Initialized
INFO - 2025-05-05 06:53:14 --> Output Class Initialized
INFO - 2025-05-05 06:53:14 --> Security Class Initialized
DEBUG - 2025-05-05 06:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:53:14 --> Input Class Initialized
INFO - 2025-05-05 06:53:14 --> Language Class Initialized
INFO - 2025-05-05 06:53:14 --> Loader Class Initialized
INFO - 2025-05-05 06:53:14 --> Helper loaded: form_helper
INFO - 2025-05-05 06:53:14 --> Helper loaded: url_helper
INFO - 2025-05-05 06:53:14 --> Database Driver Class Initialized
INFO - 2025-05-05 06:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:53:15 --> Form Validation Class Initialized
INFO - 2025-05-05 06:53:15 --> Controller Class Initialized
INFO - 2025-05-05 06:53:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:53:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:53:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:53:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:53:15 --> Final output sent to browser
DEBUG - 2025-05-05 06:53:15 --> Total execution time: 0.0323
INFO - 2025-05-05 06:53:16 --> Config Class Initialized
INFO - 2025-05-05 06:53:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:53:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:53:16 --> Utf8 Class Initialized
INFO - 2025-05-05 06:53:16 --> URI Class Initialized
INFO - 2025-05-05 06:53:16 --> Router Class Initialized
INFO - 2025-05-05 06:53:16 --> Output Class Initialized
INFO - 2025-05-05 06:53:16 --> Security Class Initialized
DEBUG - 2025-05-05 06:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:53:16 --> Input Class Initialized
INFO - 2025-05-05 06:53:16 --> Language Class Initialized
INFO - 2025-05-05 06:53:16 --> Loader Class Initialized
INFO - 2025-05-05 06:53:16 --> Helper loaded: form_helper
INFO - 2025-05-05 06:53:16 --> Helper loaded: url_helper
INFO - 2025-05-05 06:53:16 --> Database Driver Class Initialized
INFO - 2025-05-05 06:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:53:16 --> Form Validation Class Initialized
INFO - 2025-05-05 06:53:16 --> Controller Class Initialized
INFO - 2025-05-05 06:53:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:53:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:53:24 --> Config Class Initialized
INFO - 2025-05-05 06:53:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:53:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:53:24 --> Utf8 Class Initialized
INFO - 2025-05-05 06:53:24 --> URI Class Initialized
INFO - 2025-05-05 06:53:24 --> Router Class Initialized
INFO - 2025-05-05 06:53:24 --> Output Class Initialized
INFO - 2025-05-05 06:53:24 --> Security Class Initialized
DEBUG - 2025-05-05 06:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:53:24 --> Input Class Initialized
INFO - 2025-05-05 06:53:24 --> Language Class Initialized
INFO - 2025-05-05 06:53:24 --> Loader Class Initialized
INFO - 2025-05-05 06:53:24 --> Helper loaded: form_helper
INFO - 2025-05-05 06:53:24 --> Helper loaded: url_helper
INFO - 2025-05-05 06:53:24 --> Database Driver Class Initialized
INFO - 2025-05-05 06:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:53:24 --> Form Validation Class Initialized
INFO - 2025-05-05 06:53:24 --> Controller Class Initialized
INFO - 2025-05-05 06:53:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:53:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:53:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:53:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 06:53:24 --> Final output sent to browser
DEBUG - 2025-05-05 06:53:24 --> Total execution time: 0.0467
INFO - 2025-05-05 06:56:28 --> Config Class Initialized
INFO - 2025-05-05 06:56:28 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:56:28 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:56:28 --> Utf8 Class Initialized
INFO - 2025-05-05 06:56:28 --> URI Class Initialized
INFO - 2025-05-05 06:56:28 --> Router Class Initialized
INFO - 2025-05-05 06:56:28 --> Output Class Initialized
INFO - 2025-05-05 06:56:28 --> Security Class Initialized
DEBUG - 2025-05-05 06:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:56:28 --> Input Class Initialized
INFO - 2025-05-05 06:56:28 --> Language Class Initialized
INFO - 2025-05-05 06:56:28 --> Loader Class Initialized
INFO - 2025-05-05 06:56:28 --> Helper loaded: form_helper
INFO - 2025-05-05 06:56:28 --> Helper loaded: url_helper
INFO - 2025-05-05 06:56:28 --> Database Driver Class Initialized
INFO - 2025-05-05 06:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:56:28 --> Form Validation Class Initialized
INFO - 2025-05-05 06:56:28 --> Controller Class Initialized
INFO - 2025-05-05 06:56:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:56:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:56:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:56:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:56:28 --> Final output sent to browser
DEBUG - 2025-05-05 06:56:28 --> Total execution time: 0.0310
INFO - 2025-05-05 06:56:35 --> Config Class Initialized
INFO - 2025-05-05 06:56:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:56:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:56:35 --> Utf8 Class Initialized
INFO - 2025-05-05 06:56:35 --> URI Class Initialized
INFO - 2025-05-05 06:56:35 --> Router Class Initialized
INFO - 2025-05-05 06:56:35 --> Output Class Initialized
INFO - 2025-05-05 06:56:35 --> Security Class Initialized
DEBUG - 2025-05-05 06:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:56:35 --> Input Class Initialized
INFO - 2025-05-05 06:56:35 --> Language Class Initialized
INFO - 2025-05-05 06:56:35 --> Loader Class Initialized
INFO - 2025-05-05 06:56:35 --> Helper loaded: form_helper
INFO - 2025-05-05 06:56:35 --> Helper loaded: url_helper
INFO - 2025-05-05 06:56:35 --> Database Driver Class Initialized
INFO - 2025-05-05 06:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:56:35 --> Form Validation Class Initialized
INFO - 2025-05-05 06:56:35 --> Controller Class Initialized
INFO - 2025-05-05 06:56:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:56:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:56:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:56:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 06:56:35 --> Final output sent to browser
DEBUG - 2025-05-05 06:56:35 --> Total execution time: 0.0276
INFO - 2025-05-05 06:56:52 --> Config Class Initialized
INFO - 2025-05-05 06:56:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:56:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:56:52 --> Utf8 Class Initialized
INFO - 2025-05-05 06:56:52 --> URI Class Initialized
INFO - 2025-05-05 06:56:52 --> Router Class Initialized
INFO - 2025-05-05 06:56:52 --> Output Class Initialized
INFO - 2025-05-05 06:56:52 --> Security Class Initialized
DEBUG - 2025-05-05 06:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:56:52 --> Input Class Initialized
INFO - 2025-05-05 06:56:52 --> Language Class Initialized
INFO - 2025-05-05 06:56:52 --> Loader Class Initialized
INFO - 2025-05-05 06:56:52 --> Helper loaded: form_helper
INFO - 2025-05-05 06:56:52 --> Helper loaded: url_helper
INFO - 2025-05-05 06:56:52 --> Database Driver Class Initialized
INFO - 2025-05-05 06:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:56:52 --> Form Validation Class Initialized
INFO - 2025-05-05 06:56:52 --> Controller Class Initialized
INFO - 2025-05-05 06:56:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:56:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:56:52 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:56:52 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-05 06:56:52 --> Final output sent to browser
DEBUG - 2025-05-05 06:56:52 --> Total execution time: 0.0525
INFO - 2025-05-05 06:56:55 --> Config Class Initialized
INFO - 2025-05-05 06:56:55 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:56:55 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:56:55 --> Utf8 Class Initialized
INFO - 2025-05-05 06:56:55 --> URI Class Initialized
INFO - 2025-05-05 06:56:55 --> Router Class Initialized
INFO - 2025-05-05 06:56:55 --> Output Class Initialized
INFO - 2025-05-05 06:56:55 --> Security Class Initialized
DEBUG - 2025-05-05 06:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:56:55 --> Input Class Initialized
INFO - 2025-05-05 06:56:55 --> Language Class Initialized
INFO - 2025-05-05 06:56:55 --> Loader Class Initialized
INFO - 2025-05-05 06:56:55 --> Helper loaded: form_helper
INFO - 2025-05-05 06:56:55 --> Helper loaded: url_helper
INFO - 2025-05-05 06:56:55 --> Database Driver Class Initialized
INFO - 2025-05-05 06:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:56:55 --> Form Validation Class Initialized
INFO - 2025-05-05 06:56:55 --> Controller Class Initialized
INFO - 2025-05-05 06:56:55 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:56:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:56:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:56:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:56:55 --> Final output sent to browser
DEBUG - 2025-05-05 06:56:55 --> Total execution time: 0.0290
INFO - 2025-05-05 06:56:57 --> Config Class Initialized
INFO - 2025-05-05 06:56:57 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:56:57 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:56:57 --> Utf8 Class Initialized
INFO - 2025-05-05 06:56:57 --> URI Class Initialized
INFO - 2025-05-05 06:56:57 --> Router Class Initialized
INFO - 2025-05-05 06:56:57 --> Output Class Initialized
INFO - 2025-05-05 06:56:57 --> Security Class Initialized
DEBUG - 2025-05-05 06:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:56:57 --> Input Class Initialized
INFO - 2025-05-05 06:56:57 --> Language Class Initialized
INFO - 2025-05-05 06:56:57 --> Loader Class Initialized
INFO - 2025-05-05 06:56:57 --> Helper loaded: form_helper
INFO - 2025-05-05 06:56:57 --> Helper loaded: url_helper
INFO - 2025-05-05 06:56:57 --> Database Driver Class Initialized
INFO - 2025-05-05 06:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:56:57 --> Form Validation Class Initialized
INFO - 2025-05-05 06:56:57 --> Controller Class Initialized
INFO - 2025-05-05 06:56:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:56:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:56:57 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:56:57 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:56:57 --> Final output sent to browser
DEBUG - 2025-05-05 06:56:57 --> Total execution time: 0.0276
INFO - 2025-05-05 06:59:44 --> Config Class Initialized
INFO - 2025-05-05 06:59:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:44 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:44 --> URI Class Initialized
INFO - 2025-05-05 06:59:44 --> Router Class Initialized
INFO - 2025-05-05 06:59:44 --> Output Class Initialized
INFO - 2025-05-05 06:59:44 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:44 --> Input Class Initialized
INFO - 2025-05-05 06:59:44 --> Language Class Initialized
INFO - 2025-05-05 06:59:44 --> Loader Class Initialized
INFO - 2025-05-05 06:59:44 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:44 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:44 --> Database Driver Class Initialized
INFO - 2025-05-05 06:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:44 --> Form Validation Class Initialized
INFO - 2025-05-05 06:59:44 --> Controller Class Initialized
INFO - 2025-05-05 06:59:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:59:44 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:59:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:59:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:59:44 --> Final output sent to browser
DEBUG - 2025-05-05 06:59:44 --> Total execution time: 0.0319
INFO - 2025-05-05 06:59:52 --> Config Class Initialized
INFO - 2025-05-05 06:59:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:52 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:52 --> URI Class Initialized
INFO - 2025-05-05 06:59:52 --> Router Class Initialized
INFO - 2025-05-05 06:59:52 --> Output Class Initialized
INFO - 2025-05-05 06:59:52 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:52 --> Input Class Initialized
INFO - 2025-05-05 06:59:52 --> Language Class Initialized
INFO - 2025-05-05 06:59:52 --> Loader Class Initialized
INFO - 2025-05-05 06:59:52 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:52 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:52 --> Database Driver Class Initialized
INFO - 2025-05-05 06:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:52 --> Form Validation Class Initialized
INFO - 2025-05-05 06:59:52 --> Controller Class Initialized
INFO - 2025-05-05 06:59:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:59:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:59:52 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:59:52 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:59:52 --> Final output sent to browser
DEBUG - 2025-05-05 06:59:52 --> Total execution time: 0.0348
INFO - 2025-05-05 06:59:52 --> Config Class Initialized
INFO - 2025-05-05 06:59:52 --> Hooks Class Initialized
DEBUG - 2025-05-05 06:59:52 --> UTF-8 Support Enabled
INFO - 2025-05-05 06:59:52 --> Utf8 Class Initialized
INFO - 2025-05-05 06:59:52 --> URI Class Initialized
INFO - 2025-05-05 06:59:52 --> Router Class Initialized
INFO - 2025-05-05 06:59:52 --> Output Class Initialized
INFO - 2025-05-05 06:59:52 --> Security Class Initialized
DEBUG - 2025-05-05 06:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 06:59:52 --> Input Class Initialized
INFO - 2025-05-05 06:59:52 --> Language Class Initialized
INFO - 2025-05-05 06:59:52 --> Loader Class Initialized
INFO - 2025-05-05 06:59:52 --> Helper loaded: form_helper
INFO - 2025-05-05 06:59:52 --> Helper loaded: url_helper
INFO - 2025-05-05 06:59:52 --> Database Driver Class Initialized
INFO - 2025-05-05 06:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 06:59:52 --> Form Validation Class Initialized
INFO - 2025-05-05 06:59:52 --> Controller Class Initialized
INFO - 2025-05-05 06:59:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 06:59:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 06:59:52 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 06:59:52 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 06:59:52 --> Final output sent to browser
DEBUG - 2025-05-05 06:59:52 --> Total execution time: 0.0278
INFO - 2025-05-05 07:00:12 --> Config Class Initialized
INFO - 2025-05-05 07:00:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:00:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:00:12 --> Utf8 Class Initialized
INFO - 2025-05-05 07:00:12 --> URI Class Initialized
INFO - 2025-05-05 07:00:12 --> Router Class Initialized
INFO - 2025-05-05 07:00:12 --> Output Class Initialized
INFO - 2025-05-05 07:00:12 --> Security Class Initialized
DEBUG - 2025-05-05 07:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:00:12 --> Input Class Initialized
INFO - 2025-05-05 07:00:12 --> Language Class Initialized
INFO - 2025-05-05 07:00:12 --> Loader Class Initialized
INFO - 2025-05-05 07:00:12 --> Helper loaded: form_helper
INFO - 2025-05-05 07:00:12 --> Helper loaded: url_helper
INFO - 2025-05-05 07:00:12 --> Database Driver Class Initialized
INFO - 2025-05-05 07:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:00:12 --> Form Validation Class Initialized
INFO - 2025-05-05 07:00:12 --> Controller Class Initialized
INFO - 2025-05-05 07:00:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:00:12 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:00:12 --> Query error: Unknown column 'nama_sekolah' in 'field list' - Invalid query: SELECT `nama_sekolah`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `nama_sekolah`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:00:12 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:00:19 --> Config Class Initialized
INFO - 2025-05-05 07:00:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:00:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:00:19 --> Utf8 Class Initialized
INFO - 2025-05-05 07:00:19 --> URI Class Initialized
INFO - 2025-05-05 07:00:19 --> Router Class Initialized
INFO - 2025-05-05 07:00:19 --> Output Class Initialized
INFO - 2025-05-05 07:00:19 --> Security Class Initialized
DEBUG - 2025-05-05 07:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:00:19 --> Input Class Initialized
INFO - 2025-05-05 07:00:19 --> Language Class Initialized
INFO - 2025-05-05 07:00:19 --> Loader Class Initialized
INFO - 2025-05-05 07:00:19 --> Helper loaded: form_helper
INFO - 2025-05-05 07:00:19 --> Helper loaded: url_helper
INFO - 2025-05-05 07:00:19 --> Database Driver Class Initialized
INFO - 2025-05-05 07:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:00:19 --> Form Validation Class Initialized
INFO - 2025-05-05 07:00:19 --> Controller Class Initialized
INFO - 2025-05-05 07:00:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:00:19 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:00:19 --> Query error: Unknown column 'nama_sekolah' in 'field list' - Invalid query: SELECT `nama_sekolah`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `nama_sekolah`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:00:19 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:00:21 --> Config Class Initialized
INFO - 2025-05-05 07:00:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:00:21 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:00:21 --> Utf8 Class Initialized
INFO - 2025-05-05 07:00:21 --> URI Class Initialized
INFO - 2025-05-05 07:00:21 --> Router Class Initialized
INFO - 2025-05-05 07:00:21 --> Output Class Initialized
INFO - 2025-05-05 07:00:21 --> Security Class Initialized
DEBUG - 2025-05-05 07:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:00:21 --> Input Class Initialized
INFO - 2025-05-05 07:00:21 --> Language Class Initialized
INFO - 2025-05-05 07:00:21 --> Loader Class Initialized
INFO - 2025-05-05 07:00:21 --> Helper loaded: form_helper
INFO - 2025-05-05 07:00:21 --> Helper loaded: url_helper
INFO - 2025-05-05 07:00:21 --> Database Driver Class Initialized
INFO - 2025-05-05 07:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:00:21 --> Form Validation Class Initialized
INFO - 2025-05-05 07:00:21 --> Controller Class Initialized
INFO - 2025-05-05 07:00:21 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:00:21 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:00:21 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:00:21 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:12 --> Config Class Initialized
INFO - 2025-05-05 07:01:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:12 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:12 --> URI Class Initialized
INFO - 2025-05-05 07:01:12 --> Router Class Initialized
INFO - 2025-05-05 07:01:12 --> Output Class Initialized
INFO - 2025-05-05 07:01:12 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:12 --> Input Class Initialized
INFO - 2025-05-05 07:01:12 --> Language Class Initialized
INFO - 2025-05-05 07:01:12 --> Loader Class Initialized
INFO - 2025-05-05 07:01:12 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:12 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:12 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:12 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:12 --> Controller Class Initialized
INFO - 2025-05-05 07:01:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:12 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:12 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:12 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:14 --> Config Class Initialized
INFO - 2025-05-05 07:01:14 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:14 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:14 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:14 --> URI Class Initialized
INFO - 2025-05-05 07:01:14 --> Router Class Initialized
INFO - 2025-05-05 07:01:14 --> Output Class Initialized
INFO - 2025-05-05 07:01:14 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:14 --> Input Class Initialized
INFO - 2025-05-05 07:01:14 --> Language Class Initialized
INFO - 2025-05-05 07:01:14 --> Loader Class Initialized
INFO - 2025-05-05 07:01:14 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:14 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:14 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:14 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:14 --> Controller Class Initialized
INFO - 2025-05-05 07:01:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:14 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:14 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:14 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:15 --> Config Class Initialized
INFO - 2025-05-05 07:01:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:15 --> URI Class Initialized
INFO - 2025-05-05 07:01:15 --> Router Class Initialized
INFO - 2025-05-05 07:01:15 --> Output Class Initialized
INFO - 2025-05-05 07:01:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:15 --> Input Class Initialized
INFO - 2025-05-05 07:01:15 --> Language Class Initialized
INFO - 2025-05-05 07:01:15 --> Loader Class Initialized
INFO - 2025-05-05 07:01:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:15 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:15 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:15 --> Controller Class Initialized
INFO - 2025-05-05 07:01:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:15 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:15 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:15 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:15 --> Config Class Initialized
INFO - 2025-05-05 07:01:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:15 --> URI Class Initialized
INFO - 2025-05-05 07:01:15 --> Router Class Initialized
INFO - 2025-05-05 07:01:15 --> Output Class Initialized
INFO - 2025-05-05 07:01:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:15 --> Input Class Initialized
INFO - 2025-05-05 07:01:15 --> Language Class Initialized
INFO - 2025-05-05 07:01:15 --> Loader Class Initialized
INFO - 2025-05-05 07:01:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:15 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:15 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:15 --> Controller Class Initialized
INFO - 2025-05-05 07:01:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:15 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:15 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:15 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:15 --> Config Class Initialized
INFO - 2025-05-05 07:01:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:15 --> URI Class Initialized
INFO - 2025-05-05 07:01:15 --> Router Class Initialized
INFO - 2025-05-05 07:01:15 --> Output Class Initialized
INFO - 2025-05-05 07:01:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:15 --> Input Class Initialized
INFO - 2025-05-05 07:01:15 --> Language Class Initialized
INFO - 2025-05-05 07:01:15 --> Loader Class Initialized
INFO - 2025-05-05 07:01:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:15 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:15 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:15 --> Controller Class Initialized
INFO - 2025-05-05 07:01:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:15 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:15 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:15 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:15 --> Config Class Initialized
INFO - 2025-05-05 07:01:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:15 --> URI Class Initialized
INFO - 2025-05-05 07:01:15 --> Router Class Initialized
INFO - 2025-05-05 07:01:15 --> Output Class Initialized
INFO - 2025-05-05 07:01:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:15 --> Input Class Initialized
INFO - 2025-05-05 07:01:15 --> Language Class Initialized
INFO - 2025-05-05 07:01:15 --> Loader Class Initialized
INFO - 2025-05-05 07:01:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:15 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:15 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:15 --> Controller Class Initialized
INFO - 2025-05-05 07:01:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:15 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:15 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:15 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:15 --> Config Class Initialized
INFO - 2025-05-05 07:01:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:15 --> URI Class Initialized
INFO - 2025-05-05 07:01:15 --> Router Class Initialized
INFO - 2025-05-05 07:01:15 --> Output Class Initialized
INFO - 2025-05-05 07:01:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:15 --> Input Class Initialized
INFO - 2025-05-05 07:01:15 --> Language Class Initialized
INFO - 2025-05-05 07:01:15 --> Loader Class Initialized
INFO - 2025-05-05 07:01:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:15 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:15 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:15 --> Controller Class Initialized
INFO - 2025-05-05 07:01:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:15 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:15 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:15 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:16 --> Config Class Initialized
INFO - 2025-05-05 07:01:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:16 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:16 --> URI Class Initialized
INFO - 2025-05-05 07:01:16 --> Router Class Initialized
INFO - 2025-05-05 07:01:16 --> Output Class Initialized
INFO - 2025-05-05 07:01:16 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:16 --> Input Class Initialized
INFO - 2025-05-05 07:01:16 --> Language Class Initialized
INFO - 2025-05-05 07:01:16 --> Loader Class Initialized
INFO - 2025-05-05 07:01:16 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:16 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:16 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:16 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:16 --> Controller Class Initialized
INFO - 2025-05-05 07:01:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:16 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:16 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:16 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:36 --> Config Class Initialized
INFO - 2025-05-05 07:01:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:36 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:36 --> URI Class Initialized
INFO - 2025-05-05 07:01:36 --> Router Class Initialized
INFO - 2025-05-05 07:01:36 --> Output Class Initialized
INFO - 2025-05-05 07:01:36 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:36 --> Input Class Initialized
INFO - 2025-05-05 07:01:36 --> Language Class Initialized
INFO - 2025-05-05 07:01:36 --> Loader Class Initialized
INFO - 2025-05-05 07:01:36 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:36 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:36 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:36 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:36 --> Controller Class Initialized
INFO - 2025-05-05 07:01:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:36 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:36 --> Query error: Unknown column 'nama_sekolah' in 'field list' - Invalid query: SELECT `nama_sekolah`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `nama_sekolah`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:36 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:01:58 --> Config Class Initialized
INFO - 2025-05-05 07:01:58 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:01:58 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:01:58 --> Utf8 Class Initialized
INFO - 2025-05-05 07:01:58 --> URI Class Initialized
INFO - 2025-05-05 07:01:58 --> Router Class Initialized
INFO - 2025-05-05 07:01:58 --> Output Class Initialized
INFO - 2025-05-05 07:01:58 --> Security Class Initialized
DEBUG - 2025-05-05 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:01:58 --> Input Class Initialized
INFO - 2025-05-05 07:01:58 --> Language Class Initialized
INFO - 2025-05-05 07:01:58 --> Loader Class Initialized
INFO - 2025-05-05 07:01:58 --> Helper loaded: form_helper
INFO - 2025-05-05 07:01:58 --> Helper loaded: url_helper
INFO - 2025-05-05 07:01:58 --> Database Driver Class Initialized
INFO - 2025-05-05 07:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:01:58 --> Form Validation Class Initialized
INFO - 2025-05-05 07:01:58 --> Controller Class Initialized
INFO - 2025-05-05 07:01:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:01:59 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:01:59 --> Query error: Unknown column 'nama_sekolah' in 'field list' - Invalid query: SELECT `nama_sekolah`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `nama_sekolah`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:01:59 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:02:17 --> Config Class Initialized
INFO - 2025-05-05 07:02:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:17 --> URI Class Initialized
INFO - 2025-05-05 07:02:17 --> Router Class Initialized
INFO - 2025-05-05 07:02:17 --> Output Class Initialized
INFO - 2025-05-05 07:02:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:17 --> Input Class Initialized
INFO - 2025-05-05 07:02:17 --> Language Class Initialized
INFO - 2025-05-05 07:02:17 --> Loader Class Initialized
INFO - 2025-05-05 07:02:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:17 --> Database Driver Class Initialized
INFO - 2025-05-05 07:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:17 --> Form Validation Class Initialized
INFO - 2025-05-05 07:02:17 --> Controller Class Initialized
INFO - 2025-05-05 07:02:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:02:17 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:02:17 --> Query error: Unknown column 'nama_sekolah' in 'field list' - Invalid query: SELECT `nama_sekolah`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `nama_sekolah`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:02:17 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:02:19 --> Config Class Initialized
INFO - 2025-05-05 07:02:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:19 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:19 --> URI Class Initialized
INFO - 2025-05-05 07:02:19 --> Router Class Initialized
INFO - 2025-05-05 07:02:19 --> Output Class Initialized
INFO - 2025-05-05 07:02:19 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:19 --> Input Class Initialized
INFO - 2025-05-05 07:02:19 --> Language Class Initialized
INFO - 2025-05-05 07:02:19 --> Loader Class Initialized
INFO - 2025-05-05 07:02:19 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:19 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:19 --> Database Driver Class Initialized
INFO - 2025-05-05 07:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:19 --> Form Validation Class Initialized
INFO - 2025-05-05 07:02:19 --> Controller Class Initialized
INFO - 2025-05-05 07:02:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:02:19 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:02:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:02:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-05 07:02:19 --> Final output sent to browser
DEBUG - 2025-05-05 07:02:19 --> Total execution time: 0.0301
INFO - 2025-05-05 07:02:20 --> Config Class Initialized
INFO - 2025-05-05 07:02:20 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:20 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:20 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:20 --> URI Class Initialized
INFO - 2025-05-05 07:02:20 --> Router Class Initialized
INFO - 2025-05-05 07:02:20 --> Output Class Initialized
INFO - 2025-05-05 07:02:20 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:20 --> Input Class Initialized
INFO - 2025-05-05 07:02:20 --> Language Class Initialized
INFO - 2025-05-05 07:02:20 --> Loader Class Initialized
INFO - 2025-05-05 07:02:20 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:20 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:20 --> Database Driver Class Initialized
INFO - 2025-05-05 07:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:20 --> Form Validation Class Initialized
INFO - 2025-05-05 07:02:20 --> Controller Class Initialized
INFO - 2025-05-05 07:02:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:02:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:02:20 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:02:20 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-05 07:02:20 --> Final output sent to browser
DEBUG - 2025-05-05 07:02:20 --> Total execution time: 0.0301
INFO - 2025-05-05 07:02:21 --> Config Class Initialized
INFO - 2025-05-05 07:02:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:21 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:21 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:21 --> URI Class Initialized
INFO - 2025-05-05 07:02:21 --> Router Class Initialized
INFO - 2025-05-05 07:02:21 --> Output Class Initialized
INFO - 2025-05-05 07:02:21 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:21 --> Input Class Initialized
INFO - 2025-05-05 07:02:21 --> Language Class Initialized
INFO - 2025-05-05 07:02:21 --> Loader Class Initialized
INFO - 2025-05-05 07:02:21 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:21 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:21 --> Database Driver Class Initialized
INFO - 2025-05-05 07:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:21 --> Form Validation Class Initialized
INFO - 2025-05-05 07:02:21 --> Controller Class Initialized
INFO - 2025-05-05 07:02:21 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:02:21 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:02:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:02:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-05 07:02:21 --> Final output sent to browser
DEBUG - 2025-05-05 07:02:21 --> Total execution time: 0.0297
INFO - 2025-05-05 07:02:23 --> Config Class Initialized
INFO - 2025-05-05 07:02:23 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:23 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:23 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:23 --> URI Class Initialized
INFO - 2025-05-05 07:02:23 --> Router Class Initialized
INFO - 2025-05-05 07:02:23 --> Output Class Initialized
INFO - 2025-05-05 07:02:23 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:23 --> Input Class Initialized
INFO - 2025-05-05 07:02:23 --> Language Class Initialized
INFO - 2025-05-05 07:02:23 --> Loader Class Initialized
INFO - 2025-05-05 07:02:23 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:23 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:23 --> Database Driver Class Initialized
INFO - 2025-05-05 07:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:23 --> Form Validation Class Initialized
INFO - 2025-05-05 07:02:23 --> Controller Class Initialized
INFO - 2025-05-05 07:02:23 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:02:23 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:02:23 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:02:23 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 07:02:23 --> Final output sent to browser
DEBUG - 2025-05-05 07:02:23 --> Total execution time: 0.0308
INFO - 2025-05-05 07:02:25 --> Config Class Initialized
INFO - 2025-05-05 07:02:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:25 --> URI Class Initialized
INFO - 2025-05-05 07:02:25 --> Router Class Initialized
INFO - 2025-05-05 07:02:25 --> Output Class Initialized
INFO - 2025-05-05 07:02:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:25 --> Input Class Initialized
INFO - 2025-05-05 07:02:25 --> Language Class Initialized
INFO - 2025-05-05 07:02:25 --> Loader Class Initialized
INFO - 2025-05-05 07:02:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:25 --> Database Driver Class Initialized
INFO - 2025-05-05 07:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:25 --> Form Validation Class Initialized
INFO - 2025-05-05 07:02:25 --> Controller Class Initialized
INFO - 2025-05-05 07:02:25 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:02:25 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:02:25 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:02:25 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 07:02:25 --> Final output sent to browser
DEBUG - 2025-05-05 07:02:25 --> Total execution time: 0.0359
INFO - 2025-05-05 07:02:27 --> Config Class Initialized
INFO - 2025-05-05 07:02:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:27 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:27 --> URI Class Initialized
INFO - 2025-05-05 07:02:27 --> Router Class Initialized
INFO - 2025-05-05 07:02:27 --> Output Class Initialized
INFO - 2025-05-05 07:02:27 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:27 --> Input Class Initialized
INFO - 2025-05-05 07:02:27 --> Language Class Initialized
INFO - 2025-05-05 07:02:27 --> Loader Class Initialized
INFO - 2025-05-05 07:02:27 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:27 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:27 --> Database Driver Class Initialized
INFO - 2025-05-05 07:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:27 --> Form Validation Class Initialized
INFO - 2025-05-05 07:02:27 --> Controller Class Initialized
INFO - 2025-05-05 07:02:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:02:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:02:27 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:02:27 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 07:02:27 --> Final output sent to browser
DEBUG - 2025-05-05 07:02:27 --> Total execution time: 0.0382
INFO - 2025-05-05 07:02:35 --> Config Class Initialized
INFO - 2025-05-05 07:02:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:35 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:35 --> URI Class Initialized
INFO - 2025-05-05 07:02:35 --> Router Class Initialized
INFO - 2025-05-05 07:02:35 --> Output Class Initialized
INFO - 2025-05-05 07:02:35 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:35 --> Input Class Initialized
INFO - 2025-05-05 07:02:35 --> Language Class Initialized
INFO - 2025-05-05 07:02:35 --> Loader Class Initialized
INFO - 2025-05-05 07:02:35 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:35 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:35 --> Database Driver Class Initialized
INFO - 2025-05-05 07:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:35 --> Form Validation Class Initialized
INFO - 2025-05-05 07:02:35 --> Controller Class Initialized
INFO - 2025-05-05 07:02:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:02:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:02:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:02:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 07:02:35 --> Final output sent to browser
DEBUG - 2025-05-05 07:02:35 --> Total execution time: 0.0291
INFO - 2025-05-05 07:02:53 --> Config Class Initialized
INFO - 2025-05-05 07:02:53 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:02:53 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:02:53 --> Utf8 Class Initialized
INFO - 2025-05-05 07:02:53 --> URI Class Initialized
INFO - 2025-05-05 07:02:53 --> Router Class Initialized
INFO - 2025-05-05 07:02:53 --> Output Class Initialized
INFO - 2025-05-05 07:02:53 --> Security Class Initialized
DEBUG - 2025-05-05 07:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:02:53 --> Input Class Initialized
INFO - 2025-05-05 07:02:53 --> Language Class Initialized
INFO - 2025-05-05 07:02:53 --> Loader Class Initialized
INFO - 2025-05-05 07:02:53 --> Helper loaded: form_helper
INFO - 2025-05-05 07:02:53 --> Helper loaded: url_helper
INFO - 2025-05-05 07:02:53 --> Database Driver Class Initialized
INFO - 2025-05-05 07:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:02:53 --> Form Validation Class Initialized
INFO - 2025-05-05 07:02:53 --> Controller Class Initialized
INFO - 2025-05-05 07:02:53 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:02:53 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:02:53 --> Query error: Unknown column 'nama_sekolah' in 'field list' - Invalid query: SELECT `nama_sekolah`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `nama_sekolah`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:02:53 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:03:25 --> Config Class Initialized
INFO - 2025-05-05 07:03:25 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:25 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:25 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:25 --> URI Class Initialized
INFO - 2025-05-05 07:03:25 --> Router Class Initialized
INFO - 2025-05-05 07:03:25 --> Output Class Initialized
INFO - 2025-05-05 07:03:25 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:25 --> Input Class Initialized
INFO - 2025-05-05 07:03:25 --> Language Class Initialized
INFO - 2025-05-05 07:03:25 --> Loader Class Initialized
INFO - 2025-05-05 07:03:25 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:25 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:25 --> Database Driver Class Initialized
INFO - 2025-05-05 07:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:25 --> Form Validation Class Initialized
INFO - 2025-05-05 07:03:25 --> Controller Class Initialized
INFO - 2025-05-05 07:03:25 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:03:25 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:03:25 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:03:25 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 07:03:25 --> Final output sent to browser
DEBUG - 2025-05-05 07:03:25 --> Total execution time: 0.0275
INFO - 2025-05-05 07:03:26 --> Config Class Initialized
INFO - 2025-05-05 07:03:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:03:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:03:26 --> Utf8 Class Initialized
INFO - 2025-05-05 07:03:26 --> URI Class Initialized
INFO - 2025-05-05 07:03:26 --> Router Class Initialized
INFO - 2025-05-05 07:03:26 --> Output Class Initialized
INFO - 2025-05-05 07:03:26 --> Security Class Initialized
DEBUG - 2025-05-05 07:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:03:26 --> Input Class Initialized
INFO - 2025-05-05 07:03:26 --> Language Class Initialized
INFO - 2025-05-05 07:03:26 --> Loader Class Initialized
INFO - 2025-05-05 07:03:26 --> Helper loaded: form_helper
INFO - 2025-05-05 07:03:26 --> Helper loaded: url_helper
INFO - 2025-05-05 07:03:26 --> Database Driver Class Initialized
INFO - 2025-05-05 07:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:03:26 --> Form Validation Class Initialized
INFO - 2025-05-05 07:03:26 --> Controller Class Initialized
INFO - 2025-05-05 07:03:26 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:03:26 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:03:26 --> Query error: Unknown column 'nama_sekolah' in 'field list' - Invalid query: SELECT `nama_sekolah`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `nama_sekolah`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:03:26 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:05:48 --> Config Class Initialized
INFO - 2025-05-05 07:05:48 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:05:48 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:05:48 --> Utf8 Class Initialized
INFO - 2025-05-05 07:05:48 --> URI Class Initialized
INFO - 2025-05-05 07:05:48 --> Router Class Initialized
INFO - 2025-05-05 07:05:48 --> Output Class Initialized
INFO - 2025-05-05 07:05:48 --> Security Class Initialized
DEBUG - 2025-05-05 07:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:05:48 --> Input Class Initialized
INFO - 2025-05-05 07:05:48 --> Language Class Initialized
INFO - 2025-05-05 07:05:48 --> Loader Class Initialized
INFO - 2025-05-05 07:05:48 --> Helper loaded: form_helper
INFO - 2025-05-05 07:05:48 --> Helper loaded: url_helper
INFO - 2025-05-05 07:05:48 --> Database Driver Class Initialized
INFO - 2025-05-05 07:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:05:48 --> Form Validation Class Initialized
INFO - 2025-05-05 07:05:48 --> Controller Class Initialized
INFO - 2025-05-05 07:05:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:05:48 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:05:48 --> Query error: Unknown column 'nama_sekolah' in 'field list' - Invalid query: SELECT `nama_sekolah`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `nama_sekolah`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:05:48 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:06:10 --> Config Class Initialized
INFO - 2025-05-05 07:06:10 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:06:10 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:06:10 --> Utf8 Class Initialized
INFO - 2025-05-05 07:06:10 --> URI Class Initialized
INFO - 2025-05-05 07:06:10 --> Router Class Initialized
INFO - 2025-05-05 07:06:10 --> Output Class Initialized
INFO - 2025-05-05 07:06:10 --> Security Class Initialized
DEBUG - 2025-05-05 07:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:06:10 --> Input Class Initialized
INFO - 2025-05-05 07:06:10 --> Language Class Initialized
INFO - 2025-05-05 07:06:10 --> Loader Class Initialized
INFO - 2025-05-05 07:06:10 --> Helper loaded: form_helper
INFO - 2025-05-05 07:06:10 --> Helper loaded: url_helper
INFO - 2025-05-05 07:06:10 --> Database Driver Class Initialized
INFO - 2025-05-05 07:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:06:10 --> Form Validation Class Initialized
INFO - 2025-05-05 07:06:10 --> Controller Class Initialized
INFO - 2025-05-05 07:06:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:06:10 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:06:10 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:06:10 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:06:12 --> Config Class Initialized
INFO - 2025-05-05 07:06:12 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:06:12 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:06:12 --> Utf8 Class Initialized
INFO - 2025-05-05 07:06:12 --> URI Class Initialized
INFO - 2025-05-05 07:06:12 --> Router Class Initialized
INFO - 2025-05-05 07:06:12 --> Output Class Initialized
INFO - 2025-05-05 07:06:12 --> Security Class Initialized
DEBUG - 2025-05-05 07:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:06:12 --> Input Class Initialized
INFO - 2025-05-05 07:06:12 --> Language Class Initialized
INFO - 2025-05-05 07:06:12 --> Loader Class Initialized
INFO - 2025-05-05 07:06:12 --> Helper loaded: form_helper
INFO - 2025-05-05 07:06:12 --> Helper loaded: url_helper
INFO - 2025-05-05 07:06:12 --> Database Driver Class Initialized
INFO - 2025-05-05 07:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:06:12 --> Form Validation Class Initialized
INFO - 2025-05-05 07:06:12 --> Controller Class Initialized
INFO - 2025-05-05 07:06:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:06:12 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:06:12 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:06:12 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:06:35 --> Config Class Initialized
INFO - 2025-05-05 07:06:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:06:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:06:35 --> Utf8 Class Initialized
INFO - 2025-05-05 07:06:35 --> URI Class Initialized
INFO - 2025-05-05 07:06:35 --> Router Class Initialized
INFO - 2025-05-05 07:06:35 --> Output Class Initialized
INFO - 2025-05-05 07:06:35 --> Security Class Initialized
DEBUG - 2025-05-05 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:06:35 --> Input Class Initialized
INFO - 2025-05-05 07:06:35 --> Language Class Initialized
INFO - 2025-05-05 07:06:35 --> Loader Class Initialized
INFO - 2025-05-05 07:06:35 --> Helper loaded: form_helper
INFO - 2025-05-05 07:06:35 --> Helper loaded: url_helper
INFO - 2025-05-05 07:06:35 --> Database Driver Class Initialized
INFO - 2025-05-05 07:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:06:35 --> Form Validation Class Initialized
INFO - 2025-05-05 07:06:35 --> Controller Class Initialized
INFO - 2025-05-05 07:06:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:06:35 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:06:35 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:06:35 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:06:36 --> Config Class Initialized
INFO - 2025-05-05 07:06:36 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:06:36 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:06:36 --> Utf8 Class Initialized
INFO - 2025-05-05 07:06:36 --> URI Class Initialized
INFO - 2025-05-05 07:06:36 --> Router Class Initialized
INFO - 2025-05-05 07:06:36 --> Output Class Initialized
INFO - 2025-05-05 07:06:36 --> Security Class Initialized
DEBUG - 2025-05-05 07:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:06:36 --> Input Class Initialized
INFO - 2025-05-05 07:06:36 --> Language Class Initialized
INFO - 2025-05-05 07:06:36 --> Loader Class Initialized
INFO - 2025-05-05 07:06:36 --> Helper loaded: form_helper
INFO - 2025-05-05 07:06:36 --> Helper loaded: url_helper
INFO - 2025-05-05 07:06:36 --> Database Driver Class Initialized
INFO - 2025-05-05 07:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:06:36 --> Form Validation Class Initialized
INFO - 2025-05-05 07:06:36 --> Controller Class Initialized
INFO - 2025-05-05 07:06:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:06:36 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:06:36 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:06:36 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:08:27 --> Config Class Initialized
INFO - 2025-05-05 07:08:27 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:08:27 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:08:27 --> Utf8 Class Initialized
INFO - 2025-05-05 07:08:27 --> URI Class Initialized
INFO - 2025-05-05 07:08:27 --> Router Class Initialized
INFO - 2025-05-05 07:08:27 --> Output Class Initialized
INFO - 2025-05-05 07:08:27 --> Security Class Initialized
DEBUG - 2025-05-05 07:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:08:27 --> Input Class Initialized
INFO - 2025-05-05 07:08:27 --> Language Class Initialized
INFO - 2025-05-05 07:08:27 --> Loader Class Initialized
INFO - 2025-05-05 07:08:27 --> Helper loaded: form_helper
INFO - 2025-05-05 07:08:27 --> Helper loaded: url_helper
INFO - 2025-05-05 07:08:27 --> Database Driver Class Initialized
INFO - 2025-05-05 07:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:08:27 --> Form Validation Class Initialized
INFO - 2025-05-05 07:08:27 --> Controller Class Initialized
INFO - 2025-05-05 07:08:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:08:27 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:08:27 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:08:27 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:08:32 --> Config Class Initialized
INFO - 2025-05-05 07:08:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:08:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:08:32 --> Utf8 Class Initialized
INFO - 2025-05-05 07:08:32 --> URI Class Initialized
INFO - 2025-05-05 07:08:32 --> Router Class Initialized
INFO - 2025-05-05 07:08:32 --> Output Class Initialized
INFO - 2025-05-05 07:08:32 --> Security Class Initialized
DEBUG - 2025-05-05 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:08:32 --> Input Class Initialized
INFO - 2025-05-05 07:08:32 --> Language Class Initialized
INFO - 2025-05-05 07:08:32 --> Loader Class Initialized
INFO - 2025-05-05 07:08:32 --> Helper loaded: form_helper
INFO - 2025-05-05 07:08:32 --> Helper loaded: url_helper
INFO - 2025-05-05 07:08:32 --> Database Driver Class Initialized
INFO - 2025-05-05 07:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:08:32 --> Form Validation Class Initialized
INFO - 2025-05-05 07:08:32 --> Controller Class Initialized
INFO - 2025-05-05 07:08:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:08:32 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:08:32 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:08:32 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:08:32 --> Config Class Initialized
INFO - 2025-05-05 07:08:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:08:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:08:32 --> Utf8 Class Initialized
INFO - 2025-05-05 07:08:32 --> URI Class Initialized
INFO - 2025-05-05 07:08:32 --> Router Class Initialized
INFO - 2025-05-05 07:08:32 --> Output Class Initialized
INFO - 2025-05-05 07:08:32 --> Security Class Initialized
DEBUG - 2025-05-05 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:08:32 --> Input Class Initialized
INFO - 2025-05-05 07:08:32 --> Language Class Initialized
INFO - 2025-05-05 07:08:32 --> Loader Class Initialized
INFO - 2025-05-05 07:08:32 --> Helper loaded: form_helper
INFO - 2025-05-05 07:08:32 --> Helper loaded: url_helper
INFO - 2025-05-05 07:08:32 --> Database Driver Class Initialized
INFO - 2025-05-05 07:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:08:32 --> Form Validation Class Initialized
INFO - 2025-05-05 07:08:32 --> Controller Class Initialized
INFO - 2025-05-05 07:08:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:08:32 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:08:32 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:08:32 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:08:32 --> Config Class Initialized
INFO - 2025-05-05 07:08:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:08:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:08:32 --> Utf8 Class Initialized
INFO - 2025-05-05 07:08:32 --> URI Class Initialized
INFO - 2025-05-05 07:08:32 --> Router Class Initialized
INFO - 2025-05-05 07:08:32 --> Output Class Initialized
INFO - 2025-05-05 07:08:32 --> Security Class Initialized
DEBUG - 2025-05-05 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:08:32 --> Input Class Initialized
INFO - 2025-05-05 07:08:32 --> Language Class Initialized
INFO - 2025-05-05 07:08:32 --> Loader Class Initialized
INFO - 2025-05-05 07:08:32 --> Helper loaded: form_helper
INFO - 2025-05-05 07:08:32 --> Helper loaded: url_helper
INFO - 2025-05-05 07:08:32 --> Database Driver Class Initialized
INFO - 2025-05-05 07:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:08:32 --> Form Validation Class Initialized
INFO - 2025-05-05 07:08:32 --> Controller Class Initialized
INFO - 2025-05-05 07:08:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:08:32 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:08:32 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:08:32 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:08:33 --> Config Class Initialized
INFO - 2025-05-05 07:08:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:08:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:08:33 --> Utf8 Class Initialized
INFO - 2025-05-05 07:08:33 --> URI Class Initialized
INFO - 2025-05-05 07:08:33 --> Router Class Initialized
INFO - 2025-05-05 07:08:33 --> Output Class Initialized
INFO - 2025-05-05 07:08:33 --> Security Class Initialized
DEBUG - 2025-05-05 07:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:08:33 --> Input Class Initialized
INFO - 2025-05-05 07:08:33 --> Language Class Initialized
INFO - 2025-05-05 07:08:33 --> Loader Class Initialized
INFO - 2025-05-05 07:08:33 --> Helper loaded: form_helper
INFO - 2025-05-05 07:08:33 --> Helper loaded: url_helper
INFO - 2025-05-05 07:08:33 --> Database Driver Class Initialized
INFO - 2025-05-05 07:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:08:33 --> Form Validation Class Initialized
INFO - 2025-05-05 07:08:33 --> Controller Class Initialized
INFO - 2025-05-05 07:08:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:08:33 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:08:33 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:08:33 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:08:33 --> Config Class Initialized
INFO - 2025-05-05 07:08:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:08:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:08:33 --> Utf8 Class Initialized
INFO - 2025-05-05 07:08:33 --> URI Class Initialized
INFO - 2025-05-05 07:08:33 --> Router Class Initialized
INFO - 2025-05-05 07:08:33 --> Output Class Initialized
INFO - 2025-05-05 07:08:33 --> Security Class Initialized
DEBUG - 2025-05-05 07:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:08:33 --> Input Class Initialized
INFO - 2025-05-05 07:08:33 --> Language Class Initialized
INFO - 2025-05-05 07:08:33 --> Loader Class Initialized
INFO - 2025-05-05 07:08:33 --> Helper loaded: form_helper
INFO - 2025-05-05 07:08:33 --> Helper loaded: url_helper
INFO - 2025-05-05 07:08:33 --> Database Driver Class Initialized
INFO - 2025-05-05 07:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:08:33 --> Form Validation Class Initialized
INFO - 2025-05-05 07:08:33 --> Controller Class Initialized
INFO - 2025-05-05 07:08:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:08:33 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:08:33 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:08:33 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:08:33 --> Config Class Initialized
INFO - 2025-05-05 07:08:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:08:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:08:33 --> Utf8 Class Initialized
INFO - 2025-05-05 07:08:33 --> URI Class Initialized
INFO - 2025-05-05 07:08:33 --> Router Class Initialized
INFO - 2025-05-05 07:08:33 --> Output Class Initialized
INFO - 2025-05-05 07:08:33 --> Security Class Initialized
DEBUG - 2025-05-05 07:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:08:33 --> Input Class Initialized
INFO - 2025-05-05 07:08:33 --> Language Class Initialized
INFO - 2025-05-05 07:08:33 --> Loader Class Initialized
INFO - 2025-05-05 07:08:33 --> Helper loaded: form_helper
INFO - 2025-05-05 07:08:33 --> Helper loaded: url_helper
INFO - 2025-05-05 07:08:33 --> Database Driver Class Initialized
INFO - 2025-05-05 07:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:08:33 --> Form Validation Class Initialized
INFO - 2025-05-05 07:08:33 --> Controller Class Initialized
INFO - 2025-05-05 07:08:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:08:33 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:08:33 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:08:33 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:08:41 --> Config Class Initialized
INFO - 2025-05-05 07:08:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:08:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:08:41 --> Utf8 Class Initialized
INFO - 2025-05-05 07:08:41 --> URI Class Initialized
INFO - 2025-05-05 07:08:41 --> Router Class Initialized
INFO - 2025-05-05 07:08:41 --> Output Class Initialized
INFO - 2025-05-05 07:08:41 --> Security Class Initialized
DEBUG - 2025-05-05 07:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:08:41 --> Input Class Initialized
INFO - 2025-05-05 07:08:41 --> Language Class Initialized
INFO - 2025-05-05 07:08:41 --> Loader Class Initialized
INFO - 2025-05-05 07:08:41 --> Helper loaded: form_helper
INFO - 2025-05-05 07:08:41 --> Helper loaded: url_helper
INFO - 2025-05-05 07:08:41 --> Database Driver Class Initialized
INFO - 2025-05-05 07:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:08:41 --> Form Validation Class Initialized
INFO - 2025-05-05 07:08:41 --> Controller Class Initialized
INFO - 2025-05-05 07:08:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:08:41 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:08:41 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:08:41 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:10:17 --> Config Class Initialized
INFO - 2025-05-05 07:10:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:10:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:10:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:10:17 --> URI Class Initialized
INFO - 2025-05-05 07:10:17 --> Router Class Initialized
INFO - 2025-05-05 07:10:17 --> Output Class Initialized
INFO - 2025-05-05 07:10:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:10:17 --> Input Class Initialized
INFO - 2025-05-05 07:10:17 --> Language Class Initialized
INFO - 2025-05-05 07:10:17 --> Loader Class Initialized
INFO - 2025-05-05 07:10:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:10:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:10:17 --> Database Driver Class Initialized
INFO - 2025-05-05 07:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:10:17 --> Form Validation Class Initialized
INFO - 2025-05-05 07:10:17 --> Controller Class Initialized
INFO - 2025-05-05 07:10:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:10:17 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:10:17 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:10:17 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:10:18 --> Config Class Initialized
INFO - 2025-05-05 07:10:18 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:10:18 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:10:18 --> Utf8 Class Initialized
INFO - 2025-05-05 07:10:18 --> URI Class Initialized
INFO - 2025-05-05 07:10:18 --> Router Class Initialized
INFO - 2025-05-05 07:10:18 --> Output Class Initialized
INFO - 2025-05-05 07:10:18 --> Security Class Initialized
DEBUG - 2025-05-05 07:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:10:18 --> Input Class Initialized
INFO - 2025-05-05 07:10:18 --> Language Class Initialized
INFO - 2025-05-05 07:10:18 --> Loader Class Initialized
INFO - 2025-05-05 07:10:18 --> Helper loaded: form_helper
INFO - 2025-05-05 07:10:18 --> Helper loaded: url_helper
INFO - 2025-05-05 07:10:18 --> Database Driver Class Initialized
INFO - 2025-05-05 07:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:10:18 --> Form Validation Class Initialized
INFO - 2025-05-05 07:10:18 --> Controller Class Initialized
INFO - 2025-05-05 07:10:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:10:18 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:10:18 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:10:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:10:19 --> Config Class Initialized
INFO - 2025-05-05 07:10:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:10:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:10:19 --> Utf8 Class Initialized
INFO - 2025-05-05 07:10:19 --> URI Class Initialized
INFO - 2025-05-05 07:10:19 --> Router Class Initialized
INFO - 2025-05-05 07:10:19 --> Output Class Initialized
INFO - 2025-05-05 07:10:19 --> Security Class Initialized
DEBUG - 2025-05-05 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:10:19 --> Input Class Initialized
INFO - 2025-05-05 07:10:19 --> Language Class Initialized
INFO - 2025-05-05 07:10:19 --> Loader Class Initialized
INFO - 2025-05-05 07:10:19 --> Helper loaded: form_helper
INFO - 2025-05-05 07:10:19 --> Helper loaded: url_helper
INFO - 2025-05-05 07:10:19 --> Database Driver Class Initialized
INFO - 2025-05-05 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:10:19 --> Form Validation Class Initialized
INFO - 2025-05-05 07:10:19 --> Controller Class Initialized
INFO - 2025-05-05 07:10:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:10:19 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:10:19 --> Query error: Unknown column 'sekolah_asa' in 'field list' - Invalid query: SELECT `sekolah_asa`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `sekolah_asa`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:10:19 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:12:24 --> Config Class Initialized
INFO - 2025-05-05 07:12:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:12:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:12:24 --> Utf8 Class Initialized
INFO - 2025-05-05 07:12:24 --> URI Class Initialized
INFO - 2025-05-05 07:12:24 --> Router Class Initialized
INFO - 2025-05-05 07:12:24 --> Output Class Initialized
INFO - 2025-05-05 07:12:24 --> Security Class Initialized
DEBUG - 2025-05-05 07:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:12:24 --> Input Class Initialized
INFO - 2025-05-05 07:12:24 --> Language Class Initialized
INFO - 2025-05-05 07:12:24 --> Loader Class Initialized
INFO - 2025-05-05 07:12:24 --> Helper loaded: form_helper
INFO - 2025-05-05 07:12:24 --> Helper loaded: url_helper
INFO - 2025-05-05 07:12:24 --> Database Driver Class Initialized
INFO - 2025-05-05 07:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:12:24 --> Form Validation Class Initialized
INFO - 2025-05-05 07:12:24 --> Controller Class Initialized
INFO - 2025-05-05 07:12:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:12:24 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:12:24 --> Query error: Unknown column 'nama_sekolah' in 'field list' - Invalid query: SELECT `nama_sekolah`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
GROUP BY `nama_sekolah`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:12:24 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:16:33 --> Config Class Initialized
INFO - 2025-05-05 07:16:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:16:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:16:33 --> Utf8 Class Initialized
INFO - 2025-05-05 07:16:33 --> URI Class Initialized
INFO - 2025-05-05 07:16:33 --> Router Class Initialized
INFO - 2025-05-05 07:16:33 --> Output Class Initialized
INFO - 2025-05-05 07:16:33 --> Security Class Initialized
DEBUG - 2025-05-05 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:16:33 --> Input Class Initialized
INFO - 2025-05-05 07:16:33 --> Language Class Initialized
INFO - 2025-05-05 07:16:33 --> Loader Class Initialized
INFO - 2025-05-05 07:16:33 --> Helper loaded: form_helper
INFO - 2025-05-05 07:16:33 --> Helper loaded: url_helper
INFO - 2025-05-05 07:16:33 --> Database Driver Class Initialized
INFO - 2025-05-05 07:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:16:33 --> Form Validation Class Initialized
INFO - 2025-05-05 07:16:33 --> Controller Class Initialized
INFO - 2025-05-05 07:16:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:16:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:16:33 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:16:33 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_sekolah.php
INFO - 2025-05-05 07:16:33 --> Final output sent to browser
DEBUG - 2025-05-05 07:16:33 --> Total execution time: 0.0301
INFO - 2025-05-05 07:16:38 --> Config Class Initialized
INFO - 2025-05-05 07:16:38 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:16:38 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:16:38 --> Utf8 Class Initialized
INFO - 2025-05-05 07:16:38 --> URI Class Initialized
INFO - 2025-05-05 07:16:38 --> Router Class Initialized
INFO - 2025-05-05 07:16:38 --> Output Class Initialized
INFO - 2025-05-05 07:16:38 --> Security Class Initialized
DEBUG - 2025-05-05 07:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:16:38 --> Input Class Initialized
INFO - 2025-05-05 07:16:38 --> Language Class Initialized
INFO - 2025-05-05 07:16:38 --> Loader Class Initialized
INFO - 2025-05-05 07:16:38 --> Helper loaded: form_helper
INFO - 2025-05-05 07:16:38 --> Helper loaded: url_helper
INFO - 2025-05-05 07:16:38 --> Database Driver Class Initialized
INFO - 2025-05-05 07:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:16:38 --> Form Validation Class Initialized
INFO - 2025-05-05 07:16:38 --> Controller Class Initialized
INFO - 2025-05-05 07:16:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:16:38 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:16:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:16:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 07:16:38 --> Final output sent to browser
DEBUG - 2025-05-05 07:16:38 --> Total execution time: 0.0313
INFO - 2025-05-05 07:16:39 --> Config Class Initialized
INFO - 2025-05-05 07:16:39 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:16:39 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:16:39 --> Utf8 Class Initialized
INFO - 2025-05-05 07:16:39 --> URI Class Initialized
INFO - 2025-05-05 07:16:39 --> Router Class Initialized
INFO - 2025-05-05 07:16:39 --> Output Class Initialized
INFO - 2025-05-05 07:16:39 --> Security Class Initialized
DEBUG - 2025-05-05 07:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:16:39 --> Input Class Initialized
INFO - 2025-05-05 07:16:39 --> Language Class Initialized
INFO - 2025-05-05 07:16:39 --> Loader Class Initialized
INFO - 2025-05-05 07:16:39 --> Helper loaded: form_helper
INFO - 2025-05-05 07:16:39 --> Helper loaded: url_helper
INFO - 2025-05-05 07:16:39 --> Database Driver Class Initialized
INFO - 2025-05-05 07:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:16:39 --> Form Validation Class Initialized
INFO - 2025-05-05 07:16:39 --> Controller Class Initialized
INFO - 2025-05-05 07:16:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:16:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:16:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:16:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_sekolah.php
INFO - 2025-05-05 07:16:39 --> Final output sent to browser
DEBUG - 2025-05-05 07:16:39 --> Total execution time: 0.0325
INFO - 2025-05-05 07:16:40 --> Config Class Initialized
INFO - 2025-05-05 07:16:40 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:16:40 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:16:40 --> Utf8 Class Initialized
INFO - 2025-05-05 07:16:40 --> URI Class Initialized
INFO - 2025-05-05 07:16:40 --> Router Class Initialized
INFO - 2025-05-05 07:16:40 --> Output Class Initialized
INFO - 2025-05-05 07:16:40 --> Security Class Initialized
DEBUG - 2025-05-05 07:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:16:40 --> Input Class Initialized
INFO - 2025-05-05 07:16:40 --> Language Class Initialized
INFO - 2025-05-05 07:16:40 --> Loader Class Initialized
INFO - 2025-05-05 07:16:40 --> Helper loaded: form_helper
INFO - 2025-05-05 07:16:40 --> Helper loaded: url_helper
INFO - 2025-05-05 07:16:40 --> Database Driver Class Initialized
INFO - 2025-05-05 07:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:16:40 --> Form Validation Class Initialized
INFO - 2025-05-05 07:16:40 --> Controller Class Initialized
INFO - 2025-05-05 07:16:40 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:16:40 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:16:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:16:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-05 07:16:40 --> Final output sent to browser
DEBUG - 2025-05-05 07:16:40 --> Total execution time: 0.0302
INFO - 2025-05-05 07:16:41 --> Config Class Initialized
INFO - 2025-05-05 07:16:41 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:16:41 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:16:41 --> Utf8 Class Initialized
INFO - 2025-05-05 07:16:41 --> URI Class Initialized
INFO - 2025-05-05 07:16:41 --> Router Class Initialized
INFO - 2025-05-05 07:16:41 --> Output Class Initialized
INFO - 2025-05-05 07:16:41 --> Security Class Initialized
DEBUG - 2025-05-05 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:16:41 --> Input Class Initialized
INFO - 2025-05-05 07:16:41 --> Language Class Initialized
INFO - 2025-05-05 07:16:41 --> Loader Class Initialized
INFO - 2025-05-05 07:16:41 --> Helper loaded: form_helper
INFO - 2025-05-05 07:16:41 --> Helper loaded: url_helper
INFO - 2025-05-05 07:16:41 --> Database Driver Class Initialized
INFO - 2025-05-05 07:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:16:41 --> Form Validation Class Initialized
INFO - 2025-05-05 07:16:41 --> Controller Class Initialized
INFO - 2025-05-05 07:16:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:16:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:16:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:16:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 07:16:41 --> Final output sent to browser
DEBUG - 2025-05-05 07:16:41 --> Total execution time: 0.0298
INFO - 2025-05-05 07:16:42 --> Config Class Initialized
INFO - 2025-05-05 07:16:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:16:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:16:42 --> Utf8 Class Initialized
INFO - 2025-05-05 07:16:42 --> URI Class Initialized
INFO - 2025-05-05 07:16:42 --> Router Class Initialized
INFO - 2025-05-05 07:16:42 --> Output Class Initialized
INFO - 2025-05-05 07:16:42 --> Security Class Initialized
DEBUG - 2025-05-05 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:16:42 --> Input Class Initialized
INFO - 2025-05-05 07:16:42 --> Language Class Initialized
INFO - 2025-05-05 07:16:42 --> Loader Class Initialized
INFO - 2025-05-05 07:16:42 --> Helper loaded: form_helper
INFO - 2025-05-05 07:16:42 --> Helper loaded: url_helper
INFO - 2025-05-05 07:16:42 --> Database Driver Class Initialized
INFO - 2025-05-05 07:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:16:42 --> Form Validation Class Initialized
INFO - 2025-05-05 07:16:42 --> Controller Class Initialized
INFO - 2025-05-05 07:16:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:16:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:16:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:16:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-05 07:16:42 --> Final output sent to browser
DEBUG - 2025-05-05 07:16:42 --> Total execution time: 0.0292
INFO - 2025-05-05 07:16:43 --> Config Class Initialized
INFO - 2025-05-05 07:16:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:16:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:16:43 --> Utf8 Class Initialized
INFO - 2025-05-05 07:16:43 --> URI Class Initialized
INFO - 2025-05-05 07:16:43 --> Router Class Initialized
INFO - 2025-05-05 07:16:43 --> Output Class Initialized
INFO - 2025-05-05 07:16:43 --> Security Class Initialized
DEBUG - 2025-05-05 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:16:43 --> Input Class Initialized
INFO - 2025-05-05 07:16:43 --> Language Class Initialized
INFO - 2025-05-05 07:16:43 --> Loader Class Initialized
INFO - 2025-05-05 07:16:43 --> Helper loaded: form_helper
INFO - 2025-05-05 07:16:43 --> Helper loaded: url_helper
INFO - 2025-05-05 07:16:43 --> Database Driver Class Initialized
INFO - 2025-05-05 07:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:16:43 --> Form Validation Class Initialized
INFO - 2025-05-05 07:16:43 --> Controller Class Initialized
INFO - 2025-05-05 07:16:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:16:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:16:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:16:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_sekolah.php
INFO - 2025-05-05 07:16:43 --> Final output sent to browser
DEBUG - 2025-05-05 07:16:43 --> Total execution time: 0.0278
INFO - 2025-05-05 07:16:44 --> Config Class Initialized
INFO - 2025-05-05 07:16:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:16:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:16:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:16:44 --> URI Class Initialized
INFO - 2025-05-05 07:16:44 --> Router Class Initialized
INFO - 2025-05-05 07:16:44 --> Output Class Initialized
INFO - 2025-05-05 07:16:44 --> Security Class Initialized
DEBUG - 2025-05-05 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:16:44 --> Input Class Initialized
INFO - 2025-05-05 07:16:44 --> Language Class Initialized
INFO - 2025-05-05 07:16:44 --> Loader Class Initialized
INFO - 2025-05-05 07:16:44 --> Helper loaded: form_helper
INFO - 2025-05-05 07:16:44 --> Helper loaded: url_helper
INFO - 2025-05-05 07:16:44 --> Database Driver Class Initialized
INFO - 2025-05-05 07:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:16:44 --> Form Validation Class Initialized
INFO - 2025-05-05 07:16:44 --> Controller Class Initialized
INFO - 2025-05-05 07:16:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:16:44 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:16:44 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:16:44 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:17:56 --> Config Class Initialized
INFO - 2025-05-05 07:17:56 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:17:56 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:17:56 --> Utf8 Class Initialized
INFO - 2025-05-05 07:17:56 --> URI Class Initialized
INFO - 2025-05-05 07:17:56 --> Router Class Initialized
INFO - 2025-05-05 07:17:56 --> Output Class Initialized
INFO - 2025-05-05 07:17:56 --> Security Class Initialized
DEBUG - 2025-05-05 07:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:17:56 --> Input Class Initialized
INFO - 2025-05-05 07:17:56 --> Language Class Initialized
INFO - 2025-05-05 07:17:56 --> Loader Class Initialized
INFO - 2025-05-05 07:17:56 --> Helper loaded: form_helper
INFO - 2025-05-05 07:17:56 --> Helper loaded: url_helper
INFO - 2025-05-05 07:17:56 --> Database Driver Class Initialized
INFO - 2025-05-05 07:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:17:56 --> Form Validation Class Initialized
INFO - 2025-05-05 07:17:56 --> Controller Class Initialized
INFO - 2025-05-05 07:17:56 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:17:56 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:17:56 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:17:56 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-05 07:17:56 --> Final output sent to browser
DEBUG - 2025-05-05 07:17:56 --> Total execution time: 0.0331
INFO - 2025-05-05 07:17:57 --> Config Class Initialized
INFO - 2025-05-05 07:17:57 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:17:57 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:17:57 --> Utf8 Class Initialized
INFO - 2025-05-05 07:17:57 --> URI Class Initialized
INFO - 2025-05-05 07:17:57 --> Router Class Initialized
INFO - 2025-05-05 07:17:57 --> Output Class Initialized
INFO - 2025-05-05 07:17:57 --> Security Class Initialized
DEBUG - 2025-05-05 07:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:17:57 --> Input Class Initialized
INFO - 2025-05-05 07:17:57 --> Language Class Initialized
INFO - 2025-05-05 07:17:57 --> Loader Class Initialized
INFO - 2025-05-05 07:17:57 --> Helper loaded: form_helper
INFO - 2025-05-05 07:17:57 --> Helper loaded: url_helper
INFO - 2025-05-05 07:17:57 --> Database Driver Class Initialized
INFO - 2025-05-05 07:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:17:57 --> Form Validation Class Initialized
INFO - 2025-05-05 07:17:57 --> Controller Class Initialized
INFO - 2025-05-05 07:17:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:17:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:17:57 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:17:57 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_sekolah.php
INFO - 2025-05-05 07:17:57 --> Final output sent to browser
DEBUG - 2025-05-05 07:17:57 --> Total execution time: 0.0276
INFO - 2025-05-05 07:17:59 --> Config Class Initialized
INFO - 2025-05-05 07:17:59 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:17:59 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:17:59 --> Utf8 Class Initialized
INFO - 2025-05-05 07:17:59 --> URI Class Initialized
INFO - 2025-05-05 07:17:59 --> Router Class Initialized
INFO - 2025-05-05 07:17:59 --> Output Class Initialized
INFO - 2025-05-05 07:17:59 --> Security Class Initialized
DEBUG - 2025-05-05 07:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:17:59 --> Input Class Initialized
INFO - 2025-05-05 07:17:59 --> Language Class Initialized
INFO - 2025-05-05 07:17:59 --> Loader Class Initialized
INFO - 2025-05-05 07:17:59 --> Helper loaded: form_helper
INFO - 2025-05-05 07:17:59 --> Helper loaded: url_helper
INFO - 2025-05-05 07:17:59 --> Database Driver Class Initialized
INFO - 2025-05-05 07:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:17:59 --> Form Validation Class Initialized
INFO - 2025-05-05 07:17:59 --> Controller Class Initialized
INFO - 2025-05-05 07:17:59 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:17:59 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:17:59 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:17:59 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:18:02 --> Config Class Initialized
INFO - 2025-05-05 07:18:02 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:18:02 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:18:02 --> Utf8 Class Initialized
INFO - 2025-05-05 07:18:02 --> URI Class Initialized
INFO - 2025-05-05 07:18:02 --> Router Class Initialized
INFO - 2025-05-05 07:18:02 --> Output Class Initialized
INFO - 2025-05-05 07:18:02 --> Security Class Initialized
DEBUG - 2025-05-05 07:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:18:02 --> Input Class Initialized
INFO - 2025-05-05 07:18:02 --> Language Class Initialized
INFO - 2025-05-05 07:18:02 --> Loader Class Initialized
INFO - 2025-05-05 07:18:02 --> Helper loaded: form_helper
INFO - 2025-05-05 07:18:02 --> Helper loaded: url_helper
INFO - 2025-05-05 07:18:02 --> Database Driver Class Initialized
INFO - 2025-05-05 07:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:18:02 --> Form Validation Class Initialized
INFO - 2025-05-05 07:18:02 --> Controller Class Initialized
INFO - 2025-05-05 07:18:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:18:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:18:02 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:18:02 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-05 07:18:02 --> Final output sent to browser
DEBUG - 2025-05-05 07:18:02 --> Total execution time: 0.0340
INFO - 2025-05-05 07:18:21 --> Config Class Initialized
INFO - 2025-05-05 07:18:21 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:18:21 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:18:21 --> Utf8 Class Initialized
INFO - 2025-05-05 07:18:21 --> URI Class Initialized
INFO - 2025-05-05 07:18:21 --> Router Class Initialized
INFO - 2025-05-05 07:18:21 --> Output Class Initialized
INFO - 2025-05-05 07:18:21 --> Security Class Initialized
DEBUG - 2025-05-05 07:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:18:21 --> Input Class Initialized
INFO - 2025-05-05 07:18:21 --> Language Class Initialized
INFO - 2025-05-05 07:18:21 --> Loader Class Initialized
INFO - 2025-05-05 07:18:21 --> Helper loaded: form_helper
INFO - 2025-05-05 07:18:21 --> Helper loaded: url_helper
INFO - 2025-05-05 07:18:21 --> Database Driver Class Initialized
INFO - 2025-05-05 07:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:18:21 --> Form Validation Class Initialized
INFO - 2025-05-05 07:18:21 --> Controller Class Initialized
INFO - 2025-05-05 07:18:21 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:18:21 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:18:21 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:18:21 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:18:24 --> Config Class Initialized
INFO - 2025-05-05 07:18:24 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:18:24 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:18:24 --> Utf8 Class Initialized
INFO - 2025-05-05 07:18:24 --> URI Class Initialized
INFO - 2025-05-05 07:18:24 --> Router Class Initialized
INFO - 2025-05-05 07:18:24 --> Output Class Initialized
INFO - 2025-05-05 07:18:24 --> Security Class Initialized
DEBUG - 2025-05-05 07:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:18:24 --> Input Class Initialized
INFO - 2025-05-05 07:18:24 --> Language Class Initialized
INFO - 2025-05-05 07:18:24 --> Loader Class Initialized
INFO - 2025-05-05 07:18:24 --> Helper loaded: form_helper
INFO - 2025-05-05 07:18:24 --> Helper loaded: url_helper
INFO - 2025-05-05 07:18:24 --> Database Driver Class Initialized
INFO - 2025-05-05 07:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:18:24 --> Form Validation Class Initialized
INFO - 2025-05-05 07:18:24 --> Controller Class Initialized
INFO - 2025-05-05 07:18:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:18:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:18:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:18:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-05 07:18:24 --> Final output sent to browser
DEBUG - 2025-05-05 07:18:24 --> Total execution time: 0.0293
INFO - 2025-05-05 07:18:26 --> Config Class Initialized
INFO - 2025-05-05 07:18:26 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:18:26 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:18:26 --> Utf8 Class Initialized
INFO - 2025-05-05 07:18:26 --> URI Class Initialized
INFO - 2025-05-05 07:18:26 --> Router Class Initialized
INFO - 2025-05-05 07:18:26 --> Output Class Initialized
INFO - 2025-05-05 07:18:26 --> Security Class Initialized
DEBUG - 2025-05-05 07:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:18:26 --> Input Class Initialized
INFO - 2025-05-05 07:18:26 --> Language Class Initialized
INFO - 2025-05-05 07:18:26 --> Loader Class Initialized
INFO - 2025-05-05 07:18:26 --> Helper loaded: form_helper
INFO - 2025-05-05 07:18:26 --> Helper loaded: url_helper
INFO - 2025-05-05 07:18:26 --> Database Driver Class Initialized
INFO - 2025-05-05 07:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:18:26 --> Form Validation Class Initialized
INFO - 2025-05-05 07:18:26 --> Controller Class Initialized
INFO - 2025-05-05 07:18:26 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:18:26 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:18:26 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:18:26 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-05 07:18:26 --> Final output sent to browser
DEBUG - 2025-05-05 07:18:26 --> Total execution time: 0.0331
INFO - 2025-05-05 07:20:01 --> Config Class Initialized
INFO - 2025-05-05 07:20:01 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:01 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:01 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:01 --> URI Class Initialized
INFO - 2025-05-05 07:20:01 --> Router Class Initialized
INFO - 2025-05-05 07:20:01 --> Output Class Initialized
INFO - 2025-05-05 07:20:01 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:01 --> Input Class Initialized
INFO - 2025-05-05 07:20:01 --> Language Class Initialized
INFO - 2025-05-05 07:20:01 --> Loader Class Initialized
INFO - 2025-05-05 07:20:01 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:01 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:01 --> Database Driver Class Initialized
INFO - 2025-05-05 07:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:01 --> Form Validation Class Initialized
INFO - 2025-05-05 07:20:01 --> Controller Class Initialized
INFO - 2025-05-05 07:20:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:20:01 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:20:01 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:20:01 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:20:04 --> Config Class Initialized
INFO - 2025-05-05 07:20:04 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:04 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:04 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:04 --> URI Class Initialized
INFO - 2025-05-05 07:20:04 --> Router Class Initialized
INFO - 2025-05-05 07:20:04 --> Output Class Initialized
INFO - 2025-05-05 07:20:04 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:04 --> Input Class Initialized
INFO - 2025-05-05 07:20:04 --> Language Class Initialized
INFO - 2025-05-05 07:20:04 --> Loader Class Initialized
INFO - 2025-05-05 07:20:04 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:04 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:04 --> Database Driver Class Initialized
INFO - 2025-05-05 07:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:04 --> Form Validation Class Initialized
INFO - 2025-05-05 07:20:04 --> Controller Class Initialized
INFO - 2025-05-05 07:20:04 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:20:04 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:20:04 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:20:04 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_sekolah.php
INFO - 2025-05-05 07:20:04 --> Final output sent to browser
DEBUG - 2025-05-05 07:20:04 --> Total execution time: 0.0297
INFO - 2025-05-05 07:20:07 --> Config Class Initialized
INFO - 2025-05-05 07:20:07 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:20:07 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:20:07 --> Utf8 Class Initialized
INFO - 2025-05-05 07:20:07 --> URI Class Initialized
INFO - 2025-05-05 07:20:07 --> Router Class Initialized
INFO - 2025-05-05 07:20:07 --> Output Class Initialized
INFO - 2025-05-05 07:20:07 --> Security Class Initialized
DEBUG - 2025-05-05 07:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:20:07 --> Input Class Initialized
INFO - 2025-05-05 07:20:07 --> Language Class Initialized
INFO - 2025-05-05 07:20:07 --> Loader Class Initialized
INFO - 2025-05-05 07:20:07 --> Helper loaded: form_helper
INFO - 2025-05-05 07:20:07 --> Helper loaded: url_helper
INFO - 2025-05-05 07:20:07 --> Database Driver Class Initialized
INFO - 2025-05-05 07:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:20:07 --> Form Validation Class Initialized
INFO - 2025-05-05 07:20:07 --> Controller Class Initialized
INFO - 2025-05-05 07:20:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:20:07 --> Model "Daftar_ulang_model" initialized
ERROR - 2025-05-05 07:20:07 --> Query error: Unknown column 'rekomendasi' in 'field list' - Invalid query: SELECT `rekomendasi`, COUNT(*) as total_pendaftar, SUM(CASE WHEN status_daftar_ulang = "sudah" THEN 1 ELSE 0 END) as total_daftar_ulang
WHERE `rekomendasi` IS NOT NULL
GROUP BY `rekomendasi`
ORDER BY `total_pendaftar` DESC
INFO - 2025-05-05 07:20:07 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-05 07:23:42 --> Config Class Initialized
INFO - 2025-05-05 07:23:42 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:42 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:42 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:42 --> URI Class Initialized
INFO - 2025-05-05 07:23:42 --> Router Class Initialized
INFO - 2025-05-05 07:23:42 --> Output Class Initialized
INFO - 2025-05-05 07:23:42 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:42 --> Input Class Initialized
INFO - 2025-05-05 07:23:42 --> Language Class Initialized
INFO - 2025-05-05 07:23:42 --> Loader Class Initialized
INFO - 2025-05-05 07:23:42 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:42 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:42 --> Database Driver Class Initialized
INFO - 2025-05-05 07:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:42 --> Form Validation Class Initialized
INFO - 2025-05-05 07:23:42 --> Controller Class Initialized
INFO - 2025-05-05 07:23:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:23:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:23:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:23:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_rekomendasi.php
INFO - 2025-05-05 07:23:42 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:42 --> Total execution time: 0.0291
INFO - 2025-05-05 07:23:44 --> Config Class Initialized
INFO - 2025-05-05 07:23:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:44 --> URI Class Initialized
INFO - 2025-05-05 07:23:44 --> Router Class Initialized
INFO - 2025-05-05 07:23:44 --> Output Class Initialized
INFO - 2025-05-05 07:23:44 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:44 --> Input Class Initialized
INFO - 2025-05-05 07:23:44 --> Language Class Initialized
INFO - 2025-05-05 07:23:44 --> Loader Class Initialized
INFO - 2025-05-05 07:23:44 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:44 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:44 --> Database Driver Class Initialized
INFO - 2025-05-05 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:44 --> Form Validation Class Initialized
INFO - 2025-05-05 07:23:44 --> Controller Class Initialized
INFO - 2025-05-05 07:23:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:23:44 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:23:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:23:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_rekomendasi.php
INFO - 2025-05-05 07:23:44 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:44 --> Total execution time: 0.0292
INFO - 2025-05-05 07:23:49 --> Config Class Initialized
INFO - 2025-05-05 07:23:49 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:49 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:49 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:49 --> URI Class Initialized
INFO - 2025-05-05 07:23:49 --> Router Class Initialized
INFO - 2025-05-05 07:23:49 --> Output Class Initialized
INFO - 2025-05-05 07:23:49 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:49 --> Input Class Initialized
INFO - 2025-05-05 07:23:49 --> Language Class Initialized
INFO - 2025-05-05 07:23:49 --> Loader Class Initialized
INFO - 2025-05-05 07:23:49 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:49 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:49 --> Database Driver Class Initialized
INFO - 2025-05-05 07:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:49 --> Form Validation Class Initialized
INFO - 2025-05-05 07:23:49 --> Controller Class Initialized
INFO - 2025-05-05 07:23:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:23:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:23:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:23:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_rekomendasi.php
INFO - 2025-05-05 07:23:49 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:49 --> Total execution time: 0.0285
INFO - 2025-05-05 07:23:51 --> Config Class Initialized
INFO - 2025-05-05 07:23:51 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:23:51 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:23:51 --> Utf8 Class Initialized
INFO - 2025-05-05 07:23:51 --> URI Class Initialized
INFO - 2025-05-05 07:23:51 --> Router Class Initialized
INFO - 2025-05-05 07:23:51 --> Output Class Initialized
INFO - 2025-05-05 07:23:51 --> Security Class Initialized
DEBUG - 2025-05-05 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:23:51 --> Input Class Initialized
INFO - 2025-05-05 07:23:51 --> Language Class Initialized
INFO - 2025-05-05 07:23:51 --> Loader Class Initialized
INFO - 2025-05-05 07:23:51 --> Helper loaded: form_helper
INFO - 2025-05-05 07:23:51 --> Helper loaded: url_helper
INFO - 2025-05-05 07:23:51 --> Database Driver Class Initialized
INFO - 2025-05-05 07:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:23:51 --> Form Validation Class Initialized
INFO - 2025-05-05 07:23:51 --> Controller Class Initialized
INFO - 2025-05-05 07:23:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:23:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:23:51 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:23:51 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-05 07:23:51 --> Final output sent to browser
DEBUG - 2025-05-05 07:23:51 --> Total execution time: 0.0349
INFO - 2025-05-05 07:43:54 --> Config Class Initialized
INFO - 2025-05-05 07:43:54 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:43:54 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:43:54 --> Utf8 Class Initialized
INFO - 2025-05-05 07:43:54 --> URI Class Initialized
INFO - 2025-05-05 07:43:54 --> Router Class Initialized
INFO - 2025-05-05 07:43:54 --> Output Class Initialized
INFO - 2025-05-05 07:43:54 --> Security Class Initialized
DEBUG - 2025-05-05 07:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:43:54 --> Input Class Initialized
INFO - 2025-05-05 07:43:54 --> Language Class Initialized
INFO - 2025-05-05 07:43:54 --> Loader Class Initialized
INFO - 2025-05-05 07:43:54 --> Helper loaded: form_helper
INFO - 2025-05-05 07:43:54 --> Helper loaded: url_helper
INFO - 2025-05-05 07:43:54 --> Database Driver Class Initialized
INFO - 2025-05-05 07:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:43:54 --> Form Validation Class Initialized
INFO - 2025-05-05 07:43:54 --> Controller Class Initialized
INFO - 2025-05-05 07:43:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:43:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:43:54 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:43:54 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-05 07:43:54 --> Final output sent to browser
DEBUG - 2025-05-05 07:43:54 --> Total execution time: 0.0355
INFO - 2025-05-05 07:48:03 --> Config Class Initialized
INFO - 2025-05-05 07:48:03 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:03 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:03 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:03 --> URI Class Initialized
INFO - 2025-05-05 07:48:03 --> Router Class Initialized
INFO - 2025-05-05 07:48:03 --> Output Class Initialized
INFO - 2025-05-05 07:48:03 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:03 --> Input Class Initialized
INFO - 2025-05-05 07:48:03 --> Language Class Initialized
INFO - 2025-05-05 07:48:03 --> Loader Class Initialized
INFO - 2025-05-05 07:48:03 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:03 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:03 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:03 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:03 --> Controller Class Initialized
INFO - 2025-05-05 07:48:03 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:03 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:03 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:03 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-05 07:48:03 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:03 --> Total execution time: 0.0508
INFO - 2025-05-05 07:48:15 --> Config Class Initialized
INFO - 2025-05-05 07:48:15 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:15 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:15 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:15 --> URI Class Initialized
INFO - 2025-05-05 07:48:15 --> Router Class Initialized
INFO - 2025-05-05 07:48:15 --> Output Class Initialized
INFO - 2025-05-05 07:48:15 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:15 --> Input Class Initialized
INFO - 2025-05-05 07:48:15 --> Language Class Initialized
INFO - 2025-05-05 07:48:15 --> Loader Class Initialized
INFO - 2025-05-05 07:48:15 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:15 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:15 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:15 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:15 --> Controller Class Initialized
INFO - 2025-05-05 07:48:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_rekomendasi.php
INFO - 2025-05-05 07:48:15 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:15 --> Total execution time: 0.0288
INFO - 2025-05-05 07:48:16 --> Config Class Initialized
INFO - 2025-05-05 07:48:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:16 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:16 --> URI Class Initialized
INFO - 2025-05-05 07:48:16 --> Router Class Initialized
INFO - 2025-05-05 07:48:16 --> Output Class Initialized
INFO - 2025-05-05 07:48:16 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:16 --> Input Class Initialized
INFO - 2025-05-05 07:48:16 --> Language Class Initialized
INFO - 2025-05-05 07:48:16 --> Loader Class Initialized
INFO - 2025-05-05 07:48:16 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:16 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:16 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:16 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:16 --> Controller Class Initialized
INFO - 2025-05-05 07:48:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_rekomendasi.php
INFO - 2025-05-05 07:48:16 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:16 --> Total execution time: 0.0269
INFO - 2025-05-05 07:48:16 --> Config Class Initialized
INFO - 2025-05-05 07:48:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:16 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:16 --> URI Class Initialized
INFO - 2025-05-05 07:48:16 --> Router Class Initialized
INFO - 2025-05-05 07:48:16 --> Output Class Initialized
INFO - 2025-05-05 07:48:16 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:16 --> Input Class Initialized
INFO - 2025-05-05 07:48:16 --> Language Class Initialized
INFO - 2025-05-05 07:48:16 --> Loader Class Initialized
INFO - 2025-05-05 07:48:16 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:16 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:16 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:16 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:16 --> Controller Class Initialized
INFO - 2025-05-05 07:48:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_sekolah.php
INFO - 2025-05-05 07:48:16 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:16 --> Total execution time: 0.0309
INFO - 2025-05-05 07:48:17 --> Config Class Initialized
INFO - 2025-05-05 07:48:17 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:17 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:17 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:17 --> URI Class Initialized
INFO - 2025-05-05 07:48:17 --> Router Class Initialized
INFO - 2025-05-05 07:48:17 --> Output Class Initialized
INFO - 2025-05-05 07:48:17 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:17 --> Input Class Initialized
INFO - 2025-05-05 07:48:17 --> Language Class Initialized
INFO - 2025-05-05 07:48:17 --> Loader Class Initialized
INFO - 2025-05-05 07:48:17 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:17 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:17 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:17 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:17 --> Controller Class Initialized
INFO - 2025-05-05 07:48:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-05 07:48:17 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:17 --> Total execution time: 0.0439
INFO - 2025-05-05 07:48:32 --> Config Class Initialized
INFO - 2025-05-05 07:48:32 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:32 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:32 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:32 --> URI Class Initialized
INFO - 2025-05-05 07:48:32 --> Router Class Initialized
INFO - 2025-05-05 07:48:32 --> Output Class Initialized
INFO - 2025-05-05 07:48:32 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:32 --> Input Class Initialized
INFO - 2025-05-05 07:48:32 --> Language Class Initialized
INFO - 2025-05-05 07:48:32 --> Loader Class Initialized
INFO - 2025-05-05 07:48:32 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:32 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:32 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:32 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:32 --> Controller Class Initialized
INFO - 2025-05-05 07:48:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:32 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:32 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:32 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-05 07:48:32 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:32 --> Total execution time: 0.0298
INFO - 2025-05-05 07:48:34 --> Config Class Initialized
INFO - 2025-05-05 07:48:34 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:34 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:34 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:34 --> URI Class Initialized
INFO - 2025-05-05 07:48:34 --> Router Class Initialized
INFO - 2025-05-05 07:48:34 --> Output Class Initialized
INFO - 2025-05-05 07:48:34 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:34 --> Input Class Initialized
INFO - 2025-05-05 07:48:34 --> Language Class Initialized
INFO - 2025-05-05 07:48:34 --> Loader Class Initialized
INFO - 2025-05-05 07:48:34 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:34 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:34 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:34 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:34 --> Controller Class Initialized
INFO - 2025-05-05 07:48:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-05 07:48:34 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:34 --> Total execution time: 0.0330
INFO - 2025-05-05 07:48:43 --> Config Class Initialized
INFO - 2025-05-05 07:48:43 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:43 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:43 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:43 --> URI Class Initialized
INFO - 2025-05-05 07:48:43 --> Router Class Initialized
INFO - 2025-05-05 07:48:43 --> Output Class Initialized
INFO - 2025-05-05 07:48:43 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:43 --> Input Class Initialized
INFO - 2025-05-05 07:48:43 --> Language Class Initialized
INFO - 2025-05-05 07:48:43 --> Loader Class Initialized
INFO - 2025-05-05 07:48:43 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:43 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:43 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:43 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:43 --> Controller Class Initialized
INFO - 2025-05-05 07:48:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-05 07:48:43 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:43 --> Total execution time: 0.0288
INFO - 2025-05-05 07:48:44 --> Config Class Initialized
INFO - 2025-05-05 07:48:44 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:44 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:44 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:44 --> URI Class Initialized
INFO - 2025-05-05 07:48:44 --> Router Class Initialized
INFO - 2025-05-05 07:48:44 --> Output Class Initialized
INFO - 2025-05-05 07:48:44 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:44 --> Input Class Initialized
INFO - 2025-05-05 07:48:44 --> Language Class Initialized
INFO - 2025-05-05 07:48:44 --> Loader Class Initialized
INFO - 2025-05-05 07:48:44 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:44 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:44 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:44 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:44 --> Controller Class Initialized
INFO - 2025-05-05 07:48:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:44 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-05 07:48:44 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:44 --> Total execution time: 0.0272
INFO - 2025-05-05 07:48:45 --> Config Class Initialized
INFO - 2025-05-05 07:48:45 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:45 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:45 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:45 --> URI Class Initialized
INFO - 2025-05-05 07:48:45 --> Router Class Initialized
INFO - 2025-05-05 07:48:45 --> Output Class Initialized
INFO - 2025-05-05 07:48:45 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:45 --> Input Class Initialized
INFO - 2025-05-05 07:48:45 --> Language Class Initialized
INFO - 2025-05-05 07:48:45 --> Loader Class Initialized
INFO - 2025-05-05 07:48:45 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:45 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:45 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:45 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:45 --> Controller Class Initialized
INFO - 2025-05-05 07:48:45 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:45 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:45 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:45 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-05 07:48:45 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:45 --> Total execution time: 0.0294
INFO - 2025-05-05 07:48:47 --> Config Class Initialized
INFO - 2025-05-05 07:48:47 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:48:47 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:48:47 --> Utf8 Class Initialized
INFO - 2025-05-05 07:48:47 --> URI Class Initialized
INFO - 2025-05-05 07:48:47 --> Router Class Initialized
INFO - 2025-05-05 07:48:47 --> Output Class Initialized
INFO - 2025-05-05 07:48:47 --> Security Class Initialized
DEBUG - 2025-05-05 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:48:47 --> Input Class Initialized
INFO - 2025-05-05 07:48:47 --> Language Class Initialized
INFO - 2025-05-05 07:48:47 --> Loader Class Initialized
INFO - 2025-05-05 07:48:47 --> Helper loaded: form_helper
INFO - 2025-05-05 07:48:47 --> Helper loaded: url_helper
INFO - 2025-05-05 07:48:47 --> Database Driver Class Initialized
INFO - 2025-05-05 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:48:47 --> Form Validation Class Initialized
INFO - 2025-05-05 07:48:47 --> Controller Class Initialized
INFO - 2025-05-05 07:48:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:48:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:48:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:48:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-05 07:48:47 --> Final output sent to browser
DEBUG - 2025-05-05 07:48:47 --> Total execution time: 0.0280
INFO - 2025-05-05 07:50:33 --> Config Class Initialized
INFO - 2025-05-05 07:50:33 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:50:33 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:50:33 --> Utf8 Class Initialized
INFO - 2025-05-05 07:50:33 --> URI Class Initialized
INFO - 2025-05-05 07:50:33 --> Router Class Initialized
INFO - 2025-05-05 07:50:33 --> Output Class Initialized
INFO - 2025-05-05 07:50:33 --> Security Class Initialized
DEBUG - 2025-05-05 07:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:50:33 --> Input Class Initialized
INFO - 2025-05-05 07:50:33 --> Language Class Initialized
INFO - 2025-05-05 07:50:33 --> Loader Class Initialized
INFO - 2025-05-05 07:50:33 --> Helper loaded: form_helper
INFO - 2025-05-05 07:50:33 --> Helper loaded: url_helper
INFO - 2025-05-05 07:50:33 --> Database Driver Class Initialized
INFO - 2025-05-05 07:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:50:33 --> Form Validation Class Initialized
INFO - 2025-05-05 07:50:33 --> Controller Class Initialized
INFO - 2025-05-05 07:50:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:50:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:50:33 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/tambah_petugas.php
INFO - 2025-05-05 07:50:33 --> Final output sent to browser
DEBUG - 2025-05-05 07:50:33 --> Total execution time: 0.0277
INFO - 2025-05-05 07:50:34 --> Config Class Initialized
INFO - 2025-05-05 07:50:34 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:50:34 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:50:34 --> Utf8 Class Initialized
INFO - 2025-05-05 07:50:34 --> URI Class Initialized
INFO - 2025-05-05 07:50:34 --> Router Class Initialized
INFO - 2025-05-05 07:50:34 --> Output Class Initialized
INFO - 2025-05-05 07:50:34 --> Security Class Initialized
DEBUG - 2025-05-05 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:50:34 --> Input Class Initialized
INFO - 2025-05-05 07:50:34 --> Language Class Initialized
INFO - 2025-05-05 07:50:34 --> Loader Class Initialized
INFO - 2025-05-05 07:50:34 --> Helper loaded: form_helper
INFO - 2025-05-05 07:50:34 --> Helper loaded: url_helper
INFO - 2025-05-05 07:50:34 --> Database Driver Class Initialized
INFO - 2025-05-05 07:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:50:34 --> Form Validation Class Initialized
INFO - 2025-05-05 07:50:34 --> Controller Class Initialized
INFO - 2025-05-05 07:50:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:50:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:50:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:50:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/pengaturan.php
INFO - 2025-05-05 07:50:34 --> Final output sent to browser
DEBUG - 2025-05-05 07:50:34 --> Total execution time: 0.0279
INFO - 2025-05-05 07:50:35 --> Config Class Initialized
INFO - 2025-05-05 07:50:35 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:50:35 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:50:35 --> Utf8 Class Initialized
INFO - 2025-05-05 07:50:35 --> URI Class Initialized
INFO - 2025-05-05 07:50:35 --> Router Class Initialized
INFO - 2025-05-05 07:50:35 --> Output Class Initialized
INFO - 2025-05-05 07:50:35 --> Security Class Initialized
DEBUG - 2025-05-05 07:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:50:35 --> Input Class Initialized
INFO - 2025-05-05 07:50:35 --> Language Class Initialized
INFO - 2025-05-05 07:50:35 --> Loader Class Initialized
INFO - 2025-05-05 07:50:35 --> Helper loaded: form_helper
INFO - 2025-05-05 07:50:35 --> Helper loaded: url_helper
INFO - 2025-05-05 07:50:35 --> Database Driver Class Initialized
INFO - 2025-05-05 07:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:50:35 --> Form Validation Class Initialized
INFO - 2025-05-05 07:50:35 --> Controller Class Initialized
INFO - 2025-05-05 07:50:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:50:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:50:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:50:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-05 07:50:35 --> Final output sent to browser
DEBUG - 2025-05-05 07:50:35 --> Total execution time: 0.0473
INFO - 2025-05-05 07:50:37 --> Config Class Initialized
INFO - 2025-05-05 07:50:37 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:50:37 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:50:37 --> Utf8 Class Initialized
INFO - 2025-05-05 07:50:37 --> URI Class Initialized
INFO - 2025-05-05 07:50:37 --> Router Class Initialized
INFO - 2025-05-05 07:50:37 --> Output Class Initialized
INFO - 2025-05-05 07:50:37 --> Security Class Initialized
DEBUG - 2025-05-05 07:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:50:37 --> Input Class Initialized
INFO - 2025-05-05 07:50:37 --> Language Class Initialized
INFO - 2025-05-05 07:50:37 --> Loader Class Initialized
INFO - 2025-05-05 07:50:37 --> Helper loaded: form_helper
INFO - 2025-05-05 07:50:37 --> Helper loaded: url_helper
INFO - 2025-05-05 07:50:37 --> Database Driver Class Initialized
INFO - 2025-05-05 07:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:50:37 --> Form Validation Class Initialized
INFO - 2025-05-05 07:50:37 --> Controller Class Initialized
INFO - 2025-05-05 07:50:37 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:50:37 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:50:37 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:50:37 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-05 07:50:37 --> Final output sent to browser
DEBUG - 2025-05-05 07:50:37 --> Total execution time: 0.0329
INFO - 2025-05-05 07:50:37 --> Config Class Initialized
INFO - 2025-05-05 07:50:37 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:50:37 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:50:37 --> Utf8 Class Initialized
INFO - 2025-05-05 07:50:37 --> URI Class Initialized
INFO - 2025-05-05 07:50:37 --> Router Class Initialized
INFO - 2025-05-05 07:50:37 --> Output Class Initialized
INFO - 2025-05-05 07:50:37 --> Security Class Initialized
DEBUG - 2025-05-05 07:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:50:37 --> Input Class Initialized
INFO - 2025-05-05 07:50:37 --> Language Class Initialized
INFO - 2025-05-05 07:50:38 --> Loader Class Initialized
INFO - 2025-05-05 07:50:38 --> Helper loaded: form_helper
INFO - 2025-05-05 07:50:38 --> Helper loaded: url_helper
INFO - 2025-05-05 07:50:38 --> Database Driver Class Initialized
INFO - 2025-05-05 07:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:50:38 --> Form Validation Class Initialized
INFO - 2025-05-05 07:50:38 --> Controller Class Initialized
INFO - 2025-05-05 07:50:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:50:38 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:50:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:50:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_rekomendasi.php
INFO - 2025-05-05 07:50:38 --> Final output sent to browser
DEBUG - 2025-05-05 07:50:38 --> Total execution time: 0.0269
INFO - 2025-05-05 07:50:38 --> Config Class Initialized
INFO - 2025-05-05 07:50:38 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:50:38 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:50:38 --> Utf8 Class Initialized
INFO - 2025-05-05 07:50:38 --> URI Class Initialized
INFO - 2025-05-05 07:50:38 --> Router Class Initialized
INFO - 2025-05-05 07:50:38 --> Output Class Initialized
INFO - 2025-05-05 07:50:38 --> Security Class Initialized
DEBUG - 2025-05-05 07:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:50:38 --> Input Class Initialized
INFO - 2025-05-05 07:50:38 --> Language Class Initialized
INFO - 2025-05-05 07:50:38 --> Loader Class Initialized
INFO - 2025-05-05 07:50:38 --> Helper loaded: form_helper
INFO - 2025-05-05 07:50:38 --> Helper loaded: url_helper
INFO - 2025-05-05 07:50:38 --> Database Driver Class Initialized
INFO - 2025-05-05 07:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:50:38 --> Form Validation Class Initialized
INFO - 2025-05-05 07:50:38 --> Controller Class Initialized
INFO - 2025-05-05 07:50:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-05 07:50:38 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-05 07:50:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-05 07:50:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-05 07:50:38 --> Final output sent to browser
DEBUG - 2025-05-05 07:50:38 --> Total execution time: 0.0250
INFO - 2025-05-05 07:50:40 --> Config Class Initialized
INFO - 2025-05-05 07:50:40 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:50:40 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:50:40 --> Utf8 Class Initialized
INFO - 2025-05-05 07:50:40 --> URI Class Initialized
INFO - 2025-05-05 07:50:40 --> Router Class Initialized
INFO - 2025-05-05 07:50:40 --> Output Class Initialized
INFO - 2025-05-05 07:50:40 --> Security Class Initialized
DEBUG - 2025-05-05 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:50:40 --> Input Class Initialized
INFO - 2025-05-05 07:50:40 --> Language Class Initialized
INFO - 2025-05-05 07:50:40 --> Loader Class Initialized
INFO - 2025-05-05 07:50:40 --> Helper loaded: form_helper
INFO - 2025-05-05 07:50:40 --> Helper loaded: url_helper
INFO - 2025-05-05 07:50:40 --> Database Driver Class Initialized
INFO - 2025-05-05 07:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:50:40 --> Form Validation Class Initialized
INFO - 2025-05-05 07:50:40 --> Controller Class Initialized
INFO - 2025-05-05 07:50:40 --> Config Class Initialized
INFO - 2025-05-05 07:50:40 --> Hooks Class Initialized
DEBUG - 2025-05-05 07:50:40 --> UTF-8 Support Enabled
INFO - 2025-05-05 07:50:40 --> Utf8 Class Initialized
INFO - 2025-05-05 07:50:40 --> URI Class Initialized
INFO - 2025-05-05 07:50:40 --> Router Class Initialized
INFO - 2025-05-05 07:50:40 --> Output Class Initialized
INFO - 2025-05-05 07:50:40 --> Security Class Initialized
DEBUG - 2025-05-05 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 07:50:40 --> Input Class Initialized
INFO - 2025-05-05 07:50:40 --> Language Class Initialized
INFO - 2025-05-05 07:50:40 --> Loader Class Initialized
INFO - 2025-05-05 07:50:40 --> Helper loaded: form_helper
INFO - 2025-05-05 07:50:40 --> Helper loaded: url_helper
INFO - 2025-05-05 07:50:40 --> Database Driver Class Initialized
INFO - 2025-05-05 07:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 07:50:40 --> Form Validation Class Initialized
INFO - 2025-05-05 07:50:40 --> Controller Class Initialized
INFO - 2025-05-05 07:50:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/login.php
INFO - 2025-05-05 07:50:40 --> Final output sent to browser
DEBUG - 2025-05-05 07:50:40 --> Total execution time: 0.0215
INFO - 2025-05-05 11:35:13 --> Config Class Initialized
INFO - 2025-05-05 11:35:13 --> Hooks Class Initialized
DEBUG - 2025-05-05 11:35:13 --> UTF-8 Support Enabled
INFO - 2025-05-05 11:35:13 --> Utf8 Class Initialized
INFO - 2025-05-05 11:35:13 --> URI Class Initialized
DEBUG - 2025-05-05 11:35:13 --> No URI present. Default controller set.
INFO - 2025-05-05 11:35:13 --> Router Class Initialized
INFO - 2025-05-05 11:35:13 --> Output Class Initialized
INFO - 2025-05-05 11:35:13 --> Security Class Initialized
DEBUG - 2025-05-05 11:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 11:35:13 --> Input Class Initialized
INFO - 2025-05-05 11:35:13 --> Language Class Initialized
INFO - 2025-05-05 11:35:13 --> Loader Class Initialized
INFO - 2025-05-05 11:35:13 --> Helper loaded: form_helper
INFO - 2025-05-05 11:35:13 --> Helper loaded: url_helper
INFO - 2025-05-05 11:35:13 --> Database Driver Class Initialized
INFO - 2025-05-05 11:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 11:35:13 --> Form Validation Class Initialized
INFO - 2025-05-05 11:35:13 --> Controller Class Initialized
INFO - 2025-05-05 11:35:13 --> Final output sent to browser
DEBUG - 2025-05-05 11:35:13 --> Total execution time: 0.0257
INFO - 2025-05-05 11:35:16 --> Config Class Initialized
INFO - 2025-05-05 11:35:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 11:35:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 11:35:16 --> Utf8 Class Initialized
INFO - 2025-05-05 11:35:16 --> URI Class Initialized
INFO - 2025-05-05 11:35:16 --> Router Class Initialized
INFO - 2025-05-05 11:35:16 --> Output Class Initialized
INFO - 2025-05-05 11:35:16 --> Security Class Initialized
DEBUG - 2025-05-05 11:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 11:35:16 --> Input Class Initialized
INFO - 2025-05-05 11:35:16 --> Language Class Initialized
INFO - 2025-05-05 11:35:16 --> Loader Class Initialized
INFO - 2025-05-05 11:35:16 --> Helper loaded: form_helper
INFO - 2025-05-05 11:35:16 --> Helper loaded: url_helper
INFO - 2025-05-05 11:35:16 --> Database Driver Class Initialized
INFO - 2025-05-05 11:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 11:35:16 --> Form Validation Class Initialized
INFO - 2025-05-05 11:35:16 --> Controller Class Initialized
INFO - 2025-05-05 11:35:16 --> Config Class Initialized
INFO - 2025-05-05 11:35:16 --> Hooks Class Initialized
DEBUG - 2025-05-05 11:35:16 --> UTF-8 Support Enabled
INFO - 2025-05-05 11:35:16 --> Utf8 Class Initialized
INFO - 2025-05-05 11:35:16 --> URI Class Initialized
INFO - 2025-05-05 11:35:16 --> Router Class Initialized
INFO - 2025-05-05 11:35:16 --> Output Class Initialized
INFO - 2025-05-05 11:35:16 --> Security Class Initialized
DEBUG - 2025-05-05 11:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 11:35:16 --> Input Class Initialized
INFO - 2025-05-05 11:35:16 --> Language Class Initialized
INFO - 2025-05-05 11:35:16 --> Loader Class Initialized
INFO - 2025-05-05 11:35:16 --> Helper loaded: form_helper
INFO - 2025-05-05 11:35:16 --> Helper loaded: url_helper
INFO - 2025-05-05 11:35:16 --> Database Driver Class Initialized
INFO - 2025-05-05 11:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 11:35:16 --> Form Validation Class Initialized
INFO - 2025-05-05 11:35:16 --> Controller Class Initialized
INFO - 2025-05-05 11:35:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/login.php
INFO - 2025-05-05 11:35:16 --> Final output sent to browser
DEBUG - 2025-05-05 11:35:16 --> Total execution time: 0.0241
INFO - 2025-05-05 11:35:19 --> Config Class Initialized
INFO - 2025-05-05 11:35:19 --> Hooks Class Initialized
DEBUG - 2025-05-05 11:35:19 --> UTF-8 Support Enabled
INFO - 2025-05-05 11:35:19 --> Utf8 Class Initialized
INFO - 2025-05-05 11:35:19 --> URI Class Initialized
INFO - 2025-05-05 11:35:19 --> Router Class Initialized
INFO - 2025-05-05 11:35:19 --> Output Class Initialized
INFO - 2025-05-05 11:35:19 --> Security Class Initialized
DEBUG - 2025-05-05 11:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-05 11:35:19 --> Input Class Initialized
INFO - 2025-05-05 11:35:19 --> Language Class Initialized
INFO - 2025-05-05 11:35:19 --> Loader Class Initialized
INFO - 2025-05-05 11:35:19 --> Helper loaded: form_helper
INFO - 2025-05-05 11:35:19 --> Helper loaded: url_helper
INFO - 2025-05-05 11:35:19 --> Database Driver Class Initialized
INFO - 2025-05-05 11:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-05 11:35:19 --> Form Validation Class Initialized
INFO - 2025-05-05 11:35:19 --> Controller Class Initialized
DEBUG - 2025-05-05 11:35:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-05 11:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-05 11:35:19 --> Model "Ppdb_model" initialized
INFO - 2025-05-05 11:35:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-05 11:35:19 --> Final output sent to browser
DEBUG - 2025-05-05 11:35:19 --> Total execution time: 0.0243
