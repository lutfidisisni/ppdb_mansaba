<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-06 06:13:34 --> Config Class Initialized
INFO - 2025-05-06 06:13:34 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:34 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:34 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:34 --> URI Class Initialized
DEBUG - 2025-05-06 06:13:34 --> No URI present. Default controller set.
INFO - 2025-05-06 06:13:34 --> Router Class Initialized
INFO - 2025-05-06 06:13:34 --> Output Class Initialized
INFO - 2025-05-06 06:13:34 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:34 --> Input Class Initialized
INFO - 2025-05-06 06:13:34 --> Language Class Initialized
INFO - 2025-05-06 06:13:35 --> Loader Class Initialized
INFO - 2025-05-06 06:13:35 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:35 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:35 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:35 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:35 --> Controller Class Initialized
INFO - 2025-05-06 06:13:35 --> Final output sent to browser
DEBUG - 2025-05-06 06:13:35 --> Total execution time: 0.8227
INFO - 2025-05-06 06:13:38 --> Config Class Initialized
INFO - 2025-05-06 06:13:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:38 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:38 --> URI Class Initialized
INFO - 2025-05-06 06:13:38 --> Router Class Initialized
INFO - 2025-05-06 06:13:38 --> Output Class Initialized
INFO - 2025-05-06 06:13:38 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:38 --> Input Class Initialized
INFO - 2025-05-06 06:13:38 --> Language Class Initialized
INFO - 2025-05-06 06:13:38 --> Loader Class Initialized
INFO - 2025-05-06 06:13:38 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:38 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:38 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:38 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:38 --> Controller Class Initialized
INFO - 2025-05-06 06:13:38 --> Config Class Initialized
INFO - 2025-05-06 06:13:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:38 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:38 --> URI Class Initialized
INFO - 2025-05-06 06:13:38 --> Router Class Initialized
INFO - 2025-05-06 06:13:38 --> Output Class Initialized
INFO - 2025-05-06 06:13:38 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:38 --> Input Class Initialized
INFO - 2025-05-06 06:13:38 --> Language Class Initialized
INFO - 2025-05-06 06:13:38 --> Loader Class Initialized
INFO - 2025-05-06 06:13:38 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:38 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:38 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:38 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:38 --> Controller Class Initialized
INFO - 2025-05-06 06:13:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/login.php
INFO - 2025-05-06 06:13:38 --> Final output sent to browser
DEBUG - 2025-05-06 06:13:38 --> Total execution time: 0.0611
INFO - 2025-05-06 06:13:39 --> Config Class Initialized
INFO - 2025-05-06 06:13:39 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:39 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:39 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:39 --> URI Class Initialized
INFO - 2025-05-06 06:13:39 --> Router Class Initialized
INFO - 2025-05-06 06:13:39 --> Output Class Initialized
INFO - 2025-05-06 06:13:39 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:39 --> Input Class Initialized
INFO - 2025-05-06 06:13:39 --> Language Class Initialized
INFO - 2025-05-06 06:13:39 --> Loader Class Initialized
INFO - 2025-05-06 06:13:39 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:39 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:39 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:39 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:39 --> Controller Class Initialized
INFO - 2025-05-06 06:13:39 --> Config Class Initialized
INFO - 2025-05-06 06:13:39 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:39 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:39 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:39 --> URI Class Initialized
INFO - 2025-05-06 06:13:39 --> Router Class Initialized
INFO - 2025-05-06 06:13:39 --> Output Class Initialized
INFO - 2025-05-06 06:13:39 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:39 --> Input Class Initialized
INFO - 2025-05-06 06:13:39 --> Language Class Initialized
INFO - 2025-05-06 06:13:39 --> Loader Class Initialized
INFO - 2025-05-06 06:13:39 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:39 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:39 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:39 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:39 --> Controller Class Initialized
INFO - 2025-05-06 06:13:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:13:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:13:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:13:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 06:13:39 --> Final output sent to browser
DEBUG - 2025-05-06 06:13:39 --> Total execution time: 0.2319
INFO - 2025-05-06 06:13:41 --> Config Class Initialized
INFO - 2025-05-06 06:13:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:41 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:41 --> URI Class Initialized
INFO - 2025-05-06 06:13:41 --> Router Class Initialized
INFO - 2025-05-06 06:13:41 --> Output Class Initialized
INFO - 2025-05-06 06:13:41 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:41 --> Input Class Initialized
INFO - 2025-05-06 06:13:41 --> Language Class Initialized
INFO - 2025-05-06 06:13:41 --> Loader Class Initialized
INFO - 2025-05-06 06:13:41 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:41 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:41 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:41 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:41 --> Controller Class Initialized
INFO - 2025-05-06 06:13:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:13:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:13:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:13:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-06 06:13:41 --> Final output sent to browser
DEBUG - 2025-05-06 06:13:41 --> Total execution time: 0.0858
INFO - 2025-05-06 06:13:43 --> Config Class Initialized
INFO - 2025-05-06 06:13:43 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:43 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:43 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:43 --> URI Class Initialized
INFO - 2025-05-06 06:13:43 --> Router Class Initialized
INFO - 2025-05-06 06:13:43 --> Output Class Initialized
INFO - 2025-05-06 06:13:43 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:43 --> Input Class Initialized
INFO - 2025-05-06 06:13:43 --> Language Class Initialized
INFO - 2025-05-06 06:13:43 --> Loader Class Initialized
INFO - 2025-05-06 06:13:43 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:43 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:43 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:43 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:43 --> Controller Class Initialized
INFO - 2025-05-06 06:13:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:13:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:13:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:13:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-06 06:13:43 --> Final output sent to browser
DEBUG - 2025-05-06 06:13:43 --> Total execution time: 0.0823
INFO - 2025-05-06 06:13:47 --> Config Class Initialized
INFO - 2025-05-06 06:13:47 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:47 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:47 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:47 --> URI Class Initialized
INFO - 2025-05-06 06:13:47 --> Router Class Initialized
INFO - 2025-05-06 06:13:47 --> Output Class Initialized
INFO - 2025-05-06 06:13:47 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:47 --> Input Class Initialized
INFO - 2025-05-06 06:13:47 --> Language Class Initialized
INFO - 2025-05-06 06:13:47 --> Loader Class Initialized
INFO - 2025-05-06 06:13:47 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:47 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:47 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:47 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:47 --> Controller Class Initialized
INFO - 2025-05-06 06:13:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:13:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:13:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:13:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-06 06:13:47 --> Final output sent to browser
DEBUG - 2025-05-06 06:13:47 --> Total execution time: 0.1159
INFO - 2025-05-06 06:13:48 --> Config Class Initialized
INFO - 2025-05-06 06:13:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:48 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:48 --> URI Class Initialized
INFO - 2025-05-06 06:13:48 --> Router Class Initialized
INFO - 2025-05-06 06:13:48 --> Output Class Initialized
INFO - 2025-05-06 06:13:48 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:48 --> Input Class Initialized
INFO - 2025-05-06 06:13:48 --> Language Class Initialized
INFO - 2025-05-06 06:13:48 --> Loader Class Initialized
INFO - 2025-05-06 06:13:48 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:48 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:48 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:48 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:48 --> Controller Class Initialized
INFO - 2025-05-06 06:13:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:13:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:13:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:13:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:13:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-06 06:13:49 --> Final output sent to browser
DEBUG - 2025-05-06 06:13:49 --> Total execution time: 0.1840
INFO - 2025-05-06 06:13:56 --> Config Class Initialized
INFO - 2025-05-06 06:13:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:13:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:13:56 --> Utf8 Class Initialized
INFO - 2025-05-06 06:13:56 --> URI Class Initialized
INFO - 2025-05-06 06:13:56 --> Router Class Initialized
INFO - 2025-05-06 06:13:56 --> Output Class Initialized
INFO - 2025-05-06 06:13:56 --> Security Class Initialized
DEBUG - 2025-05-06 06:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:13:56 --> Input Class Initialized
INFO - 2025-05-06 06:13:56 --> Language Class Initialized
INFO - 2025-05-06 06:13:56 --> Loader Class Initialized
INFO - 2025-05-06 06:13:56 --> Helper loaded: form_helper
INFO - 2025-05-06 06:13:56 --> Helper loaded: url_helper
INFO - 2025-05-06 06:13:56 --> Database Driver Class Initialized
INFO - 2025-05-06 06:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:13:56 --> Form Validation Class Initialized
INFO - 2025-05-06 06:13:56 --> Controller Class Initialized
INFO - 2025-05-06 06:13:56 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:13:56 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:13:56 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:13:56 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:13:56 --> Final output sent to browser
DEBUG - 2025-05-06 06:13:56 --> Total execution time: 0.1153
INFO - 2025-05-06 06:14:03 --> Config Class Initialized
INFO - 2025-05-06 06:14:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:14:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:14:03 --> Utf8 Class Initialized
INFO - 2025-05-06 06:14:03 --> URI Class Initialized
INFO - 2025-05-06 06:14:03 --> Router Class Initialized
INFO - 2025-05-06 06:14:03 --> Output Class Initialized
INFO - 2025-05-06 06:14:03 --> Security Class Initialized
DEBUG - 2025-05-06 06:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:14:03 --> Input Class Initialized
INFO - 2025-05-06 06:14:03 --> Language Class Initialized
INFO - 2025-05-06 06:14:03 --> Loader Class Initialized
INFO - 2025-05-06 06:14:03 --> Helper loaded: form_helper
INFO - 2025-05-06 06:14:03 --> Helper loaded: url_helper
INFO - 2025-05-06 06:14:03 --> Database Driver Class Initialized
INFO - 2025-05-06 06:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:14:03 --> Form Validation Class Initialized
INFO - 2025-05-06 06:14:03 --> Controller Class Initialized
INFO - 2025-05-06 06:14:03 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:14:03 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:14:03 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:14:03 --> Final output sent to browser
DEBUG - 2025-05-06 06:14:03 --> Total execution time: 0.2623
INFO - 2025-05-06 06:14:16 --> Config Class Initialized
INFO - 2025-05-06 06:14:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:14:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:14:16 --> Utf8 Class Initialized
INFO - 2025-05-06 06:14:16 --> URI Class Initialized
INFO - 2025-05-06 06:14:16 --> Router Class Initialized
INFO - 2025-05-06 06:14:16 --> Output Class Initialized
INFO - 2025-05-06 06:14:16 --> Security Class Initialized
DEBUG - 2025-05-06 06:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:14:16 --> Input Class Initialized
INFO - 2025-05-06 06:14:16 --> Language Class Initialized
INFO - 2025-05-06 06:14:16 --> Loader Class Initialized
INFO - 2025-05-06 06:14:16 --> Helper loaded: form_helper
INFO - 2025-05-06 06:14:16 --> Helper loaded: url_helper
INFO - 2025-05-06 06:14:16 --> Database Driver Class Initialized
INFO - 2025-05-06 06:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:14:16 --> Form Validation Class Initialized
INFO - 2025-05-06 06:14:16 --> Controller Class Initialized
INFO - 2025-05-06 06:14:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:14:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:14:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:14:16 --> Config Class Initialized
INFO - 2025-05-06 06:14:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:14:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:14:16 --> Utf8 Class Initialized
INFO - 2025-05-06 06:14:16 --> URI Class Initialized
INFO - 2025-05-06 06:14:16 --> Router Class Initialized
INFO - 2025-05-06 06:14:16 --> Output Class Initialized
INFO - 2025-05-06 06:14:16 --> Security Class Initialized
DEBUG - 2025-05-06 06:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:14:16 --> Input Class Initialized
INFO - 2025-05-06 06:14:16 --> Language Class Initialized
INFO - 2025-05-06 06:14:16 --> Loader Class Initialized
INFO - 2025-05-06 06:14:16 --> Helper loaded: form_helper
INFO - 2025-05-06 06:14:16 --> Helper loaded: url_helper
INFO - 2025-05-06 06:14:16 --> Database Driver Class Initialized
INFO - 2025-05-06 06:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:14:16 --> Form Validation Class Initialized
INFO - 2025-05-06 06:14:16 --> Controller Class Initialized
INFO - 2025-05-06 06:14:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:14:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:14:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:14:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:14:16 --> Final output sent to browser
DEBUG - 2025-05-06 06:14:16 --> Total execution time: 0.0324
INFO - 2025-05-06 06:14:38 --> Config Class Initialized
INFO - 2025-05-06 06:14:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:14:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:14:38 --> Utf8 Class Initialized
INFO - 2025-05-06 06:14:38 --> URI Class Initialized
INFO - 2025-05-06 06:14:38 --> Router Class Initialized
INFO - 2025-05-06 06:14:38 --> Output Class Initialized
INFO - 2025-05-06 06:14:38 --> Security Class Initialized
DEBUG - 2025-05-06 06:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:14:38 --> Input Class Initialized
INFO - 2025-05-06 06:14:38 --> Language Class Initialized
INFO - 2025-05-06 06:14:38 --> Loader Class Initialized
INFO - 2025-05-06 06:14:38 --> Helper loaded: form_helper
INFO - 2025-05-06 06:14:38 --> Helper loaded: url_helper
INFO - 2025-05-06 06:14:38 --> Database Driver Class Initialized
INFO - 2025-05-06 06:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:14:38 --> Form Validation Class Initialized
INFO - 2025-05-06 06:14:38 --> Controller Class Initialized
INFO - 2025-05-06 06:14:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:14:38 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:14:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:14:38 --> Final output sent to browser
DEBUG - 2025-05-06 06:14:38 --> Total execution time: 0.0271
INFO - 2025-05-06 06:14:42 --> Config Class Initialized
INFO - 2025-05-06 06:14:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:14:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:14:42 --> Utf8 Class Initialized
INFO - 2025-05-06 06:14:42 --> URI Class Initialized
INFO - 2025-05-06 06:14:42 --> Router Class Initialized
INFO - 2025-05-06 06:14:42 --> Output Class Initialized
INFO - 2025-05-06 06:14:42 --> Security Class Initialized
DEBUG - 2025-05-06 06:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:14:42 --> Input Class Initialized
INFO - 2025-05-06 06:14:42 --> Language Class Initialized
INFO - 2025-05-06 06:14:42 --> Loader Class Initialized
INFO - 2025-05-06 06:14:42 --> Helper loaded: form_helper
INFO - 2025-05-06 06:14:42 --> Helper loaded: url_helper
INFO - 2025-05-06 06:14:42 --> Database Driver Class Initialized
INFO - 2025-05-06 06:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:14:42 --> Form Validation Class Initialized
INFO - 2025-05-06 06:14:42 --> Controller Class Initialized
INFO - 2025-05-06 06:14:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:14:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:14:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:14:42 --> Config Class Initialized
INFO - 2025-05-06 06:14:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:14:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:14:42 --> Utf8 Class Initialized
INFO - 2025-05-06 06:14:42 --> URI Class Initialized
INFO - 2025-05-06 06:14:42 --> Router Class Initialized
INFO - 2025-05-06 06:14:42 --> Output Class Initialized
INFO - 2025-05-06 06:14:42 --> Security Class Initialized
DEBUG - 2025-05-06 06:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:14:42 --> Input Class Initialized
INFO - 2025-05-06 06:14:42 --> Language Class Initialized
INFO - 2025-05-06 06:14:42 --> Loader Class Initialized
INFO - 2025-05-06 06:14:42 --> Helper loaded: form_helper
INFO - 2025-05-06 06:14:42 --> Helper loaded: url_helper
INFO - 2025-05-06 06:14:42 --> Database Driver Class Initialized
INFO - 2025-05-06 06:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:14:42 --> Form Validation Class Initialized
INFO - 2025-05-06 06:14:42 --> Controller Class Initialized
INFO - 2025-05-06 06:14:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:14:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:14:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:14:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:14:42 --> Final output sent to browser
DEBUG - 2025-05-06 06:14:42 --> Total execution time: 0.0348
INFO - 2025-05-06 06:15:20 --> Config Class Initialized
INFO - 2025-05-06 06:15:20 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:15:20 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:15:20 --> Utf8 Class Initialized
INFO - 2025-05-06 06:15:20 --> URI Class Initialized
INFO - 2025-05-06 06:15:20 --> Router Class Initialized
INFO - 2025-05-06 06:15:20 --> Output Class Initialized
INFO - 2025-05-06 06:15:20 --> Security Class Initialized
DEBUG - 2025-05-06 06:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:15:20 --> Input Class Initialized
INFO - 2025-05-06 06:15:20 --> Language Class Initialized
INFO - 2025-05-06 06:15:20 --> Loader Class Initialized
INFO - 2025-05-06 06:15:20 --> Helper loaded: form_helper
INFO - 2025-05-06 06:15:20 --> Helper loaded: url_helper
INFO - 2025-05-06 06:15:20 --> Database Driver Class Initialized
INFO - 2025-05-06 06:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:15:20 --> Form Validation Class Initialized
INFO - 2025-05-06 06:15:20 --> Controller Class Initialized
INFO - 2025-05-06 06:15:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:15:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:15:20 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:15:20 --> Final output sent to browser
DEBUG - 2025-05-06 06:15:20 --> Total execution time: 0.0267
INFO - 2025-05-06 06:16:35 --> Config Class Initialized
INFO - 2025-05-06 06:16:35 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:16:35 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:16:35 --> Utf8 Class Initialized
INFO - 2025-05-06 06:16:35 --> URI Class Initialized
DEBUG - 2025-05-06 06:16:35 --> No URI present. Default controller set.
INFO - 2025-05-06 06:16:35 --> Router Class Initialized
INFO - 2025-05-06 06:16:35 --> Output Class Initialized
INFO - 2025-05-06 06:16:35 --> Security Class Initialized
DEBUG - 2025-05-06 06:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:16:35 --> Input Class Initialized
INFO - 2025-05-06 06:16:35 --> Language Class Initialized
INFO - 2025-05-06 06:16:35 --> Loader Class Initialized
INFO - 2025-05-06 06:16:35 --> Helper loaded: form_helper
INFO - 2025-05-06 06:16:35 --> Helper loaded: url_helper
INFO - 2025-05-06 06:16:35 --> Database Driver Class Initialized
INFO - 2025-05-06 06:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:16:35 --> Form Validation Class Initialized
INFO - 2025-05-06 06:16:35 --> Controller Class Initialized
INFO - 2025-05-06 06:16:35 --> Final output sent to browser
DEBUG - 2025-05-06 06:16:35 --> Total execution time: 0.0239
INFO - 2025-05-06 06:16:43 --> Config Class Initialized
INFO - 2025-05-06 06:16:43 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:16:43 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:16:43 --> Utf8 Class Initialized
INFO - 2025-05-06 06:16:43 --> URI Class Initialized
INFO - 2025-05-06 06:16:43 --> Router Class Initialized
INFO - 2025-05-06 06:16:43 --> Output Class Initialized
INFO - 2025-05-06 06:16:43 --> Security Class Initialized
DEBUG - 2025-05-06 06:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:16:43 --> Input Class Initialized
INFO - 2025-05-06 06:16:43 --> Language Class Initialized
INFO - 2025-05-06 06:16:43 --> Loader Class Initialized
INFO - 2025-05-06 06:16:43 --> Helper loaded: form_helper
INFO - 2025-05-06 06:16:43 --> Helper loaded: url_helper
INFO - 2025-05-06 06:16:43 --> Database Driver Class Initialized
INFO - 2025-05-06 06:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:16:43 --> Form Validation Class Initialized
INFO - 2025-05-06 06:16:43 --> Controller Class Initialized
INFO - 2025-05-06 06:16:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:16:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:16:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:16:43 --> Config Class Initialized
INFO - 2025-05-06 06:16:43 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:16:43 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:16:43 --> Utf8 Class Initialized
INFO - 2025-05-06 06:16:43 --> URI Class Initialized
INFO - 2025-05-06 06:16:43 --> Router Class Initialized
INFO - 2025-05-06 06:16:43 --> Output Class Initialized
INFO - 2025-05-06 06:16:43 --> Security Class Initialized
DEBUG - 2025-05-06 06:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:16:43 --> Input Class Initialized
INFO - 2025-05-06 06:16:43 --> Language Class Initialized
INFO - 2025-05-06 06:16:43 --> Loader Class Initialized
INFO - 2025-05-06 06:16:43 --> Helper loaded: form_helper
INFO - 2025-05-06 06:16:43 --> Helper loaded: url_helper
INFO - 2025-05-06 06:16:43 --> Database Driver Class Initialized
INFO - 2025-05-06 06:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:16:43 --> Form Validation Class Initialized
INFO - 2025-05-06 06:16:43 --> Controller Class Initialized
INFO - 2025-05-06 06:16:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:16:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:16:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:16:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:16:43 --> Final output sent to browser
DEBUG - 2025-05-06 06:16:43 --> Total execution time: 0.0356
INFO - 2025-05-06 06:16:51 --> Config Class Initialized
INFO - 2025-05-06 06:16:51 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:16:51 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:16:51 --> Utf8 Class Initialized
INFO - 2025-05-06 06:16:51 --> URI Class Initialized
INFO - 2025-05-06 06:16:51 --> Router Class Initialized
INFO - 2025-05-06 06:16:51 --> Output Class Initialized
INFO - 2025-05-06 06:16:51 --> Security Class Initialized
DEBUG - 2025-05-06 06:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:16:51 --> Input Class Initialized
INFO - 2025-05-06 06:16:51 --> Language Class Initialized
INFO - 2025-05-06 06:16:51 --> Loader Class Initialized
INFO - 2025-05-06 06:16:51 --> Helper loaded: form_helper
INFO - 2025-05-06 06:16:51 --> Helper loaded: url_helper
INFO - 2025-05-06 06:16:51 --> Database Driver Class Initialized
INFO - 2025-05-06 06:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:16:51 --> Form Validation Class Initialized
INFO - 2025-05-06 06:16:51 --> Controller Class Initialized
INFO - 2025-05-06 06:16:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:16:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:16:51 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:16:51 --> Final output sent to browser
DEBUG - 2025-05-06 06:16:51 --> Total execution time: 0.0322
INFO - 2025-05-06 06:17:06 --> Config Class Initialized
INFO - 2025-05-06 06:17:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:17:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:17:06 --> Utf8 Class Initialized
INFO - 2025-05-06 06:17:06 --> URI Class Initialized
INFO - 2025-05-06 06:17:06 --> Router Class Initialized
INFO - 2025-05-06 06:17:06 --> Output Class Initialized
INFO - 2025-05-06 06:17:06 --> Security Class Initialized
DEBUG - 2025-05-06 06:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:17:06 --> Input Class Initialized
INFO - 2025-05-06 06:17:06 --> Language Class Initialized
INFO - 2025-05-06 06:17:06 --> Loader Class Initialized
INFO - 2025-05-06 06:17:06 --> Helper loaded: form_helper
INFO - 2025-05-06 06:17:06 --> Helper loaded: url_helper
INFO - 2025-05-06 06:17:06 --> Database Driver Class Initialized
INFO - 2025-05-06 06:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:17:06 --> Form Validation Class Initialized
INFO - 2025-05-06 06:17:06 --> Controller Class Initialized
INFO - 2025-05-06 06:17:06 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:17:06 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:17:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:17:06 --> Config Class Initialized
INFO - 2025-05-06 06:17:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:17:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:17:06 --> Utf8 Class Initialized
INFO - 2025-05-06 06:17:06 --> URI Class Initialized
INFO - 2025-05-06 06:17:06 --> Router Class Initialized
INFO - 2025-05-06 06:17:06 --> Output Class Initialized
INFO - 2025-05-06 06:17:06 --> Security Class Initialized
DEBUG - 2025-05-06 06:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:17:06 --> Input Class Initialized
INFO - 2025-05-06 06:17:06 --> Language Class Initialized
INFO - 2025-05-06 06:17:06 --> Loader Class Initialized
INFO - 2025-05-06 06:17:06 --> Helper loaded: form_helper
INFO - 2025-05-06 06:17:06 --> Helper loaded: url_helper
INFO - 2025-05-06 06:17:06 --> Database Driver Class Initialized
INFO - 2025-05-06 06:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:17:06 --> Form Validation Class Initialized
INFO - 2025-05-06 06:17:06 --> Controller Class Initialized
INFO - 2025-05-06 06:17:06 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:17:06 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:17:06 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:17:06 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:17:06 --> Final output sent to browser
DEBUG - 2025-05-06 06:17:06 --> Total execution time: 0.0348
INFO - 2025-05-06 06:19:40 --> Config Class Initialized
INFO - 2025-05-06 06:19:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:19:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:19:40 --> Utf8 Class Initialized
INFO - 2025-05-06 06:19:40 --> URI Class Initialized
INFO - 2025-05-06 06:19:40 --> Router Class Initialized
INFO - 2025-05-06 06:19:40 --> Output Class Initialized
INFO - 2025-05-06 06:19:40 --> Security Class Initialized
DEBUG - 2025-05-06 06:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:19:40 --> Input Class Initialized
INFO - 2025-05-06 06:19:40 --> Language Class Initialized
INFO - 2025-05-06 06:19:40 --> Loader Class Initialized
INFO - 2025-05-06 06:19:40 --> Helper loaded: form_helper
INFO - 2025-05-06 06:19:40 --> Helper loaded: url_helper
INFO - 2025-05-06 06:19:40 --> Database Driver Class Initialized
INFO - 2025-05-06 06:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:19:40 --> Form Validation Class Initialized
INFO - 2025-05-06 06:19:40 --> Controller Class Initialized
INFO - 2025-05-06 06:19:40 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:19:40 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:19:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:19:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:19:40 --> Final output sent to browser
DEBUG - 2025-05-06 06:19:40 --> Total execution time: 0.1436
INFO - 2025-05-06 06:19:46 --> Config Class Initialized
INFO - 2025-05-06 06:19:46 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:19:46 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:19:46 --> Utf8 Class Initialized
INFO - 2025-05-06 06:19:46 --> URI Class Initialized
INFO - 2025-05-06 06:19:46 --> Router Class Initialized
INFO - 2025-05-06 06:19:46 --> Output Class Initialized
INFO - 2025-05-06 06:19:46 --> Security Class Initialized
DEBUG - 2025-05-06 06:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:19:46 --> Input Class Initialized
INFO - 2025-05-06 06:19:46 --> Language Class Initialized
INFO - 2025-05-06 06:19:47 --> Loader Class Initialized
INFO - 2025-05-06 06:19:47 --> Helper loaded: form_helper
INFO - 2025-05-06 06:19:47 --> Helper loaded: url_helper
INFO - 2025-05-06 06:19:47 --> Database Driver Class Initialized
INFO - 2025-05-06 06:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:19:47 --> Form Validation Class Initialized
INFO - 2025-05-06 06:19:47 --> Controller Class Initialized
INFO - 2025-05-06 06:19:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:19:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:19:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:19:47 --> Final output sent to browser
DEBUG - 2025-05-06 06:19:47 --> Total execution time: 0.0362
INFO - 2025-05-06 06:19:51 --> Config Class Initialized
INFO - 2025-05-06 06:19:51 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:19:51 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:19:51 --> Utf8 Class Initialized
INFO - 2025-05-06 06:19:51 --> URI Class Initialized
INFO - 2025-05-06 06:19:51 --> Router Class Initialized
INFO - 2025-05-06 06:19:51 --> Output Class Initialized
INFO - 2025-05-06 06:19:51 --> Security Class Initialized
DEBUG - 2025-05-06 06:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:19:51 --> Input Class Initialized
INFO - 2025-05-06 06:19:51 --> Language Class Initialized
INFO - 2025-05-06 06:19:51 --> Loader Class Initialized
INFO - 2025-05-06 06:19:51 --> Helper loaded: form_helper
INFO - 2025-05-06 06:19:51 --> Helper loaded: url_helper
INFO - 2025-05-06 06:19:51 --> Database Driver Class Initialized
INFO - 2025-05-06 06:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:19:51 --> Form Validation Class Initialized
INFO - 2025-05-06 06:19:51 --> Controller Class Initialized
INFO - 2025-05-06 06:19:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:19:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:19:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:19:51 --> Config Class Initialized
INFO - 2025-05-06 06:19:51 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:19:51 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:19:51 --> Utf8 Class Initialized
INFO - 2025-05-06 06:19:51 --> URI Class Initialized
INFO - 2025-05-06 06:19:51 --> Router Class Initialized
INFO - 2025-05-06 06:19:51 --> Output Class Initialized
INFO - 2025-05-06 06:19:51 --> Security Class Initialized
DEBUG - 2025-05-06 06:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:19:51 --> Input Class Initialized
INFO - 2025-05-06 06:19:51 --> Language Class Initialized
INFO - 2025-05-06 06:19:51 --> Loader Class Initialized
INFO - 2025-05-06 06:19:51 --> Helper loaded: form_helper
INFO - 2025-05-06 06:19:51 --> Helper loaded: url_helper
INFO - 2025-05-06 06:19:51 --> Database Driver Class Initialized
INFO - 2025-05-06 06:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:19:51 --> Form Validation Class Initialized
INFO - 2025-05-06 06:19:51 --> Controller Class Initialized
INFO - 2025-05-06 06:19:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:19:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:19:51 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:19:51 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:19:51 --> Final output sent to browser
DEBUG - 2025-05-06 06:19:51 --> Total execution time: 0.0428
INFO - 2025-05-06 06:19:55 --> Config Class Initialized
INFO - 2025-05-06 06:19:55 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:19:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:19:55 --> Utf8 Class Initialized
INFO - 2025-05-06 06:19:55 --> URI Class Initialized
INFO - 2025-05-06 06:19:55 --> Router Class Initialized
INFO - 2025-05-06 06:19:55 --> Output Class Initialized
INFO - 2025-05-06 06:19:55 --> Security Class Initialized
DEBUG - 2025-05-06 06:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:19:55 --> Input Class Initialized
INFO - 2025-05-06 06:19:55 --> Language Class Initialized
INFO - 2025-05-06 06:19:55 --> Loader Class Initialized
INFO - 2025-05-06 06:19:55 --> Helper loaded: form_helper
INFO - 2025-05-06 06:19:55 --> Helper loaded: url_helper
INFO - 2025-05-06 06:19:55 --> Database Driver Class Initialized
INFO - 2025-05-06 06:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:19:55 --> Form Validation Class Initialized
INFO - 2025-05-06 06:19:55 --> Controller Class Initialized
INFO - 2025-05-06 06:19:55 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:19:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:19:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:19:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:19:55 --> Final output sent to browser
DEBUG - 2025-05-06 06:19:55 --> Total execution time: 0.0345
INFO - 2025-05-06 06:20:05 --> Config Class Initialized
INFO - 2025-05-06 06:20:05 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:20:05 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:20:05 --> Utf8 Class Initialized
INFO - 2025-05-06 06:20:05 --> URI Class Initialized
INFO - 2025-05-06 06:20:05 --> Router Class Initialized
INFO - 2025-05-06 06:20:05 --> Output Class Initialized
INFO - 2025-05-06 06:20:05 --> Security Class Initialized
DEBUG - 2025-05-06 06:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:20:05 --> Input Class Initialized
INFO - 2025-05-06 06:20:05 --> Language Class Initialized
INFO - 2025-05-06 06:20:05 --> Loader Class Initialized
INFO - 2025-05-06 06:20:05 --> Helper loaded: form_helper
INFO - 2025-05-06 06:20:05 --> Helper loaded: url_helper
INFO - 2025-05-06 06:20:05 --> Database Driver Class Initialized
INFO - 2025-05-06 06:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:20:05 --> Form Validation Class Initialized
INFO - 2025-05-06 06:20:05 --> Controller Class Initialized
INFO - 2025-05-06 06:20:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:20:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:20:05 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:20:05 --> Final output sent to browser
DEBUG - 2025-05-06 06:20:05 --> Total execution time: 0.0329
INFO - 2025-05-06 06:20:11 --> Config Class Initialized
INFO - 2025-05-06 06:20:11 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:20:11 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:20:11 --> Utf8 Class Initialized
INFO - 2025-05-06 06:20:11 --> URI Class Initialized
INFO - 2025-05-06 06:20:11 --> Router Class Initialized
INFO - 2025-05-06 06:20:11 --> Output Class Initialized
INFO - 2025-05-06 06:20:11 --> Security Class Initialized
DEBUG - 2025-05-06 06:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:20:11 --> Input Class Initialized
INFO - 2025-05-06 06:20:11 --> Language Class Initialized
INFO - 2025-05-06 06:20:11 --> Loader Class Initialized
INFO - 2025-05-06 06:20:11 --> Helper loaded: form_helper
INFO - 2025-05-06 06:20:11 --> Helper loaded: url_helper
INFO - 2025-05-06 06:20:11 --> Database Driver Class Initialized
INFO - 2025-05-06 06:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:20:11 --> Form Validation Class Initialized
INFO - 2025-05-06 06:20:11 --> Controller Class Initialized
INFO - 2025-05-06 06:20:11 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:20:11 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:20:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:20:11 --> Config Class Initialized
INFO - 2025-05-06 06:20:11 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:20:11 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:20:11 --> Utf8 Class Initialized
INFO - 2025-05-06 06:20:11 --> URI Class Initialized
INFO - 2025-05-06 06:20:11 --> Router Class Initialized
INFO - 2025-05-06 06:20:11 --> Output Class Initialized
INFO - 2025-05-06 06:20:11 --> Security Class Initialized
DEBUG - 2025-05-06 06:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:20:11 --> Input Class Initialized
INFO - 2025-05-06 06:20:11 --> Language Class Initialized
INFO - 2025-05-06 06:20:11 --> Loader Class Initialized
INFO - 2025-05-06 06:20:11 --> Helper loaded: form_helper
INFO - 2025-05-06 06:20:11 --> Helper loaded: url_helper
INFO - 2025-05-06 06:20:11 --> Database Driver Class Initialized
INFO - 2025-05-06 06:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:20:11 --> Form Validation Class Initialized
INFO - 2025-05-06 06:20:11 --> Controller Class Initialized
INFO - 2025-05-06 06:20:11 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:20:11 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:20:11 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:20:11 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:20:11 --> Final output sent to browser
DEBUG - 2025-05-06 06:20:11 --> Total execution time: 0.0281
INFO - 2025-05-06 06:20:21 --> Config Class Initialized
INFO - 2025-05-06 06:20:21 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:20:21 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:20:21 --> Utf8 Class Initialized
INFO - 2025-05-06 06:20:21 --> URI Class Initialized
INFO - 2025-05-06 06:20:21 --> Router Class Initialized
INFO - 2025-05-06 06:20:21 --> Output Class Initialized
INFO - 2025-05-06 06:20:21 --> Security Class Initialized
DEBUG - 2025-05-06 06:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:20:21 --> Input Class Initialized
INFO - 2025-05-06 06:20:21 --> Language Class Initialized
INFO - 2025-05-06 06:20:21 --> Loader Class Initialized
INFO - 2025-05-06 06:20:21 --> Helper loaded: form_helper
INFO - 2025-05-06 06:20:21 --> Helper loaded: url_helper
INFO - 2025-05-06 06:20:21 --> Database Driver Class Initialized
INFO - 2025-05-06 06:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:20:21 --> Form Validation Class Initialized
INFO - 2025-05-06 06:20:21 --> Controller Class Initialized
INFO - 2025-05-06 06:20:21 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:20:21 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:20:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:20:21 --> Final output sent to browser
DEBUG - 2025-05-06 06:20:21 --> Total execution time: 0.0296
INFO - 2025-05-06 06:20:27 --> Config Class Initialized
INFO - 2025-05-06 06:20:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:20:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:20:27 --> Utf8 Class Initialized
INFO - 2025-05-06 06:20:27 --> URI Class Initialized
INFO - 2025-05-06 06:20:27 --> Router Class Initialized
INFO - 2025-05-06 06:20:27 --> Output Class Initialized
INFO - 2025-05-06 06:20:27 --> Security Class Initialized
DEBUG - 2025-05-06 06:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:20:27 --> Input Class Initialized
INFO - 2025-05-06 06:20:27 --> Language Class Initialized
INFO - 2025-05-06 06:20:27 --> Loader Class Initialized
INFO - 2025-05-06 06:20:27 --> Helper loaded: form_helper
INFO - 2025-05-06 06:20:27 --> Helper loaded: url_helper
INFO - 2025-05-06 06:20:27 --> Database Driver Class Initialized
INFO - 2025-05-06 06:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:20:27 --> Form Validation Class Initialized
INFO - 2025-05-06 06:20:27 --> Controller Class Initialized
INFO - 2025-05-06 06:20:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:20:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:20:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:20:28 --> Config Class Initialized
INFO - 2025-05-06 06:20:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:20:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:20:28 --> Utf8 Class Initialized
INFO - 2025-05-06 06:20:28 --> URI Class Initialized
INFO - 2025-05-06 06:20:28 --> Router Class Initialized
INFO - 2025-05-06 06:20:28 --> Output Class Initialized
INFO - 2025-05-06 06:20:28 --> Security Class Initialized
DEBUG - 2025-05-06 06:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:20:28 --> Input Class Initialized
INFO - 2025-05-06 06:20:28 --> Language Class Initialized
INFO - 2025-05-06 06:20:28 --> Loader Class Initialized
INFO - 2025-05-06 06:20:28 --> Helper loaded: form_helper
INFO - 2025-05-06 06:20:28 --> Helper loaded: url_helper
INFO - 2025-05-06 06:20:28 --> Database Driver Class Initialized
INFO - 2025-05-06 06:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:20:28 --> Form Validation Class Initialized
INFO - 2025-05-06 06:20:28 --> Controller Class Initialized
INFO - 2025-05-06 06:20:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:20:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:20:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:20:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:20:28 --> Final output sent to browser
DEBUG - 2025-05-06 06:20:28 --> Total execution time: 0.0431
INFO - 2025-05-06 06:20:41 --> Config Class Initialized
INFO - 2025-05-06 06:20:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:20:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:20:41 --> Utf8 Class Initialized
INFO - 2025-05-06 06:20:41 --> URI Class Initialized
INFO - 2025-05-06 06:20:41 --> Router Class Initialized
INFO - 2025-05-06 06:20:41 --> Output Class Initialized
INFO - 2025-05-06 06:20:41 --> Security Class Initialized
DEBUG - 2025-05-06 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:20:41 --> Input Class Initialized
INFO - 2025-05-06 06:20:41 --> Language Class Initialized
INFO - 2025-05-06 06:20:41 --> Loader Class Initialized
INFO - 2025-05-06 06:20:41 --> Helper loaded: form_helper
INFO - 2025-05-06 06:20:41 --> Helper loaded: url_helper
INFO - 2025-05-06 06:20:41 --> Database Driver Class Initialized
INFO - 2025-05-06 06:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:20:42 --> Form Validation Class Initialized
INFO - 2025-05-06 06:20:42 --> Controller Class Initialized
INFO - 2025-05-06 06:20:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:20:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:20:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:20:42 --> Final output sent to browser
DEBUG - 2025-05-06 06:20:42 --> Total execution time: 0.0259
INFO - 2025-05-06 06:21:08 --> Config Class Initialized
INFO - 2025-05-06 06:21:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:21:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:21:08 --> Utf8 Class Initialized
INFO - 2025-05-06 06:21:08 --> URI Class Initialized
INFO - 2025-05-06 06:21:08 --> Router Class Initialized
INFO - 2025-05-06 06:21:08 --> Output Class Initialized
INFO - 2025-05-06 06:21:08 --> Security Class Initialized
DEBUG - 2025-05-06 06:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:21:08 --> Input Class Initialized
INFO - 2025-05-06 06:21:08 --> Language Class Initialized
INFO - 2025-05-06 06:21:08 --> Loader Class Initialized
INFO - 2025-05-06 06:21:08 --> Helper loaded: form_helper
INFO - 2025-05-06 06:21:08 --> Helper loaded: url_helper
INFO - 2025-05-06 06:21:09 --> Database Driver Class Initialized
INFO - 2025-05-06 06:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:21:09 --> Form Validation Class Initialized
INFO - 2025-05-06 06:21:09 --> Controller Class Initialized
INFO - 2025-05-06 06:21:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:21:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:21:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:21:09 --> Config Class Initialized
INFO - 2025-05-06 06:21:09 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:21:09 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:21:09 --> Utf8 Class Initialized
INFO - 2025-05-06 06:21:09 --> URI Class Initialized
INFO - 2025-05-06 06:21:09 --> Router Class Initialized
INFO - 2025-05-06 06:21:09 --> Output Class Initialized
INFO - 2025-05-06 06:21:09 --> Security Class Initialized
DEBUG - 2025-05-06 06:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:21:09 --> Input Class Initialized
INFO - 2025-05-06 06:21:09 --> Language Class Initialized
INFO - 2025-05-06 06:21:09 --> Loader Class Initialized
INFO - 2025-05-06 06:21:09 --> Helper loaded: form_helper
INFO - 2025-05-06 06:21:09 --> Helper loaded: url_helper
INFO - 2025-05-06 06:21:09 --> Database Driver Class Initialized
INFO - 2025-05-06 06:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:21:09 --> Form Validation Class Initialized
INFO - 2025-05-06 06:21:09 --> Controller Class Initialized
INFO - 2025-05-06 06:21:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:21:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:21:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:21:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:21:09 --> Final output sent to browser
DEBUG - 2025-05-06 06:21:09 --> Total execution time: 0.0296
INFO - 2025-05-06 06:22:15 --> Config Class Initialized
INFO - 2025-05-06 06:22:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:22:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:22:15 --> Utf8 Class Initialized
INFO - 2025-05-06 06:22:15 --> URI Class Initialized
INFO - 2025-05-06 06:22:15 --> Router Class Initialized
INFO - 2025-05-06 06:22:15 --> Output Class Initialized
INFO - 2025-05-06 06:22:15 --> Security Class Initialized
DEBUG - 2025-05-06 06:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:22:15 --> Input Class Initialized
INFO - 2025-05-06 06:22:15 --> Language Class Initialized
INFO - 2025-05-06 06:22:15 --> Loader Class Initialized
INFO - 2025-05-06 06:22:15 --> Helper loaded: form_helper
INFO - 2025-05-06 06:22:15 --> Helper loaded: url_helper
INFO - 2025-05-06 06:22:15 --> Database Driver Class Initialized
INFO - 2025-05-06 06:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:22:15 --> Form Validation Class Initialized
INFO - 2025-05-06 06:22:15 --> Controller Class Initialized
INFO - 2025-05-06 06:22:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:22:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:22:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:22:15 --> Final output sent to browser
DEBUG - 2025-05-06 06:22:15 --> Total execution time: 0.0324
INFO - 2025-05-06 06:22:44 --> Config Class Initialized
INFO - 2025-05-06 06:22:44 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:22:44 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:22:44 --> Utf8 Class Initialized
INFO - 2025-05-06 06:22:44 --> URI Class Initialized
INFO - 2025-05-06 06:22:44 --> Router Class Initialized
INFO - 2025-05-06 06:22:44 --> Output Class Initialized
INFO - 2025-05-06 06:22:44 --> Security Class Initialized
DEBUG - 2025-05-06 06:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:22:44 --> Input Class Initialized
INFO - 2025-05-06 06:22:44 --> Language Class Initialized
INFO - 2025-05-06 06:22:44 --> Loader Class Initialized
INFO - 2025-05-06 06:22:44 --> Helper loaded: form_helper
INFO - 2025-05-06 06:22:44 --> Helper loaded: url_helper
INFO - 2025-05-06 06:22:44 --> Database Driver Class Initialized
INFO - 2025-05-06 06:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:22:44 --> Form Validation Class Initialized
INFO - 2025-05-06 06:22:44 --> Controller Class Initialized
INFO - 2025-05-06 06:22:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:22:44 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:22:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:22:44 --> Config Class Initialized
INFO - 2025-05-06 06:22:44 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:22:44 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:22:44 --> Utf8 Class Initialized
INFO - 2025-05-06 06:22:44 --> URI Class Initialized
INFO - 2025-05-06 06:22:44 --> Router Class Initialized
INFO - 2025-05-06 06:22:44 --> Output Class Initialized
INFO - 2025-05-06 06:22:44 --> Security Class Initialized
DEBUG - 2025-05-06 06:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:22:44 --> Input Class Initialized
INFO - 2025-05-06 06:22:44 --> Language Class Initialized
INFO - 2025-05-06 06:22:44 --> Loader Class Initialized
INFO - 2025-05-06 06:22:44 --> Helper loaded: form_helper
INFO - 2025-05-06 06:22:44 --> Helper loaded: url_helper
INFO - 2025-05-06 06:22:44 --> Database Driver Class Initialized
INFO - 2025-05-06 06:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:22:44 --> Form Validation Class Initialized
INFO - 2025-05-06 06:22:44 --> Controller Class Initialized
INFO - 2025-05-06 06:22:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:22:44 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:22:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:22:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:22:44 --> Final output sent to browser
DEBUG - 2025-05-06 06:22:44 --> Total execution time: 0.0318
INFO - 2025-05-06 06:23:07 --> Config Class Initialized
INFO - 2025-05-06 06:23:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:07 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:07 --> URI Class Initialized
INFO - 2025-05-06 06:23:07 --> Router Class Initialized
INFO - 2025-05-06 06:23:07 --> Output Class Initialized
INFO - 2025-05-06 06:23:07 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:07 --> Input Class Initialized
INFO - 2025-05-06 06:23:07 --> Language Class Initialized
INFO - 2025-05-06 06:23:07 --> Loader Class Initialized
INFO - 2025-05-06 06:23:07 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:07 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:07 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:07 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:07 --> Controller Class Initialized
INFO - 2025-05-06 06:23:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:07 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:07 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-06 06:23:07 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:07 --> Total execution time: 0.0268
INFO - 2025-05-06 06:23:13 --> Config Class Initialized
INFO - 2025-05-06 06:23:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:13 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:13 --> URI Class Initialized
INFO - 2025-05-06 06:23:13 --> Router Class Initialized
INFO - 2025-05-06 06:23:13 --> Output Class Initialized
INFO - 2025-05-06 06:23:13 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:13 --> Input Class Initialized
INFO - 2025-05-06 06:23:13 --> Language Class Initialized
INFO - 2025-05-06 06:23:13 --> Loader Class Initialized
INFO - 2025-05-06 06:23:13 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:13 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:13 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:13 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:13 --> Controller Class Initialized
INFO - 2025-05-06 06:23:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 06:23:13 --> Config Class Initialized
INFO - 2025-05-06 06:23:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:13 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:13 --> URI Class Initialized
INFO - 2025-05-06 06:23:13 --> Router Class Initialized
INFO - 2025-05-06 06:23:13 --> Output Class Initialized
INFO - 2025-05-06 06:23:13 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:13 --> Input Class Initialized
INFO - 2025-05-06 06:23:13 --> Language Class Initialized
INFO - 2025-05-06 06:23:13 --> Loader Class Initialized
INFO - 2025-05-06 06:23:13 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:13 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:13 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:13 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:13 --> Controller Class Initialized
INFO - 2025-05-06 06:23:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:23:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:23:13 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:13 --> Total execution time: 0.0311
INFO - 2025-05-06 06:23:24 --> Config Class Initialized
INFO - 2025-05-06 06:23:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:24 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:24 --> URI Class Initialized
INFO - 2025-05-06 06:23:24 --> Router Class Initialized
INFO - 2025-05-06 06:23:24 --> Output Class Initialized
INFO - 2025-05-06 06:23:24 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:24 --> Input Class Initialized
INFO - 2025-05-06 06:23:24 --> Language Class Initialized
INFO - 2025-05-06 06:23:24 --> Loader Class Initialized
INFO - 2025-05-06 06:23:24 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:24 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:24 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:24 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:24 --> Controller Class Initialized
INFO - 2025-05-06 06:23:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:24 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:24 --> Total execution time: 0.0323
INFO - 2025-05-06 06:23:28 --> Config Class Initialized
INFO - 2025-05-06 06:23:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:28 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:28 --> URI Class Initialized
INFO - 2025-05-06 06:23:28 --> Router Class Initialized
INFO - 2025-05-06 06:23:28 --> Output Class Initialized
INFO - 2025-05-06 06:23:28 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:28 --> Input Class Initialized
INFO - 2025-05-06 06:23:28 --> Language Class Initialized
INFO - 2025-05-06 06:23:28 --> Loader Class Initialized
INFO - 2025-05-06 06:23:28 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:28 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:28 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:28 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:28 --> Controller Class Initialized
INFO - 2025-05-06 06:23:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:23:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:23:28 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:28 --> Total execution time: 0.0331
INFO - 2025-05-06 06:23:29 --> Config Class Initialized
INFO - 2025-05-06 06:23:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:29 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:29 --> URI Class Initialized
INFO - 2025-05-06 06:23:29 --> Router Class Initialized
INFO - 2025-05-06 06:23:29 --> Output Class Initialized
INFO - 2025-05-06 06:23:29 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:29 --> Input Class Initialized
INFO - 2025-05-06 06:23:29 --> Language Class Initialized
INFO - 2025-05-06 06:23:29 --> Loader Class Initialized
INFO - 2025-05-06 06:23:29 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:29 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:29 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:29 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:29 --> Controller Class Initialized
INFO - 2025-05-06 06:23:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:23:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-06 06:23:29 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:29 --> Total execution time: 0.0353
INFO - 2025-05-06 06:23:30 --> Config Class Initialized
INFO - 2025-05-06 06:23:30 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:30 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:30 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:30 --> URI Class Initialized
INFO - 2025-05-06 06:23:30 --> Router Class Initialized
INFO - 2025-05-06 06:23:30 --> Output Class Initialized
INFO - 2025-05-06 06:23:30 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:30 --> Input Class Initialized
INFO - 2025-05-06 06:23:30 --> Language Class Initialized
INFO - 2025-05-06 06:23:30 --> Loader Class Initialized
INFO - 2025-05-06 06:23:30 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:30 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:30 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:30 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:30 --> Controller Class Initialized
INFO - 2025-05-06 06:23:30 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:30 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:23:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 06:23:30 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:30 --> Total execution time: 0.0308
INFO - 2025-05-06 06:23:31 --> Config Class Initialized
INFO - 2025-05-06 06:23:31 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:31 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:31 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:31 --> URI Class Initialized
INFO - 2025-05-06 06:23:31 --> Router Class Initialized
INFO - 2025-05-06 06:23:31 --> Output Class Initialized
INFO - 2025-05-06 06:23:31 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:31 --> Input Class Initialized
INFO - 2025-05-06 06:23:31 --> Language Class Initialized
INFO - 2025-05-06 06:23:31 --> Loader Class Initialized
INFO - 2025-05-06 06:23:31 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:31 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:31 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:31 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:31 --> Controller Class Initialized
INFO - 2025-05-06 06:23:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:23:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-06 06:23:31 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:31 --> Total execution time: 0.0282
INFO - 2025-05-06 06:23:33 --> Config Class Initialized
INFO - 2025-05-06 06:23:33 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:33 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:33 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:33 --> URI Class Initialized
INFO - 2025-05-06 06:23:33 --> Router Class Initialized
INFO - 2025-05-06 06:23:33 --> Output Class Initialized
INFO - 2025-05-06 06:23:33 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:33 --> Input Class Initialized
INFO - 2025-05-06 06:23:33 --> Language Class Initialized
INFO - 2025-05-06 06:23:33 --> Loader Class Initialized
INFO - 2025-05-06 06:23:33 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:33 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:33 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:33 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:33 --> Controller Class Initialized
INFO - 2025-05-06 06:23:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:33 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:23:33 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_sekolah.php
INFO - 2025-05-06 06:23:33 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:33 --> Total execution time: 0.0349
INFO - 2025-05-06 06:23:38 --> Config Class Initialized
INFO - 2025-05-06 06:23:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:38 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:38 --> URI Class Initialized
INFO - 2025-05-06 06:23:38 --> Router Class Initialized
INFO - 2025-05-06 06:23:38 --> Output Class Initialized
INFO - 2025-05-06 06:23:38 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:38 --> Input Class Initialized
INFO - 2025-05-06 06:23:38 --> Language Class Initialized
INFO - 2025-05-06 06:23:38 --> Loader Class Initialized
INFO - 2025-05-06 06:23:38 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:38 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:38 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:38 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:38 --> Controller Class Initialized
INFO - 2025-05-06 06:23:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:38 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:23:38 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-06 06:23:38 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:38 --> Total execution time: 0.0999
INFO - 2025-05-06 06:23:41 --> Config Class Initialized
INFO - 2025-05-06 06:23:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:23:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:23:41 --> Utf8 Class Initialized
INFO - 2025-05-06 06:23:41 --> URI Class Initialized
INFO - 2025-05-06 06:23:41 --> Router Class Initialized
INFO - 2025-05-06 06:23:41 --> Output Class Initialized
INFO - 2025-05-06 06:23:41 --> Security Class Initialized
DEBUG - 2025-05-06 06:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:23:41 --> Input Class Initialized
INFO - 2025-05-06 06:23:41 --> Language Class Initialized
INFO - 2025-05-06 06:23:41 --> Loader Class Initialized
INFO - 2025-05-06 06:23:41 --> Helper loaded: form_helper
INFO - 2025-05-06 06:23:41 --> Helper loaded: url_helper
INFO - 2025-05-06 06:23:41 --> Database Driver Class Initialized
INFO - 2025-05-06 06:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:23:41 --> Form Validation Class Initialized
INFO - 2025-05-06 06:23:41 --> Controller Class Initialized
INFO - 2025-05-06 06:23:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:23:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:23:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:23:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:23:41 --> Final output sent to browser
DEBUG - 2025-05-06 06:23:41 --> Total execution time: 0.2462
INFO - 2025-05-06 06:47:04 --> Config Class Initialized
INFO - 2025-05-06 06:47:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:47:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:47:04 --> Utf8 Class Initialized
INFO - 2025-05-06 06:47:04 --> URI Class Initialized
INFO - 2025-05-06 06:47:04 --> Router Class Initialized
INFO - 2025-05-06 06:47:04 --> Output Class Initialized
INFO - 2025-05-06 06:47:04 --> Security Class Initialized
DEBUG - 2025-05-06 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:47:04 --> Input Class Initialized
INFO - 2025-05-06 06:47:04 --> Language Class Initialized
INFO - 2025-05-06 06:47:04 --> Loader Class Initialized
INFO - 2025-05-06 06:47:04 --> Helper loaded: form_helper
INFO - 2025-05-06 06:47:04 --> Helper loaded: url_helper
INFO - 2025-05-06 06:47:04 --> Database Driver Class Initialized
INFO - 2025-05-06 06:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:47:04 --> Form Validation Class Initialized
INFO - 2025-05-06 06:47:04 --> Controller Class Initialized
INFO - 2025-05-06 06:47:04 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:47:04 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:47:04 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:47:04 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:47:04 --> Final output sent to browser
DEBUG - 2025-05-06 06:47:04 --> Total execution time: 0.0486
INFO - 2025-05-06 06:50:08 --> Config Class Initialized
INFO - 2025-05-06 06:50:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:50:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:50:08 --> Utf8 Class Initialized
INFO - 2025-05-06 06:50:08 --> URI Class Initialized
INFO - 2025-05-06 06:50:08 --> Router Class Initialized
INFO - 2025-05-06 06:50:08 --> Output Class Initialized
INFO - 2025-05-06 06:50:08 --> Security Class Initialized
DEBUG - 2025-05-06 06:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:50:08 --> Input Class Initialized
INFO - 2025-05-06 06:50:08 --> Language Class Initialized
INFO - 2025-05-06 06:50:08 --> Loader Class Initialized
INFO - 2025-05-06 06:50:08 --> Helper loaded: form_helper
INFO - 2025-05-06 06:50:08 --> Helper loaded: url_helper
INFO - 2025-05-06 06:50:08 --> Database Driver Class Initialized
INFO - 2025-05-06 06:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:50:08 --> Form Validation Class Initialized
INFO - 2025-05-06 06:50:08 --> Controller Class Initialized
INFO - 2025-05-06 06:50:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:50:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:50:08 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:50:08 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:50:08 --> Final output sent to browser
DEBUG - 2025-05-06 06:50:08 --> Total execution time: 0.0428
INFO - 2025-05-06 06:53:12 --> Config Class Initialized
INFO - 2025-05-06 06:53:12 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:12 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:12 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:12 --> URI Class Initialized
INFO - 2025-05-06 06:53:12 --> Router Class Initialized
INFO - 2025-05-06 06:53:12 --> Output Class Initialized
INFO - 2025-05-06 06:53:12 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:12 --> Input Class Initialized
INFO - 2025-05-06 06:53:12 --> Language Class Initialized
INFO - 2025-05-06 06:53:12 --> Loader Class Initialized
INFO - 2025-05-06 06:53:12 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:12 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:12 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:12 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:12 --> Controller Class Initialized
INFO - 2025-05-06 06:53:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:12 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:12 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:12 --> Total execution time: 0.0491
INFO - 2025-05-06 06:53:13 --> Config Class Initialized
INFO - 2025-05-06 06:53:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:13 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:13 --> URI Class Initialized
INFO - 2025-05-06 06:53:13 --> Router Class Initialized
INFO - 2025-05-06 06:53:13 --> Output Class Initialized
INFO - 2025-05-06 06:53:13 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:13 --> Input Class Initialized
INFO - 2025-05-06 06:53:13 --> Language Class Initialized
INFO - 2025-05-06 06:53:13 --> Loader Class Initialized
INFO - 2025-05-06 06:53:13 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:13 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:13 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:13 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:13 --> Controller Class Initialized
INFO - 2025-05-06 06:53:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:13 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:13 --> Total execution time: 0.0418
INFO - 2025-05-06 06:53:14 --> Config Class Initialized
INFO - 2025-05-06 06:53:14 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:14 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:14 --> URI Class Initialized
INFO - 2025-05-06 06:53:14 --> Router Class Initialized
INFO - 2025-05-06 06:53:14 --> Output Class Initialized
INFO - 2025-05-06 06:53:14 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:14 --> Input Class Initialized
INFO - 2025-05-06 06:53:14 --> Language Class Initialized
INFO - 2025-05-06 06:53:14 --> Loader Class Initialized
INFO - 2025-05-06 06:53:14 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:14 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:14 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:14 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:14 --> Controller Class Initialized
INFO - 2025-05-06 06:53:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:14 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:14 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:14 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:14 --> Total execution time: 0.0635
INFO - 2025-05-06 06:53:14 --> Config Class Initialized
INFO - 2025-05-06 06:53:14 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:14 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:14 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:14 --> URI Class Initialized
INFO - 2025-05-06 06:53:14 --> Router Class Initialized
INFO - 2025-05-06 06:53:14 --> Output Class Initialized
INFO - 2025-05-06 06:53:14 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:14 --> Input Class Initialized
INFO - 2025-05-06 06:53:14 --> Language Class Initialized
INFO - 2025-05-06 06:53:14 --> Loader Class Initialized
INFO - 2025-05-06 06:53:14 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:14 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:15 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:15 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:15 --> Controller Class Initialized
INFO - 2025-05-06 06:53:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:15 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:15 --> Total execution time: 0.1892
INFO - 2025-05-06 06:53:15 --> Config Class Initialized
INFO - 2025-05-06 06:53:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:15 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:15 --> URI Class Initialized
INFO - 2025-05-06 06:53:15 --> Router Class Initialized
INFO - 2025-05-06 06:53:15 --> Output Class Initialized
INFO - 2025-05-06 06:53:15 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:15 --> Input Class Initialized
INFO - 2025-05-06 06:53:15 --> Language Class Initialized
INFO - 2025-05-06 06:53:15 --> Loader Class Initialized
INFO - 2025-05-06 06:53:15 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:15 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:15 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:15 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:15 --> Controller Class Initialized
INFO - 2025-05-06 06:53:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:15 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:15 --> Total execution time: 0.0656
INFO - 2025-05-06 06:53:24 --> Config Class Initialized
INFO - 2025-05-06 06:53:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:24 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:24 --> URI Class Initialized
INFO - 2025-05-06 06:53:24 --> Router Class Initialized
INFO - 2025-05-06 06:53:24 --> Output Class Initialized
INFO - 2025-05-06 06:53:24 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:24 --> Input Class Initialized
INFO - 2025-05-06 06:53:24 --> Language Class Initialized
INFO - 2025-05-06 06:53:24 --> Loader Class Initialized
INFO - 2025-05-06 06:53:24 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:24 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:24 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:24 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:24 --> Controller Class Initialized
INFO - 2025-05-06 06:53:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:24 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:24 --> Total execution time: 0.0545
INFO - 2025-05-06 06:53:26 --> Config Class Initialized
INFO - 2025-05-06 06:53:26 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:26 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:26 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:26 --> URI Class Initialized
INFO - 2025-05-06 06:53:26 --> Router Class Initialized
INFO - 2025-05-06 06:53:26 --> Output Class Initialized
INFO - 2025-05-06 06:53:26 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:26 --> Input Class Initialized
INFO - 2025-05-06 06:53:26 --> Language Class Initialized
INFO - 2025-05-06 06:53:26 --> Loader Class Initialized
INFO - 2025-05-06 06:53:26 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:26 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:26 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:26 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:26 --> Controller Class Initialized
INFO - 2025-05-06 06:53:26 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:26 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:26 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:26 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:26 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:26 --> Total execution time: 0.0453
INFO - 2025-05-06 06:53:31 --> Config Class Initialized
INFO - 2025-05-06 06:53:31 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:31 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:31 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:31 --> URI Class Initialized
INFO - 2025-05-06 06:53:31 --> Router Class Initialized
INFO - 2025-05-06 06:53:31 --> Output Class Initialized
INFO - 2025-05-06 06:53:31 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:31 --> Input Class Initialized
INFO - 2025-05-06 06:53:31 --> Language Class Initialized
INFO - 2025-05-06 06:53:31 --> Loader Class Initialized
INFO - 2025-05-06 06:53:31 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:31 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:31 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:31 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:31 --> Controller Class Initialized
INFO - 2025-05-06 06:53:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:31 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:31 --> Total execution time: 0.0572
INFO - 2025-05-06 06:53:35 --> Config Class Initialized
INFO - 2025-05-06 06:53:35 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:35 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:35 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:35 --> URI Class Initialized
INFO - 2025-05-06 06:53:35 --> Router Class Initialized
INFO - 2025-05-06 06:53:35 --> Output Class Initialized
INFO - 2025-05-06 06:53:35 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:35 --> Input Class Initialized
INFO - 2025-05-06 06:53:35 --> Language Class Initialized
INFO - 2025-05-06 06:53:35 --> Loader Class Initialized
INFO - 2025-05-06 06:53:35 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:35 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:35 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:35 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:35 --> Controller Class Initialized
INFO - 2025-05-06 06:53:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:35 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:35 --> Total execution time: 0.0433
INFO - 2025-05-06 06:53:42 --> Config Class Initialized
INFO - 2025-05-06 06:53:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:53:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:53:42 --> Utf8 Class Initialized
INFO - 2025-05-06 06:53:42 --> URI Class Initialized
INFO - 2025-05-06 06:53:42 --> Router Class Initialized
INFO - 2025-05-06 06:53:42 --> Output Class Initialized
INFO - 2025-05-06 06:53:42 --> Security Class Initialized
DEBUG - 2025-05-06 06:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:53:42 --> Input Class Initialized
INFO - 2025-05-06 06:53:42 --> Language Class Initialized
INFO - 2025-05-06 06:53:42 --> Loader Class Initialized
INFO - 2025-05-06 06:53:42 --> Helper loaded: form_helper
INFO - 2025-05-06 06:53:42 --> Helper loaded: url_helper
INFO - 2025-05-06 06:53:42 --> Database Driver Class Initialized
INFO - 2025-05-06 06:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:53:42 --> Form Validation Class Initialized
INFO - 2025-05-06 06:53:42 --> Controller Class Initialized
INFO - 2025-05-06 06:53:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:53:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:53:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:53:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:53:42 --> Final output sent to browser
DEBUG - 2025-05-06 06:53:42 --> Total execution time: 0.0539
INFO - 2025-05-06 06:54:48 --> Config Class Initialized
INFO - 2025-05-06 06:54:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:54:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:54:48 --> Utf8 Class Initialized
INFO - 2025-05-06 06:54:48 --> URI Class Initialized
INFO - 2025-05-06 06:54:48 --> Router Class Initialized
INFO - 2025-05-06 06:54:48 --> Output Class Initialized
INFO - 2025-05-06 06:54:48 --> Security Class Initialized
DEBUG - 2025-05-06 06:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:54:48 --> Input Class Initialized
INFO - 2025-05-06 06:54:48 --> Language Class Initialized
INFO - 2025-05-06 06:54:48 --> Loader Class Initialized
INFO - 2025-05-06 06:54:48 --> Helper loaded: form_helper
INFO - 2025-05-06 06:54:48 --> Helper loaded: url_helper
INFO - 2025-05-06 06:54:48 --> Database Driver Class Initialized
INFO - 2025-05-06 06:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:54:48 --> Form Validation Class Initialized
INFO - 2025-05-06 06:54:48 --> Controller Class Initialized
INFO - 2025-05-06 06:54:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:54:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:54:48 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:54:48 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 06:54:48 --> Final output sent to browser
DEBUG - 2025-05-06 06:54:48 --> Total execution time: 0.0288
INFO - 2025-05-06 06:54:50 --> Config Class Initialized
INFO - 2025-05-06 06:54:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:54:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:54:50 --> Utf8 Class Initialized
INFO - 2025-05-06 06:54:50 --> URI Class Initialized
INFO - 2025-05-06 06:54:50 --> Router Class Initialized
INFO - 2025-05-06 06:54:50 --> Output Class Initialized
INFO - 2025-05-06 06:54:50 --> Security Class Initialized
DEBUG - 2025-05-06 06:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:54:50 --> Input Class Initialized
INFO - 2025-05-06 06:54:50 --> Language Class Initialized
INFO - 2025-05-06 06:54:50 --> Loader Class Initialized
INFO - 2025-05-06 06:54:50 --> Helper loaded: form_helper
INFO - 2025-05-06 06:54:50 --> Helper loaded: url_helper
INFO - 2025-05-06 06:54:50 --> Database Driver Class Initialized
INFO - 2025-05-06 06:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 06:54:50 --> Form Validation Class Initialized
INFO - 2025-05-06 06:54:50 --> Controller Class Initialized
INFO - 2025-05-06 06:54:50 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 06:54:50 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 06:54:50 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 06:54:50 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 06:54:50 --> Final output sent to browser
DEBUG - 2025-05-06 06:54:50 --> Total execution time: 0.0469
INFO - 2025-05-06 07:13:56 --> Config Class Initialized
INFO - 2025-05-06 07:13:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:13:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:13:56 --> Utf8 Class Initialized
INFO - 2025-05-06 07:13:56 --> URI Class Initialized
INFO - 2025-05-06 07:13:56 --> Router Class Initialized
INFO - 2025-05-06 07:13:56 --> Output Class Initialized
INFO - 2025-05-06 07:13:56 --> Security Class Initialized
DEBUG - 2025-05-06 07:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:13:56 --> Input Class Initialized
INFO - 2025-05-06 07:13:56 --> Language Class Initialized
INFO - 2025-05-06 07:13:56 --> Loader Class Initialized
INFO - 2025-05-06 07:13:56 --> Helper loaded: form_helper
INFO - 2025-05-06 07:13:56 --> Helper loaded: url_helper
INFO - 2025-05-06 07:13:56 --> Database Driver Class Initialized
INFO - 2025-05-06 07:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:13:56 --> Form Validation Class Initialized
INFO - 2025-05-06 07:13:56 --> Controller Class Initialized
INFO - 2025-05-06 07:13:56 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:13:56 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:13:57 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/tambah_petugas.php
INFO - 2025-05-06 07:13:57 --> Final output sent to browser
DEBUG - 2025-05-06 07:13:57 --> Total execution time: 0.0492
INFO - 2025-05-06 07:14:32 --> Config Class Initialized
INFO - 2025-05-06 07:14:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:14:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:14:32 --> Utf8 Class Initialized
INFO - 2025-05-06 07:14:32 --> URI Class Initialized
INFO - 2025-05-06 07:14:32 --> Router Class Initialized
INFO - 2025-05-06 07:14:32 --> Output Class Initialized
INFO - 2025-05-06 07:14:32 --> Security Class Initialized
DEBUG - 2025-05-06 07:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:14:32 --> Input Class Initialized
INFO - 2025-05-06 07:14:32 --> Language Class Initialized
INFO - 2025-05-06 07:14:32 --> Loader Class Initialized
INFO - 2025-05-06 07:14:32 --> Helper loaded: form_helper
INFO - 2025-05-06 07:14:32 --> Helper loaded: url_helper
INFO - 2025-05-06 07:14:32 --> Database Driver Class Initialized
INFO - 2025-05-06 07:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:14:32 --> Form Validation Class Initialized
INFO - 2025-05-06 07:14:32 --> Controller Class Initialized
INFO - 2025-05-06 07:14:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:14:32 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:14:32 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/tambah_petugas.php
INFO - 2025-05-06 07:14:32 --> Final output sent to browser
DEBUG - 2025-05-06 07:14:32 --> Total execution time: 0.0879
INFO - 2025-05-06 07:14:59 --> Config Class Initialized
INFO - 2025-05-06 07:14:59 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:14:59 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:14:59 --> Utf8 Class Initialized
INFO - 2025-05-06 07:14:59 --> URI Class Initialized
INFO - 2025-05-06 07:14:59 --> Router Class Initialized
INFO - 2025-05-06 07:14:59 --> Output Class Initialized
INFO - 2025-05-06 07:14:59 --> Security Class Initialized
DEBUG - 2025-05-06 07:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:14:59 --> Input Class Initialized
INFO - 2025-05-06 07:14:59 --> Language Class Initialized
INFO - 2025-05-06 07:14:59 --> Loader Class Initialized
INFO - 2025-05-06 07:14:59 --> Helper loaded: form_helper
INFO - 2025-05-06 07:14:59 --> Helper loaded: url_helper
INFO - 2025-05-06 07:14:59 --> Database Driver Class Initialized
INFO - 2025-05-06 07:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:14:59 --> Form Validation Class Initialized
INFO - 2025-05-06 07:14:59 --> Controller Class Initialized
INFO - 2025-05-06 07:14:59 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:14:59 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:14:59 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/tambah_petugas.php
INFO - 2025-05-06 07:14:59 --> Final output sent to browser
DEBUG - 2025-05-06 07:14:59 --> Total execution time: 0.0846
INFO - 2025-05-06 07:15:14 --> Config Class Initialized
INFO - 2025-05-06 07:15:14 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:15:14 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:15:14 --> Utf8 Class Initialized
INFO - 2025-05-06 07:15:14 --> URI Class Initialized
INFO - 2025-05-06 07:15:14 --> Router Class Initialized
INFO - 2025-05-06 07:15:14 --> Output Class Initialized
INFO - 2025-05-06 07:15:14 --> Security Class Initialized
DEBUG - 2025-05-06 07:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:15:14 --> Input Class Initialized
INFO - 2025-05-06 07:15:14 --> Language Class Initialized
INFO - 2025-05-06 07:15:14 --> Loader Class Initialized
INFO - 2025-05-06 07:15:14 --> Helper loaded: form_helper
INFO - 2025-05-06 07:15:14 --> Helper loaded: url_helper
INFO - 2025-05-06 07:15:14 --> Database Driver Class Initialized
INFO - 2025-05-06 07:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:15:14 --> Form Validation Class Initialized
INFO - 2025-05-06 07:15:14 --> Controller Class Initialized
INFO - 2025-05-06 07:15:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:15:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:15:14 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/tambah_petugas.php
INFO - 2025-05-06 07:15:14 --> Final output sent to browser
DEBUG - 2025-05-06 07:15:14 --> Total execution time: 0.0831
INFO - 2025-05-06 07:18:41 --> Config Class Initialized
INFO - 2025-05-06 07:18:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:18:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:18:41 --> Utf8 Class Initialized
INFO - 2025-05-06 07:18:41 --> URI Class Initialized
INFO - 2025-05-06 07:18:41 --> Router Class Initialized
INFO - 2025-05-06 07:18:41 --> Output Class Initialized
INFO - 2025-05-06 07:18:41 --> Security Class Initialized
DEBUG - 2025-05-06 07:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:18:41 --> Input Class Initialized
INFO - 2025-05-06 07:18:41 --> Language Class Initialized
INFO - 2025-05-06 07:18:41 --> Loader Class Initialized
INFO - 2025-05-06 07:18:41 --> Helper loaded: form_helper
INFO - 2025-05-06 07:18:41 --> Helper loaded: url_helper
INFO - 2025-05-06 07:18:41 --> Database Driver Class Initialized
INFO - 2025-05-06 07:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:18:41 --> Form Validation Class Initialized
INFO - 2025-05-06 07:18:41 --> Controller Class Initialized
INFO - 2025-05-06 07:18:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:18:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:18:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/tambah_petugas.php
INFO - 2025-05-06 07:18:41 --> Final output sent to browser
DEBUG - 2025-05-06 07:18:41 --> Total execution time: 0.0304
INFO - 2025-05-06 07:24:27 --> Config Class Initialized
INFO - 2025-05-06 07:24:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:24:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:24:27 --> Utf8 Class Initialized
INFO - 2025-05-06 07:24:27 --> URI Class Initialized
INFO - 2025-05-06 07:24:27 --> Router Class Initialized
INFO - 2025-05-06 07:24:27 --> Output Class Initialized
INFO - 2025-05-06 07:24:27 --> Security Class Initialized
DEBUG - 2025-05-06 07:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:24:27 --> Input Class Initialized
INFO - 2025-05-06 07:24:27 --> Language Class Initialized
INFO - 2025-05-06 07:24:27 --> Loader Class Initialized
INFO - 2025-05-06 07:24:27 --> Helper loaded: form_helper
INFO - 2025-05-06 07:24:27 --> Helper loaded: url_helper
INFO - 2025-05-06 07:24:27 --> Database Driver Class Initialized
INFO - 2025-05-06 07:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:24:27 --> Form Validation Class Initialized
INFO - 2025-05-06 07:24:27 --> Controller Class Initialized
INFO - 2025-05-06 07:24:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:24:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:24:27 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:24:27 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-06 07:24:27 --> Final output sent to browser
DEBUG - 2025-05-06 07:24:27 --> Total execution time: 0.0311
INFO - 2025-05-06 07:24:29 --> Config Class Initialized
INFO - 2025-05-06 07:24:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:24:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:24:29 --> Utf8 Class Initialized
INFO - 2025-05-06 07:24:29 --> URI Class Initialized
INFO - 2025-05-06 07:24:29 --> Router Class Initialized
INFO - 2025-05-06 07:24:29 --> Output Class Initialized
INFO - 2025-05-06 07:24:29 --> Security Class Initialized
DEBUG - 2025-05-06 07:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:24:29 --> Input Class Initialized
INFO - 2025-05-06 07:24:29 --> Language Class Initialized
INFO - 2025-05-06 07:24:29 --> Loader Class Initialized
INFO - 2025-05-06 07:24:29 --> Helper loaded: form_helper
INFO - 2025-05-06 07:24:29 --> Helper loaded: url_helper
INFO - 2025-05-06 07:24:29 --> Database Driver Class Initialized
INFO - 2025-05-06 07:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:24:29 --> Form Validation Class Initialized
INFO - 2025-05-06 07:24:29 --> Controller Class Initialized
INFO - 2025-05-06 07:24:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:24:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:24:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:24:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-06 07:24:29 --> Final output sent to browser
DEBUG - 2025-05-06 07:24:29 --> Total execution time: 0.0299
INFO - 2025-05-06 07:24:30 --> Config Class Initialized
INFO - 2025-05-06 07:24:30 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:24:30 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:24:30 --> Utf8 Class Initialized
INFO - 2025-05-06 07:24:30 --> URI Class Initialized
INFO - 2025-05-06 07:24:30 --> Router Class Initialized
INFO - 2025-05-06 07:24:30 --> Output Class Initialized
INFO - 2025-05-06 07:24:30 --> Security Class Initialized
DEBUG - 2025-05-06 07:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:24:30 --> Input Class Initialized
INFO - 2025-05-06 07:24:30 --> Language Class Initialized
INFO - 2025-05-06 07:24:30 --> Loader Class Initialized
INFO - 2025-05-06 07:24:30 --> Helper loaded: form_helper
INFO - 2025-05-06 07:24:30 --> Helper loaded: url_helper
INFO - 2025-05-06 07:24:30 --> Database Driver Class Initialized
INFO - 2025-05-06 07:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:24:30 --> Form Validation Class Initialized
INFO - 2025-05-06 07:24:30 --> Controller Class Initialized
INFO - 2025-05-06 07:24:30 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:24:30 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:24:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:24:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-06 07:24:30 --> Final output sent to browser
DEBUG - 2025-05-06 07:24:30 --> Total execution time: 0.0292
INFO - 2025-05-06 07:29:15 --> Config Class Initialized
INFO - 2025-05-06 07:29:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:29:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:29:15 --> Utf8 Class Initialized
INFO - 2025-05-06 07:29:15 --> URI Class Initialized
INFO - 2025-05-06 07:29:15 --> Router Class Initialized
INFO - 2025-05-06 07:29:15 --> Output Class Initialized
INFO - 2025-05-06 07:29:15 --> Security Class Initialized
DEBUG - 2025-05-06 07:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:29:15 --> Input Class Initialized
INFO - 2025-05-06 07:29:15 --> Language Class Initialized
INFO - 2025-05-06 07:29:15 --> Loader Class Initialized
INFO - 2025-05-06 07:29:15 --> Helper loaded: form_helper
INFO - 2025-05-06 07:29:15 --> Helper loaded: url_helper
INFO - 2025-05-06 07:29:15 --> Database Driver Class Initialized
INFO - 2025-05-06 07:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:29:15 --> Form Validation Class Initialized
INFO - 2025-05-06 07:29:15 --> Controller Class Initialized
INFO - 2025-05-06 07:29:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:29:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:29:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:29:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 07:29:15 --> Final output sent to browser
DEBUG - 2025-05-06 07:29:15 --> Total execution time: 0.0268
INFO - 2025-05-06 07:29:17 --> Config Class Initialized
INFO - 2025-05-06 07:29:17 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:29:17 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:29:17 --> Utf8 Class Initialized
INFO - 2025-05-06 07:29:17 --> URI Class Initialized
INFO - 2025-05-06 07:29:17 --> Router Class Initialized
INFO - 2025-05-06 07:29:17 --> Output Class Initialized
INFO - 2025-05-06 07:29:17 --> Security Class Initialized
DEBUG - 2025-05-06 07:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:29:17 --> Input Class Initialized
INFO - 2025-05-06 07:29:17 --> Language Class Initialized
INFO - 2025-05-06 07:29:17 --> Loader Class Initialized
INFO - 2025-05-06 07:29:17 --> Helper loaded: form_helper
INFO - 2025-05-06 07:29:17 --> Helper loaded: url_helper
INFO - 2025-05-06 07:29:17 --> Database Driver Class Initialized
INFO - 2025-05-06 07:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:29:17 --> Form Validation Class Initialized
INFO - 2025-05-06 07:29:17 --> Controller Class Initialized
INFO - 2025-05-06 07:29:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:29:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:29:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/tambah_petugas.php
INFO - 2025-05-06 07:29:17 --> Final output sent to browser
DEBUG - 2025-05-06 07:29:17 --> Total execution time: 0.0259
INFO - 2025-05-06 07:29:32 --> Config Class Initialized
INFO - 2025-05-06 07:29:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:29:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:29:32 --> Utf8 Class Initialized
INFO - 2025-05-06 07:29:32 --> URI Class Initialized
INFO - 2025-05-06 07:29:32 --> Router Class Initialized
INFO - 2025-05-06 07:29:32 --> Output Class Initialized
INFO - 2025-05-06 07:29:32 --> Security Class Initialized
DEBUG - 2025-05-06 07:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:29:32 --> Input Class Initialized
INFO - 2025-05-06 07:29:32 --> Language Class Initialized
INFO - 2025-05-06 07:29:32 --> Loader Class Initialized
INFO - 2025-05-06 07:29:32 --> Helper loaded: form_helper
INFO - 2025-05-06 07:29:32 --> Helper loaded: url_helper
INFO - 2025-05-06 07:29:32 --> Database Driver Class Initialized
INFO - 2025-05-06 07:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:29:32 --> Form Validation Class Initialized
INFO - 2025-05-06 07:29:32 --> Controller Class Initialized
INFO - 2025-05-06 07:29:32 --> Config Class Initialized
INFO - 2025-05-06 07:29:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:29:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:29:32 --> Utf8 Class Initialized
INFO - 2025-05-06 07:29:32 --> URI Class Initialized
INFO - 2025-05-06 07:29:32 --> Router Class Initialized
INFO - 2025-05-06 07:29:32 --> Output Class Initialized
INFO - 2025-05-06 07:29:32 --> Security Class Initialized
DEBUG - 2025-05-06 07:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:29:32 --> Input Class Initialized
INFO - 2025-05-06 07:29:32 --> Language Class Initialized
INFO - 2025-05-06 07:29:32 --> Loader Class Initialized
INFO - 2025-05-06 07:29:32 --> Helper loaded: form_helper
INFO - 2025-05-06 07:29:32 --> Helper loaded: url_helper
INFO - 2025-05-06 07:29:32 --> Database Driver Class Initialized
INFO - 2025-05-06 07:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:29:32 --> Form Validation Class Initialized
INFO - 2025-05-06 07:29:32 --> Controller Class Initialized
INFO - 2025-05-06 07:29:32 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/login.php
INFO - 2025-05-06 07:29:32 --> Final output sent to browser
DEBUG - 2025-05-06 07:29:32 --> Total execution time: 0.0269
INFO - 2025-05-06 07:29:38 --> Config Class Initialized
INFO - 2025-05-06 07:29:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:29:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:29:38 --> Utf8 Class Initialized
INFO - 2025-05-06 07:29:38 --> URI Class Initialized
INFO - 2025-05-06 07:29:38 --> Router Class Initialized
INFO - 2025-05-06 07:29:38 --> Output Class Initialized
INFO - 2025-05-06 07:29:38 --> Security Class Initialized
DEBUG - 2025-05-06 07:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:29:38 --> Input Class Initialized
INFO - 2025-05-06 07:29:38 --> Language Class Initialized
INFO - 2025-05-06 07:29:38 --> Loader Class Initialized
INFO - 2025-05-06 07:29:38 --> Helper loaded: form_helper
INFO - 2025-05-06 07:29:38 --> Helper loaded: url_helper
INFO - 2025-05-06 07:29:38 --> Database Driver Class Initialized
INFO - 2025-05-06 07:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:29:38 --> Form Validation Class Initialized
INFO - 2025-05-06 07:29:38 --> Controller Class Initialized
INFO - 2025-05-06 07:29:38 --> Config Class Initialized
INFO - 2025-05-06 07:29:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:29:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:29:38 --> Utf8 Class Initialized
INFO - 2025-05-06 07:29:38 --> URI Class Initialized
INFO - 2025-05-06 07:29:38 --> Router Class Initialized
INFO - 2025-05-06 07:29:38 --> Output Class Initialized
INFO - 2025-05-06 07:29:38 --> Security Class Initialized
DEBUG - 2025-05-06 07:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:29:38 --> Input Class Initialized
INFO - 2025-05-06 07:29:38 --> Language Class Initialized
INFO - 2025-05-06 07:29:38 --> Loader Class Initialized
INFO - 2025-05-06 07:29:38 --> Helper loaded: form_helper
INFO - 2025-05-06 07:29:38 --> Helper loaded: url_helper
INFO - 2025-05-06 07:29:39 --> Database Driver Class Initialized
INFO - 2025-05-06 07:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:29:39 --> Form Validation Class Initialized
INFO - 2025-05-06 07:29:39 --> Controller Class Initialized
INFO - 2025-05-06 07:29:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:29:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:29:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:29:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 07:29:39 --> Final output sent to browser
DEBUG - 2025-05-06 07:29:39 --> Total execution time: 0.0308
INFO - 2025-05-06 07:29:41 --> Config Class Initialized
INFO - 2025-05-06 07:29:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:29:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:29:41 --> Utf8 Class Initialized
INFO - 2025-05-06 07:29:41 --> URI Class Initialized
INFO - 2025-05-06 07:29:41 --> Router Class Initialized
INFO - 2025-05-06 07:29:41 --> Output Class Initialized
INFO - 2025-05-06 07:29:41 --> Security Class Initialized
DEBUG - 2025-05-06 07:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:29:41 --> Input Class Initialized
INFO - 2025-05-06 07:29:41 --> Language Class Initialized
INFO - 2025-05-06 07:29:41 --> Loader Class Initialized
INFO - 2025-05-06 07:29:41 --> Helper loaded: form_helper
INFO - 2025-05-06 07:29:41 --> Helper loaded: url_helper
INFO - 2025-05-06 07:29:41 --> Database Driver Class Initialized
INFO - 2025-05-06 07:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:29:41 --> Form Validation Class Initialized
INFO - 2025-05-06 07:29:41 --> Controller Class Initialized
INFO - 2025-05-06 07:29:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:29:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:29:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:29:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-06 07:29:41 --> Final output sent to browser
DEBUG - 2025-05-06 07:29:41 --> Total execution time: 0.0321
INFO - 2025-05-06 07:29:43 --> Config Class Initialized
INFO - 2025-05-06 07:29:43 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:29:43 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:29:43 --> Utf8 Class Initialized
INFO - 2025-05-06 07:29:43 --> URI Class Initialized
INFO - 2025-05-06 07:29:43 --> Router Class Initialized
INFO - 2025-05-06 07:29:43 --> Output Class Initialized
INFO - 2025-05-06 07:29:43 --> Security Class Initialized
DEBUG - 2025-05-06 07:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:29:43 --> Input Class Initialized
INFO - 2025-05-06 07:29:43 --> Language Class Initialized
INFO - 2025-05-06 07:29:43 --> Loader Class Initialized
INFO - 2025-05-06 07:29:43 --> Helper loaded: form_helper
INFO - 2025-05-06 07:29:43 --> Helper loaded: url_helper
INFO - 2025-05-06 07:29:43 --> Database Driver Class Initialized
INFO - 2025-05-06 07:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:29:43 --> Form Validation Class Initialized
INFO - 2025-05-06 07:29:43 --> Controller Class Initialized
INFO - 2025-05-06 07:29:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:29:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:29:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:29:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-06 07:29:43 --> Final output sent to browser
DEBUG - 2025-05-06 07:29:43 --> Total execution time: 0.0279
INFO - 2025-05-06 07:30:30 --> Config Class Initialized
INFO - 2025-05-06 07:30:30 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:30:30 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:30:30 --> Utf8 Class Initialized
INFO - 2025-05-06 07:30:30 --> URI Class Initialized
INFO - 2025-05-06 07:30:30 --> Router Class Initialized
INFO - 2025-05-06 07:30:30 --> Output Class Initialized
INFO - 2025-05-06 07:30:30 --> Security Class Initialized
DEBUG - 2025-05-06 07:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:30:30 --> Input Class Initialized
INFO - 2025-05-06 07:30:30 --> Language Class Initialized
INFO - 2025-05-06 07:30:30 --> Loader Class Initialized
INFO - 2025-05-06 07:30:30 --> Helper loaded: form_helper
INFO - 2025-05-06 07:30:30 --> Helper loaded: url_helper
INFO - 2025-05-06 07:30:30 --> Database Driver Class Initialized
INFO - 2025-05-06 07:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:30:30 --> Form Validation Class Initialized
INFO - 2025-05-06 07:30:30 --> Controller Class Initialized
INFO - 2025-05-06 07:30:30 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:30:30 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:30:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:30:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 07:30:30 --> Final output sent to browser
DEBUG - 2025-05-06 07:30:30 --> Total execution time: 0.0261
INFO - 2025-05-06 07:30:32 --> Config Class Initialized
INFO - 2025-05-06 07:30:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:30:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:30:32 --> Utf8 Class Initialized
INFO - 2025-05-06 07:30:32 --> URI Class Initialized
INFO - 2025-05-06 07:30:32 --> Router Class Initialized
INFO - 2025-05-06 07:30:32 --> Output Class Initialized
INFO - 2025-05-06 07:30:32 --> Security Class Initialized
DEBUG - 2025-05-06 07:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:30:32 --> Input Class Initialized
INFO - 2025-05-06 07:30:32 --> Language Class Initialized
INFO - 2025-05-06 07:30:32 --> Loader Class Initialized
INFO - 2025-05-06 07:30:32 --> Helper loaded: form_helper
INFO - 2025-05-06 07:30:32 --> Helper loaded: url_helper
INFO - 2025-05-06 07:30:32 --> Database Driver Class Initialized
INFO - 2025-05-06 07:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:30:32 --> Form Validation Class Initialized
INFO - 2025-05-06 07:30:32 --> Controller Class Initialized
INFO - 2025-05-06 07:30:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:30:32 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:30:32 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:30:32 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_sekolah.php
INFO - 2025-05-06 07:30:32 --> Final output sent to browser
DEBUG - 2025-05-06 07:30:32 --> Total execution time: 0.0290
INFO - 2025-05-06 07:33:30 --> Config Class Initialized
INFO - 2025-05-06 07:33:30 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:33:30 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:33:30 --> Utf8 Class Initialized
INFO - 2025-05-06 07:33:30 --> URI Class Initialized
INFO - 2025-05-06 07:33:30 --> Router Class Initialized
INFO - 2025-05-06 07:33:30 --> Output Class Initialized
INFO - 2025-05-06 07:33:30 --> Security Class Initialized
DEBUG - 2025-05-06 07:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:33:30 --> Input Class Initialized
INFO - 2025-05-06 07:33:30 --> Language Class Initialized
INFO - 2025-05-06 07:33:30 --> Loader Class Initialized
INFO - 2025-05-06 07:33:30 --> Helper loaded: form_helper
INFO - 2025-05-06 07:33:30 --> Helper loaded: url_helper
INFO - 2025-05-06 07:33:30 --> Database Driver Class Initialized
INFO - 2025-05-06 07:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:33:30 --> Form Validation Class Initialized
INFO - 2025-05-06 07:33:30 --> Controller Class Initialized
INFO - 2025-05-06 07:33:30 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:33:30 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:33:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:33:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_rekomendasi.php
INFO - 2025-05-06 07:33:30 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:30 --> Total execution time: 0.0823
INFO - 2025-05-06 07:33:40 --> Config Class Initialized
INFO - 2025-05-06 07:33:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:33:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:33:40 --> Utf8 Class Initialized
INFO - 2025-05-06 07:33:40 --> URI Class Initialized
INFO - 2025-05-06 07:33:40 --> Router Class Initialized
INFO - 2025-05-06 07:33:40 --> Output Class Initialized
INFO - 2025-05-06 07:33:40 --> Security Class Initialized
DEBUG - 2025-05-06 07:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:33:40 --> Input Class Initialized
INFO - 2025-05-06 07:33:40 --> Language Class Initialized
INFO - 2025-05-06 07:33:40 --> Loader Class Initialized
INFO - 2025-05-06 07:33:40 --> Helper loaded: form_helper
INFO - 2025-05-06 07:33:40 --> Helper loaded: url_helper
INFO - 2025-05-06 07:33:40 --> Database Driver Class Initialized
INFO - 2025-05-06 07:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:33:40 --> Form Validation Class Initialized
INFO - 2025-05-06 07:33:40 --> Controller Class Initialized
INFO - 2025-05-06 07:33:40 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:33:40 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:33:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:33:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 07:33:40 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:40 --> Total execution time: 0.0255
INFO - 2025-05-06 07:33:41 --> Config Class Initialized
INFO - 2025-05-06 07:33:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:33:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:33:41 --> Utf8 Class Initialized
INFO - 2025-05-06 07:33:41 --> URI Class Initialized
INFO - 2025-05-06 07:33:41 --> Router Class Initialized
INFO - 2025-05-06 07:33:41 --> Output Class Initialized
INFO - 2025-05-06 07:33:41 --> Security Class Initialized
DEBUG - 2025-05-06 07:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:33:41 --> Input Class Initialized
INFO - 2025-05-06 07:33:41 --> Language Class Initialized
INFO - 2025-05-06 07:33:41 --> Loader Class Initialized
INFO - 2025-05-06 07:33:41 --> Helper loaded: form_helper
INFO - 2025-05-06 07:33:41 --> Helper loaded: url_helper
INFO - 2025-05-06 07:33:41 --> Database Driver Class Initialized
INFO - 2025-05-06 07:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:33:41 --> Form Validation Class Initialized
INFO - 2025-05-06 07:33:41 --> Controller Class Initialized
INFO - 2025-05-06 07:33:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:33:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:33:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:33:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-06 07:33:41 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:41 --> Total execution time: 0.0290
INFO - 2025-05-06 07:33:43 --> Config Class Initialized
INFO - 2025-05-06 07:33:43 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:33:43 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:33:43 --> Utf8 Class Initialized
INFO - 2025-05-06 07:33:43 --> URI Class Initialized
INFO - 2025-05-06 07:33:43 --> Router Class Initialized
INFO - 2025-05-06 07:33:43 --> Output Class Initialized
INFO - 2025-05-06 07:33:43 --> Security Class Initialized
DEBUG - 2025-05-06 07:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:33:43 --> Input Class Initialized
INFO - 2025-05-06 07:33:43 --> Language Class Initialized
INFO - 2025-05-06 07:33:43 --> Loader Class Initialized
INFO - 2025-05-06 07:33:43 --> Helper loaded: form_helper
INFO - 2025-05-06 07:33:43 --> Helper loaded: url_helper
INFO - 2025-05-06 07:33:43 --> Database Driver Class Initialized
INFO - 2025-05-06 07:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:33:43 --> Form Validation Class Initialized
INFO - 2025-05-06 07:33:43 --> Controller Class Initialized
INFO - 2025-05-06 07:33:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:33:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:33:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:33:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-06 07:33:43 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:43 --> Total execution time: 0.0282
INFO - 2025-05-06 07:33:45 --> Config Class Initialized
INFO - 2025-05-06 07:33:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:33:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:33:45 --> Utf8 Class Initialized
INFO - 2025-05-06 07:33:45 --> URI Class Initialized
INFO - 2025-05-06 07:33:45 --> Router Class Initialized
INFO - 2025-05-06 07:33:45 --> Output Class Initialized
INFO - 2025-05-06 07:33:45 --> Security Class Initialized
DEBUG - 2025-05-06 07:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:33:45 --> Input Class Initialized
INFO - 2025-05-06 07:33:45 --> Language Class Initialized
INFO - 2025-05-06 07:33:45 --> Loader Class Initialized
INFO - 2025-05-06 07:33:45 --> Helper loaded: form_helper
INFO - 2025-05-06 07:33:45 --> Helper loaded: url_helper
INFO - 2025-05-06 07:33:45 --> Database Driver Class Initialized
INFO - 2025-05-06 07:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:33:45 --> Form Validation Class Initialized
INFO - 2025-05-06 07:33:45 --> Controller Class Initialized
INFO - 2025-05-06 07:33:45 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:33:45 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:33:46 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-06 07:33:46 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:46 --> Total execution time: 0.2045
INFO - 2025-05-06 07:33:54 --> Config Class Initialized
INFO - 2025-05-06 07:33:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:33:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:33:54 --> Utf8 Class Initialized
INFO - 2025-05-06 07:33:54 --> URI Class Initialized
INFO - 2025-05-06 07:33:54 --> Router Class Initialized
INFO - 2025-05-06 07:33:54 --> Output Class Initialized
INFO - 2025-05-06 07:33:54 --> Security Class Initialized
DEBUG - 2025-05-06 07:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:33:54 --> Input Class Initialized
INFO - 2025-05-06 07:33:54 --> Language Class Initialized
INFO - 2025-05-06 07:33:54 --> Loader Class Initialized
INFO - 2025-05-06 07:33:54 --> Helper loaded: form_helper
INFO - 2025-05-06 07:33:54 --> Helper loaded: url_helper
INFO - 2025-05-06 07:33:54 --> Database Driver Class Initialized
INFO - 2025-05-06 07:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:33:54 --> Form Validation Class Initialized
INFO - 2025-05-06 07:33:54 --> Controller Class Initialized
INFO - 2025-05-06 07:33:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:33:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:33:54 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-06 07:33:54 --> Final output sent to browser
DEBUG - 2025-05-06 07:33:54 --> Total execution time: 0.0290
INFO - 2025-05-06 07:34:59 --> Config Class Initialized
INFO - 2025-05-06 07:34:59 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:34:59 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:34:59 --> Utf8 Class Initialized
INFO - 2025-05-06 07:34:59 --> URI Class Initialized
INFO - 2025-05-06 07:34:59 --> Router Class Initialized
INFO - 2025-05-06 07:34:59 --> Output Class Initialized
INFO - 2025-05-06 07:34:59 --> Security Class Initialized
DEBUG - 2025-05-06 07:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:34:59 --> Input Class Initialized
INFO - 2025-05-06 07:34:59 --> Language Class Initialized
INFO - 2025-05-06 07:34:59 --> Loader Class Initialized
INFO - 2025-05-06 07:34:59 --> Helper loaded: form_helper
INFO - 2025-05-06 07:34:59 --> Helper loaded: url_helper
INFO - 2025-05-06 07:34:59 --> Database Driver Class Initialized
INFO - 2025-05-06 07:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:34:59 --> Form Validation Class Initialized
INFO - 2025-05-06 07:34:59 --> Controller Class Initialized
INFO - 2025-05-06 07:34:59 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:34:59 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:34:59 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:34:59 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 07:34:59 --> Final output sent to browser
DEBUG - 2025-05-06 07:34:59 --> Total execution time: 0.0256
INFO - 2025-05-06 07:35:06 --> Config Class Initialized
INFO - 2025-05-06 07:35:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:35:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:35:06 --> Utf8 Class Initialized
INFO - 2025-05-06 07:35:06 --> URI Class Initialized
INFO - 2025-05-06 07:35:06 --> Router Class Initialized
INFO - 2025-05-06 07:35:06 --> Output Class Initialized
INFO - 2025-05-06 07:35:06 --> Security Class Initialized
DEBUG - 2025-05-06 07:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:35:06 --> Input Class Initialized
INFO - 2025-05-06 07:35:06 --> Language Class Initialized
INFO - 2025-05-06 07:35:06 --> Loader Class Initialized
INFO - 2025-05-06 07:35:06 --> Helper loaded: form_helper
INFO - 2025-05-06 07:35:06 --> Helper loaded: url_helper
INFO - 2025-05-06 07:35:06 --> Database Driver Class Initialized
INFO - 2025-05-06 07:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:35:06 --> Form Validation Class Initialized
INFO - 2025-05-06 07:35:06 --> Controller Class Initialized
INFO - 2025-05-06 07:35:06 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:35:06 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:35:06 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:35:06 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-06 07:35:06 --> Final output sent to browser
DEBUG - 2025-05-06 07:35:06 --> Total execution time: 0.0279
INFO - 2025-05-06 07:39:02 --> Config Class Initialized
INFO - 2025-05-06 07:39:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:39:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:39:02 --> Utf8 Class Initialized
INFO - 2025-05-06 07:39:02 --> URI Class Initialized
DEBUG - 2025-05-06 07:39:02 --> No URI present. Default controller set.
INFO - 2025-05-06 07:39:02 --> Router Class Initialized
INFO - 2025-05-06 07:39:02 --> Output Class Initialized
INFO - 2025-05-06 07:39:02 --> Security Class Initialized
DEBUG - 2025-05-06 07:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:39:02 --> Input Class Initialized
INFO - 2025-05-06 07:39:02 --> Language Class Initialized
INFO - 2025-05-06 07:39:02 --> Loader Class Initialized
INFO - 2025-05-06 07:39:02 --> Helper loaded: form_helper
INFO - 2025-05-06 07:39:02 --> Helper loaded: url_helper
INFO - 2025-05-06 07:39:02 --> Database Driver Class Initialized
INFO - 2025-05-06 07:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:39:02 --> Form Validation Class Initialized
INFO - 2025-05-06 07:39:02 --> Controller Class Initialized
INFO - 2025-05-06 07:39:02 --> Final output sent to browser
DEBUG - 2025-05-06 07:39:02 --> Total execution time: 0.0240
INFO - 2025-05-06 07:39:06 --> Config Class Initialized
INFO - 2025-05-06 07:39:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:39:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:39:06 --> Utf8 Class Initialized
INFO - 2025-05-06 07:39:06 --> URI Class Initialized
INFO - 2025-05-06 07:39:06 --> Router Class Initialized
INFO - 2025-05-06 07:39:06 --> Output Class Initialized
INFO - 2025-05-06 07:39:06 --> Security Class Initialized
DEBUG - 2025-05-06 07:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:39:06 --> Input Class Initialized
INFO - 2025-05-06 07:39:06 --> Language Class Initialized
INFO - 2025-05-06 07:39:06 --> Loader Class Initialized
INFO - 2025-05-06 07:39:06 --> Helper loaded: form_helper
INFO - 2025-05-06 07:39:06 --> Helper loaded: url_helper
INFO - 2025-05-06 07:39:06 --> Database Driver Class Initialized
INFO - 2025-05-06 07:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:39:06 --> Form Validation Class Initialized
INFO - 2025-05-06 07:39:06 --> Controller Class Initialized
DEBUG - 2025-05-06 07:39:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-06 07:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-06 07:39:06 --> Model "Ppdb_model" initialized
INFO - 2025-05-06 07:39:06 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-06 07:39:06 --> Final output sent to browser
DEBUG - 2025-05-06 07:39:06 --> Total execution time: 0.0647
INFO - 2025-05-06 07:39:09 --> Config Class Initialized
INFO - 2025-05-06 07:39:09 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:39:09 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:39:09 --> Utf8 Class Initialized
INFO - 2025-05-06 07:39:09 --> URI Class Initialized
INFO - 2025-05-06 07:39:09 --> Router Class Initialized
INFO - 2025-05-06 07:39:09 --> Output Class Initialized
INFO - 2025-05-06 07:39:09 --> Security Class Initialized
DEBUG - 2025-05-06 07:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:39:09 --> Input Class Initialized
INFO - 2025-05-06 07:39:09 --> Language Class Initialized
INFO - 2025-05-06 07:39:09 --> Loader Class Initialized
INFO - 2025-05-06 07:39:09 --> Helper loaded: form_helper
INFO - 2025-05-06 07:39:09 --> Helper loaded: url_helper
INFO - 2025-05-06 07:39:09 --> Database Driver Class Initialized
INFO - 2025-05-06 07:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:39:09 --> Form Validation Class Initialized
INFO - 2025-05-06 07:39:09 --> Controller Class Initialized
INFO - 2025-05-06 07:39:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:39:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:39:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:39:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 07:39:09 --> Final output sent to browser
DEBUG - 2025-05-06 07:39:09 --> Total execution time: 0.0266
INFO - 2025-05-06 07:39:16 --> Config Class Initialized
INFO - 2025-05-06 07:39:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:39:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:39:16 --> Utf8 Class Initialized
INFO - 2025-05-06 07:39:16 --> URI Class Initialized
INFO - 2025-05-06 07:39:16 --> Router Class Initialized
INFO - 2025-05-06 07:39:16 --> Output Class Initialized
INFO - 2025-05-06 07:39:16 --> Security Class Initialized
DEBUG - 2025-05-06 07:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:39:16 --> Input Class Initialized
INFO - 2025-05-06 07:39:16 --> Language Class Initialized
INFO - 2025-05-06 07:39:16 --> Loader Class Initialized
INFO - 2025-05-06 07:39:16 --> Helper loaded: form_helper
INFO - 2025-05-06 07:39:16 --> Helper loaded: url_helper
INFO - 2025-05-06 07:39:16 --> Database Driver Class Initialized
INFO - 2025-05-06 07:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:39:16 --> Form Validation Class Initialized
INFO - 2025-05-06 07:39:16 --> Controller Class Initialized
INFO - 2025-05-06 07:39:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:39:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:39:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:39:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-06 07:39:16 --> Final output sent to browser
DEBUG - 2025-05-06 07:39:16 --> Total execution time: 0.0283
INFO - 2025-05-06 07:39:23 --> Config Class Initialized
INFO - 2025-05-06 07:39:23 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:39:23 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:39:23 --> Utf8 Class Initialized
INFO - 2025-05-06 07:39:23 --> URI Class Initialized
INFO - 2025-05-06 07:39:23 --> Router Class Initialized
INFO - 2025-05-06 07:39:23 --> Output Class Initialized
INFO - 2025-05-06 07:39:23 --> Security Class Initialized
DEBUG - 2025-05-06 07:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:39:23 --> Input Class Initialized
INFO - 2025-05-06 07:39:23 --> Language Class Initialized
INFO - 2025-05-06 07:39:23 --> Loader Class Initialized
INFO - 2025-05-06 07:39:23 --> Helper loaded: form_helper
INFO - 2025-05-06 07:39:23 --> Helper loaded: url_helper
INFO - 2025-05-06 07:39:23 --> Database Driver Class Initialized
INFO - 2025-05-06 07:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:39:23 --> Form Validation Class Initialized
INFO - 2025-05-06 07:39:23 --> Controller Class Initialized
INFO - 2025-05-06 07:39:23 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:39:23 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:39:23 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:39:23 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-06 07:39:23 --> Final output sent to browser
DEBUG - 2025-05-06 07:39:23 --> Total execution time: 0.0348
INFO - 2025-05-06 07:40:09 --> Config Class Initialized
INFO - 2025-05-06 07:40:09 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:40:09 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:40:09 --> Utf8 Class Initialized
INFO - 2025-05-06 07:40:09 --> URI Class Initialized
INFO - 2025-05-06 07:40:09 --> Router Class Initialized
INFO - 2025-05-06 07:40:09 --> Output Class Initialized
INFO - 2025-05-06 07:40:09 --> Security Class Initialized
DEBUG - 2025-05-06 07:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:40:09 --> Input Class Initialized
INFO - 2025-05-06 07:40:09 --> Language Class Initialized
INFO - 2025-05-06 07:40:09 --> Loader Class Initialized
INFO - 2025-05-06 07:40:09 --> Helper loaded: form_helper
INFO - 2025-05-06 07:40:09 --> Helper loaded: url_helper
INFO - 2025-05-06 07:40:09 --> Database Driver Class Initialized
INFO - 2025-05-06 07:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:40:09 --> Form Validation Class Initialized
INFO - 2025-05-06 07:40:09 --> Controller Class Initialized
INFO - 2025-05-06 07:40:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:40:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:40:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:40:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-06 07:40:09 --> Final output sent to browser
DEBUG - 2025-05-06 07:40:09 --> Total execution time: 0.0302
INFO - 2025-05-06 07:40:12 --> Config Class Initialized
INFO - 2025-05-06 07:40:12 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:40:12 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:40:12 --> Utf8 Class Initialized
INFO - 2025-05-06 07:40:12 --> URI Class Initialized
INFO - 2025-05-06 07:40:12 --> Router Class Initialized
INFO - 2025-05-06 07:40:12 --> Output Class Initialized
INFO - 2025-05-06 07:40:12 --> Security Class Initialized
DEBUG - 2025-05-06 07:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:40:12 --> Input Class Initialized
INFO - 2025-05-06 07:40:12 --> Language Class Initialized
INFO - 2025-05-06 07:40:12 --> Loader Class Initialized
INFO - 2025-05-06 07:40:12 --> Helper loaded: form_helper
INFO - 2025-05-06 07:40:12 --> Helper loaded: url_helper
INFO - 2025-05-06 07:40:12 --> Database Driver Class Initialized
INFO - 2025-05-06 07:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:40:12 --> Form Validation Class Initialized
INFO - 2025-05-06 07:40:12 --> Controller Class Initialized
INFO - 2025-05-06 07:40:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:40:12 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:40:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:40:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 07:40:12 --> Final output sent to browser
DEBUG - 2025-05-06 07:40:12 --> Total execution time: 0.0316
INFO - 2025-05-06 07:40:43 --> Config Class Initialized
INFO - 2025-05-06 07:40:43 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:40:43 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:40:43 --> Utf8 Class Initialized
INFO - 2025-05-06 07:40:43 --> URI Class Initialized
INFO - 2025-05-06 07:40:43 --> Router Class Initialized
INFO - 2025-05-06 07:40:43 --> Output Class Initialized
INFO - 2025-05-06 07:40:43 --> Security Class Initialized
DEBUG - 2025-05-06 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:40:43 --> Input Class Initialized
INFO - 2025-05-06 07:40:43 --> Language Class Initialized
INFO - 2025-05-06 07:40:43 --> Loader Class Initialized
INFO - 2025-05-06 07:40:43 --> Helper loaded: form_helper
INFO - 2025-05-06 07:40:43 --> Helper loaded: url_helper
INFO - 2025-05-06 07:40:43 --> Database Driver Class Initialized
INFO - 2025-05-06 07:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:40:43 --> Form Validation Class Initialized
INFO - 2025-05-06 07:40:43 --> Controller Class Initialized
INFO - 2025-05-06 07:40:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:40:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:40:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:40:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 07:40:43 --> Final output sent to browser
DEBUG - 2025-05-06 07:40:43 --> Total execution time: 0.0265
INFO - 2025-05-06 07:49:11 --> Config Class Initialized
INFO - 2025-05-06 07:49:11 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:49:11 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:49:11 --> Utf8 Class Initialized
INFO - 2025-05-06 07:49:11 --> URI Class Initialized
INFO - 2025-05-06 07:49:11 --> Router Class Initialized
INFO - 2025-05-06 07:49:11 --> Output Class Initialized
INFO - 2025-05-06 07:49:11 --> Security Class Initialized
DEBUG - 2025-05-06 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:49:11 --> Input Class Initialized
INFO - 2025-05-06 07:49:11 --> Language Class Initialized
INFO - 2025-05-06 07:49:11 --> Loader Class Initialized
INFO - 2025-05-06 07:49:11 --> Helper loaded: form_helper
INFO - 2025-05-06 07:49:11 --> Helper loaded: url_helper
INFO - 2025-05-06 07:49:11 --> Database Driver Class Initialized
INFO - 2025-05-06 07:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:49:11 --> Form Validation Class Initialized
INFO - 2025-05-06 07:49:11 --> Controller Class Initialized
INFO - 2025-05-06 07:49:11 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:49:11 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:49:11 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:49:11 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-06 07:49:11 --> Final output sent to browser
DEBUG - 2025-05-06 07:49:11 --> Total execution time: 0.0311
INFO - 2025-05-06 07:49:22 --> Config Class Initialized
INFO - 2025-05-06 07:49:22 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:49:22 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:49:22 --> Utf8 Class Initialized
INFO - 2025-05-06 07:49:22 --> URI Class Initialized
INFO - 2025-05-06 07:49:22 --> Router Class Initialized
INFO - 2025-05-06 07:49:22 --> Output Class Initialized
INFO - 2025-05-06 07:49:22 --> Security Class Initialized
DEBUG - 2025-05-06 07:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:49:22 --> Input Class Initialized
INFO - 2025-05-06 07:49:22 --> Language Class Initialized
INFO - 2025-05-06 07:49:22 --> Loader Class Initialized
INFO - 2025-05-06 07:49:22 --> Helper loaded: form_helper
INFO - 2025-05-06 07:49:22 --> Helper loaded: url_helper
INFO - 2025-05-06 07:49:22 --> Database Driver Class Initialized
INFO - 2025-05-06 07:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:49:22 --> Form Validation Class Initialized
INFO - 2025-05-06 07:49:22 --> Controller Class Initialized
INFO - 2025-05-06 07:49:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:49:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:49:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:49:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-06 07:49:22 --> Final output sent to browser
DEBUG - 2025-05-06 07:49:22 --> Total execution time: 0.0336
INFO - 2025-05-06 07:49:24 --> Config Class Initialized
INFO - 2025-05-06 07:49:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:49:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:49:24 --> Utf8 Class Initialized
INFO - 2025-05-06 07:49:24 --> URI Class Initialized
INFO - 2025-05-06 07:49:24 --> Router Class Initialized
INFO - 2025-05-06 07:49:24 --> Output Class Initialized
INFO - 2025-05-06 07:49:24 --> Security Class Initialized
DEBUG - 2025-05-06 07:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:49:24 --> Input Class Initialized
INFO - 2025-05-06 07:49:24 --> Language Class Initialized
INFO - 2025-05-06 07:49:24 --> Loader Class Initialized
INFO - 2025-05-06 07:49:24 --> Helper loaded: form_helper
INFO - 2025-05-06 07:49:24 --> Helper loaded: url_helper
INFO - 2025-05-06 07:49:24 --> Database Driver Class Initialized
INFO - 2025-05-06 07:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:49:24 --> Form Validation Class Initialized
INFO - 2025-05-06 07:49:24 --> Controller Class Initialized
INFO - 2025-05-06 07:49:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:49:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:49:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:49:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-06 07:49:24 --> Final output sent to browser
DEBUG - 2025-05-06 07:49:24 --> Total execution time: 0.0302
INFO - 2025-05-06 07:49:49 --> Config Class Initialized
INFO - 2025-05-06 07:49:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:49:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:49:49 --> Utf8 Class Initialized
INFO - 2025-05-06 07:49:49 --> URI Class Initialized
INFO - 2025-05-06 07:49:49 --> Router Class Initialized
INFO - 2025-05-06 07:49:49 --> Output Class Initialized
INFO - 2025-05-06 07:49:49 --> Security Class Initialized
DEBUG - 2025-05-06 07:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:49:49 --> Input Class Initialized
INFO - 2025-05-06 07:49:49 --> Language Class Initialized
INFO - 2025-05-06 07:49:49 --> Loader Class Initialized
INFO - 2025-05-06 07:49:49 --> Helper loaded: form_helper
INFO - 2025-05-06 07:49:49 --> Helper loaded: url_helper
INFO - 2025-05-06 07:49:49 --> Database Driver Class Initialized
INFO - 2025-05-06 07:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:49:49 --> Form Validation Class Initialized
INFO - 2025-05-06 07:49:49 --> Controller Class Initialized
INFO - 2025-05-06 07:49:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:49:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:49:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:49:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 07:49:49 --> Final output sent to browser
DEBUG - 2025-05-06 07:49:49 --> Total execution time: 0.0297
INFO - 2025-05-06 07:57:55 --> Config Class Initialized
INFO - 2025-05-06 07:57:55 --> Hooks Class Initialized
DEBUG - 2025-05-06 07:57:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 07:57:55 --> Utf8 Class Initialized
INFO - 2025-05-06 07:57:55 --> URI Class Initialized
INFO - 2025-05-06 07:57:55 --> Router Class Initialized
INFO - 2025-05-06 07:57:55 --> Output Class Initialized
INFO - 2025-05-06 07:57:55 --> Security Class Initialized
DEBUG - 2025-05-06 07:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 07:57:55 --> Input Class Initialized
INFO - 2025-05-06 07:57:55 --> Language Class Initialized
INFO - 2025-05-06 07:57:55 --> Loader Class Initialized
INFO - 2025-05-06 07:57:55 --> Helper loaded: form_helper
INFO - 2025-05-06 07:57:55 --> Helper loaded: url_helper
INFO - 2025-05-06 07:57:55 --> Database Driver Class Initialized
INFO - 2025-05-06 07:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 07:57:55 --> Form Validation Class Initialized
INFO - 2025-05-06 07:57:55 --> Controller Class Initialized
INFO - 2025-05-06 07:57:55 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 07:57:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 07:57:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 07:57:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 07:57:55 --> Final output sent to browser
DEBUG - 2025-05-06 07:57:55 --> Total execution time: 0.0303
INFO - 2025-05-06 08:39:16 --> Config Class Initialized
INFO - 2025-05-06 08:39:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:39:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:39:16 --> Utf8 Class Initialized
INFO - 2025-05-06 08:39:16 --> URI Class Initialized
INFO - 2025-05-06 08:39:16 --> Router Class Initialized
INFO - 2025-05-06 08:39:16 --> Output Class Initialized
INFO - 2025-05-06 08:39:16 --> Security Class Initialized
DEBUG - 2025-05-06 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:39:16 --> Input Class Initialized
INFO - 2025-05-06 08:39:16 --> Language Class Initialized
INFO - 2025-05-06 08:39:16 --> Loader Class Initialized
INFO - 2025-05-06 08:39:16 --> Helper loaded: form_helper
INFO - 2025-05-06 08:39:16 --> Helper loaded: url_helper
INFO - 2025-05-06 08:39:16 --> Database Driver Class Initialized
INFO - 2025-05-06 08:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:39:16 --> Form Validation Class Initialized
INFO - 2025-05-06 08:39:16 --> Controller Class Initialized
INFO - 2025-05-06 08:39:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:39:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:39:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:39:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-06 08:39:16 --> Final output sent to browser
DEBUG - 2025-05-06 08:39:16 --> Total execution time: 0.0358
INFO - 2025-05-06 08:39:19 --> Config Class Initialized
INFO - 2025-05-06 08:39:19 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:39:19 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:39:19 --> Utf8 Class Initialized
INFO - 2025-05-06 08:39:19 --> URI Class Initialized
INFO - 2025-05-06 08:39:19 --> Router Class Initialized
INFO - 2025-05-06 08:39:19 --> Output Class Initialized
INFO - 2025-05-06 08:39:19 --> Security Class Initialized
DEBUG - 2025-05-06 08:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:39:19 --> Input Class Initialized
INFO - 2025-05-06 08:39:19 --> Language Class Initialized
INFO - 2025-05-06 08:39:19 --> Loader Class Initialized
INFO - 2025-05-06 08:39:19 --> Helper loaded: form_helper
INFO - 2025-05-06 08:39:19 --> Helper loaded: url_helper
INFO - 2025-05-06 08:39:19 --> Database Driver Class Initialized
INFO - 2025-05-06 08:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:39:19 --> Form Validation Class Initialized
INFO - 2025-05-06 08:39:19 --> Controller Class Initialized
INFO - 2025-05-06 08:39:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:39:19 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:39:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:39:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-06 08:39:19 --> Final output sent to browser
DEBUG - 2025-05-06 08:39:19 --> Total execution time: 0.0318
INFO - 2025-05-06 08:40:48 --> Config Class Initialized
INFO - 2025-05-06 08:40:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:40:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:40:48 --> Utf8 Class Initialized
INFO - 2025-05-06 08:40:48 --> URI Class Initialized
INFO - 2025-05-06 08:40:48 --> Router Class Initialized
INFO - 2025-05-06 08:40:48 --> Output Class Initialized
INFO - 2025-05-06 08:40:48 --> Security Class Initialized
DEBUG - 2025-05-06 08:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:40:48 --> Input Class Initialized
INFO - 2025-05-06 08:40:48 --> Language Class Initialized
INFO - 2025-05-06 08:40:48 --> Loader Class Initialized
INFO - 2025-05-06 08:40:48 --> Helper loaded: form_helper
INFO - 2025-05-06 08:40:48 --> Helper loaded: url_helper
INFO - 2025-05-06 08:40:48 --> Database Driver Class Initialized
INFO - 2025-05-06 08:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:40:48 --> Form Validation Class Initialized
INFO - 2025-05-06 08:40:48 --> Controller Class Initialized
INFO - 2025-05-06 08:40:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:40:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:40:48 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:40:48 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-06 08:40:48 --> Final output sent to browser
DEBUG - 2025-05-06 08:40:48 --> Total execution time: 0.0317
INFO - 2025-05-06 08:40:51 --> Config Class Initialized
INFO - 2025-05-06 08:40:51 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:40:51 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:40:51 --> Utf8 Class Initialized
INFO - 2025-05-06 08:40:51 --> URI Class Initialized
INFO - 2025-05-06 08:40:51 --> Router Class Initialized
INFO - 2025-05-06 08:40:51 --> Output Class Initialized
INFO - 2025-05-06 08:40:51 --> Security Class Initialized
DEBUG - 2025-05-06 08:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:40:51 --> Input Class Initialized
INFO - 2025-05-06 08:40:51 --> Language Class Initialized
INFO - 2025-05-06 08:40:51 --> Loader Class Initialized
INFO - 2025-05-06 08:40:51 --> Helper loaded: form_helper
INFO - 2025-05-06 08:40:51 --> Helper loaded: url_helper
INFO - 2025-05-06 08:40:51 --> Database Driver Class Initialized
INFO - 2025-05-06 08:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:40:51 --> Form Validation Class Initialized
INFO - 2025-05-06 08:40:51 --> Controller Class Initialized
INFO - 2025-05-06 08:40:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:40:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:40:51 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:40:51 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 08:40:51 --> Final output sent to browser
DEBUG - 2025-05-06 08:40:51 --> Total execution time: 0.0317
INFO - 2025-05-06 08:41:21 --> Config Class Initialized
INFO - 2025-05-06 08:41:21 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:41:21 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:41:21 --> Utf8 Class Initialized
INFO - 2025-05-06 08:41:21 --> URI Class Initialized
INFO - 2025-05-06 08:41:21 --> Router Class Initialized
INFO - 2025-05-06 08:41:21 --> Output Class Initialized
INFO - 2025-05-06 08:41:21 --> Security Class Initialized
DEBUG - 2025-05-06 08:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:41:21 --> Input Class Initialized
INFO - 2025-05-06 08:41:21 --> Language Class Initialized
INFO - 2025-05-06 08:41:21 --> Loader Class Initialized
INFO - 2025-05-06 08:41:21 --> Helper loaded: form_helper
INFO - 2025-05-06 08:41:21 --> Helper loaded: url_helper
INFO - 2025-05-06 08:41:21 --> Database Driver Class Initialized
INFO - 2025-05-06 08:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:41:21 --> Form Validation Class Initialized
INFO - 2025-05-06 08:41:21 --> Controller Class Initialized
INFO - 2025-05-06 08:41:21 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:41:21 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:41:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:41:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-06 08:41:21 --> Final output sent to browser
DEBUG - 2025-05-06 08:41:21 --> Total execution time: 0.0277
INFO - 2025-05-06 08:41:34 --> Config Class Initialized
INFO - 2025-05-06 08:41:34 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:41:34 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:41:34 --> Utf8 Class Initialized
INFO - 2025-05-06 08:41:34 --> URI Class Initialized
INFO - 2025-05-06 08:41:34 --> Router Class Initialized
INFO - 2025-05-06 08:41:34 --> Output Class Initialized
INFO - 2025-05-06 08:41:34 --> Security Class Initialized
DEBUG - 2025-05-06 08:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:41:34 --> Input Class Initialized
INFO - 2025-05-06 08:41:34 --> Language Class Initialized
INFO - 2025-05-06 08:41:34 --> Loader Class Initialized
INFO - 2025-05-06 08:41:34 --> Helper loaded: form_helper
INFO - 2025-05-06 08:41:34 --> Helper loaded: url_helper
INFO - 2025-05-06 08:41:34 --> Database Driver Class Initialized
INFO - 2025-05-06 08:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:41:34 --> Form Validation Class Initialized
INFO - 2025-05-06 08:41:34 --> Controller Class Initialized
INFO - 2025-05-06 08:41:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:41:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:41:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:41:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_sekolah.php
INFO - 2025-05-06 08:41:34 --> Final output sent to browser
DEBUG - 2025-05-06 08:41:34 --> Total execution time: 0.0303
INFO - 2025-05-06 08:41:38 --> Config Class Initialized
INFO - 2025-05-06 08:41:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:41:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:41:38 --> Utf8 Class Initialized
INFO - 2025-05-06 08:41:38 --> URI Class Initialized
INFO - 2025-05-06 08:41:38 --> Router Class Initialized
INFO - 2025-05-06 08:41:38 --> Output Class Initialized
INFO - 2025-05-06 08:41:38 --> Security Class Initialized
DEBUG - 2025-05-06 08:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:41:38 --> Input Class Initialized
INFO - 2025-05-06 08:41:38 --> Language Class Initialized
INFO - 2025-05-06 08:41:39 --> Loader Class Initialized
INFO - 2025-05-06 08:41:39 --> Helper loaded: form_helper
INFO - 2025-05-06 08:41:39 --> Helper loaded: url_helper
INFO - 2025-05-06 08:41:39 --> Database Driver Class Initialized
INFO - 2025-05-06 08:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:41:39 --> Form Validation Class Initialized
INFO - 2025-05-06 08:41:39 --> Controller Class Initialized
INFO - 2025-05-06 08:41:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:41:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:41:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:41:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_rekomendasi.php
INFO - 2025-05-06 08:41:39 --> Final output sent to browser
DEBUG - 2025-05-06 08:41:39 --> Total execution time: 0.0288
INFO - 2025-05-06 08:41:40 --> Config Class Initialized
INFO - 2025-05-06 08:41:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:41:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:41:40 --> Utf8 Class Initialized
INFO - 2025-05-06 08:41:40 --> URI Class Initialized
INFO - 2025-05-06 08:41:40 --> Router Class Initialized
INFO - 2025-05-06 08:41:40 --> Output Class Initialized
INFO - 2025-05-06 08:41:40 --> Security Class Initialized
DEBUG - 2025-05-06 08:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:41:40 --> Input Class Initialized
INFO - 2025-05-06 08:41:40 --> Language Class Initialized
INFO - 2025-05-06 08:41:40 --> Loader Class Initialized
INFO - 2025-05-06 08:41:40 --> Helper loaded: form_helper
INFO - 2025-05-06 08:41:40 --> Helper loaded: url_helper
INFO - 2025-05-06 08:41:40 --> Database Driver Class Initialized
INFO - 2025-05-06 08:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:41:40 --> Form Validation Class Initialized
INFO - 2025-05-06 08:41:40 --> Controller Class Initialized
INFO - 2025-05-06 08:41:40 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:41:40 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:41:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:41:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-06 08:41:40 --> Final output sent to browser
DEBUG - 2025-05-06 08:41:40 --> Total execution time: 0.0454
INFO - 2025-05-06 08:42:23 --> Config Class Initialized
INFO - 2025-05-06 08:42:23 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:42:23 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:42:23 --> Utf8 Class Initialized
INFO - 2025-05-06 08:42:23 --> URI Class Initialized
INFO - 2025-05-06 08:42:23 --> Router Class Initialized
INFO - 2025-05-06 08:42:23 --> Output Class Initialized
INFO - 2025-05-06 08:42:23 --> Security Class Initialized
DEBUG - 2025-05-06 08:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:42:23 --> Input Class Initialized
INFO - 2025-05-06 08:42:23 --> Language Class Initialized
INFO - 2025-05-06 08:42:23 --> Loader Class Initialized
INFO - 2025-05-06 08:42:23 --> Helper loaded: form_helper
INFO - 2025-05-06 08:42:23 --> Helper loaded: url_helper
INFO - 2025-05-06 08:42:23 --> Database Driver Class Initialized
INFO - 2025-05-06 08:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:42:23 --> Form Validation Class Initialized
INFO - 2025-05-06 08:42:23 --> Controller Class Initialized
INFO - 2025-05-06 08:42:23 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:42:23 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:42:23 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:42:23 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-06 08:42:23 --> Final output sent to browser
DEBUG - 2025-05-06 08:42:23 --> Total execution time: 0.0313
INFO - 2025-05-06 08:42:42 --> Config Class Initialized
INFO - 2025-05-06 08:42:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:42:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:42:42 --> Utf8 Class Initialized
INFO - 2025-05-06 08:42:42 --> URI Class Initialized
INFO - 2025-05-06 08:42:42 --> Router Class Initialized
INFO - 2025-05-06 08:42:42 --> Output Class Initialized
INFO - 2025-05-06 08:42:42 --> Security Class Initialized
DEBUG - 2025-05-06 08:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:42:42 --> Input Class Initialized
INFO - 2025-05-06 08:42:42 --> Language Class Initialized
INFO - 2025-05-06 08:42:42 --> Loader Class Initialized
INFO - 2025-05-06 08:42:42 --> Helper loaded: form_helper
INFO - 2025-05-06 08:42:42 --> Helper loaded: url_helper
INFO - 2025-05-06 08:42:42 --> Database Driver Class Initialized
INFO - 2025-05-06 08:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:42:42 --> Form Validation Class Initialized
INFO - 2025-05-06 08:42:42 --> Controller Class Initialized
INFO - 2025-05-06 08:42:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:42:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:42:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:42:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:42:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-06 08:42:42 --> Final output sent to browser
DEBUG - 2025-05-06 08:42:42 --> Total execution time: 0.0273
INFO - 2025-05-06 08:42:47 --> Config Class Initialized
INFO - 2025-05-06 08:42:47 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:42:47 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:42:47 --> Utf8 Class Initialized
INFO - 2025-05-06 08:42:47 --> URI Class Initialized
INFO - 2025-05-06 08:42:47 --> Router Class Initialized
INFO - 2025-05-06 08:42:47 --> Output Class Initialized
INFO - 2025-05-06 08:42:47 --> Security Class Initialized
DEBUG - 2025-05-06 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:42:47 --> Input Class Initialized
INFO - 2025-05-06 08:42:47 --> Language Class Initialized
INFO - 2025-05-06 08:42:47 --> Loader Class Initialized
INFO - 2025-05-06 08:42:47 --> Helper loaded: form_helper
INFO - 2025-05-06 08:42:47 --> Helper loaded: url_helper
INFO - 2025-05-06 08:42:47 --> Database Driver Class Initialized
INFO - 2025-05-06 08:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:42:47 --> Form Validation Class Initialized
INFO - 2025-05-06 08:42:47 --> Controller Class Initialized
INFO - 2025-05-06 08:42:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:42:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:42:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:42:47 --> Config Class Initialized
INFO - 2025-05-06 08:42:47 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:42:47 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:42:47 --> Utf8 Class Initialized
INFO - 2025-05-06 08:42:47 --> URI Class Initialized
INFO - 2025-05-06 08:42:47 --> Router Class Initialized
INFO - 2025-05-06 08:42:47 --> Output Class Initialized
INFO - 2025-05-06 08:42:47 --> Security Class Initialized
DEBUG - 2025-05-06 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:42:47 --> Input Class Initialized
INFO - 2025-05-06 08:42:47 --> Language Class Initialized
INFO - 2025-05-06 08:42:47 --> Loader Class Initialized
INFO - 2025-05-06 08:42:47 --> Helper loaded: form_helper
INFO - 2025-05-06 08:42:47 --> Helper loaded: url_helper
INFO - 2025-05-06 08:42:47 --> Database Driver Class Initialized
INFO - 2025-05-06 08:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:42:47 --> Form Validation Class Initialized
INFO - 2025-05-06 08:42:47 --> Controller Class Initialized
INFO - 2025-05-06 08:42:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:42:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:42:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:42:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-06 08:42:47 --> Final output sent to browser
DEBUG - 2025-05-06 08:42:47 --> Total execution time: 0.0283
INFO - 2025-05-06 08:42:49 --> Config Class Initialized
INFO - 2025-05-06 08:42:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:42:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:42:49 --> Utf8 Class Initialized
INFO - 2025-05-06 08:42:49 --> URI Class Initialized
INFO - 2025-05-06 08:42:49 --> Router Class Initialized
INFO - 2025-05-06 08:42:49 --> Output Class Initialized
INFO - 2025-05-06 08:42:49 --> Security Class Initialized
DEBUG - 2025-05-06 08:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:42:49 --> Input Class Initialized
INFO - 2025-05-06 08:42:49 --> Language Class Initialized
INFO - 2025-05-06 08:42:49 --> Loader Class Initialized
INFO - 2025-05-06 08:42:49 --> Helper loaded: form_helper
INFO - 2025-05-06 08:42:49 --> Helper loaded: url_helper
INFO - 2025-05-06 08:42:49 --> Database Driver Class Initialized
INFO - 2025-05-06 08:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:42:49 --> Form Validation Class Initialized
INFO - 2025-05-06 08:42:49 --> Controller Class Initialized
INFO - 2025-05-06 08:42:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:42:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:42:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:42:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/rekapitulasi.php
INFO - 2025-05-06 08:42:49 --> Final output sent to browser
DEBUG - 2025-05-06 08:42:49 --> Total execution time: 0.0420
INFO - 2025-05-06 08:42:54 --> Config Class Initialized
INFO - 2025-05-06 08:42:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:42:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:42:54 --> Utf8 Class Initialized
INFO - 2025-05-06 08:42:54 --> URI Class Initialized
INFO - 2025-05-06 08:42:54 --> Router Class Initialized
INFO - 2025-05-06 08:42:54 --> Output Class Initialized
INFO - 2025-05-06 08:42:54 --> Security Class Initialized
DEBUG - 2025-05-06 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:42:54 --> Input Class Initialized
INFO - 2025-05-06 08:42:54 --> Language Class Initialized
INFO - 2025-05-06 08:42:54 --> Loader Class Initialized
INFO - 2025-05-06 08:42:54 --> Helper loaded: form_helper
INFO - 2025-05-06 08:42:54 --> Helper loaded: url_helper
INFO - 2025-05-06 08:42:54 --> Database Driver Class Initialized
INFO - 2025-05-06 08:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:42:54 --> Form Validation Class Initialized
INFO - 2025-05-06 08:42:54 --> Controller Class Initialized
INFO - 2025-05-06 08:42:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:42:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:42:54 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:42:54 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-06 08:42:54 --> Final output sent to browser
DEBUG - 2025-05-06 08:42:54 --> Total execution time: 0.0475
INFO - 2025-05-06 08:50:19 --> Config Class Initialized
INFO - 2025-05-06 08:50:19 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:50:19 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:50:19 --> Utf8 Class Initialized
INFO - 2025-05-06 08:50:19 --> URI Class Initialized
INFO - 2025-05-06 08:50:19 --> Router Class Initialized
INFO - 2025-05-06 08:50:19 --> Output Class Initialized
INFO - 2025-05-06 08:50:19 --> Security Class Initialized
DEBUG - 2025-05-06 08:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:50:19 --> Input Class Initialized
INFO - 2025-05-06 08:50:19 --> Language Class Initialized
INFO - 2025-05-06 08:50:19 --> Loader Class Initialized
INFO - 2025-05-06 08:50:19 --> Helper loaded: form_helper
INFO - 2025-05-06 08:50:19 --> Helper loaded: url_helper
INFO - 2025-05-06 08:50:19 --> Database Driver Class Initialized
INFO - 2025-05-06 08:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:50:19 --> Form Validation Class Initialized
INFO - 2025-05-06 08:50:19 --> Controller Class Initialized
INFO - 2025-05-06 08:50:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:50:19 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:50:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:50:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-06 08:50:19 --> Final output sent to browser
DEBUG - 2025-05-06 08:50:19 --> Total execution time: 0.0306
INFO - 2025-05-06 08:50:35 --> Config Class Initialized
INFO - 2025-05-06 08:50:35 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:50:35 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:50:35 --> Utf8 Class Initialized
INFO - 2025-05-06 08:50:35 --> URI Class Initialized
INFO - 2025-05-06 08:50:35 --> Router Class Initialized
INFO - 2025-05-06 08:50:35 --> Output Class Initialized
INFO - 2025-05-06 08:50:35 --> Security Class Initialized
DEBUG - 2025-05-06 08:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:50:35 --> Input Class Initialized
INFO - 2025-05-06 08:50:35 --> Language Class Initialized
INFO - 2025-05-06 08:50:35 --> Loader Class Initialized
INFO - 2025-05-06 08:50:35 --> Helper loaded: form_helper
INFO - 2025-05-06 08:50:35 --> Helper loaded: url_helper
INFO - 2025-05-06 08:50:35 --> Database Driver Class Initialized
INFO - 2025-05-06 08:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:50:35 --> Form Validation Class Initialized
INFO - 2025-05-06 08:50:35 --> Controller Class Initialized
INFO - 2025-05-06 08:50:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:50:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:50:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:50:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_rekomendasi.php
INFO - 2025-05-06 08:50:35 --> Final output sent to browser
DEBUG - 2025-05-06 08:50:35 --> Total execution time: 0.0281
INFO - 2025-05-06 08:50:37 --> Config Class Initialized
INFO - 2025-05-06 08:50:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:50:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:50:37 --> Utf8 Class Initialized
INFO - 2025-05-06 08:50:37 --> URI Class Initialized
INFO - 2025-05-06 08:50:37 --> Router Class Initialized
INFO - 2025-05-06 08:50:37 --> Output Class Initialized
INFO - 2025-05-06 08:50:37 --> Security Class Initialized
DEBUG - 2025-05-06 08:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:50:37 --> Input Class Initialized
INFO - 2025-05-06 08:50:37 --> Language Class Initialized
INFO - 2025-05-06 08:50:37 --> Loader Class Initialized
INFO - 2025-05-06 08:50:37 --> Helper loaded: form_helper
INFO - 2025-05-06 08:50:37 --> Helper loaded: url_helper
INFO - 2025-05-06 08:50:37 --> Database Driver Class Initialized
INFO - 2025-05-06 08:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:50:37 --> Form Validation Class Initialized
INFO - 2025-05-06 08:50:37 --> Controller Class Initialized
INFO - 2025-05-06 08:50:37 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:50:37 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:50:37 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:50:37 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/laporan_seragam.php
INFO - 2025-05-06 08:50:37 --> Final output sent to browser
DEBUG - 2025-05-06 08:50:37 --> Total execution time: 0.0337
INFO - 2025-05-06 08:50:48 --> Config Class Initialized
INFO - 2025-05-06 08:50:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:50:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:50:48 --> Utf8 Class Initialized
INFO - 2025-05-06 08:50:48 --> URI Class Initialized
INFO - 2025-05-06 08:50:48 --> Router Class Initialized
INFO - 2025-05-06 08:50:48 --> Output Class Initialized
INFO - 2025-05-06 08:50:48 --> Security Class Initialized
DEBUG - 2025-05-06 08:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:50:48 --> Input Class Initialized
INFO - 2025-05-06 08:50:48 --> Language Class Initialized
INFO - 2025-05-06 08:50:48 --> Loader Class Initialized
INFO - 2025-05-06 08:50:48 --> Helper loaded: form_helper
INFO - 2025-05-06 08:50:48 --> Helper loaded: url_helper
INFO - 2025-05-06 08:50:48 --> Database Driver Class Initialized
INFO - 2025-05-06 08:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:50:48 --> Form Validation Class Initialized
INFO - 2025-05-06 08:50:48 --> Controller Class Initialized
INFO - 2025-05-06 08:50:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:50:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:50:48 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:50:48 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-06 08:50:48 --> Final output sent to browser
DEBUG - 2025-05-06 08:50:48 --> Total execution time: 0.0288
INFO - 2025-05-06 08:50:54 --> Config Class Initialized
INFO - 2025-05-06 08:50:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:50:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:50:54 --> Utf8 Class Initialized
INFO - 2025-05-06 08:50:54 --> URI Class Initialized
INFO - 2025-05-06 08:50:54 --> Router Class Initialized
INFO - 2025-05-06 08:50:54 --> Output Class Initialized
INFO - 2025-05-06 08:50:54 --> Security Class Initialized
DEBUG - 2025-05-06 08:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:50:54 --> Input Class Initialized
INFO - 2025-05-06 08:50:54 --> Language Class Initialized
INFO - 2025-05-06 08:50:54 --> Loader Class Initialized
INFO - 2025-05-06 08:50:54 --> Helper loaded: form_helper
INFO - 2025-05-06 08:50:54 --> Helper loaded: url_helper
INFO - 2025-05-06 08:50:54 --> Database Driver Class Initialized
INFO - 2025-05-06 08:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 08:50:54 --> Form Validation Class Initialized
INFO - 2025-05-06 08:50:54 --> Controller Class Initialized
INFO - 2025-05-06 08:50:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 08:50:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 08:50:54 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-06 08:50:54 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-06 08:50:54 --> Final output sent to browser
DEBUG - 2025-05-06 08:50:54 --> Total execution time: 0.0266
