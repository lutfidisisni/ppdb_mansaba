<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-03 06:01:24 --> Config Class Initialized
INFO - 2025-05-03 06:01:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 06:01:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 06:01:24 --> Utf8 Class Initialized
INFO - 2025-05-03 06:01:24 --> URI Class Initialized
INFO - 2025-05-03 06:01:24 --> Router Class Initialized
INFO - 2025-05-03 06:01:24 --> Output Class Initialized
INFO - 2025-05-03 06:01:24 --> Security Class Initialized
DEBUG - 2025-05-03 06:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 06:01:24 --> Input Class Initialized
INFO - 2025-05-03 06:01:24 --> Language Class Initialized
ERROR - 2025-05-03 06:01:24 --> 404 Page Not Found: Sftp-configjson/index
INFO - 2025-05-03 06:01:25 --> Config Class Initialized
INFO - 2025-05-03 06:01:25 --> Hooks Class Initialized
DEBUG - 2025-05-03 06:01:25 --> UTF-8 Support Enabled
INFO - 2025-05-03 06:01:25 --> Utf8 Class Initialized
INFO - 2025-05-03 06:01:25 --> URI Class Initialized
INFO - 2025-05-03 06:01:25 --> Router Class Initialized
INFO - 2025-05-03 06:01:25 --> Output Class Initialized
INFO - 2025-05-03 06:01:25 --> Security Class Initialized
DEBUG - 2025-05-03 06:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 06:01:25 --> Input Class Initialized
INFO - 2025-05-03 06:01:25 --> Language Class Initialized
ERROR - 2025-05-03 06:01:25 --> 404 Page Not Found: Vscode/sftp.json
INFO - 2025-05-03 06:20:29 --> Config Class Initialized
INFO - 2025-05-03 06:20:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 06:20:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 06:20:29 --> Utf8 Class Initialized
INFO - 2025-05-03 06:20:29 --> URI Class Initialized
INFO - 2025-05-03 06:20:29 --> Router Class Initialized
INFO - 2025-05-03 06:20:29 --> Output Class Initialized
INFO - 2025-05-03 06:20:29 --> Security Class Initialized
DEBUG - 2025-05-03 06:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 06:20:29 --> Input Class Initialized
INFO - 2025-05-03 06:20:29 --> Language Class Initialized
ERROR - 2025-05-03 06:20:29 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-03 06:20:29 --> Config Class Initialized
INFO - 2025-05-03 06:20:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 06:20:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 06:20:29 --> Utf8 Class Initialized
INFO - 2025-05-03 06:20:29 --> URI Class Initialized
DEBUG - 2025-05-03 06:20:29 --> No URI present. Default controller set.
INFO - 2025-05-03 06:20:29 --> Router Class Initialized
INFO - 2025-05-03 06:20:29 --> Output Class Initialized
INFO - 2025-05-03 06:20:29 --> Security Class Initialized
DEBUG - 2025-05-03 06:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 06:20:29 --> Input Class Initialized
INFO - 2025-05-03 06:20:29 --> Language Class Initialized
INFO - 2025-05-03 06:20:29 --> Loader Class Initialized
INFO - 2025-05-03 06:20:29 --> Helper loaded: form_helper
INFO - 2025-05-03 06:20:29 --> Helper loaded: url_helper
INFO - 2025-05-03 06:20:29 --> Database Driver Class Initialized
INFO - 2025-05-03 06:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 06:20:29 --> Form Validation Class Initialized
INFO - 2025-05-03 06:20:29 --> Controller Class Initialized
INFO - 2025-05-03 06:20:29 --> Final output sent to browser
DEBUG - 2025-05-03 06:20:29 --> Total execution time: 0.0407
INFO - 2025-05-03 06:20:29 --> Config Class Initialized
INFO - 2025-05-03 06:20:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 06:20:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 06:20:29 --> Utf8 Class Initialized
INFO - 2025-05-03 06:20:29 --> URI Class Initialized
DEBUG - 2025-05-03 06:20:29 --> No URI present. Default controller set.
INFO - 2025-05-03 06:20:29 --> Router Class Initialized
INFO - 2025-05-03 06:20:29 --> Output Class Initialized
INFO - 2025-05-03 06:20:29 --> Security Class Initialized
DEBUG - 2025-05-03 06:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 06:20:29 --> Input Class Initialized
INFO - 2025-05-03 06:20:29 --> Language Class Initialized
INFO - 2025-05-03 06:20:29 --> Loader Class Initialized
INFO - 2025-05-03 06:20:29 --> Helper loaded: form_helper
INFO - 2025-05-03 06:20:29 --> Helper loaded: url_helper
INFO - 2025-05-03 06:20:29 --> Database Driver Class Initialized
INFO - 2025-05-03 06:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 06:20:29 --> Form Validation Class Initialized
INFO - 2025-05-03 06:20:29 --> Controller Class Initialized
INFO - 2025-05-03 06:20:29 --> Final output sent to browser
DEBUG - 2025-05-03 06:20:29 --> Total execution time: 0.0341
INFO - 2025-05-03 06:20:30 --> Config Class Initialized
INFO - 2025-05-03 06:20:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 06:20:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 06:20:30 --> Utf8 Class Initialized
INFO - 2025-05-03 06:20:30 --> URI Class Initialized
INFO - 2025-05-03 06:20:30 --> Router Class Initialized
INFO - 2025-05-03 06:20:30 --> Output Class Initialized
INFO - 2025-05-03 06:20:30 --> Security Class Initialized
DEBUG - 2025-05-03 06:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 06:20:30 --> Input Class Initialized
INFO - 2025-05-03 06:20:30 --> Language Class Initialized
ERROR - 2025-05-03 06:20:30 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 07:00:29 --> Config Class Initialized
INFO - 2025-05-03 07:00:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 07:00:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 07:00:29 --> Utf8 Class Initialized
INFO - 2025-05-03 07:00:29 --> URI Class Initialized
DEBUG - 2025-05-03 07:00:29 --> No URI present. Default controller set.
INFO - 2025-05-03 07:00:29 --> Router Class Initialized
INFO - 2025-05-03 07:00:29 --> Output Class Initialized
INFO - 2025-05-03 07:00:29 --> Security Class Initialized
DEBUG - 2025-05-03 07:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 07:00:29 --> Input Class Initialized
INFO - 2025-05-03 07:00:29 --> Language Class Initialized
INFO - 2025-05-03 07:00:29 --> Loader Class Initialized
INFO - 2025-05-03 07:00:29 --> Helper loaded: form_helper
INFO - 2025-05-03 07:00:29 --> Helper loaded: url_helper
INFO - 2025-05-03 07:00:29 --> Database Driver Class Initialized
INFO - 2025-05-03 07:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 07:00:29 --> Form Validation Class Initialized
INFO - 2025-05-03 07:00:29 --> Controller Class Initialized
INFO - 2025-05-03 07:00:29 --> Final output sent to browser
DEBUG - 2025-05-03 07:00:29 --> Total execution time: 0.0307
INFO - 2025-05-03 07:02:43 --> Config Class Initialized
INFO - 2025-05-03 07:02:43 --> Hooks Class Initialized
DEBUG - 2025-05-03 07:02:43 --> UTF-8 Support Enabled
INFO - 2025-05-03 07:02:43 --> Utf8 Class Initialized
INFO - 2025-05-03 07:02:43 --> URI Class Initialized
INFO - 2025-05-03 07:02:43 --> Router Class Initialized
INFO - 2025-05-03 07:02:43 --> Output Class Initialized
INFO - 2025-05-03 07:02:43 --> Security Class Initialized
DEBUG - 2025-05-03 07:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 07:02:43 --> Input Class Initialized
INFO - 2025-05-03 07:02:43 --> Language Class Initialized
ERROR - 2025-05-03 07:02:43 --> 404 Page Not Found: Panel_admin/log_in
INFO - 2025-05-03 09:00:41 --> Config Class Initialized
INFO - 2025-05-03 09:00:41 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:41 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:41 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:41 --> URI Class Initialized
DEBUG - 2025-05-03 09:00:41 --> No URI present. Default controller set.
INFO - 2025-05-03 09:00:41 --> Router Class Initialized
INFO - 2025-05-03 09:00:41 --> Output Class Initialized
INFO - 2025-05-03 09:00:41 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:41 --> Input Class Initialized
INFO - 2025-05-03 09:00:41 --> Language Class Initialized
INFO - 2025-05-03 09:00:41 --> Loader Class Initialized
INFO - 2025-05-03 09:00:41 --> Helper loaded: form_helper
INFO - 2025-05-03 09:00:41 --> Helper loaded: url_helper
INFO - 2025-05-03 09:00:41 --> Database Driver Class Initialized
INFO - 2025-05-03 09:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:00:41 --> Form Validation Class Initialized
INFO - 2025-05-03 09:00:41 --> Controller Class Initialized
INFO - 2025-05-03 09:00:41 --> Final output sent to browser
DEBUG - 2025-05-03 09:00:41 --> Total execution time: 0.0350
INFO - 2025-05-03 09:00:45 --> Config Class Initialized
INFO - 2025-05-03 09:00:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:45 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:45 --> URI Class Initialized
INFO - 2025-05-03 09:00:45 --> Router Class Initialized
INFO - 2025-05-03 09:00:45 --> Output Class Initialized
INFO - 2025-05-03 09:00:45 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:45 --> Input Class Initialized
INFO - 2025-05-03 09:00:45 --> Language Class Initialized
INFO - 2025-05-03 09:00:45 --> Loader Class Initialized
INFO - 2025-05-03 09:00:45 --> Helper loaded: form_helper
INFO - 2025-05-03 09:00:45 --> Helper loaded: url_helper
INFO - 2025-05-03 09:00:45 --> Database Driver Class Initialized
INFO - 2025-05-03 09:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:00:45 --> Form Validation Class Initialized
INFO - 2025-05-03 09:00:45 --> Controller Class Initialized
INFO - 2025-05-03 09:00:45 --> Config Class Initialized
INFO - 2025-05-03 09:00:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:45 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:45 --> URI Class Initialized
INFO - 2025-05-03 09:00:45 --> Router Class Initialized
INFO - 2025-05-03 09:00:45 --> Output Class Initialized
INFO - 2025-05-03 09:00:45 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:45 --> Input Class Initialized
INFO - 2025-05-03 09:00:45 --> Language Class Initialized
INFO - 2025-05-03 09:00:45 --> Loader Class Initialized
INFO - 2025-05-03 09:00:45 --> Helper loaded: form_helper
INFO - 2025-05-03 09:00:45 --> Helper loaded: url_helper
INFO - 2025-05-03 09:00:45 --> Database Driver Class Initialized
INFO - 2025-05-03 09:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:00:45 --> Form Validation Class Initialized
INFO - 2025-05-03 09:00:45 --> Controller Class Initialized
INFO - 2025-05-03 09:00:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 09:00:45 --> Final output sent to browser
DEBUG - 2025-05-03 09:00:45 --> Total execution time: 0.0332
INFO - 2025-05-03 09:00:45 --> Config Class Initialized
INFO - 2025-05-03 09:00:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:45 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:45 --> URI Class Initialized
INFO - 2025-05-03 09:00:45 --> Router Class Initialized
INFO - 2025-05-03 09:00:45 --> Output Class Initialized
INFO - 2025-05-03 09:00:45 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:45 --> Input Class Initialized
INFO - 2025-05-03 09:00:45 --> Language Class Initialized
ERROR - 2025-05-03 09:00:45 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 09:00:46 --> Config Class Initialized
INFO - 2025-05-03 09:00:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:46 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:46 --> URI Class Initialized
INFO - 2025-05-03 09:00:46 --> Router Class Initialized
INFO - 2025-05-03 09:00:46 --> Output Class Initialized
INFO - 2025-05-03 09:00:47 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:47 --> Input Class Initialized
INFO - 2025-05-03 09:00:47 --> Language Class Initialized
INFO - 2025-05-03 09:00:47 --> Loader Class Initialized
INFO - 2025-05-03 09:00:47 --> Helper loaded: form_helper
INFO - 2025-05-03 09:00:47 --> Helper loaded: url_helper
INFO - 2025-05-03 09:00:47 --> Database Driver Class Initialized
INFO - 2025-05-03 09:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:00:47 --> Form Validation Class Initialized
INFO - 2025-05-03 09:00:47 --> Controller Class Initialized
INFO - 2025-05-03 09:00:47 --> Config Class Initialized
INFO - 2025-05-03 09:00:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:47 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:47 --> URI Class Initialized
INFO - 2025-05-03 09:00:47 --> Router Class Initialized
INFO - 2025-05-03 09:00:47 --> Output Class Initialized
INFO - 2025-05-03 09:00:47 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:47 --> Input Class Initialized
INFO - 2025-05-03 09:00:47 --> Language Class Initialized
INFO - 2025-05-03 09:00:47 --> Loader Class Initialized
INFO - 2025-05-03 09:00:47 --> Helper loaded: form_helper
INFO - 2025-05-03 09:00:47 --> Helper loaded: url_helper
INFO - 2025-05-03 09:00:47 --> Database Driver Class Initialized
INFO - 2025-05-03 09:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:00:47 --> Form Validation Class Initialized
INFO - 2025-05-03 09:00:47 --> Controller Class Initialized
INFO - 2025-05-03 09:00:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:00:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:00:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:00:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 09:00:47 --> Final output sent to browser
DEBUG - 2025-05-03 09:00:47 --> Total execution time: 0.0347
INFO - 2025-05-03 09:00:49 --> Config Class Initialized
INFO - 2025-05-03 09:00:49 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:49 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:49 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:49 --> URI Class Initialized
INFO - 2025-05-03 09:00:49 --> Router Class Initialized
INFO - 2025-05-03 09:00:49 --> Output Class Initialized
INFO - 2025-05-03 09:00:49 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:49 --> Input Class Initialized
INFO - 2025-05-03 09:00:49 --> Language Class Initialized
INFO - 2025-05-03 09:00:49 --> Loader Class Initialized
INFO - 2025-05-03 09:00:49 --> Helper loaded: form_helper
INFO - 2025-05-03 09:00:49 --> Helper loaded: url_helper
INFO - 2025-05-03 09:00:49 --> Database Driver Class Initialized
INFO - 2025-05-03 09:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:00:49 --> Form Validation Class Initialized
INFO - 2025-05-03 09:00:49 --> Controller Class Initialized
INFO - 2025-05-03 09:00:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:00:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:00:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:00:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 09:00:49 --> Final output sent to browser
DEBUG - 2025-05-03 09:00:49 --> Total execution time: 0.0563
INFO - 2025-05-03 09:00:51 --> Config Class Initialized
INFO - 2025-05-03 09:00:51 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:51 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:51 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:51 --> URI Class Initialized
INFO - 2025-05-03 09:00:51 --> Router Class Initialized
INFO - 2025-05-03 09:00:51 --> Output Class Initialized
INFO - 2025-05-03 09:00:51 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:51 --> Input Class Initialized
INFO - 2025-05-03 09:00:51 --> Language Class Initialized
INFO - 2025-05-03 09:00:51 --> Loader Class Initialized
INFO - 2025-05-03 09:00:51 --> Helper loaded: form_helper
INFO - 2025-05-03 09:00:51 --> Helper loaded: url_helper
INFO - 2025-05-03 09:00:51 --> Database Driver Class Initialized
INFO - 2025-05-03 09:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:00:51 --> Form Validation Class Initialized
INFO - 2025-05-03 09:00:51 --> Controller Class Initialized
INFO - 2025-05-03 09:00:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:00:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:00:51 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:00:51 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 09:00:51 --> Final output sent to browser
DEBUG - 2025-05-03 09:00:51 --> Total execution time: 0.0456
INFO - 2025-05-03 09:00:54 --> Config Class Initialized
INFO - 2025-05-03 09:00:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:54 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:54 --> URI Class Initialized
INFO - 2025-05-03 09:00:54 --> Router Class Initialized
INFO - 2025-05-03 09:00:54 --> Output Class Initialized
INFO - 2025-05-03 09:00:54 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:54 --> Input Class Initialized
INFO - 2025-05-03 09:00:54 --> Language Class Initialized
INFO - 2025-05-03 09:00:54 --> Loader Class Initialized
INFO - 2025-05-03 09:00:54 --> Helper loaded: form_helper
INFO - 2025-05-03 09:00:54 --> Helper loaded: url_helper
INFO - 2025-05-03 09:00:54 --> Database Driver Class Initialized
INFO - 2025-05-03 09:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:00:54 --> Form Validation Class Initialized
INFO - 2025-05-03 09:00:54 --> Controller Class Initialized
INFO - 2025-05-03 09:00:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:00:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:00:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:00:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 09:00:54 --> Final output sent to browser
DEBUG - 2025-05-03 09:00:54 --> Total execution time: 0.0476
INFO - 2025-05-03 09:00:56 --> Config Class Initialized
INFO - 2025-05-03 09:00:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:00:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:00:56 --> Utf8 Class Initialized
INFO - 2025-05-03 09:00:56 --> URI Class Initialized
INFO - 2025-05-03 09:00:56 --> Router Class Initialized
INFO - 2025-05-03 09:00:56 --> Output Class Initialized
INFO - 2025-05-03 09:00:56 --> Security Class Initialized
DEBUG - 2025-05-03 09:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:00:56 --> Input Class Initialized
INFO - 2025-05-03 09:00:56 --> Language Class Initialized
INFO - 2025-05-03 09:00:56 --> Loader Class Initialized
INFO - 2025-05-03 09:00:56 --> Helper loaded: form_helper
INFO - 2025-05-03 09:00:56 --> Helper loaded: url_helper
INFO - 2025-05-03 09:00:56 --> Database Driver Class Initialized
INFO - 2025-05-03 09:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:00:56 --> Form Validation Class Initialized
INFO - 2025-05-03 09:00:56 --> Controller Class Initialized
INFO - 2025-05-03 09:00:56 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:00:56 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:00:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:00:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 09:00:56 --> Final output sent to browser
DEBUG - 2025-05-03 09:00:56 --> Total execution time: 0.0493
INFO - 2025-05-03 09:01:13 --> Config Class Initialized
INFO - 2025-05-03 09:01:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:01:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:01:13 --> Utf8 Class Initialized
INFO - 2025-05-03 09:01:13 --> URI Class Initialized
INFO - 2025-05-03 09:01:13 --> Router Class Initialized
INFO - 2025-05-03 09:01:13 --> Output Class Initialized
INFO - 2025-05-03 09:01:13 --> Security Class Initialized
DEBUG - 2025-05-03 09:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:01:13 --> Input Class Initialized
INFO - 2025-05-03 09:01:13 --> Language Class Initialized
INFO - 2025-05-03 09:01:13 --> Loader Class Initialized
INFO - 2025-05-03 09:01:13 --> Helper loaded: form_helper
INFO - 2025-05-03 09:01:13 --> Helper loaded: url_helper
INFO - 2025-05-03 09:01:13 --> Database Driver Class Initialized
INFO - 2025-05-03 09:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:01:13 --> Form Validation Class Initialized
INFO - 2025-05-03 09:01:13 --> Controller Class Initialized
INFO - 2025-05-03 09:01:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:01:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:01:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:01:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 09:01:13 --> Final output sent to browser
DEBUG - 2025-05-03 09:01:13 --> Total execution time: 0.0493
INFO - 2025-05-03 09:01:24 --> Config Class Initialized
INFO - 2025-05-03 09:01:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:01:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:01:24 --> Utf8 Class Initialized
INFO - 2025-05-03 09:01:24 --> URI Class Initialized
INFO - 2025-05-03 09:01:24 --> Router Class Initialized
INFO - 2025-05-03 09:01:24 --> Output Class Initialized
INFO - 2025-05-03 09:01:24 --> Security Class Initialized
DEBUG - 2025-05-03 09:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:01:24 --> Input Class Initialized
INFO - 2025-05-03 09:01:24 --> Language Class Initialized
INFO - 2025-05-03 09:01:24 --> Loader Class Initialized
INFO - 2025-05-03 09:01:24 --> Helper loaded: form_helper
INFO - 2025-05-03 09:01:24 --> Helper loaded: url_helper
INFO - 2025-05-03 09:01:24 --> Database Driver Class Initialized
INFO - 2025-05-03 09:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:01:24 --> Form Validation Class Initialized
INFO - 2025-05-03 09:01:24 --> Controller Class Initialized
INFO - 2025-05-03 09:01:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:01:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:01:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:01:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 09:01:24 --> Final output sent to browser
DEBUG - 2025-05-03 09:01:24 --> Total execution time: 0.0416
INFO - 2025-05-03 09:01:29 --> Config Class Initialized
INFO - 2025-05-03 09:01:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:01:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:01:29 --> Utf8 Class Initialized
INFO - 2025-05-03 09:01:29 --> URI Class Initialized
INFO - 2025-05-03 09:01:29 --> Router Class Initialized
INFO - 2025-05-03 09:01:29 --> Output Class Initialized
INFO - 2025-05-03 09:01:29 --> Security Class Initialized
DEBUG - 2025-05-03 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:01:29 --> Input Class Initialized
INFO - 2025-05-03 09:01:29 --> Language Class Initialized
INFO - 2025-05-03 09:01:29 --> Loader Class Initialized
INFO - 2025-05-03 09:01:29 --> Helper loaded: form_helper
INFO - 2025-05-03 09:01:29 --> Helper loaded: url_helper
INFO - 2025-05-03 09:01:29 --> Database Driver Class Initialized
INFO - 2025-05-03 09:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:01:29 --> Form Validation Class Initialized
INFO - 2025-05-03 09:01:29 --> Controller Class Initialized
INFO - 2025-05-03 09:01:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:01:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:01:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:01:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 09:01:29 --> Final output sent to browser
DEBUG - 2025-05-03 09:01:29 --> Total execution time: 0.0449
INFO - 2025-05-03 09:01:39 --> Config Class Initialized
INFO - 2025-05-03 09:01:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:01:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:01:39 --> Utf8 Class Initialized
INFO - 2025-05-03 09:01:39 --> URI Class Initialized
INFO - 2025-05-03 09:01:39 --> Router Class Initialized
INFO - 2025-05-03 09:01:39 --> Output Class Initialized
INFO - 2025-05-03 09:01:39 --> Security Class Initialized
DEBUG - 2025-05-03 09:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:01:39 --> Input Class Initialized
INFO - 2025-05-03 09:01:39 --> Language Class Initialized
INFO - 2025-05-03 09:01:39 --> Loader Class Initialized
INFO - 2025-05-03 09:01:39 --> Helper loaded: form_helper
INFO - 2025-05-03 09:01:39 --> Helper loaded: url_helper
INFO - 2025-05-03 09:01:39 --> Database Driver Class Initialized
INFO - 2025-05-03 09:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:01:39 --> Form Validation Class Initialized
INFO - 2025-05-03 09:01:39 --> Controller Class Initialized
INFO - 2025-05-03 09:01:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:01:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:01:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:01:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 09:01:39 --> Final output sent to browser
DEBUG - 2025-05-03 09:01:39 --> Total execution time: 0.0526
INFO - 2025-05-03 09:31:07 --> Config Class Initialized
INFO - 2025-05-03 09:31:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:31:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:31:07 --> Utf8 Class Initialized
INFO - 2025-05-03 09:31:07 --> URI Class Initialized
DEBUG - 2025-05-03 09:31:07 --> No URI present. Default controller set.
INFO - 2025-05-03 09:31:07 --> Router Class Initialized
INFO - 2025-05-03 09:31:07 --> Output Class Initialized
INFO - 2025-05-03 09:31:07 --> Security Class Initialized
DEBUG - 2025-05-03 09:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:31:07 --> Input Class Initialized
INFO - 2025-05-03 09:31:07 --> Language Class Initialized
INFO - 2025-05-03 09:31:07 --> Loader Class Initialized
INFO - 2025-05-03 09:31:07 --> Helper loaded: form_helper
INFO - 2025-05-03 09:31:07 --> Helper loaded: url_helper
INFO - 2025-05-03 09:31:07 --> Database Driver Class Initialized
INFO - 2025-05-03 09:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:31:07 --> Form Validation Class Initialized
INFO - 2025-05-03 09:31:07 --> Controller Class Initialized
INFO - 2025-05-03 09:31:07 --> Final output sent to browser
DEBUG - 2025-05-03 09:31:07 --> Total execution time: 0.0299
INFO - 2025-05-03 09:32:44 --> Config Class Initialized
INFO - 2025-05-03 09:32:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:32:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:32:44 --> Utf8 Class Initialized
INFO - 2025-05-03 09:32:44 --> URI Class Initialized
DEBUG - 2025-05-03 09:32:44 --> No URI present. Default controller set.
INFO - 2025-05-03 09:32:44 --> Router Class Initialized
INFO - 2025-05-03 09:32:44 --> Output Class Initialized
INFO - 2025-05-03 09:32:44 --> Security Class Initialized
DEBUG - 2025-05-03 09:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:32:44 --> Input Class Initialized
INFO - 2025-05-03 09:32:44 --> Language Class Initialized
INFO - 2025-05-03 09:32:44 --> Loader Class Initialized
INFO - 2025-05-03 09:32:44 --> Helper loaded: form_helper
INFO - 2025-05-03 09:32:44 --> Helper loaded: url_helper
INFO - 2025-05-03 09:32:44 --> Database Driver Class Initialized
INFO - 2025-05-03 09:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:32:44 --> Form Validation Class Initialized
INFO - 2025-05-03 09:32:44 --> Controller Class Initialized
INFO - 2025-05-03 09:32:44 --> Final output sent to browser
DEBUG - 2025-05-03 09:32:44 --> Total execution time: 0.0300
INFO - 2025-05-03 09:32:49 --> Config Class Initialized
INFO - 2025-05-03 09:32:49 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:32:49 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:32:49 --> Utf8 Class Initialized
INFO - 2025-05-03 09:32:49 --> URI Class Initialized
DEBUG - 2025-05-03 09:32:49 --> No URI present. Default controller set.
INFO - 2025-05-03 09:32:49 --> Router Class Initialized
INFO - 2025-05-03 09:32:49 --> Output Class Initialized
INFO - 2025-05-03 09:32:49 --> Security Class Initialized
DEBUG - 2025-05-03 09:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:32:49 --> Input Class Initialized
INFO - 2025-05-03 09:32:49 --> Language Class Initialized
INFO - 2025-05-03 09:32:49 --> Loader Class Initialized
INFO - 2025-05-03 09:32:49 --> Helper loaded: form_helper
INFO - 2025-05-03 09:32:49 --> Helper loaded: url_helper
INFO - 2025-05-03 09:32:49 --> Database Driver Class Initialized
INFO - 2025-05-03 09:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:32:49 --> Form Validation Class Initialized
INFO - 2025-05-03 09:32:49 --> Controller Class Initialized
INFO - 2025-05-03 09:32:49 --> Final output sent to browser
DEBUG - 2025-05-03 09:32:49 --> Total execution time: 0.0339
INFO - 2025-05-03 09:33:06 --> Config Class Initialized
INFO - 2025-05-03 09:33:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:33:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:33:06 --> Utf8 Class Initialized
INFO - 2025-05-03 09:33:06 --> URI Class Initialized
INFO - 2025-05-03 09:33:06 --> Router Class Initialized
INFO - 2025-05-03 09:33:06 --> Output Class Initialized
INFO - 2025-05-03 09:33:06 --> Security Class Initialized
DEBUG - 2025-05-03 09:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:33:06 --> Input Class Initialized
INFO - 2025-05-03 09:33:06 --> Language Class Initialized
INFO - 2025-05-03 09:33:06 --> Loader Class Initialized
INFO - 2025-05-03 09:33:06 --> Helper loaded: form_helper
INFO - 2025-05-03 09:33:06 --> Helper loaded: url_helper
INFO - 2025-05-03 09:33:06 --> Database Driver Class Initialized
INFO - 2025-05-03 09:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:33:06 --> Form Validation Class Initialized
INFO - 2025-05-03 09:33:06 --> Controller Class Initialized
DEBUG - 2025-05-03 09:33:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 09:33:06 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 09:33:06 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 09:33:06 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 09:33:06 --> Final output sent to browser
DEBUG - 2025-05-03 09:33:06 --> Total execution time: 0.0413
INFO - 2025-05-03 09:33:06 --> Config Class Initialized
INFO - 2025-05-03 09:33:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:33:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:33:06 --> Utf8 Class Initialized
INFO - 2025-05-03 09:33:06 --> URI Class Initialized
INFO - 2025-05-03 09:33:06 --> Router Class Initialized
INFO - 2025-05-03 09:33:06 --> Output Class Initialized
INFO - 2025-05-03 09:33:06 --> Security Class Initialized
DEBUG - 2025-05-03 09:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:33:06 --> Input Class Initialized
INFO - 2025-05-03 09:33:06 --> Language Class Initialized
ERROR - 2025-05-03 09:33:06 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 09:46:03 --> Config Class Initialized
INFO - 2025-05-03 09:46:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:46:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:46:03 --> Utf8 Class Initialized
INFO - 2025-05-03 09:46:03 --> URI Class Initialized
INFO - 2025-05-03 09:46:03 --> Router Class Initialized
INFO - 2025-05-03 09:46:03 --> Output Class Initialized
INFO - 2025-05-03 09:46:03 --> Security Class Initialized
DEBUG - 2025-05-03 09:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:46:03 --> Input Class Initialized
INFO - 2025-05-03 09:46:03 --> Language Class Initialized
INFO - 2025-05-03 09:46:03 --> Loader Class Initialized
INFO - 2025-05-03 09:46:03 --> Helper loaded: form_helper
INFO - 2025-05-03 09:46:03 --> Helper loaded: url_helper
INFO - 2025-05-03 09:46:03 --> Database Driver Class Initialized
INFO - 2025-05-03 09:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:46:03 --> Form Validation Class Initialized
INFO - 2025-05-03 09:46:03 --> Controller Class Initialized
INFO - 2025-05-03 09:46:03 --> Config Class Initialized
INFO - 2025-05-03 09:46:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:46:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:46:03 --> Utf8 Class Initialized
INFO - 2025-05-03 09:46:03 --> URI Class Initialized
INFO - 2025-05-03 09:46:03 --> Router Class Initialized
INFO - 2025-05-03 09:46:03 --> Output Class Initialized
INFO - 2025-05-03 09:46:03 --> Security Class Initialized
DEBUG - 2025-05-03 09:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:46:03 --> Input Class Initialized
INFO - 2025-05-03 09:46:03 --> Language Class Initialized
INFO - 2025-05-03 09:46:03 --> Loader Class Initialized
INFO - 2025-05-03 09:46:03 --> Helper loaded: form_helper
INFO - 2025-05-03 09:46:03 --> Helper loaded: url_helper
INFO - 2025-05-03 09:46:03 --> Database Driver Class Initialized
INFO - 2025-05-03 09:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:46:03 --> Form Validation Class Initialized
INFO - 2025-05-03 09:46:03 --> Controller Class Initialized
INFO - 2025-05-03 09:46:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 09:46:03 --> Final output sent to browser
DEBUG - 2025-05-03 09:46:03 --> Total execution time: 0.0395
INFO - 2025-05-03 09:46:04 --> Config Class Initialized
INFO - 2025-05-03 09:46:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:46:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:46:04 --> Utf8 Class Initialized
INFO - 2025-05-03 09:46:04 --> URI Class Initialized
INFO - 2025-05-03 09:46:04 --> Router Class Initialized
INFO - 2025-05-03 09:46:04 --> Output Class Initialized
INFO - 2025-05-03 09:46:04 --> Security Class Initialized
DEBUG - 2025-05-03 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:46:04 --> Input Class Initialized
INFO - 2025-05-03 09:46:04 --> Language Class Initialized
ERROR - 2025-05-03 09:46:04 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 09:56:37 --> Config Class Initialized
INFO - 2025-05-03 09:56:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:56:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:56:37 --> Utf8 Class Initialized
INFO - 2025-05-03 09:56:37 --> URI Class Initialized
INFO - 2025-05-03 09:56:37 --> Router Class Initialized
INFO - 2025-05-03 09:56:37 --> Output Class Initialized
INFO - 2025-05-03 09:56:37 --> Security Class Initialized
DEBUG - 2025-05-03 09:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:56:37 --> Input Class Initialized
INFO - 2025-05-03 09:56:37 --> Language Class Initialized
INFO - 2025-05-03 09:56:37 --> Loader Class Initialized
INFO - 2025-05-03 09:56:37 --> Helper loaded: form_helper
INFO - 2025-05-03 09:56:37 --> Helper loaded: url_helper
INFO - 2025-05-03 09:56:37 --> Database Driver Class Initialized
INFO - 2025-05-03 09:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:56:38 --> Form Validation Class Initialized
INFO - 2025-05-03 09:56:38 --> Controller Class Initialized
INFO - 2025-05-03 09:56:38 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 09:56:38 --> Final output sent to browser
DEBUG - 2025-05-03 09:56:38 --> Total execution time: 0.0324
INFO - 2025-05-03 09:56:38 --> Config Class Initialized
INFO - 2025-05-03 09:56:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:56:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:56:38 --> Utf8 Class Initialized
INFO - 2025-05-03 09:56:38 --> URI Class Initialized
INFO - 2025-05-03 09:56:38 --> Router Class Initialized
INFO - 2025-05-03 09:56:38 --> Output Class Initialized
INFO - 2025-05-03 09:56:38 --> Security Class Initialized
DEBUG - 2025-05-03 09:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:56:38 --> Input Class Initialized
INFO - 2025-05-03 09:56:38 --> Language Class Initialized
ERROR - 2025-05-03 09:56:38 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 09:56:54 --> Config Class Initialized
INFO - 2025-05-03 09:56:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:56:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:56:54 --> Utf8 Class Initialized
INFO - 2025-05-03 09:56:54 --> URI Class Initialized
INFO - 2025-05-03 09:56:54 --> Router Class Initialized
INFO - 2025-05-03 09:56:54 --> Output Class Initialized
INFO - 2025-05-03 09:56:54 --> Security Class Initialized
DEBUG - 2025-05-03 09:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:56:54 --> Input Class Initialized
INFO - 2025-05-03 09:56:54 --> Language Class Initialized
INFO - 2025-05-03 09:56:54 --> Loader Class Initialized
INFO - 2025-05-03 09:56:54 --> Helper loaded: form_helper
INFO - 2025-05-03 09:56:54 --> Helper loaded: url_helper
INFO - 2025-05-03 09:56:54 --> Database Driver Class Initialized
INFO - 2025-05-03 09:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:56:54 --> Form Validation Class Initialized
INFO - 2025-05-03 09:56:54 --> Controller Class Initialized
INFO - 2025-05-03 09:56:54 --> Config Class Initialized
INFO - 2025-05-03 09:56:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:56:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:56:54 --> Utf8 Class Initialized
INFO - 2025-05-03 09:56:54 --> URI Class Initialized
INFO - 2025-05-03 09:56:54 --> Router Class Initialized
INFO - 2025-05-03 09:56:54 --> Output Class Initialized
INFO - 2025-05-03 09:56:54 --> Security Class Initialized
DEBUG - 2025-05-03 09:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:56:54 --> Input Class Initialized
INFO - 2025-05-03 09:56:54 --> Language Class Initialized
INFO - 2025-05-03 09:56:54 --> Loader Class Initialized
INFO - 2025-05-03 09:56:54 --> Helper loaded: form_helper
INFO - 2025-05-03 09:56:54 --> Helper loaded: url_helper
INFO - 2025-05-03 09:56:54 --> Database Driver Class Initialized
INFO - 2025-05-03 09:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:56:54 --> Form Validation Class Initialized
INFO - 2025-05-03 09:56:54 --> Controller Class Initialized
INFO - 2025-05-03 09:56:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:56:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:56:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:56:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 09:56:54 --> Final output sent to browser
DEBUG - 2025-05-03 09:56:54 --> Total execution time: 0.0330
INFO - 2025-05-03 09:57:14 --> Config Class Initialized
INFO - 2025-05-03 09:57:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:57:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:57:14 --> Utf8 Class Initialized
INFO - 2025-05-03 09:57:14 --> URI Class Initialized
INFO - 2025-05-03 09:57:14 --> Router Class Initialized
INFO - 2025-05-03 09:57:14 --> Output Class Initialized
INFO - 2025-05-03 09:57:14 --> Security Class Initialized
DEBUG - 2025-05-03 09:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:57:14 --> Input Class Initialized
INFO - 2025-05-03 09:57:14 --> Language Class Initialized
INFO - 2025-05-03 09:57:14 --> Loader Class Initialized
INFO - 2025-05-03 09:57:14 --> Helper loaded: form_helper
INFO - 2025-05-03 09:57:14 --> Helper loaded: url_helper
INFO - 2025-05-03 09:57:14 --> Database Driver Class Initialized
INFO - 2025-05-03 09:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:57:14 --> Form Validation Class Initialized
INFO - 2025-05-03 09:57:14 --> Controller Class Initialized
INFO - 2025-05-03 09:57:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:57:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:57:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:57:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 09:57:14 --> Final output sent to browser
DEBUG - 2025-05-03 09:57:14 --> Total execution time: 0.0427
INFO - 2025-05-03 09:57:32 --> Config Class Initialized
INFO - 2025-05-03 09:57:32 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:57:32 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:57:32 --> Utf8 Class Initialized
INFO - 2025-05-03 09:57:32 --> URI Class Initialized
INFO - 2025-05-03 09:57:32 --> Router Class Initialized
INFO - 2025-05-03 09:57:32 --> Output Class Initialized
INFO - 2025-05-03 09:57:32 --> Security Class Initialized
DEBUG - 2025-05-03 09:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:57:32 --> Input Class Initialized
INFO - 2025-05-03 09:57:32 --> Language Class Initialized
INFO - 2025-05-03 09:57:32 --> Loader Class Initialized
INFO - 2025-05-03 09:57:32 --> Helper loaded: form_helper
INFO - 2025-05-03 09:57:32 --> Helper loaded: url_helper
INFO - 2025-05-03 09:57:32 --> Database Driver Class Initialized
INFO - 2025-05-03 09:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:57:32 --> Form Validation Class Initialized
INFO - 2025-05-03 09:57:32 --> Controller Class Initialized
INFO - 2025-05-03 09:57:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:57:32 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:57:32 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-03 09:57:32 --> Final output sent to browser
DEBUG - 2025-05-03 09:57:32 --> Total execution time: 0.0393
INFO - 2025-05-03 09:58:58 --> Config Class Initialized
INFO - 2025-05-03 09:58:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:58:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:58:58 --> Utf8 Class Initialized
INFO - 2025-05-03 09:58:58 --> URI Class Initialized
INFO - 2025-05-03 09:58:58 --> Router Class Initialized
INFO - 2025-05-03 09:58:58 --> Output Class Initialized
INFO - 2025-05-03 09:58:58 --> Security Class Initialized
DEBUG - 2025-05-03 09:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:58:58 --> Input Class Initialized
INFO - 2025-05-03 09:58:58 --> Language Class Initialized
INFO - 2025-05-03 09:58:58 --> Loader Class Initialized
INFO - 2025-05-03 09:58:58 --> Helper loaded: form_helper
INFO - 2025-05-03 09:58:58 --> Helper loaded: url_helper
INFO - 2025-05-03 09:58:58 --> Database Driver Class Initialized
INFO - 2025-05-03 09:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:58:58 --> Form Validation Class Initialized
INFO - 2025-05-03 09:58:58 --> Controller Class Initialized
INFO - 2025-05-03 09:58:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:58:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:58:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:58:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 09:58:58 --> Final output sent to browser
DEBUG - 2025-05-03 09:58:58 --> Total execution time: 0.0349
INFO - 2025-05-03 09:59:33 --> Config Class Initialized
INFO - 2025-05-03 09:59:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:59:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:59:33 --> Utf8 Class Initialized
INFO - 2025-05-03 09:59:33 --> URI Class Initialized
INFO - 2025-05-03 09:59:33 --> Router Class Initialized
INFO - 2025-05-03 09:59:33 --> Output Class Initialized
INFO - 2025-05-03 09:59:33 --> Security Class Initialized
DEBUG - 2025-05-03 09:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:59:33 --> Input Class Initialized
INFO - 2025-05-03 09:59:33 --> Language Class Initialized
INFO - 2025-05-03 09:59:33 --> Loader Class Initialized
INFO - 2025-05-03 09:59:33 --> Helper loaded: form_helper
INFO - 2025-05-03 09:59:33 --> Helper loaded: url_helper
INFO - 2025-05-03 09:59:33 --> Database Driver Class Initialized
INFO - 2025-05-03 09:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:59:33 --> Form Validation Class Initialized
INFO - 2025-05-03 09:59:33 --> Controller Class Initialized
INFO - 2025-05-03 09:59:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:59:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:59:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:59:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/belum_daftar_ulang.php
INFO - 2025-05-03 09:59:33 --> Final output sent to browser
DEBUG - 2025-05-03 09:59:33 --> Total execution time: 0.0381
INFO - 2025-05-03 09:59:42 --> Config Class Initialized
INFO - 2025-05-03 09:59:42 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:59:42 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:59:42 --> Utf8 Class Initialized
INFO - 2025-05-03 09:59:42 --> URI Class Initialized
INFO - 2025-05-03 09:59:42 --> Router Class Initialized
INFO - 2025-05-03 09:59:42 --> Output Class Initialized
INFO - 2025-05-03 09:59:42 --> Security Class Initialized
DEBUG - 2025-05-03 09:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:59:42 --> Input Class Initialized
INFO - 2025-05-03 09:59:42 --> Language Class Initialized
INFO - 2025-05-03 09:59:42 --> Loader Class Initialized
INFO - 2025-05-03 09:59:42 --> Helper loaded: form_helper
INFO - 2025-05-03 09:59:42 --> Helper loaded: url_helper
INFO - 2025-05-03 09:59:42 --> Database Driver Class Initialized
INFO - 2025-05-03 09:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:59:42 --> Form Validation Class Initialized
INFO - 2025-05-03 09:59:42 --> Controller Class Initialized
INFO - 2025-05-03 09:59:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:59:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:59:42 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:59:42 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 09:59:42 --> Final output sent to browser
DEBUG - 2025-05-03 09:59:42 --> Total execution time: 0.0461
INFO - 2025-05-03 09:59:59 --> Config Class Initialized
INFO - 2025-05-03 09:59:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 09:59:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 09:59:59 --> Utf8 Class Initialized
INFO - 2025-05-03 09:59:59 --> URI Class Initialized
INFO - 2025-05-03 09:59:59 --> Router Class Initialized
INFO - 2025-05-03 09:59:59 --> Output Class Initialized
INFO - 2025-05-03 09:59:59 --> Security Class Initialized
DEBUG - 2025-05-03 09:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 09:59:59 --> Input Class Initialized
INFO - 2025-05-03 09:59:59 --> Language Class Initialized
INFO - 2025-05-03 09:59:59 --> Loader Class Initialized
INFO - 2025-05-03 09:59:59 --> Helper loaded: form_helper
INFO - 2025-05-03 09:59:59 --> Helper loaded: url_helper
INFO - 2025-05-03 09:59:59 --> Database Driver Class Initialized
INFO - 2025-05-03 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 09:59:59 --> Form Validation Class Initialized
INFO - 2025-05-03 09:59:59 --> Controller Class Initialized
INFO - 2025-05-03 09:59:59 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 09:59:59 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 09:59:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 09:59:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 09:59:59 --> Final output sent to browser
DEBUG - 2025-05-03 09:59:59 --> Total execution time: 0.0341
INFO - 2025-05-03 10:00:01 --> Config Class Initialized
INFO - 2025-05-03 10:00:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:00:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:00:01 --> Utf8 Class Initialized
INFO - 2025-05-03 10:00:01 --> URI Class Initialized
INFO - 2025-05-03 10:00:01 --> Router Class Initialized
INFO - 2025-05-03 10:00:01 --> Output Class Initialized
INFO - 2025-05-03 10:00:01 --> Security Class Initialized
DEBUG - 2025-05-03 10:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:00:02 --> Input Class Initialized
INFO - 2025-05-03 10:00:02 --> Language Class Initialized
INFO - 2025-05-03 10:00:02 --> Loader Class Initialized
INFO - 2025-05-03 10:00:02 --> Helper loaded: form_helper
INFO - 2025-05-03 10:00:02 --> Helper loaded: url_helper
INFO - 2025-05-03 10:00:02 --> Database Driver Class Initialized
INFO - 2025-05-03 10:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:00:02 --> Form Validation Class Initialized
INFO - 2025-05-03 10:00:02 --> Controller Class Initialized
INFO - 2025-05-03 10:00:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:00:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:00:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:00:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 10:00:02 --> Final output sent to browser
DEBUG - 2025-05-03 10:00:02 --> Total execution time: 0.0876
INFO - 2025-05-03 10:22:19 --> Config Class Initialized
INFO - 2025-05-03 10:22:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:22:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:22:19 --> Utf8 Class Initialized
INFO - 2025-05-03 10:22:19 --> URI Class Initialized
DEBUG - 2025-05-03 10:22:19 --> No URI present. Default controller set.
INFO - 2025-05-03 10:22:19 --> Router Class Initialized
INFO - 2025-05-03 10:22:19 --> Output Class Initialized
INFO - 2025-05-03 10:22:19 --> Security Class Initialized
DEBUG - 2025-05-03 10:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:22:19 --> Input Class Initialized
INFO - 2025-05-03 10:22:19 --> Language Class Initialized
INFO - 2025-05-03 10:22:19 --> Loader Class Initialized
INFO - 2025-05-03 10:22:19 --> Helper loaded: form_helper
INFO - 2025-05-03 10:22:19 --> Helper loaded: url_helper
INFO - 2025-05-03 10:22:19 --> Database Driver Class Initialized
INFO - 2025-05-03 10:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:22:19 --> Form Validation Class Initialized
INFO - 2025-05-03 10:22:19 --> Controller Class Initialized
INFO - 2025-05-03 10:22:19 --> Final output sent to browser
DEBUG - 2025-05-03 10:22:19 --> Total execution time: 0.0300
INFO - 2025-05-03 10:22:25 --> Config Class Initialized
INFO - 2025-05-03 10:22:25 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:22:25 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:22:25 --> Utf8 Class Initialized
INFO - 2025-05-03 10:22:25 --> URI Class Initialized
INFO - 2025-05-03 10:22:25 --> Router Class Initialized
INFO - 2025-05-03 10:22:25 --> Output Class Initialized
INFO - 2025-05-03 10:22:25 --> Security Class Initialized
DEBUG - 2025-05-03 10:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:22:25 --> Input Class Initialized
INFO - 2025-05-03 10:22:25 --> Language Class Initialized
INFO - 2025-05-03 10:22:25 --> Loader Class Initialized
INFO - 2025-05-03 10:22:25 --> Helper loaded: form_helper
INFO - 2025-05-03 10:22:25 --> Helper loaded: url_helper
INFO - 2025-05-03 10:22:25 --> Database Driver Class Initialized
INFO - 2025-05-03 10:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:22:25 --> Form Validation Class Initialized
INFO - 2025-05-03 10:22:25 --> Controller Class Initialized
DEBUG - 2025-05-03 10:22:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 10:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 10:22:25 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 10:22:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 10:22:25 --> Final output sent to browser
DEBUG - 2025-05-03 10:22:25 --> Total execution time: 0.0381
INFO - 2025-05-03 10:22:26 --> Config Class Initialized
INFO - 2025-05-03 10:22:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:22:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:22:26 --> Utf8 Class Initialized
INFO - 2025-05-03 10:22:26 --> URI Class Initialized
INFO - 2025-05-03 10:22:26 --> Router Class Initialized
INFO - 2025-05-03 10:22:26 --> Output Class Initialized
INFO - 2025-05-03 10:22:26 --> Security Class Initialized
DEBUG - 2025-05-03 10:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:22:26 --> Input Class Initialized
INFO - 2025-05-03 10:22:26 --> Language Class Initialized
ERROR - 2025-05-03 10:22:26 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 10:22:37 --> Config Class Initialized
INFO - 2025-05-03 10:22:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:22:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:22:37 --> Utf8 Class Initialized
INFO - 2025-05-03 10:22:37 --> URI Class Initialized
DEBUG - 2025-05-03 10:22:37 --> No URI present. Default controller set.
INFO - 2025-05-03 10:22:37 --> Router Class Initialized
INFO - 2025-05-03 10:22:37 --> Output Class Initialized
INFO - 2025-05-03 10:22:37 --> Security Class Initialized
DEBUG - 2025-05-03 10:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:22:37 --> Input Class Initialized
INFO - 2025-05-03 10:22:37 --> Language Class Initialized
INFO - 2025-05-03 10:22:37 --> Loader Class Initialized
INFO - 2025-05-03 10:22:37 --> Helper loaded: form_helper
INFO - 2025-05-03 10:22:37 --> Helper loaded: url_helper
INFO - 2025-05-03 10:22:37 --> Database Driver Class Initialized
INFO - 2025-05-03 10:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:22:37 --> Form Validation Class Initialized
INFO - 2025-05-03 10:22:37 --> Controller Class Initialized
INFO - 2025-05-03 10:22:37 --> Final output sent to browser
DEBUG - 2025-05-03 10:22:37 --> Total execution time: 0.0298
INFO - 2025-05-03 10:23:14 --> Config Class Initialized
INFO - 2025-05-03 10:23:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:23:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:23:14 --> Utf8 Class Initialized
INFO - 2025-05-03 10:23:14 --> URI Class Initialized
DEBUG - 2025-05-03 10:23:14 --> No URI present. Default controller set.
INFO - 2025-05-03 10:23:14 --> Router Class Initialized
INFO - 2025-05-03 10:23:14 --> Output Class Initialized
INFO - 2025-05-03 10:23:14 --> Security Class Initialized
DEBUG - 2025-05-03 10:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:23:14 --> Input Class Initialized
INFO - 2025-05-03 10:23:14 --> Language Class Initialized
INFO - 2025-05-03 10:23:14 --> Loader Class Initialized
INFO - 2025-05-03 10:23:14 --> Helper loaded: form_helper
INFO - 2025-05-03 10:23:14 --> Helper loaded: url_helper
INFO - 2025-05-03 10:23:14 --> Database Driver Class Initialized
INFO - 2025-05-03 10:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:23:14 --> Form Validation Class Initialized
INFO - 2025-05-03 10:23:14 --> Controller Class Initialized
INFO - 2025-05-03 10:23:14 --> Final output sent to browser
DEBUG - 2025-05-03 10:23:14 --> Total execution time: 0.0304
INFO - 2025-05-03 10:23:16 --> Config Class Initialized
INFO - 2025-05-03 10:23:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:23:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:23:16 --> Utf8 Class Initialized
INFO - 2025-05-03 10:23:16 --> URI Class Initialized
DEBUG - 2025-05-03 10:23:16 --> No URI present. Default controller set.
INFO - 2025-05-03 10:23:16 --> Router Class Initialized
INFO - 2025-05-03 10:23:16 --> Output Class Initialized
INFO - 2025-05-03 10:23:16 --> Security Class Initialized
DEBUG - 2025-05-03 10:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:23:16 --> Input Class Initialized
INFO - 2025-05-03 10:23:16 --> Language Class Initialized
INFO - 2025-05-03 10:23:16 --> Loader Class Initialized
INFO - 2025-05-03 10:23:16 --> Helper loaded: form_helper
INFO - 2025-05-03 10:23:16 --> Helper loaded: url_helper
INFO - 2025-05-03 10:23:16 --> Database Driver Class Initialized
INFO - 2025-05-03 10:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:23:16 --> Form Validation Class Initialized
INFO - 2025-05-03 10:23:16 --> Controller Class Initialized
INFO - 2025-05-03 10:23:16 --> Final output sent to browser
DEBUG - 2025-05-03 10:23:16 --> Total execution time: 0.0312
INFO - 2025-05-03 10:23:56 --> Config Class Initialized
INFO - 2025-05-03 10:23:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:23:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:23:56 --> Utf8 Class Initialized
INFO - 2025-05-03 10:23:56 --> URI Class Initialized
INFO - 2025-05-03 10:23:56 --> Router Class Initialized
INFO - 2025-05-03 10:23:56 --> Output Class Initialized
INFO - 2025-05-03 10:23:56 --> Security Class Initialized
DEBUG - 2025-05-03 10:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:23:56 --> Input Class Initialized
INFO - 2025-05-03 10:23:56 --> Language Class Initialized
INFO - 2025-05-03 10:23:56 --> Loader Class Initialized
INFO - 2025-05-03 10:23:56 --> Helper loaded: form_helper
INFO - 2025-05-03 10:23:56 --> Helper loaded: url_helper
INFO - 2025-05-03 10:23:56 --> Database Driver Class Initialized
INFO - 2025-05-03 10:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:23:56 --> Form Validation Class Initialized
INFO - 2025-05-03 10:23:56 --> Controller Class Initialized
INFO - 2025-05-03 10:23:57 --> Config Class Initialized
INFO - 2025-05-03 10:23:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:23:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:23:57 --> Utf8 Class Initialized
INFO - 2025-05-03 10:23:57 --> URI Class Initialized
INFO - 2025-05-03 10:23:57 --> Router Class Initialized
INFO - 2025-05-03 10:23:57 --> Output Class Initialized
INFO - 2025-05-03 10:23:57 --> Security Class Initialized
DEBUG - 2025-05-03 10:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:23:57 --> Input Class Initialized
INFO - 2025-05-03 10:23:57 --> Language Class Initialized
INFO - 2025-05-03 10:23:57 --> Loader Class Initialized
INFO - 2025-05-03 10:23:57 --> Helper loaded: form_helper
INFO - 2025-05-03 10:23:57 --> Helper loaded: url_helper
INFO - 2025-05-03 10:23:57 --> Database Driver Class Initialized
INFO - 2025-05-03 10:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:23:57 --> Form Validation Class Initialized
INFO - 2025-05-03 10:23:57 --> Controller Class Initialized
INFO - 2025-05-03 10:23:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 10:23:57 --> Final output sent to browser
DEBUG - 2025-05-03 10:23:57 --> Total execution time: 0.0307
INFO - 2025-05-03 10:24:13 --> Config Class Initialized
INFO - 2025-05-03 10:24:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:24:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:24:13 --> Utf8 Class Initialized
INFO - 2025-05-03 10:24:13 --> URI Class Initialized
INFO - 2025-05-03 10:24:13 --> Router Class Initialized
INFO - 2025-05-03 10:24:13 --> Output Class Initialized
INFO - 2025-05-03 10:24:13 --> Security Class Initialized
DEBUG - 2025-05-03 10:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:24:13 --> Input Class Initialized
INFO - 2025-05-03 10:24:13 --> Language Class Initialized
INFO - 2025-05-03 10:24:13 --> Loader Class Initialized
INFO - 2025-05-03 10:24:13 --> Helper loaded: form_helper
INFO - 2025-05-03 10:24:13 --> Helper loaded: url_helper
INFO - 2025-05-03 10:24:13 --> Database Driver Class Initialized
INFO - 2025-05-03 10:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:24:13 --> Form Validation Class Initialized
INFO - 2025-05-03 10:24:13 --> Controller Class Initialized
INFO - 2025-05-03 10:24:13 --> Config Class Initialized
INFO - 2025-05-03 10:24:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:24:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:24:13 --> Utf8 Class Initialized
INFO - 2025-05-03 10:24:13 --> URI Class Initialized
INFO - 2025-05-03 10:24:13 --> Router Class Initialized
INFO - 2025-05-03 10:24:13 --> Output Class Initialized
INFO - 2025-05-03 10:24:13 --> Security Class Initialized
DEBUG - 2025-05-03 10:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:24:13 --> Input Class Initialized
INFO - 2025-05-03 10:24:13 --> Language Class Initialized
INFO - 2025-05-03 10:24:13 --> Loader Class Initialized
INFO - 2025-05-03 10:24:13 --> Helper loaded: form_helper
INFO - 2025-05-03 10:24:13 --> Helper loaded: url_helper
INFO - 2025-05-03 10:24:13 --> Database Driver Class Initialized
INFO - 2025-05-03 10:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:24:13 --> Form Validation Class Initialized
INFO - 2025-05-03 10:24:13 --> Controller Class Initialized
INFO - 2025-05-03 10:24:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:24:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:24:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:24:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 10:24:13 --> Final output sent to browser
DEBUG - 2025-05-03 10:24:13 --> Total execution time: 0.0330
INFO - 2025-05-03 10:24:17 --> Config Class Initialized
INFO - 2025-05-03 10:24:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:24:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:24:17 --> Utf8 Class Initialized
INFO - 2025-05-03 10:24:17 --> URI Class Initialized
INFO - 2025-05-03 10:24:17 --> Router Class Initialized
INFO - 2025-05-03 10:24:17 --> Output Class Initialized
INFO - 2025-05-03 10:24:17 --> Security Class Initialized
DEBUG - 2025-05-03 10:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:24:17 --> Input Class Initialized
INFO - 2025-05-03 10:24:17 --> Language Class Initialized
INFO - 2025-05-03 10:24:17 --> Loader Class Initialized
INFO - 2025-05-03 10:24:17 --> Helper loaded: form_helper
INFO - 2025-05-03 10:24:17 --> Helper loaded: url_helper
INFO - 2025-05-03 10:24:17 --> Database Driver Class Initialized
INFO - 2025-05-03 10:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:24:17 --> Form Validation Class Initialized
INFO - 2025-05-03 10:24:17 --> Controller Class Initialized
INFO - 2025-05-03 10:24:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:24:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:24:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:24:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 10:24:17 --> Final output sent to browser
DEBUG - 2025-05-03 10:24:17 --> Total execution time: 0.0316
INFO - 2025-05-03 10:24:23 --> Config Class Initialized
INFO - 2025-05-03 10:24:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:24:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:24:23 --> Utf8 Class Initialized
INFO - 2025-05-03 10:24:23 --> URI Class Initialized
INFO - 2025-05-03 10:24:23 --> Router Class Initialized
INFO - 2025-05-03 10:24:23 --> Output Class Initialized
INFO - 2025-05-03 10:24:23 --> Security Class Initialized
DEBUG - 2025-05-03 10:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:24:23 --> Input Class Initialized
INFO - 2025-05-03 10:24:23 --> Language Class Initialized
INFO - 2025-05-03 10:24:23 --> Loader Class Initialized
INFO - 2025-05-03 10:24:23 --> Helper loaded: form_helper
INFO - 2025-05-03 10:24:23 --> Helper loaded: url_helper
INFO - 2025-05-03 10:24:23 --> Database Driver Class Initialized
INFO - 2025-05-03 10:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:24:23 --> Form Validation Class Initialized
INFO - 2025-05-03 10:24:23 --> Controller Class Initialized
INFO - 2025-05-03 10:24:23 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:24:23 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:24:23 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:24:23 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 10:24:23 --> Final output sent to browser
DEBUG - 2025-05-03 10:24:23 --> Total execution time: 0.0420
INFO - 2025-05-03 10:24:25 --> Config Class Initialized
INFO - 2025-05-03 10:24:25 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:24:25 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:24:25 --> Utf8 Class Initialized
INFO - 2025-05-03 10:24:25 --> URI Class Initialized
INFO - 2025-05-03 10:24:25 --> Router Class Initialized
INFO - 2025-05-03 10:24:25 --> Output Class Initialized
INFO - 2025-05-03 10:24:25 --> Security Class Initialized
DEBUG - 2025-05-03 10:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:24:25 --> Input Class Initialized
INFO - 2025-05-03 10:24:25 --> Language Class Initialized
INFO - 2025-05-03 10:24:25 --> Loader Class Initialized
INFO - 2025-05-03 10:24:25 --> Helper loaded: form_helper
INFO - 2025-05-03 10:24:25 --> Helper loaded: url_helper
INFO - 2025-05-03 10:24:25 --> Database Driver Class Initialized
INFO - 2025-05-03 10:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:24:25 --> Form Validation Class Initialized
INFO - 2025-05-03 10:24:25 --> Controller Class Initialized
INFO - 2025-05-03 10:24:25 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:24:25 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:24:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:24:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 10:24:25 --> Final output sent to browser
DEBUG - 2025-05-03 10:24:25 --> Total execution time: 0.0344
INFO - 2025-05-03 10:24:31 --> Config Class Initialized
INFO - 2025-05-03 10:24:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:24:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:24:31 --> Utf8 Class Initialized
INFO - 2025-05-03 10:24:31 --> URI Class Initialized
INFO - 2025-05-03 10:24:31 --> Router Class Initialized
INFO - 2025-05-03 10:24:31 --> Output Class Initialized
INFO - 2025-05-03 10:24:31 --> Security Class Initialized
DEBUG - 2025-05-03 10:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:24:31 --> Input Class Initialized
INFO - 2025-05-03 10:24:31 --> Language Class Initialized
INFO - 2025-05-03 10:24:31 --> Loader Class Initialized
INFO - 2025-05-03 10:24:31 --> Helper loaded: form_helper
INFO - 2025-05-03 10:24:31 --> Helper loaded: url_helper
INFO - 2025-05-03 10:24:31 --> Database Driver Class Initialized
INFO - 2025-05-03 10:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:24:31 --> Form Validation Class Initialized
INFO - 2025-05-03 10:24:31 --> Controller Class Initialized
INFO - 2025-05-03 10:24:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:24:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:24:31 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:24:31 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 10:24:31 --> Final output sent to browser
DEBUG - 2025-05-03 10:24:31 --> Total execution time: 0.0372
INFO - 2025-05-03 10:25:01 --> Config Class Initialized
INFO - 2025-05-03 10:25:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:25:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:25:01 --> Utf8 Class Initialized
INFO - 2025-05-03 10:25:01 --> URI Class Initialized
INFO - 2025-05-03 10:25:01 --> Router Class Initialized
INFO - 2025-05-03 10:25:01 --> Output Class Initialized
INFO - 2025-05-03 10:25:01 --> Security Class Initialized
DEBUG - 2025-05-03 10:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:25:01 --> Input Class Initialized
INFO - 2025-05-03 10:25:01 --> Language Class Initialized
INFO - 2025-05-03 10:25:01 --> Loader Class Initialized
INFO - 2025-05-03 10:25:01 --> Helper loaded: form_helper
INFO - 2025-05-03 10:25:01 --> Helper loaded: url_helper
INFO - 2025-05-03 10:25:01 --> Database Driver Class Initialized
INFO - 2025-05-03 10:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:25:01 --> Form Validation Class Initialized
INFO - 2025-05-03 10:25:01 --> Controller Class Initialized
INFO - 2025-05-03 10:25:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:25:01 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:25:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:25:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 10:25:01 --> Final output sent to browser
DEBUG - 2025-05-03 10:25:01 --> Total execution time: 0.0596
INFO - 2025-05-03 10:25:13 --> Config Class Initialized
INFO - 2025-05-03 10:25:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:25:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:25:13 --> Utf8 Class Initialized
INFO - 2025-05-03 10:25:13 --> URI Class Initialized
INFO - 2025-05-03 10:25:13 --> Router Class Initialized
INFO - 2025-05-03 10:25:13 --> Output Class Initialized
INFO - 2025-05-03 10:25:13 --> Security Class Initialized
DEBUG - 2025-05-03 10:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:25:13 --> Input Class Initialized
INFO - 2025-05-03 10:25:13 --> Language Class Initialized
INFO - 2025-05-03 10:25:13 --> Loader Class Initialized
INFO - 2025-05-03 10:25:13 --> Helper loaded: form_helper
INFO - 2025-05-03 10:25:13 --> Helper loaded: url_helper
INFO - 2025-05-03 10:25:13 --> Database Driver Class Initialized
INFO - 2025-05-03 10:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:25:13 --> Form Validation Class Initialized
INFO - 2025-05-03 10:25:13 --> Controller Class Initialized
INFO - 2025-05-03 10:25:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:25:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:25:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:25:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-03 10:25:13 --> Final output sent to browser
DEBUG - 2025-05-03 10:25:13 --> Total execution time: 0.0478
INFO - 2025-05-03 10:25:22 --> Config Class Initialized
INFO - 2025-05-03 10:25:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:25:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:25:22 --> Utf8 Class Initialized
INFO - 2025-05-03 10:25:22 --> URI Class Initialized
INFO - 2025-05-03 10:25:22 --> Router Class Initialized
INFO - 2025-05-03 10:25:22 --> Output Class Initialized
INFO - 2025-05-03 10:25:22 --> Security Class Initialized
DEBUG - 2025-05-03 10:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:25:22 --> Input Class Initialized
INFO - 2025-05-03 10:25:22 --> Language Class Initialized
INFO - 2025-05-03 10:25:22 --> Loader Class Initialized
INFO - 2025-05-03 10:25:22 --> Helper loaded: form_helper
INFO - 2025-05-03 10:25:22 --> Helper loaded: url_helper
INFO - 2025-05-03 10:25:22 --> Database Driver Class Initialized
INFO - 2025-05-03 10:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:25:22 --> Form Validation Class Initialized
INFO - 2025-05-03 10:25:22 --> Controller Class Initialized
INFO - 2025-05-03 10:25:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:25:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:25:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:25:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-03 10:25:22 --> Final output sent to browser
DEBUG - 2025-05-03 10:25:22 --> Total execution time: 0.0474
INFO - 2025-05-03 10:25:24 --> Config Class Initialized
INFO - 2025-05-03 10:25:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:25:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:25:24 --> Utf8 Class Initialized
INFO - 2025-05-03 10:25:24 --> URI Class Initialized
INFO - 2025-05-03 10:25:24 --> Router Class Initialized
INFO - 2025-05-03 10:25:24 --> Output Class Initialized
INFO - 2025-05-03 10:25:24 --> Security Class Initialized
DEBUG - 2025-05-03 10:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:25:24 --> Input Class Initialized
INFO - 2025-05-03 10:25:24 --> Language Class Initialized
INFO - 2025-05-03 10:25:24 --> Loader Class Initialized
INFO - 2025-05-03 10:25:24 --> Helper loaded: form_helper
INFO - 2025-05-03 10:25:24 --> Helper loaded: url_helper
INFO - 2025-05-03 10:25:24 --> Database Driver Class Initialized
INFO - 2025-05-03 10:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:25:24 --> Form Validation Class Initialized
INFO - 2025-05-03 10:25:24 --> Controller Class Initialized
INFO - 2025-05-03 10:25:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:25:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:25:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:25:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 10:25:24 --> Final output sent to browser
DEBUG - 2025-05-03 10:25:24 --> Total execution time: 0.0488
INFO - 2025-05-03 10:32:04 --> Config Class Initialized
INFO - 2025-05-03 10:32:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:04 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:04 --> URI Class Initialized
INFO - 2025-05-03 10:32:04 --> Router Class Initialized
INFO - 2025-05-03 10:32:04 --> Output Class Initialized
INFO - 2025-05-03 10:32:04 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:04 --> Input Class Initialized
INFO - 2025-05-03 10:32:04 --> Language Class Initialized
INFO - 2025-05-03 10:32:04 --> Loader Class Initialized
INFO - 2025-05-03 10:32:04 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:04 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:04 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:04 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:04 --> Controller Class Initialized
DEBUG - 2025-05-03 10:32:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 10:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 10:32:04 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 10:32:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 10:32:04 --> Final output sent to browser
DEBUG - 2025-05-03 10:32:04 --> Total execution time: 0.0291
INFO - 2025-05-03 10:32:05 --> Config Class Initialized
INFO - 2025-05-03 10:32:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:05 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:05 --> URI Class Initialized
DEBUG - 2025-05-03 10:32:05 --> No URI present. Default controller set.
INFO - 2025-05-03 10:32:05 --> Router Class Initialized
INFO - 2025-05-03 10:32:05 --> Output Class Initialized
INFO - 2025-05-03 10:32:05 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:05 --> Input Class Initialized
INFO - 2025-05-03 10:32:05 --> Language Class Initialized
INFO - 2025-05-03 10:32:05 --> Loader Class Initialized
INFO - 2025-05-03 10:32:05 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:05 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:05 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:05 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:05 --> Controller Class Initialized
INFO - 2025-05-03 10:32:05 --> Final output sent to browser
DEBUG - 2025-05-03 10:32:05 --> Total execution time: 0.0285
INFO - 2025-05-03 10:32:08 --> Config Class Initialized
INFO - 2025-05-03 10:32:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:08 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:08 --> URI Class Initialized
INFO - 2025-05-03 10:32:08 --> Router Class Initialized
INFO - 2025-05-03 10:32:08 --> Output Class Initialized
INFO - 2025-05-03 10:32:08 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:08 --> Input Class Initialized
INFO - 2025-05-03 10:32:08 --> Language Class Initialized
INFO - 2025-05-03 10:32:08 --> Loader Class Initialized
INFO - 2025-05-03 10:32:08 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:08 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:08 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:08 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:08 --> Controller Class Initialized
INFO - 2025-05-03 10:32:08 --> Config Class Initialized
INFO - 2025-05-03 10:32:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:08 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:08 --> URI Class Initialized
INFO - 2025-05-03 10:32:08 --> Router Class Initialized
INFO - 2025-05-03 10:32:08 --> Output Class Initialized
INFO - 2025-05-03 10:32:08 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:08 --> Input Class Initialized
INFO - 2025-05-03 10:32:08 --> Language Class Initialized
INFO - 2025-05-03 10:32:08 --> Loader Class Initialized
INFO - 2025-05-03 10:32:08 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:08 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:08 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:08 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:08 --> Controller Class Initialized
INFO - 2025-05-03 10:32:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 10:32:08 --> Final output sent to browser
DEBUG - 2025-05-03 10:32:08 --> Total execution time: 0.0307
INFO - 2025-05-03 10:32:10 --> Config Class Initialized
INFO - 2025-05-03 10:32:10 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:10 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:10 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:10 --> URI Class Initialized
INFO - 2025-05-03 10:32:10 --> Router Class Initialized
INFO - 2025-05-03 10:32:10 --> Output Class Initialized
INFO - 2025-05-03 10:32:10 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:10 --> Input Class Initialized
INFO - 2025-05-03 10:32:10 --> Language Class Initialized
INFO - 2025-05-03 10:32:10 --> Loader Class Initialized
INFO - 2025-05-03 10:32:10 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:10 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:10 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:10 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:10 --> Controller Class Initialized
INFO - 2025-05-03 10:32:10 --> Config Class Initialized
INFO - 2025-05-03 10:32:10 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:10 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:10 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:10 --> URI Class Initialized
INFO - 2025-05-03 10:32:10 --> Router Class Initialized
INFO - 2025-05-03 10:32:10 --> Output Class Initialized
INFO - 2025-05-03 10:32:10 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:10 --> Input Class Initialized
INFO - 2025-05-03 10:32:10 --> Language Class Initialized
INFO - 2025-05-03 10:32:10 --> Loader Class Initialized
INFO - 2025-05-03 10:32:10 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:10 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:10 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:10 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:10 --> Controller Class Initialized
INFO - 2025-05-03 10:32:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:32:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:32:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:32:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 10:32:10 --> Final output sent to browser
DEBUG - 2025-05-03 10:32:10 --> Total execution time: 0.0325
INFO - 2025-05-03 10:32:12 --> Config Class Initialized
INFO - 2025-05-03 10:32:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:12 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:12 --> URI Class Initialized
INFO - 2025-05-03 10:32:12 --> Router Class Initialized
INFO - 2025-05-03 10:32:12 --> Output Class Initialized
INFO - 2025-05-03 10:32:12 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:12 --> Input Class Initialized
INFO - 2025-05-03 10:32:12 --> Language Class Initialized
INFO - 2025-05-03 10:32:12 --> Loader Class Initialized
INFO - 2025-05-03 10:32:12 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:12 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:12 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:12 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:12 --> Controller Class Initialized
INFO - 2025-05-03 10:32:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:32:12 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:32:12 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:32:12 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 10:32:12 --> Final output sent to browser
DEBUG - 2025-05-03 10:32:12 --> Total execution time: 0.0412
INFO - 2025-05-03 10:32:15 --> Config Class Initialized
INFO - 2025-05-03 10:32:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:15 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:15 --> URI Class Initialized
INFO - 2025-05-03 10:32:15 --> Router Class Initialized
INFO - 2025-05-03 10:32:15 --> Output Class Initialized
INFO - 2025-05-03 10:32:15 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:15 --> Input Class Initialized
INFO - 2025-05-03 10:32:15 --> Language Class Initialized
INFO - 2025-05-03 10:32:15 --> Loader Class Initialized
INFO - 2025-05-03 10:32:15 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:15 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:15 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:15 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:15 --> Controller Class Initialized
INFO - 2025-05-03 10:32:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:32:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:32:15 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:32:15 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 10:32:15 --> Final output sent to browser
DEBUG - 2025-05-03 10:32:15 --> Total execution time: 0.0415
INFO - 2025-05-03 10:32:20 --> Config Class Initialized
INFO - 2025-05-03 10:32:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:20 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:20 --> URI Class Initialized
INFO - 2025-05-03 10:32:20 --> Router Class Initialized
INFO - 2025-05-03 10:32:20 --> Output Class Initialized
INFO - 2025-05-03 10:32:20 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:20 --> Input Class Initialized
INFO - 2025-05-03 10:32:20 --> Language Class Initialized
INFO - 2025-05-03 10:32:20 --> Loader Class Initialized
INFO - 2025-05-03 10:32:20 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:20 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:20 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:20 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:20 --> Controller Class Initialized
INFO - 2025-05-03 10:32:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:32:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:32:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:32:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 10:32:20 --> Final output sent to browser
DEBUG - 2025-05-03 10:32:20 --> Total execution time: 0.0380
INFO - 2025-05-03 10:32:22 --> Config Class Initialized
INFO - 2025-05-03 10:32:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:22 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:22 --> URI Class Initialized
INFO - 2025-05-03 10:32:22 --> Router Class Initialized
INFO - 2025-05-03 10:32:22 --> Output Class Initialized
INFO - 2025-05-03 10:32:22 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:22 --> Input Class Initialized
INFO - 2025-05-03 10:32:22 --> Language Class Initialized
INFO - 2025-05-03 10:32:22 --> Loader Class Initialized
INFO - 2025-05-03 10:32:22 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:22 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:22 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:22 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:22 --> Controller Class Initialized
INFO - 2025-05-03 10:32:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:32:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:32:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:32:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 10:32:22 --> Final output sent to browser
DEBUG - 2025-05-03 10:32:22 --> Total execution time: 0.0405
INFO - 2025-05-03 10:32:26 --> Config Class Initialized
INFO - 2025-05-03 10:32:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:32:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:32:26 --> Utf8 Class Initialized
INFO - 2025-05-03 10:32:26 --> URI Class Initialized
INFO - 2025-05-03 10:32:26 --> Router Class Initialized
INFO - 2025-05-03 10:32:26 --> Output Class Initialized
INFO - 2025-05-03 10:32:26 --> Security Class Initialized
DEBUG - 2025-05-03 10:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:32:26 --> Input Class Initialized
INFO - 2025-05-03 10:32:26 --> Language Class Initialized
INFO - 2025-05-03 10:32:26 --> Loader Class Initialized
INFO - 2025-05-03 10:32:26 --> Helper loaded: form_helper
INFO - 2025-05-03 10:32:26 --> Helper loaded: url_helper
INFO - 2025-05-03 10:32:26 --> Database Driver Class Initialized
INFO - 2025-05-03 10:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:32:26 --> Form Validation Class Initialized
INFO - 2025-05-03 10:32:26 --> Controller Class Initialized
INFO - 2025-05-03 10:32:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:32:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:32:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:32:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 10:32:27 --> Final output sent to browser
DEBUG - 2025-05-03 10:32:27 --> Total execution time: 0.0383
INFO - 2025-05-03 10:34:00 --> Config Class Initialized
INFO - 2025-05-03 10:34:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:34:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:34:00 --> Utf8 Class Initialized
INFO - 2025-05-03 10:34:00 --> URI Class Initialized
INFO - 2025-05-03 10:34:00 --> Router Class Initialized
INFO - 2025-05-03 10:34:00 --> Output Class Initialized
INFO - 2025-05-03 10:34:00 --> Security Class Initialized
DEBUG - 2025-05-03 10:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:34:00 --> Input Class Initialized
INFO - 2025-05-03 10:34:00 --> Language Class Initialized
INFO - 2025-05-03 10:34:00 --> Loader Class Initialized
INFO - 2025-05-03 10:34:00 --> Helper loaded: form_helper
INFO - 2025-05-03 10:34:00 --> Helper loaded: url_helper
INFO - 2025-05-03 10:34:00 --> Database Driver Class Initialized
INFO - 2025-05-03 10:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:34:00 --> Form Validation Class Initialized
INFO - 2025-05-03 10:34:00 --> Controller Class Initialized
INFO - 2025-05-03 10:34:00 --> Config Class Initialized
INFO - 2025-05-03 10:34:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:34:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:34:00 --> Utf8 Class Initialized
INFO - 2025-05-03 10:34:00 --> URI Class Initialized
INFO - 2025-05-03 10:34:00 --> Router Class Initialized
INFO - 2025-05-03 10:34:00 --> Output Class Initialized
INFO - 2025-05-03 10:34:00 --> Security Class Initialized
DEBUG - 2025-05-03 10:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:34:00 --> Input Class Initialized
INFO - 2025-05-03 10:34:00 --> Language Class Initialized
INFO - 2025-05-03 10:34:00 --> Loader Class Initialized
INFO - 2025-05-03 10:34:00 --> Helper loaded: form_helper
INFO - 2025-05-03 10:34:00 --> Helper loaded: url_helper
INFO - 2025-05-03 10:34:00 --> Database Driver Class Initialized
INFO - 2025-05-03 10:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:34:00 --> Form Validation Class Initialized
INFO - 2025-05-03 10:34:00 --> Controller Class Initialized
INFO - 2025-05-03 10:34:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 10:34:00 --> Final output sent to browser
DEBUG - 2025-05-03 10:34:00 --> Total execution time: 0.0294
INFO - 2025-05-03 10:34:00 --> Config Class Initialized
INFO - 2025-05-03 10:34:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:34:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:34:00 --> Utf8 Class Initialized
INFO - 2025-05-03 10:34:00 --> URI Class Initialized
INFO - 2025-05-03 10:34:00 --> Router Class Initialized
INFO - 2025-05-03 10:34:00 --> Output Class Initialized
INFO - 2025-05-03 10:34:00 --> Security Class Initialized
DEBUG - 2025-05-03 10:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:34:00 --> Input Class Initialized
INFO - 2025-05-03 10:34:00 --> Language Class Initialized
INFO - 2025-05-03 10:34:00 --> Loader Class Initialized
INFO - 2025-05-03 10:34:00 --> Helper loaded: form_helper
INFO - 2025-05-03 10:34:00 --> Helper loaded: url_helper
INFO - 2025-05-03 10:34:00 --> Database Driver Class Initialized
INFO - 2025-05-03 10:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:34:00 --> Form Validation Class Initialized
INFO - 2025-05-03 10:34:00 --> Controller Class Initialized
INFO - 2025-05-03 10:34:01 --> Config Class Initialized
INFO - 2025-05-03 10:34:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:34:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:34:01 --> Utf8 Class Initialized
INFO - 2025-05-03 10:34:01 --> URI Class Initialized
INFO - 2025-05-03 10:34:01 --> Router Class Initialized
INFO - 2025-05-03 10:34:01 --> Output Class Initialized
INFO - 2025-05-03 10:34:01 --> Security Class Initialized
DEBUG - 2025-05-03 10:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:34:01 --> Input Class Initialized
INFO - 2025-05-03 10:34:01 --> Language Class Initialized
INFO - 2025-05-03 10:34:01 --> Loader Class Initialized
INFO - 2025-05-03 10:34:01 --> Helper loaded: form_helper
INFO - 2025-05-03 10:34:01 --> Helper loaded: url_helper
INFO - 2025-05-03 10:34:01 --> Database Driver Class Initialized
INFO - 2025-05-03 10:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:34:01 --> Form Validation Class Initialized
INFO - 2025-05-03 10:34:01 --> Controller Class Initialized
INFO - 2025-05-03 10:34:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 10:34:01 --> Final output sent to browser
DEBUG - 2025-05-03 10:34:01 --> Total execution time: 0.0325
INFO - 2025-05-03 10:35:20 --> Config Class Initialized
INFO - 2025-05-03 10:35:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:35:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:35:20 --> Utf8 Class Initialized
INFO - 2025-05-03 10:35:20 --> URI Class Initialized
DEBUG - 2025-05-03 10:35:20 --> No URI present. Default controller set.
INFO - 2025-05-03 10:35:20 --> Router Class Initialized
INFO - 2025-05-03 10:35:20 --> Output Class Initialized
INFO - 2025-05-03 10:35:20 --> Security Class Initialized
DEBUG - 2025-05-03 10:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:35:20 --> Input Class Initialized
INFO - 2025-05-03 10:35:20 --> Language Class Initialized
INFO - 2025-05-03 10:35:20 --> Loader Class Initialized
INFO - 2025-05-03 10:35:20 --> Helper loaded: form_helper
INFO - 2025-05-03 10:35:20 --> Helper loaded: url_helper
INFO - 2025-05-03 10:35:20 --> Database Driver Class Initialized
INFO - 2025-05-03 10:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:35:20 --> Form Validation Class Initialized
INFO - 2025-05-03 10:35:20 --> Controller Class Initialized
INFO - 2025-05-03 10:35:20 --> Final output sent to browser
DEBUG - 2025-05-03 10:35:20 --> Total execution time: 0.0353
INFO - 2025-05-03 10:35:24 --> Config Class Initialized
INFO - 2025-05-03 10:35:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:35:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:35:24 --> Utf8 Class Initialized
INFO - 2025-05-03 10:35:24 --> URI Class Initialized
INFO - 2025-05-03 10:35:24 --> Router Class Initialized
INFO - 2025-05-03 10:35:24 --> Output Class Initialized
INFO - 2025-05-03 10:35:24 --> Security Class Initialized
DEBUG - 2025-05-03 10:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:35:24 --> Input Class Initialized
INFO - 2025-05-03 10:35:24 --> Language Class Initialized
INFO - 2025-05-03 10:35:24 --> Loader Class Initialized
INFO - 2025-05-03 10:35:24 --> Helper loaded: form_helper
INFO - 2025-05-03 10:35:24 --> Helper loaded: url_helper
INFO - 2025-05-03 10:35:24 --> Database Driver Class Initialized
INFO - 2025-05-03 10:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:35:24 --> Form Validation Class Initialized
INFO - 2025-05-03 10:35:24 --> Controller Class Initialized
INFO - 2025-05-03 10:35:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:35:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:35:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:35:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 10:35:24 --> Final output sent to browser
DEBUG - 2025-05-03 10:35:24 --> Total execution time: 0.0343
INFO - 2025-05-03 10:35:28 --> Config Class Initialized
INFO - 2025-05-03 10:35:28 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:35:28 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:35:28 --> Utf8 Class Initialized
INFO - 2025-05-03 10:35:28 --> URI Class Initialized
INFO - 2025-05-03 10:35:28 --> Router Class Initialized
INFO - 2025-05-03 10:35:28 --> Output Class Initialized
INFO - 2025-05-03 10:35:28 --> Security Class Initialized
DEBUG - 2025-05-03 10:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:35:28 --> Input Class Initialized
INFO - 2025-05-03 10:35:28 --> Language Class Initialized
INFO - 2025-05-03 10:35:28 --> Loader Class Initialized
INFO - 2025-05-03 10:35:28 --> Helper loaded: form_helper
INFO - 2025-05-03 10:35:28 --> Helper loaded: url_helper
INFO - 2025-05-03 10:35:28 --> Database Driver Class Initialized
INFO - 2025-05-03 10:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:35:28 --> Form Validation Class Initialized
INFO - 2025-05-03 10:35:28 --> Controller Class Initialized
INFO - 2025-05-03 10:35:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:35:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:35:28 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:35:28 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 10:35:28 --> Final output sent to browser
DEBUG - 2025-05-03 10:35:28 --> Total execution time: 0.0399
INFO - 2025-05-03 10:37:21 --> Config Class Initialized
INFO - 2025-05-03 10:37:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:37:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:37:21 --> Utf8 Class Initialized
INFO - 2025-05-03 10:37:21 --> URI Class Initialized
INFO - 2025-05-03 10:37:21 --> Router Class Initialized
INFO - 2025-05-03 10:37:21 --> Output Class Initialized
INFO - 2025-05-03 10:37:21 --> Security Class Initialized
DEBUG - 2025-05-03 10:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:37:21 --> Input Class Initialized
INFO - 2025-05-03 10:37:21 --> Language Class Initialized
INFO - 2025-05-03 10:37:21 --> Loader Class Initialized
INFO - 2025-05-03 10:37:21 --> Helper loaded: form_helper
INFO - 2025-05-03 10:37:21 --> Helper loaded: url_helper
INFO - 2025-05-03 10:37:21 --> Database Driver Class Initialized
INFO - 2025-05-03 10:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:37:21 --> Form Validation Class Initialized
INFO - 2025-05-03 10:37:21 --> Controller Class Initialized
INFO - 2025-05-03 10:37:21 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:37:21 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:37:21 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:37:21 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 10:37:21 --> Final output sent to browser
DEBUG - 2025-05-03 10:37:21 --> Total execution time: 0.0409
INFO - 2025-05-03 10:38:19 --> Config Class Initialized
INFO - 2025-05-03 10:38:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:38:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:38:19 --> Utf8 Class Initialized
INFO - 2025-05-03 10:38:19 --> URI Class Initialized
INFO - 2025-05-03 10:38:19 --> Router Class Initialized
INFO - 2025-05-03 10:38:19 --> Output Class Initialized
INFO - 2025-05-03 10:38:19 --> Security Class Initialized
DEBUG - 2025-05-03 10:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:38:19 --> Input Class Initialized
INFO - 2025-05-03 10:38:19 --> Language Class Initialized
INFO - 2025-05-03 10:38:19 --> Loader Class Initialized
INFO - 2025-05-03 10:38:19 --> Helper loaded: form_helper
INFO - 2025-05-03 10:38:19 --> Helper loaded: url_helper
INFO - 2025-05-03 10:38:19 --> Database Driver Class Initialized
INFO - 2025-05-03 10:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:38:19 --> Form Validation Class Initialized
INFO - 2025-05-03 10:38:19 --> Controller Class Initialized
INFO - 2025-05-03 10:38:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:38:19 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:38:19 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:38:19 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 10:38:19 --> Final output sent to browser
DEBUG - 2025-05-03 10:38:19 --> Total execution time: 0.0432
INFO - 2025-05-03 10:40:36 --> Config Class Initialized
INFO - 2025-05-03 10:40:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:40:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:40:36 --> Utf8 Class Initialized
INFO - 2025-05-03 10:40:36 --> URI Class Initialized
INFO - 2025-05-03 10:40:36 --> Router Class Initialized
INFO - 2025-05-03 10:40:36 --> Output Class Initialized
INFO - 2025-05-03 10:40:36 --> Security Class Initialized
DEBUG - 2025-05-03 10:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:40:36 --> Input Class Initialized
INFO - 2025-05-03 10:40:36 --> Language Class Initialized
INFO - 2025-05-03 10:40:36 --> Loader Class Initialized
INFO - 2025-05-03 10:40:36 --> Helper loaded: form_helper
INFO - 2025-05-03 10:40:36 --> Helper loaded: url_helper
INFO - 2025-05-03 10:40:36 --> Database Driver Class Initialized
INFO - 2025-05-03 10:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:40:36 --> Form Validation Class Initialized
INFO - 2025-05-03 10:40:36 --> Controller Class Initialized
INFO - 2025-05-03 10:40:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:40:36 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:40:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:40:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 10:40:36 --> Final output sent to browser
DEBUG - 2025-05-03 10:40:36 --> Total execution time: 0.0321
INFO - 2025-05-03 10:43:33 --> Config Class Initialized
INFO - 2025-05-03 10:43:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:43:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:43:33 --> Utf8 Class Initialized
INFO - 2025-05-03 10:43:33 --> URI Class Initialized
INFO - 2025-05-03 10:43:33 --> Router Class Initialized
INFO - 2025-05-03 10:43:33 --> Output Class Initialized
INFO - 2025-05-03 10:43:33 --> Security Class Initialized
DEBUG - 2025-05-03 10:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:43:33 --> Input Class Initialized
INFO - 2025-05-03 10:43:33 --> Language Class Initialized
INFO - 2025-05-03 10:43:33 --> Loader Class Initialized
INFO - 2025-05-03 10:43:33 --> Helper loaded: form_helper
INFO - 2025-05-03 10:43:33 --> Helper loaded: url_helper
INFO - 2025-05-03 10:43:33 --> Database Driver Class Initialized
INFO - 2025-05-03 10:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:43:33 --> Form Validation Class Initialized
INFO - 2025-05-03 10:43:33 --> Controller Class Initialized
INFO - 2025-05-03 10:43:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:43:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:43:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:43:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 10:43:33 --> Final output sent to browser
DEBUG - 2025-05-03 10:43:33 --> Total execution time: 0.0412
INFO - 2025-05-03 10:43:40 --> Config Class Initialized
INFO - 2025-05-03 10:43:40 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:43:40 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:43:40 --> Utf8 Class Initialized
INFO - 2025-05-03 10:43:40 --> URI Class Initialized
INFO - 2025-05-03 10:43:40 --> Router Class Initialized
INFO - 2025-05-03 10:43:40 --> Output Class Initialized
INFO - 2025-05-03 10:43:40 --> Security Class Initialized
DEBUG - 2025-05-03 10:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:43:40 --> Input Class Initialized
INFO - 2025-05-03 10:43:40 --> Language Class Initialized
INFO - 2025-05-03 10:43:40 --> Loader Class Initialized
INFO - 2025-05-03 10:43:40 --> Helper loaded: form_helper
INFO - 2025-05-03 10:43:40 --> Helper loaded: url_helper
INFO - 2025-05-03 10:43:40 --> Database Driver Class Initialized
INFO - 2025-05-03 10:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:43:40 --> Form Validation Class Initialized
INFO - 2025-05-03 10:43:40 --> Controller Class Initialized
INFO - 2025-05-03 10:43:40 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:43:40 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:43:40 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:43:40 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 10:43:40 --> Final output sent to browser
DEBUG - 2025-05-03 10:43:40 --> Total execution time: 0.0336
INFO - 2025-05-03 10:43:43 --> Config Class Initialized
INFO - 2025-05-03 10:43:43 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:43:43 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:43:43 --> Utf8 Class Initialized
INFO - 2025-05-03 10:43:43 --> URI Class Initialized
INFO - 2025-05-03 10:43:43 --> Router Class Initialized
INFO - 2025-05-03 10:43:43 --> Output Class Initialized
INFO - 2025-05-03 10:43:43 --> Security Class Initialized
DEBUG - 2025-05-03 10:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:43:43 --> Input Class Initialized
INFO - 2025-05-03 10:43:43 --> Language Class Initialized
INFO - 2025-05-03 10:43:43 --> Loader Class Initialized
INFO - 2025-05-03 10:43:43 --> Helper loaded: form_helper
INFO - 2025-05-03 10:43:43 --> Helper loaded: url_helper
INFO - 2025-05-03 10:43:43 --> Database Driver Class Initialized
INFO - 2025-05-03 10:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:43:43 --> Form Validation Class Initialized
INFO - 2025-05-03 10:43:43 --> Controller Class Initialized
INFO - 2025-05-03 10:43:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:43:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:43:43 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:43:43 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/belum_daftar_ulang.php
INFO - 2025-05-03 10:43:43 --> Final output sent to browser
DEBUG - 2025-05-03 10:43:43 --> Total execution time: 0.0356
INFO - 2025-05-03 10:43:53 --> Config Class Initialized
INFO - 2025-05-03 10:43:53 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:43:53 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:43:53 --> Utf8 Class Initialized
INFO - 2025-05-03 10:43:53 --> URI Class Initialized
INFO - 2025-05-03 10:43:53 --> Router Class Initialized
INFO - 2025-05-03 10:43:53 --> Output Class Initialized
INFO - 2025-05-03 10:43:53 --> Security Class Initialized
DEBUG - 2025-05-03 10:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:43:53 --> Input Class Initialized
INFO - 2025-05-03 10:43:53 --> Language Class Initialized
INFO - 2025-05-03 10:43:53 --> Loader Class Initialized
INFO - 2025-05-03 10:43:53 --> Helper loaded: form_helper
INFO - 2025-05-03 10:43:53 --> Helper loaded: url_helper
INFO - 2025-05-03 10:43:53 --> Database Driver Class Initialized
INFO - 2025-05-03 10:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 10:43:53 --> Form Validation Class Initialized
INFO - 2025-05-03 10:43:53 --> Controller Class Initialized
INFO - 2025-05-03 10:43:53 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 10:43:53 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 10:43:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 10:43:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 10:43:53 --> Final output sent to browser
DEBUG - 2025-05-03 10:43:53 --> Total execution time: 0.0351
INFO - 2025-05-03 10:46:01 --> Config Class Initialized
INFO - 2025-05-03 10:46:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 10:46:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 10:46:01 --> Utf8 Class Initialized
INFO - 2025-05-03 10:46:01 --> URI Class Initialized
INFO - 2025-05-03 10:46:01 --> Router Class Initialized
INFO - 2025-05-03 10:46:01 --> Output Class Initialized
INFO - 2025-05-03 10:46:01 --> Security Class Initialized
DEBUG - 2025-05-03 10:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 10:46:01 --> Input Class Initialized
INFO - 2025-05-03 10:46:01 --> Language Class Initialized
ERROR - 2025-05-03 10:46:01 --> 404 Page Not Found: Www/js
INFO - 2025-05-03 11:10:07 --> Config Class Initialized
INFO - 2025-05-03 11:10:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:10:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:10:07 --> Utf8 Class Initialized
INFO - 2025-05-03 11:10:07 --> URI Class Initialized
INFO - 2025-05-03 11:10:07 --> Router Class Initialized
INFO - 2025-05-03 11:10:07 --> Output Class Initialized
INFO - 2025-05-03 11:10:07 --> Security Class Initialized
DEBUG - 2025-05-03 11:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:10:07 --> Input Class Initialized
INFO - 2025-05-03 11:10:07 --> Language Class Initialized
INFO - 2025-05-03 11:10:07 --> Loader Class Initialized
INFO - 2025-05-03 11:10:07 --> Helper loaded: form_helper
INFO - 2025-05-03 11:10:07 --> Helper loaded: url_helper
INFO - 2025-05-03 11:10:07 --> Database Driver Class Initialized
INFO - 2025-05-03 11:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:10:07 --> Form Validation Class Initialized
INFO - 2025-05-03 11:10:07 --> Controller Class Initialized
INFO - 2025-05-03 11:10:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:10:07 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:10:07 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:10:07 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 11:10:07 --> Final output sent to browser
DEBUG - 2025-05-03 11:10:07 --> Total execution time: 0.0415
INFO - 2025-05-03 11:10:09 --> Config Class Initialized
INFO - 2025-05-03 11:10:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:10:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:10:09 --> Utf8 Class Initialized
INFO - 2025-05-03 11:10:09 --> URI Class Initialized
INFO - 2025-05-03 11:10:09 --> Router Class Initialized
INFO - 2025-05-03 11:10:09 --> Output Class Initialized
INFO - 2025-05-03 11:10:09 --> Security Class Initialized
DEBUG - 2025-05-03 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:10:09 --> Input Class Initialized
INFO - 2025-05-03 11:10:09 --> Language Class Initialized
INFO - 2025-05-03 11:10:09 --> Loader Class Initialized
INFO - 2025-05-03 11:10:09 --> Helper loaded: form_helper
INFO - 2025-05-03 11:10:09 --> Helper loaded: url_helper
INFO - 2025-05-03 11:10:09 --> Database Driver Class Initialized
INFO - 2025-05-03 11:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:10:09 --> Form Validation Class Initialized
INFO - 2025-05-03 11:10:09 --> Controller Class Initialized
INFO - 2025-05-03 11:10:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:10:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:10:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-03 11:10:09 --> Final output sent to browser
DEBUG - 2025-05-03 11:10:09 --> Total execution time: 0.0382
INFO - 2025-05-03 11:44:28 --> Config Class Initialized
INFO - 2025-05-03 11:44:28 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:44:28 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:44:28 --> Utf8 Class Initialized
INFO - 2025-05-03 11:44:28 --> URI Class Initialized
DEBUG - 2025-05-03 11:44:28 --> No URI present. Default controller set.
INFO - 2025-05-03 11:44:28 --> Router Class Initialized
INFO - 2025-05-03 11:44:28 --> Output Class Initialized
INFO - 2025-05-03 11:44:28 --> Security Class Initialized
DEBUG - 2025-05-03 11:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:44:28 --> Input Class Initialized
INFO - 2025-05-03 11:44:28 --> Language Class Initialized
INFO - 2025-05-03 11:44:28 --> Loader Class Initialized
INFO - 2025-05-03 11:44:28 --> Helper loaded: form_helper
INFO - 2025-05-03 11:44:28 --> Helper loaded: url_helper
INFO - 2025-05-03 11:44:28 --> Database Driver Class Initialized
INFO - 2025-05-03 11:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:44:28 --> Form Validation Class Initialized
INFO - 2025-05-03 11:44:28 --> Controller Class Initialized
INFO - 2025-05-03 11:44:28 --> Final output sent to browser
DEBUG - 2025-05-03 11:44:28 --> Total execution time: 0.0324
INFO - 2025-05-03 11:44:49 --> Config Class Initialized
INFO - 2025-05-03 11:44:49 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:44:49 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:44:49 --> Utf8 Class Initialized
INFO - 2025-05-03 11:44:49 --> URI Class Initialized
INFO - 2025-05-03 11:44:49 --> Router Class Initialized
INFO - 2025-05-03 11:44:49 --> Output Class Initialized
INFO - 2025-05-03 11:44:49 --> Security Class Initialized
DEBUG - 2025-05-03 11:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:44:49 --> Input Class Initialized
INFO - 2025-05-03 11:44:49 --> Language Class Initialized
INFO - 2025-05-03 11:44:49 --> Loader Class Initialized
INFO - 2025-05-03 11:44:49 --> Helper loaded: form_helper
INFO - 2025-05-03 11:44:49 --> Helper loaded: url_helper
INFO - 2025-05-03 11:44:49 --> Database Driver Class Initialized
INFO - 2025-05-03 11:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:44:49 --> Form Validation Class Initialized
INFO - 2025-05-03 11:44:49 --> Controller Class Initialized
INFO - 2025-05-03 11:44:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:44:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:44:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:44:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 11:44:49 --> Final output sent to browser
DEBUG - 2025-05-03 11:44:49 --> Total execution time: 0.0369
INFO - 2025-05-03 11:44:52 --> Config Class Initialized
INFO - 2025-05-03 11:44:52 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:44:52 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:44:52 --> Utf8 Class Initialized
INFO - 2025-05-03 11:44:52 --> URI Class Initialized
INFO - 2025-05-03 11:44:52 --> Router Class Initialized
INFO - 2025-05-03 11:44:52 --> Output Class Initialized
INFO - 2025-05-03 11:44:52 --> Security Class Initialized
DEBUG - 2025-05-03 11:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:44:52 --> Input Class Initialized
INFO - 2025-05-03 11:44:52 --> Language Class Initialized
INFO - 2025-05-03 11:44:52 --> Loader Class Initialized
INFO - 2025-05-03 11:44:52 --> Helper loaded: form_helper
INFO - 2025-05-03 11:44:52 --> Helper loaded: url_helper
INFO - 2025-05-03 11:44:52 --> Database Driver Class Initialized
INFO - 2025-05-03 11:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:44:52 --> Form Validation Class Initialized
INFO - 2025-05-03 11:44:52 --> Controller Class Initialized
INFO - 2025-05-03 11:44:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:44:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:44:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:44:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 11:44:52 --> Final output sent to browser
DEBUG - 2025-05-03 11:44:52 --> Total execution time: 0.0431
INFO - 2025-05-03 11:44:54 --> Config Class Initialized
INFO - 2025-05-03 11:44:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:44:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:44:54 --> Utf8 Class Initialized
INFO - 2025-05-03 11:44:54 --> URI Class Initialized
INFO - 2025-05-03 11:44:54 --> Router Class Initialized
INFO - 2025-05-03 11:44:54 --> Output Class Initialized
INFO - 2025-05-03 11:44:54 --> Security Class Initialized
DEBUG - 2025-05-03 11:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:44:54 --> Input Class Initialized
INFO - 2025-05-03 11:44:54 --> Language Class Initialized
INFO - 2025-05-03 11:44:54 --> Loader Class Initialized
INFO - 2025-05-03 11:44:54 --> Helper loaded: form_helper
INFO - 2025-05-03 11:44:54 --> Helper loaded: url_helper
INFO - 2025-05-03 11:44:54 --> Database Driver Class Initialized
INFO - 2025-05-03 11:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:44:54 --> Form Validation Class Initialized
INFO - 2025-05-03 11:44:54 --> Controller Class Initialized
INFO - 2025-05-03 11:44:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:44:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:44:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:44:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 11:44:54 --> Final output sent to browser
DEBUG - 2025-05-03 11:44:54 --> Total execution time: 0.0457
INFO - 2025-05-03 11:44:57 --> Config Class Initialized
INFO - 2025-05-03 11:44:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:44:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:44:57 --> Utf8 Class Initialized
INFO - 2025-05-03 11:44:57 --> URI Class Initialized
INFO - 2025-05-03 11:44:57 --> Router Class Initialized
INFO - 2025-05-03 11:44:57 --> Output Class Initialized
INFO - 2025-05-03 11:44:57 --> Security Class Initialized
DEBUG - 2025-05-03 11:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:44:57 --> Input Class Initialized
INFO - 2025-05-03 11:44:57 --> Language Class Initialized
INFO - 2025-05-03 11:44:57 --> Loader Class Initialized
INFO - 2025-05-03 11:44:57 --> Helper loaded: form_helper
INFO - 2025-05-03 11:44:57 --> Helper loaded: url_helper
INFO - 2025-05-03 11:44:57 --> Database Driver Class Initialized
INFO - 2025-05-03 11:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:44:57 --> Form Validation Class Initialized
INFO - 2025-05-03 11:44:57 --> Controller Class Initialized
INFO - 2025-05-03 11:44:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:44:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:44:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:44:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 11:44:57 --> Final output sent to browser
DEBUG - 2025-05-03 11:44:57 --> Total execution time: 0.0372
INFO - 2025-05-03 11:45:09 --> Config Class Initialized
INFO - 2025-05-03 11:45:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:45:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:45:09 --> Utf8 Class Initialized
INFO - 2025-05-03 11:45:09 --> URI Class Initialized
INFO - 2025-05-03 11:45:09 --> Router Class Initialized
INFO - 2025-05-03 11:45:09 --> Output Class Initialized
INFO - 2025-05-03 11:45:09 --> Security Class Initialized
DEBUG - 2025-05-03 11:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:45:09 --> Input Class Initialized
INFO - 2025-05-03 11:45:09 --> Language Class Initialized
INFO - 2025-05-03 11:45:09 --> Loader Class Initialized
INFO - 2025-05-03 11:45:09 --> Helper loaded: form_helper
INFO - 2025-05-03 11:45:09 --> Helper loaded: url_helper
INFO - 2025-05-03 11:45:09 --> Database Driver Class Initialized
INFO - 2025-05-03 11:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:45:09 --> Form Validation Class Initialized
INFO - 2025-05-03 11:45:09 --> Controller Class Initialized
INFO - 2025-05-03 11:45:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:45:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:45:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/pengaturan.php
INFO - 2025-05-03 11:45:09 --> Final output sent to browser
DEBUG - 2025-05-03 11:45:09 --> Total execution time: 0.0375
INFO - 2025-05-03 11:45:13 --> Config Class Initialized
INFO - 2025-05-03 11:45:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:45:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:45:13 --> Utf8 Class Initialized
INFO - 2025-05-03 11:45:13 --> URI Class Initialized
INFO - 2025-05-03 11:45:13 --> Router Class Initialized
INFO - 2025-05-03 11:45:13 --> Output Class Initialized
INFO - 2025-05-03 11:45:13 --> Security Class Initialized
DEBUG - 2025-05-03 11:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:45:13 --> Input Class Initialized
INFO - 2025-05-03 11:45:13 --> Language Class Initialized
INFO - 2025-05-03 11:45:13 --> Loader Class Initialized
INFO - 2025-05-03 11:45:13 --> Helper loaded: form_helper
INFO - 2025-05-03 11:45:13 --> Helper loaded: url_helper
INFO - 2025-05-03 11:45:13 --> Database Driver Class Initialized
INFO - 2025-05-03 11:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:45:13 --> Form Validation Class Initialized
INFO - 2025-05-03 11:45:13 --> Controller Class Initialized
INFO - 2025-05-03 11:45:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:45:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:45:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:45:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 11:45:13 --> Final output sent to browser
DEBUG - 2025-05-03 11:45:13 --> Total execution time: 0.0340
INFO - 2025-05-03 11:45:17 --> Config Class Initialized
INFO - 2025-05-03 11:45:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:45:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:45:17 --> Utf8 Class Initialized
INFO - 2025-05-03 11:45:17 --> URI Class Initialized
INFO - 2025-05-03 11:45:17 --> Router Class Initialized
INFO - 2025-05-03 11:45:17 --> Output Class Initialized
INFO - 2025-05-03 11:45:17 --> Security Class Initialized
DEBUG - 2025-05-03 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:45:17 --> Input Class Initialized
INFO - 2025-05-03 11:45:17 --> Language Class Initialized
INFO - 2025-05-03 11:45:17 --> Loader Class Initialized
INFO - 2025-05-03 11:45:17 --> Helper loaded: form_helper
INFO - 2025-05-03 11:45:17 --> Helper loaded: url_helper
INFO - 2025-05-03 11:45:17 --> Database Driver Class Initialized
INFO - 2025-05-03 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:45:17 --> Form Validation Class Initialized
INFO - 2025-05-03 11:45:17 --> Controller Class Initialized
INFO - 2025-05-03 11:45:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:45:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:45:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:45:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 11:45:17 --> Final output sent to browser
DEBUG - 2025-05-03 11:45:17 --> Total execution time: 0.0359
INFO - 2025-05-03 11:45:22 --> Config Class Initialized
INFO - 2025-05-03 11:45:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:45:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:45:22 --> Utf8 Class Initialized
INFO - 2025-05-03 11:45:22 --> URI Class Initialized
INFO - 2025-05-03 11:45:22 --> Router Class Initialized
INFO - 2025-05-03 11:45:22 --> Output Class Initialized
INFO - 2025-05-03 11:45:22 --> Security Class Initialized
DEBUG - 2025-05-03 11:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:45:22 --> Input Class Initialized
INFO - 2025-05-03 11:45:22 --> Language Class Initialized
INFO - 2025-05-03 11:45:22 --> Loader Class Initialized
INFO - 2025-05-03 11:45:22 --> Helper loaded: form_helper
INFO - 2025-05-03 11:45:22 --> Helper loaded: url_helper
INFO - 2025-05-03 11:45:22 --> Database Driver Class Initialized
INFO - 2025-05-03 11:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:45:22 --> Form Validation Class Initialized
INFO - 2025-05-03 11:45:22 --> Controller Class Initialized
INFO - 2025-05-03 11:45:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:45:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:45:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:45:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 11:45:22 --> Final output sent to browser
DEBUG - 2025-05-03 11:45:22 --> Total execution time: 0.0352
INFO - 2025-05-03 11:45:34 --> Config Class Initialized
INFO - 2025-05-03 11:45:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:45:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:45:34 --> Utf8 Class Initialized
INFO - 2025-05-03 11:45:34 --> URI Class Initialized
INFO - 2025-05-03 11:45:34 --> Router Class Initialized
INFO - 2025-05-03 11:45:34 --> Output Class Initialized
INFO - 2025-05-03 11:45:34 --> Security Class Initialized
DEBUG - 2025-05-03 11:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:45:34 --> Input Class Initialized
INFO - 2025-05-03 11:45:34 --> Language Class Initialized
INFO - 2025-05-03 11:45:34 --> Loader Class Initialized
INFO - 2025-05-03 11:45:34 --> Helper loaded: form_helper
INFO - 2025-05-03 11:45:34 --> Helper loaded: url_helper
INFO - 2025-05-03 11:45:34 --> Database Driver Class Initialized
INFO - 2025-05-03 11:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:45:34 --> Form Validation Class Initialized
INFO - 2025-05-03 11:45:34 --> Controller Class Initialized
INFO - 2025-05-03 11:45:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:45:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:45:34 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:45:34 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 11:45:34 --> Final output sent to browser
DEBUG - 2025-05-03 11:45:34 --> Total execution time: 0.0424
INFO - 2025-05-03 11:45:45 --> Config Class Initialized
INFO - 2025-05-03 11:45:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:45:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:45:45 --> Utf8 Class Initialized
INFO - 2025-05-03 11:45:45 --> URI Class Initialized
INFO - 2025-05-03 11:45:45 --> Router Class Initialized
INFO - 2025-05-03 11:45:45 --> Output Class Initialized
INFO - 2025-05-03 11:45:45 --> Security Class Initialized
DEBUG - 2025-05-03 11:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:45:45 --> Input Class Initialized
INFO - 2025-05-03 11:45:45 --> Language Class Initialized
INFO - 2025-05-03 11:45:45 --> Loader Class Initialized
INFO - 2025-05-03 11:45:45 --> Helper loaded: form_helper
INFO - 2025-05-03 11:45:45 --> Helper loaded: url_helper
INFO - 2025-05-03 11:45:45 --> Database Driver Class Initialized
INFO - 2025-05-03 11:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:45:45 --> Form Validation Class Initialized
INFO - 2025-05-03 11:45:45 --> Controller Class Initialized
INFO - 2025-05-03 11:45:45 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:45:45 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:45:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:45:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 11:45:45 --> Final output sent to browser
DEBUG - 2025-05-03 11:45:45 --> Total execution time: 0.0332
INFO - 2025-05-03 11:45:55 --> Config Class Initialized
INFO - 2025-05-03 11:45:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:45:55 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:45:55 --> Utf8 Class Initialized
INFO - 2025-05-03 11:45:55 --> URI Class Initialized
INFO - 2025-05-03 11:45:55 --> Router Class Initialized
INFO - 2025-05-03 11:45:55 --> Output Class Initialized
INFO - 2025-05-03 11:45:55 --> Security Class Initialized
DEBUG - 2025-05-03 11:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:45:55 --> Input Class Initialized
INFO - 2025-05-03 11:45:55 --> Language Class Initialized
INFO - 2025-05-03 11:45:55 --> Loader Class Initialized
INFO - 2025-05-03 11:45:55 --> Helper loaded: form_helper
INFO - 2025-05-03 11:45:55 --> Helper loaded: url_helper
INFO - 2025-05-03 11:45:55 --> Database Driver Class Initialized
INFO - 2025-05-03 11:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:45:55 --> Form Validation Class Initialized
INFO - 2025-05-03 11:45:55 --> Controller Class Initialized
INFO - 2025-05-03 11:45:55 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:45:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:45:55 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:45:55 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 11:45:55 --> Final output sent to browser
DEBUG - 2025-05-03 11:45:55 --> Total execution time: 0.0455
INFO - 2025-05-03 11:46:05 --> Config Class Initialized
INFO - 2025-05-03 11:46:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:05 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:05 --> URI Class Initialized
INFO - 2025-05-03 11:46:05 --> Router Class Initialized
INFO - 2025-05-03 11:46:05 --> Output Class Initialized
INFO - 2025-05-03 11:46:05 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:06 --> Input Class Initialized
INFO - 2025-05-03 11:46:06 --> Language Class Initialized
INFO - 2025-05-03 11:46:06 --> Loader Class Initialized
INFO - 2025-05-03 11:46:06 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:06 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:06 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:06 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:06 --> Controller Class Initialized
INFO - 2025-05-03 11:46:06 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:06 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:06 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:06 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 11:46:06 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:06 --> Total execution time: 0.0443
INFO - 2025-05-03 11:46:08 --> Config Class Initialized
INFO - 2025-05-03 11:46:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:08 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:08 --> URI Class Initialized
INFO - 2025-05-03 11:46:08 --> Router Class Initialized
INFO - 2025-05-03 11:46:08 --> Output Class Initialized
INFO - 2025-05-03 11:46:08 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:08 --> Input Class Initialized
INFO - 2025-05-03 11:46:08 --> Language Class Initialized
INFO - 2025-05-03 11:46:08 --> Loader Class Initialized
INFO - 2025-05-03 11:46:08 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:08 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:08 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:08 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:08 --> Controller Class Initialized
INFO - 2025-05-03 11:46:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 11:46:08 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:08 --> Total execution time: 0.0338
INFO - 2025-05-03 11:46:10 --> Config Class Initialized
INFO - 2025-05-03 11:46:10 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:10 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:10 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:10 --> URI Class Initialized
INFO - 2025-05-03 11:46:10 --> Router Class Initialized
INFO - 2025-05-03 11:46:10 --> Output Class Initialized
INFO - 2025-05-03 11:46:10 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:10 --> Input Class Initialized
INFO - 2025-05-03 11:46:10 --> Language Class Initialized
INFO - 2025-05-03 11:46:10 --> Loader Class Initialized
INFO - 2025-05-03 11:46:10 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:10 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:10 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:10 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:10 --> Controller Class Initialized
INFO - 2025-05-03 11:46:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 11:46:10 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:10 --> Total execution time: 0.0362
INFO - 2025-05-03 11:46:18 --> Config Class Initialized
INFO - 2025-05-03 11:46:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:18 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:18 --> URI Class Initialized
INFO - 2025-05-03 11:46:18 --> Router Class Initialized
INFO - 2025-05-03 11:46:18 --> Output Class Initialized
INFO - 2025-05-03 11:46:18 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:18 --> Input Class Initialized
INFO - 2025-05-03 11:46:18 --> Language Class Initialized
INFO - 2025-05-03 11:46:18 --> Loader Class Initialized
INFO - 2025-05-03 11:46:18 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:18 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:18 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:18 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:18 --> Controller Class Initialized
INFO - 2025-05-03 11:46:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 11:46:18 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:18 --> Total execution time: 0.0364
INFO - 2025-05-03 11:46:20 --> Config Class Initialized
INFO - 2025-05-03 11:46:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:20 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:20 --> URI Class Initialized
INFO - 2025-05-03 11:46:20 --> Router Class Initialized
INFO - 2025-05-03 11:46:20 --> Output Class Initialized
INFO - 2025-05-03 11:46:20 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:20 --> Input Class Initialized
INFO - 2025-05-03 11:46:20 --> Language Class Initialized
INFO - 2025-05-03 11:46:20 --> Loader Class Initialized
INFO - 2025-05-03 11:46:20 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:20 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:20 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:20 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:20 --> Controller Class Initialized
INFO - 2025-05-03 11:46:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 11:46:20 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:20 --> Total execution time: 0.0357
INFO - 2025-05-03 11:46:23 --> Config Class Initialized
INFO - 2025-05-03 11:46:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:23 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:23 --> URI Class Initialized
INFO - 2025-05-03 11:46:23 --> Router Class Initialized
INFO - 2025-05-03 11:46:23 --> Output Class Initialized
INFO - 2025-05-03 11:46:23 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:23 --> Input Class Initialized
INFO - 2025-05-03 11:46:23 --> Language Class Initialized
INFO - 2025-05-03 11:46:23 --> Loader Class Initialized
INFO - 2025-05-03 11:46:23 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:23 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:23 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:23 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:23 --> Controller Class Initialized
INFO - 2025-05-03 11:46:23 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:23 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:23 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:23 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 11:46:23 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:23 --> Total execution time: 0.0371
INFO - 2025-05-03 11:46:24 --> Config Class Initialized
INFO - 2025-05-03 11:46:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:24 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:24 --> URI Class Initialized
INFO - 2025-05-03 11:46:24 --> Router Class Initialized
INFO - 2025-05-03 11:46:24 --> Output Class Initialized
INFO - 2025-05-03 11:46:24 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:24 --> Input Class Initialized
INFO - 2025-05-03 11:46:24 --> Language Class Initialized
INFO - 2025-05-03 11:46:24 --> Loader Class Initialized
INFO - 2025-05-03 11:46:24 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:24 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:24 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:24 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:24 --> Controller Class Initialized
INFO - 2025-05-03 11:46:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 11:46:24 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:24 --> Total execution time: 0.0372
INFO - 2025-05-03 11:46:26 --> Config Class Initialized
INFO - 2025-05-03 11:46:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:26 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:26 --> URI Class Initialized
INFO - 2025-05-03 11:46:26 --> Router Class Initialized
INFO - 2025-05-03 11:46:26 --> Output Class Initialized
INFO - 2025-05-03 11:46:26 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:26 --> Input Class Initialized
INFO - 2025-05-03 11:46:26 --> Language Class Initialized
INFO - 2025-05-03 11:46:26 --> Loader Class Initialized
INFO - 2025-05-03 11:46:26 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:26 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:26 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:26 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:26 --> Controller Class Initialized
INFO - 2025-05-03 11:46:26 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:26 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:26 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:26 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 11:46:26 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:26 --> Total execution time: 0.0418
INFO - 2025-05-03 11:46:29 --> Config Class Initialized
INFO - 2025-05-03 11:46:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:29 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:29 --> URI Class Initialized
INFO - 2025-05-03 11:46:29 --> Router Class Initialized
INFO - 2025-05-03 11:46:29 --> Output Class Initialized
INFO - 2025-05-03 11:46:29 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:29 --> Input Class Initialized
INFO - 2025-05-03 11:46:29 --> Language Class Initialized
INFO - 2025-05-03 11:46:29 --> Loader Class Initialized
INFO - 2025-05-03 11:46:29 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:29 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:29 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:29 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:29 --> Controller Class Initialized
INFO - 2025-05-03 11:46:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/belum_daftar_ulang.php
INFO - 2025-05-03 11:46:29 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:29 --> Total execution time: 0.0398
INFO - 2025-05-03 11:46:35 --> Config Class Initialized
INFO - 2025-05-03 11:46:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:35 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:35 --> URI Class Initialized
INFO - 2025-05-03 11:46:35 --> Router Class Initialized
INFO - 2025-05-03 11:46:35 --> Output Class Initialized
INFO - 2025-05-03 11:46:35 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:35 --> Input Class Initialized
INFO - 2025-05-03 11:46:35 --> Language Class Initialized
INFO - 2025-05-03 11:46:35 --> Loader Class Initialized
INFO - 2025-05-03 11:46:35 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:35 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:35 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:35 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:35 --> Controller Class Initialized
INFO - 2025-05-03 11:46:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_sekolah.php
INFO - 2025-05-03 11:46:35 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:35 --> Total execution time: 0.0321
INFO - 2025-05-03 11:46:38 --> Config Class Initialized
INFO - 2025-05-03 11:46:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:46:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:46:38 --> Utf8 Class Initialized
INFO - 2025-05-03 11:46:38 --> URI Class Initialized
INFO - 2025-05-03 11:46:38 --> Router Class Initialized
INFO - 2025-05-03 11:46:38 --> Output Class Initialized
INFO - 2025-05-03 11:46:38 --> Security Class Initialized
DEBUG - 2025-05-03 11:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:46:38 --> Input Class Initialized
INFO - 2025-05-03 11:46:38 --> Language Class Initialized
INFO - 2025-05-03 11:46:38 --> Loader Class Initialized
INFO - 2025-05-03 11:46:38 --> Helper loaded: form_helper
INFO - 2025-05-03 11:46:38 --> Helper loaded: url_helper
INFO - 2025-05-03 11:46:38 --> Database Driver Class Initialized
INFO - 2025-05-03 11:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:46:38 --> Form Validation Class Initialized
INFO - 2025-05-03 11:46:38 --> Controller Class Initialized
INFO - 2025-05-03 11:46:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:46:38 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:46:38 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:46:38 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 11:46:38 --> Final output sent to browser
DEBUG - 2025-05-03 11:46:38 --> Total execution time: 0.0376
INFO - 2025-05-03 11:47:12 --> Config Class Initialized
INFO - 2025-05-03 11:47:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:47:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:47:12 --> Utf8 Class Initialized
INFO - 2025-05-03 11:47:12 --> URI Class Initialized
INFO - 2025-05-03 11:47:12 --> Router Class Initialized
INFO - 2025-05-03 11:47:12 --> Output Class Initialized
INFO - 2025-05-03 11:47:12 --> Security Class Initialized
DEBUG - 2025-05-03 11:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:47:12 --> Input Class Initialized
INFO - 2025-05-03 11:47:12 --> Language Class Initialized
INFO - 2025-05-03 11:47:12 --> Loader Class Initialized
INFO - 2025-05-03 11:47:12 --> Helper loaded: form_helper
INFO - 2025-05-03 11:47:12 --> Helper loaded: url_helper
INFO - 2025-05-03 11:47:12 --> Database Driver Class Initialized
INFO - 2025-05-03 11:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:47:12 --> Form Validation Class Initialized
INFO - 2025-05-03 11:47:12 --> Controller Class Initialized
INFO - 2025-05-03 11:47:12 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:47:12 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:47:12 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:47:12 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 11:47:12 --> Final output sent to browser
DEBUG - 2025-05-03 11:47:12 --> Total execution time: 0.0412
INFO - 2025-05-03 11:47:14 --> Config Class Initialized
INFO - 2025-05-03 11:47:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:47:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:47:14 --> Utf8 Class Initialized
INFO - 2025-05-03 11:47:14 --> URI Class Initialized
INFO - 2025-05-03 11:47:14 --> Router Class Initialized
INFO - 2025-05-03 11:47:14 --> Output Class Initialized
INFO - 2025-05-03 11:47:14 --> Security Class Initialized
DEBUG - 2025-05-03 11:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:47:14 --> Input Class Initialized
INFO - 2025-05-03 11:47:14 --> Language Class Initialized
INFO - 2025-05-03 11:47:14 --> Loader Class Initialized
INFO - 2025-05-03 11:47:14 --> Helper loaded: form_helper
INFO - 2025-05-03 11:47:14 --> Helper loaded: url_helper
INFO - 2025-05-03 11:47:14 --> Database Driver Class Initialized
INFO - 2025-05-03 11:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:47:14 --> Form Validation Class Initialized
INFO - 2025-05-03 11:47:14 --> Controller Class Initialized
INFO - 2025-05-03 11:47:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:47:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:47:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:47:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 11:47:14 --> Final output sent to browser
DEBUG - 2025-05-03 11:47:14 --> Total execution time: 0.0476
INFO - 2025-05-03 11:48:15 --> Config Class Initialized
INFO - 2025-05-03 11:48:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:48:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:48:15 --> Utf8 Class Initialized
INFO - 2025-05-03 11:48:15 --> URI Class Initialized
DEBUG - 2025-05-03 11:48:15 --> No URI present. Default controller set.
INFO - 2025-05-03 11:48:15 --> Router Class Initialized
INFO - 2025-05-03 11:48:15 --> Output Class Initialized
INFO - 2025-05-03 11:48:15 --> Security Class Initialized
DEBUG - 2025-05-03 11:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:48:15 --> Input Class Initialized
INFO - 2025-05-03 11:48:15 --> Language Class Initialized
INFO - 2025-05-03 11:48:15 --> Loader Class Initialized
INFO - 2025-05-03 11:48:15 --> Helper loaded: form_helper
INFO - 2025-05-03 11:48:15 --> Helper loaded: url_helper
INFO - 2025-05-03 11:48:15 --> Database Driver Class Initialized
INFO - 2025-05-03 11:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:48:15 --> Form Validation Class Initialized
INFO - 2025-05-03 11:48:15 --> Controller Class Initialized
INFO - 2025-05-03 11:48:15 --> Final output sent to browser
DEBUG - 2025-05-03 11:48:15 --> Total execution time: 0.0275
INFO - 2025-05-03 11:49:00 --> Config Class Initialized
INFO - 2025-05-03 11:49:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:49:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:49:00 --> Utf8 Class Initialized
INFO - 2025-05-03 11:49:00 --> URI Class Initialized
DEBUG - 2025-05-03 11:49:00 --> No URI present. Default controller set.
INFO - 2025-05-03 11:49:00 --> Router Class Initialized
INFO - 2025-05-03 11:49:00 --> Output Class Initialized
INFO - 2025-05-03 11:49:00 --> Security Class Initialized
DEBUG - 2025-05-03 11:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:49:00 --> Input Class Initialized
INFO - 2025-05-03 11:49:00 --> Language Class Initialized
INFO - 2025-05-03 11:49:00 --> Loader Class Initialized
INFO - 2025-05-03 11:49:00 --> Helper loaded: form_helper
INFO - 2025-05-03 11:49:00 --> Helper loaded: url_helper
INFO - 2025-05-03 11:49:00 --> Database Driver Class Initialized
INFO - 2025-05-03 11:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:49:00 --> Form Validation Class Initialized
INFO - 2025-05-03 11:49:00 --> Controller Class Initialized
INFO - 2025-05-03 11:49:00 --> Final output sent to browser
DEBUG - 2025-05-03 11:49:00 --> Total execution time: 0.0354
INFO - 2025-05-03 11:49:14 --> Config Class Initialized
INFO - 2025-05-03 11:49:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:49:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:49:14 --> Utf8 Class Initialized
INFO - 2025-05-03 11:49:14 --> URI Class Initialized
INFO - 2025-05-03 11:49:14 --> Router Class Initialized
INFO - 2025-05-03 11:49:14 --> Output Class Initialized
INFO - 2025-05-03 11:49:14 --> Security Class Initialized
DEBUG - 2025-05-03 11:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:49:14 --> Input Class Initialized
INFO - 2025-05-03 11:49:14 --> Language Class Initialized
INFO - 2025-05-03 11:49:14 --> Loader Class Initialized
INFO - 2025-05-03 11:49:14 --> Helper loaded: form_helper
INFO - 2025-05-03 11:49:14 --> Helper loaded: url_helper
INFO - 2025-05-03 11:49:14 --> Database Driver Class Initialized
INFO - 2025-05-03 11:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:49:14 --> Form Validation Class Initialized
INFO - 2025-05-03 11:49:14 --> Controller Class Initialized
DEBUG - 2025-05-03 11:49:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 11:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 11:49:14 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 11:49:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 11:49:14 --> Final output sent to browser
DEBUG - 2025-05-03 11:49:14 --> Total execution time: 0.0339
INFO - 2025-05-03 11:49:15 --> Config Class Initialized
INFO - 2025-05-03 11:49:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:49:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:49:15 --> Utf8 Class Initialized
INFO - 2025-05-03 11:49:15 --> URI Class Initialized
INFO - 2025-05-03 11:49:15 --> Router Class Initialized
INFO - 2025-05-03 11:49:15 --> Output Class Initialized
INFO - 2025-05-03 11:49:15 --> Security Class Initialized
DEBUG - 2025-05-03 11:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:49:15 --> Input Class Initialized
INFO - 2025-05-03 11:49:15 --> Language Class Initialized
ERROR - 2025-05-03 11:49:15 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 11:52:51 --> Config Class Initialized
INFO - 2025-05-03 11:52:51 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:52:51 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:52:51 --> Utf8 Class Initialized
INFO - 2025-05-03 11:52:51 --> URI Class Initialized
INFO - 2025-05-03 11:52:51 --> Router Class Initialized
INFO - 2025-05-03 11:52:51 --> Output Class Initialized
INFO - 2025-05-03 11:52:51 --> Security Class Initialized
DEBUG - 2025-05-03 11:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:52:51 --> Input Class Initialized
INFO - 2025-05-03 11:52:51 --> Language Class Initialized
INFO - 2025-05-03 11:52:51 --> Loader Class Initialized
INFO - 2025-05-03 11:52:51 --> Helper loaded: form_helper
INFO - 2025-05-03 11:52:51 --> Helper loaded: url_helper
INFO - 2025-05-03 11:52:51 --> Database Driver Class Initialized
INFO - 2025-05-03 11:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:52:51 --> Form Validation Class Initialized
INFO - 2025-05-03 11:52:51 --> Controller Class Initialized
INFO - 2025-05-03 11:52:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:52:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:52:51 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:52:51 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 11:52:51 --> Final output sent to browser
DEBUG - 2025-05-03 11:52:51 --> Total execution time: 0.0381
INFO - 2025-05-03 11:52:54 --> Config Class Initialized
INFO - 2025-05-03 11:52:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:52:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:52:54 --> Utf8 Class Initialized
INFO - 2025-05-03 11:52:54 --> URI Class Initialized
INFO - 2025-05-03 11:52:54 --> Router Class Initialized
INFO - 2025-05-03 11:52:54 --> Output Class Initialized
INFO - 2025-05-03 11:52:54 --> Security Class Initialized
DEBUG - 2025-05-03 11:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:52:54 --> Input Class Initialized
INFO - 2025-05-03 11:52:54 --> Language Class Initialized
INFO - 2025-05-03 11:52:54 --> Loader Class Initialized
INFO - 2025-05-03 11:52:54 --> Helper loaded: form_helper
INFO - 2025-05-03 11:52:54 --> Helper loaded: url_helper
INFO - 2025-05-03 11:52:54 --> Database Driver Class Initialized
INFO - 2025-05-03 11:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:52:54 --> Form Validation Class Initialized
INFO - 2025-05-03 11:52:54 --> Controller Class Initialized
INFO - 2025-05-03 11:52:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:52:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:52:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:52:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 11:52:54 --> Final output sent to browser
DEBUG - 2025-05-03 11:52:54 --> Total execution time: 0.0330
INFO - 2025-05-03 11:55:02 --> Config Class Initialized
INFO - 2025-05-03 11:55:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:55:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:55:02 --> Utf8 Class Initialized
INFO - 2025-05-03 11:55:02 --> URI Class Initialized
INFO - 2025-05-03 11:55:02 --> Router Class Initialized
INFO - 2025-05-03 11:55:02 --> Output Class Initialized
INFO - 2025-05-03 11:55:02 --> Security Class Initialized
DEBUG - 2025-05-03 11:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:55:02 --> Input Class Initialized
INFO - 2025-05-03 11:55:02 --> Language Class Initialized
INFO - 2025-05-03 11:55:02 --> Loader Class Initialized
INFO - 2025-05-03 11:55:02 --> Helper loaded: form_helper
INFO - 2025-05-03 11:55:02 --> Helper loaded: url_helper
INFO - 2025-05-03 11:55:02 --> Database Driver Class Initialized
INFO - 2025-05-03 11:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:55:02 --> Form Validation Class Initialized
INFO - 2025-05-03 11:55:02 --> Controller Class Initialized
INFO - 2025-05-03 11:55:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:55:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:55:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:55:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 11:55:02 --> Final output sent to browser
DEBUG - 2025-05-03 11:55:02 --> Total execution time: 0.0428
INFO - 2025-05-03 11:55:49 --> Config Class Initialized
INFO - 2025-05-03 11:55:49 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:55:49 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:55:49 --> Utf8 Class Initialized
INFO - 2025-05-03 11:55:49 --> URI Class Initialized
INFO - 2025-05-03 11:55:49 --> Router Class Initialized
INFO - 2025-05-03 11:55:49 --> Output Class Initialized
INFO - 2025-05-03 11:55:49 --> Security Class Initialized
DEBUG - 2025-05-03 11:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:55:49 --> Input Class Initialized
INFO - 2025-05-03 11:55:49 --> Language Class Initialized
INFO - 2025-05-03 11:55:49 --> Loader Class Initialized
INFO - 2025-05-03 11:55:49 --> Helper loaded: form_helper
INFO - 2025-05-03 11:55:49 --> Helper loaded: url_helper
INFO - 2025-05-03 11:55:49 --> Database Driver Class Initialized
INFO - 2025-05-03 11:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:55:49 --> Form Validation Class Initialized
INFO - 2025-05-03 11:55:49 --> Controller Class Initialized
INFO - 2025-05-03 11:55:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:55:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:55:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:55:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 11:55:49 --> Final output sent to browser
DEBUG - 2025-05-03 11:55:49 --> Total execution time: 0.0366
INFO - 2025-05-03 11:55:51 --> Config Class Initialized
INFO - 2025-05-03 11:55:51 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:55:51 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:55:51 --> Utf8 Class Initialized
INFO - 2025-05-03 11:55:51 --> URI Class Initialized
INFO - 2025-05-03 11:55:51 --> Router Class Initialized
INFO - 2025-05-03 11:55:51 --> Output Class Initialized
INFO - 2025-05-03 11:55:51 --> Security Class Initialized
DEBUG - 2025-05-03 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:55:51 --> Input Class Initialized
INFO - 2025-05-03 11:55:51 --> Language Class Initialized
INFO - 2025-05-03 11:55:51 --> Loader Class Initialized
INFO - 2025-05-03 11:55:51 --> Helper loaded: form_helper
INFO - 2025-05-03 11:55:51 --> Helper loaded: url_helper
INFO - 2025-05-03 11:55:51 --> Database Driver Class Initialized
INFO - 2025-05-03 11:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:55:51 --> Form Validation Class Initialized
INFO - 2025-05-03 11:55:51 --> Controller Class Initialized
INFO - 2025-05-03 11:55:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:55:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:55:51 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:55:51 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-03 11:55:51 --> Final output sent to browser
DEBUG - 2025-05-03 11:55:51 --> Total execution time: 0.0478
INFO - 2025-05-03 11:55:54 --> Config Class Initialized
INFO - 2025-05-03 11:55:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:55:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:55:54 --> Utf8 Class Initialized
INFO - 2025-05-03 11:55:54 --> URI Class Initialized
INFO - 2025-05-03 11:55:54 --> Router Class Initialized
INFO - 2025-05-03 11:55:54 --> Output Class Initialized
INFO - 2025-05-03 11:55:54 --> Security Class Initialized
DEBUG - 2025-05-03 11:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:55:54 --> Input Class Initialized
INFO - 2025-05-03 11:55:54 --> Language Class Initialized
INFO - 2025-05-03 11:55:54 --> Loader Class Initialized
INFO - 2025-05-03 11:55:54 --> Helper loaded: form_helper
INFO - 2025-05-03 11:55:54 --> Helper loaded: url_helper
INFO - 2025-05-03 11:55:54 --> Database Driver Class Initialized
INFO - 2025-05-03 11:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:55:54 --> Form Validation Class Initialized
INFO - 2025-05-03 11:55:54 --> Controller Class Initialized
INFO - 2025-05-03 11:55:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:55:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:55:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:55:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_rekomendasi.php
INFO - 2025-05-03 11:55:54 --> Final output sent to browser
DEBUG - 2025-05-03 11:55:54 --> Total execution time: 0.0343
INFO - 2025-05-03 11:55:56 --> Config Class Initialized
INFO - 2025-05-03 11:55:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:55:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:55:56 --> Utf8 Class Initialized
INFO - 2025-05-03 11:55:56 --> URI Class Initialized
INFO - 2025-05-03 11:55:56 --> Router Class Initialized
INFO - 2025-05-03 11:55:56 --> Output Class Initialized
INFO - 2025-05-03 11:55:56 --> Security Class Initialized
DEBUG - 2025-05-03 11:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:55:56 --> Input Class Initialized
INFO - 2025-05-03 11:55:56 --> Language Class Initialized
INFO - 2025-05-03 11:55:56 --> Loader Class Initialized
INFO - 2025-05-03 11:55:56 --> Helper loaded: form_helper
INFO - 2025-05-03 11:55:56 --> Helper loaded: url_helper
INFO - 2025-05-03 11:55:56 --> Database Driver Class Initialized
INFO - 2025-05-03 11:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:55:56 --> Form Validation Class Initialized
INFO - 2025-05-03 11:55:56 --> Controller Class Initialized
INFO - 2025-05-03 11:55:56 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:55:56 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:55:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:55:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_sekolah.php
INFO - 2025-05-03 11:55:56 --> Final output sent to browser
DEBUG - 2025-05-03 11:55:56 --> Total execution time: 0.0360
INFO - 2025-05-03 11:55:58 --> Config Class Initialized
INFO - 2025-05-03 11:55:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:55:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:55:58 --> Utf8 Class Initialized
INFO - 2025-05-03 11:55:58 --> URI Class Initialized
INFO - 2025-05-03 11:55:58 --> Router Class Initialized
INFO - 2025-05-03 11:55:58 --> Output Class Initialized
INFO - 2025-05-03 11:55:58 --> Security Class Initialized
DEBUG - 2025-05-03 11:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:55:58 --> Input Class Initialized
INFO - 2025-05-03 11:55:58 --> Language Class Initialized
INFO - 2025-05-03 11:55:58 --> Loader Class Initialized
INFO - 2025-05-03 11:55:58 --> Helper loaded: form_helper
INFO - 2025-05-03 11:55:58 --> Helper loaded: url_helper
INFO - 2025-05-03 11:55:58 --> Database Driver Class Initialized
INFO - 2025-05-03 11:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:55:58 --> Form Validation Class Initialized
INFO - 2025-05-03 11:55:58 --> Controller Class Initialized
INFO - 2025-05-03 11:55:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:55:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:55:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:55:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 11:55:58 --> Final output sent to browser
DEBUG - 2025-05-03 11:55:58 --> Total execution time: 0.0358
INFO - 2025-05-03 11:56:01 --> Config Class Initialized
INFO - 2025-05-03 11:56:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:56:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:56:01 --> Utf8 Class Initialized
INFO - 2025-05-03 11:56:01 --> URI Class Initialized
INFO - 2025-05-03 11:56:01 --> Router Class Initialized
INFO - 2025-05-03 11:56:01 --> Output Class Initialized
INFO - 2025-05-03 11:56:01 --> Security Class Initialized
DEBUG - 2025-05-03 11:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:56:01 --> Input Class Initialized
INFO - 2025-05-03 11:56:01 --> Language Class Initialized
INFO - 2025-05-03 11:56:01 --> Loader Class Initialized
INFO - 2025-05-03 11:56:01 --> Helper loaded: form_helper
INFO - 2025-05-03 11:56:01 --> Helper loaded: url_helper
INFO - 2025-05-03 11:56:01 --> Database Driver Class Initialized
INFO - 2025-05-03 11:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:56:01 --> Form Validation Class Initialized
INFO - 2025-05-03 11:56:01 --> Controller Class Initialized
INFO - 2025-05-03 11:56:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:56:01 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:56:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:56:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 11:56:01 --> Final output sent to browser
DEBUG - 2025-05-03 11:56:01 --> Total execution time: 0.0433
INFO - 2025-05-03 11:56:08 --> Config Class Initialized
INFO - 2025-05-03 11:56:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:56:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:56:08 --> Utf8 Class Initialized
INFO - 2025-05-03 11:56:08 --> URI Class Initialized
INFO - 2025-05-03 11:56:08 --> Router Class Initialized
INFO - 2025-05-03 11:56:08 --> Output Class Initialized
INFO - 2025-05-03 11:56:08 --> Security Class Initialized
DEBUG - 2025-05-03 11:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:56:08 --> Input Class Initialized
INFO - 2025-05-03 11:56:08 --> Language Class Initialized
INFO - 2025-05-03 11:56:08 --> Loader Class Initialized
INFO - 2025-05-03 11:56:08 --> Helper loaded: form_helper
INFO - 2025-05-03 11:56:08 --> Helper loaded: url_helper
INFO - 2025-05-03 11:56:08 --> Database Driver Class Initialized
INFO - 2025-05-03 11:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:56:08 --> Form Validation Class Initialized
INFO - 2025-05-03 11:56:08 --> Controller Class Initialized
INFO - 2025-05-03 11:56:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:56:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:56:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:56:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 11:56:08 --> Final output sent to browser
DEBUG - 2025-05-03 11:56:08 --> Total execution time: 0.0431
INFO - 2025-05-03 11:56:18 --> Config Class Initialized
INFO - 2025-05-03 11:56:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:56:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:56:18 --> Utf8 Class Initialized
INFO - 2025-05-03 11:56:18 --> URI Class Initialized
INFO - 2025-05-03 11:56:18 --> Router Class Initialized
INFO - 2025-05-03 11:56:18 --> Output Class Initialized
INFO - 2025-05-03 11:56:18 --> Security Class Initialized
DEBUG - 2025-05-03 11:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:56:18 --> Input Class Initialized
INFO - 2025-05-03 11:56:18 --> Language Class Initialized
INFO - 2025-05-03 11:56:18 --> Loader Class Initialized
INFO - 2025-05-03 11:56:18 --> Helper loaded: form_helper
INFO - 2025-05-03 11:56:18 --> Helper loaded: url_helper
INFO - 2025-05-03 11:56:18 --> Database Driver Class Initialized
INFO - 2025-05-03 11:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:56:18 --> Form Validation Class Initialized
INFO - 2025-05-03 11:56:18 --> Controller Class Initialized
INFO - 2025-05-03 11:56:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:56:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:56:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:56:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 11:56:18 --> Final output sent to browser
DEBUG - 2025-05-03 11:56:18 --> Total execution time: 0.0313
INFO - 2025-05-03 11:56:22 --> Config Class Initialized
INFO - 2025-05-03 11:56:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:56:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:56:22 --> Utf8 Class Initialized
INFO - 2025-05-03 11:56:22 --> URI Class Initialized
INFO - 2025-05-03 11:56:22 --> Router Class Initialized
INFO - 2025-05-03 11:56:22 --> Output Class Initialized
INFO - 2025-05-03 11:56:22 --> Security Class Initialized
DEBUG - 2025-05-03 11:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:56:22 --> Input Class Initialized
INFO - 2025-05-03 11:56:22 --> Language Class Initialized
INFO - 2025-05-03 11:56:22 --> Loader Class Initialized
INFO - 2025-05-03 11:56:22 --> Helper loaded: form_helper
INFO - 2025-05-03 11:56:22 --> Helper loaded: url_helper
INFO - 2025-05-03 11:56:22 --> Database Driver Class Initialized
INFO - 2025-05-03 11:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:56:22 --> Form Validation Class Initialized
INFO - 2025-05-03 11:56:22 --> Controller Class Initialized
INFO - 2025-05-03 11:56:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:56:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:56:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:56:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 11:56:22 --> Final output sent to browser
DEBUG - 2025-05-03 11:56:22 --> Total execution time: 0.0391
INFO - 2025-05-03 11:57:37 --> Config Class Initialized
INFO - 2025-05-03 11:57:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:57:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:57:37 --> Utf8 Class Initialized
INFO - 2025-05-03 11:57:37 --> URI Class Initialized
INFO - 2025-05-03 11:57:37 --> Router Class Initialized
INFO - 2025-05-03 11:57:37 --> Output Class Initialized
INFO - 2025-05-03 11:57:37 --> Security Class Initialized
DEBUG - 2025-05-03 11:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:57:37 --> Input Class Initialized
INFO - 2025-05-03 11:57:37 --> Language Class Initialized
INFO - 2025-05-03 11:57:37 --> Loader Class Initialized
INFO - 2025-05-03 11:57:37 --> Helper loaded: form_helper
INFO - 2025-05-03 11:57:37 --> Helper loaded: url_helper
INFO - 2025-05-03 11:57:37 --> Database Driver Class Initialized
INFO - 2025-05-03 11:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:57:37 --> Form Validation Class Initialized
INFO - 2025-05-03 11:57:37 --> Controller Class Initialized
DEBUG - 2025-05-03 11:57:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 11:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 11:57:37 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-03 11:57:37 --> POST data: Array
(
    [nama_siswa] => Brama Pasya Denta
    [jenis_kelamin] => L
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2010-01-14
    [tempat_tanggal_lahir] => Batang, 14 Januari 2010
    [rekomendasi] => Andhika 10.5/Rohmatul
    [pilihan_program] => MIPA
    [no_hp_siswa] => 085786024271
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Pungangan
    [rt] => 01
    [rw] => 01
    [desa] => Pungangan
    [kecamatan] => Limpung
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Pungangan, RT 01/RW 01, Pungangan, Limpung, Batang, Jawa Tengah
    [nama_ayah] => Nur Alimin
    [nama_ibu] => Tri Indarwati
    [pendidikan_ayah] => SLTP Sederajat
    [pendidikan_ibu] => SLTP Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => IRT
    [no_hp_ayah] => 0895371807811
    [no_hp_ibu] => 0
    [alamat_ortu] => Pungangan 1/1, Limpung, Batang
    [saudara_sekolah] => Tidak
    [nama_wali] => Nur Alimin
    [hubungan_wali] => Ayah kandung
    [pendidikan_wali] => SLTP Sederajat
    [pekerjaan_wali] => Wiraswasta
    [no_hp_wali] => 0895371807811
    [alamat_wali] => Pungangan 1/1, Limpung, Batang
    [nama_sekolah] => MTs Darussalam
    [nisn] => 0
    [alamat_sekolah] => Kemiri Barat, Subah, Batang
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan ke madrasah yang lebih dekat
    [tanggal_lahir_db] => 2010-01-14
)

INFO - 2025-05-03 11:57:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-03 11:57:37 --> Generated registration number: A-2526/0158
DEBUG - 2025-05-03 11:57:37 --> Form data to save: Array
(
    [nama_siswa] => Brama Pasya Denta
    [jenis_kelamin] => L
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2010-01-14
    [no_hp_siswa] => 085786024271
    [rekomendasi] => Andhika 10.5/Rohmatul
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Pungangan
    [rt] => 01
    [rw] => 01
    [desa] => Pungangan
    [kecamatan] => Limpung
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Nur Alimin
    [nama_ibu] => Tri Indarwati
    [pendidikan_ayah] => SLTP Sederajat
    [pendidikan_ibu] => SLTP Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => IRT
    [no_hp_ayah] => 0895371807811
    [no_hp_ibu] => 0
    [alamat_ortu] => Pungangan 1/1, Limpung, Batang
    [saudara_sekolah] => Tidak
    [nama_wali] => Nur Alimin
    [hubungan_wali] => Ayah kandung
    [pendidikan_wali] => SLTP Sederajat
    [pekerjaan_wali] => Wiraswasta
    [no_hp_wali] => 0895371807811
    [alamat_wali] => Pungangan 1/1, Limpung, Batang
    [nama_sekolah] => MTs Darussalam
    [nisn] => 0
    [alamat_sekolah] => Kemiri Barat, Subah, Batang
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan ke madrasah yang lebih dekat
    [tanggal_daftar] => 2025-05-03 11:57:37
    [status] => Baru
    [no_pendaftaran] => A-2526/0158
)

DEBUG - 2025-05-03 11:57:37 --> Attempting to save data to pendaftaran table
DEBUG - 2025-05-03 11:57:37 --> Data: Array
(
    [nama_siswa] => Brama Pasya Denta
    [jenis_kelamin] => L
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2010-01-14
    [no_hp_siswa] => 085786024271
    [rekomendasi] => Andhika 10.5/Rohmatul
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Pungangan
    [rt] => 01
    [rw] => 01
    [desa] => Pungangan
    [kecamatan] => Limpung
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Nur Alimin
    [nama_ibu] => Tri Indarwati
    [pendidikan_ayah] => SLTP Sederajat
    [pendidikan_ibu] => SLTP Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => IRT
    [no_hp_ayah] => 0895371807811
    [no_hp_ibu] => 0
    [alamat_ortu] => Pungangan 1/1, Limpung, Batang
    [saudara_sekolah] => Tidak
    [nama_wali] => Nur Alimin
    [hubungan_wali] => Ayah kandung
    [pendidikan_wali] => SLTP Sederajat
    [pekerjaan_wali] => Wiraswasta
    [no_hp_wali] => 0895371807811
    [alamat_wali] => Pungangan 1/1, Limpung, Batang
    [nama_sekolah] => MTs Darussalam
    [nisn] => 0
    [alamat_sekolah] => Kemiri Barat, Subah, Batang
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan ke madrasah yang lebih dekat
    [tanggal_daftar] => 2025-05-03 11:57:37
    [status] => Baru
    [no_pendaftaran] => A-2526/0158
)

DEBUG - 2025-05-03 11:57:37 --> Data inserted successfully with ID: 167
INFO - 2025-05-03 11:57:39 --> Config Class Initialized
INFO - 2025-05-03 11:57:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:57:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:57:39 --> Utf8 Class Initialized
INFO - 2025-05-03 11:57:39 --> URI Class Initialized
INFO - 2025-05-03 11:57:39 --> Router Class Initialized
INFO - 2025-05-03 11:57:39 --> Output Class Initialized
INFO - 2025-05-03 11:57:39 --> Security Class Initialized
DEBUG - 2025-05-03 11:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:57:39 --> Input Class Initialized
INFO - 2025-05-03 11:57:39 --> Language Class Initialized
INFO - 2025-05-03 11:57:39 --> Loader Class Initialized
INFO - 2025-05-03 11:57:39 --> Helper loaded: form_helper
INFO - 2025-05-03 11:57:39 --> Helper loaded: url_helper
INFO - 2025-05-03 11:57:39 --> Database Driver Class Initialized
INFO - 2025-05-03 11:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:57:39 --> Form Validation Class Initialized
INFO - 2025-05-03 11:57:39 --> Controller Class Initialized
DEBUG - 2025-05-03 11:57:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 11:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 11:57:39 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 11:57:39 --> Config Class Initialized
INFO - 2025-05-03 11:57:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:57:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:57:39 --> Utf8 Class Initialized
INFO - 2025-05-03 11:57:39 --> URI Class Initialized
INFO - 2025-05-03 11:57:39 --> Router Class Initialized
INFO - 2025-05-03 11:57:39 --> Output Class Initialized
INFO - 2025-05-03 11:57:39 --> Security Class Initialized
DEBUG - 2025-05-03 11:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:57:39 --> Input Class Initialized
INFO - 2025-05-03 11:57:39 --> Language Class Initialized
INFO - 2025-05-03 11:57:39 --> Loader Class Initialized
INFO - 2025-05-03 11:57:39 --> Helper loaded: form_helper
INFO - 2025-05-03 11:57:39 --> Helper loaded: url_helper
INFO - 2025-05-03 11:57:39 --> Database Driver Class Initialized
INFO - 2025-05-03 11:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:57:39 --> Form Validation Class Initialized
INFO - 2025-05-03 11:57:39 --> Controller Class Initialized
DEBUG - 2025-05-03 11:57:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 11:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 11:57:39 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 11:57:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 11:57:39 --> Final output sent to browser
DEBUG - 2025-05-03 11:57:39 --> Total execution time: 0.0354
INFO - 2025-05-03 11:57:46 --> Config Class Initialized
INFO - 2025-05-03 11:57:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:57:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:57:46 --> Utf8 Class Initialized
INFO - 2025-05-03 11:57:46 --> URI Class Initialized
INFO - 2025-05-03 11:57:46 --> Router Class Initialized
INFO - 2025-05-03 11:57:46 --> Output Class Initialized
INFO - 2025-05-03 11:57:46 --> Security Class Initialized
DEBUG - 2025-05-03 11:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:57:46 --> Input Class Initialized
INFO - 2025-05-03 11:57:46 --> Language Class Initialized
INFO - 2025-05-03 11:57:46 --> Loader Class Initialized
INFO - 2025-05-03 11:57:46 --> Helper loaded: form_helper
INFO - 2025-05-03 11:57:46 --> Helper loaded: url_helper
INFO - 2025-05-03 11:57:46 --> Database Driver Class Initialized
INFO - 2025-05-03 11:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:57:46 --> Form Validation Class Initialized
INFO - 2025-05-03 11:57:46 --> Controller Class Initialized
INFO - 2025-05-03 11:57:46 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:57:46 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:57:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:57:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 11:57:46 --> Final output sent to browser
DEBUG - 2025-05-03 11:57:46 --> Total execution time: 0.0430
INFO - 2025-05-03 11:58:08 --> Config Class Initialized
INFO - 2025-05-03 11:58:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:58:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:58:08 --> Utf8 Class Initialized
INFO - 2025-05-03 11:58:08 --> URI Class Initialized
INFO - 2025-05-03 11:58:08 --> Router Class Initialized
INFO - 2025-05-03 11:58:08 --> Output Class Initialized
INFO - 2025-05-03 11:58:08 --> Security Class Initialized
DEBUG - 2025-05-03 11:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:58:08 --> Input Class Initialized
INFO - 2025-05-03 11:58:08 --> Language Class Initialized
INFO - 2025-05-03 11:58:08 --> Loader Class Initialized
INFO - 2025-05-03 11:58:08 --> Helper loaded: form_helper
INFO - 2025-05-03 11:58:08 --> Helper loaded: url_helper
INFO - 2025-05-03 11:58:08 --> Database Driver Class Initialized
INFO - 2025-05-03 11:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:58:08 --> Form Validation Class Initialized
INFO - 2025-05-03 11:58:08 --> Controller Class Initialized
INFO - 2025-05-03 11:58:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:58:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:58:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:58:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 11:58:08 --> Final output sent to browser
DEBUG - 2025-05-03 11:58:08 --> Total execution time: 0.0312
INFO - 2025-05-03 11:58:09 --> Config Class Initialized
INFO - 2025-05-03 11:58:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:58:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:58:09 --> Utf8 Class Initialized
INFO - 2025-05-03 11:58:09 --> URI Class Initialized
INFO - 2025-05-03 11:58:09 --> Router Class Initialized
INFO - 2025-05-03 11:58:09 --> Output Class Initialized
INFO - 2025-05-03 11:58:09 --> Security Class Initialized
DEBUG - 2025-05-03 11:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:58:09 --> Input Class Initialized
INFO - 2025-05-03 11:58:09 --> Language Class Initialized
INFO - 2025-05-03 11:58:09 --> Loader Class Initialized
INFO - 2025-05-03 11:58:09 --> Helper loaded: form_helper
INFO - 2025-05-03 11:58:09 --> Helper loaded: url_helper
INFO - 2025-05-03 11:58:09 --> Database Driver Class Initialized
INFO - 2025-05-03 11:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:58:09 --> Form Validation Class Initialized
INFO - 2025-05-03 11:58:09 --> Controller Class Initialized
INFO - 2025-05-03 11:58:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:58:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:58:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:58:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 11:58:09 --> Final output sent to browser
DEBUG - 2025-05-03 11:58:09 --> Total execution time: 0.0355
INFO - 2025-05-03 11:58:14 --> Config Class Initialized
INFO - 2025-05-03 11:58:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:58:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:58:14 --> Utf8 Class Initialized
INFO - 2025-05-03 11:58:14 --> URI Class Initialized
INFO - 2025-05-03 11:58:14 --> Router Class Initialized
INFO - 2025-05-03 11:58:14 --> Output Class Initialized
INFO - 2025-05-03 11:58:14 --> Security Class Initialized
DEBUG - 2025-05-03 11:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:58:14 --> Input Class Initialized
INFO - 2025-05-03 11:58:14 --> Language Class Initialized
INFO - 2025-05-03 11:58:14 --> Loader Class Initialized
INFO - 2025-05-03 11:58:14 --> Helper loaded: form_helper
INFO - 2025-05-03 11:58:14 --> Helper loaded: url_helper
INFO - 2025-05-03 11:58:14 --> Database Driver Class Initialized
INFO - 2025-05-03 11:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:58:14 --> Form Validation Class Initialized
INFO - 2025-05-03 11:58:14 --> Controller Class Initialized
INFO - 2025-05-03 11:58:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:58:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:58:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-03 11:58:14 --> Final output sent to browser
DEBUG - 2025-05-03 11:58:14 --> Total execution time: 0.0325
INFO - 2025-05-03 11:59:10 --> Config Class Initialized
INFO - 2025-05-03 11:59:10 --> Hooks Class Initialized
DEBUG - 2025-05-03 11:59:10 --> UTF-8 Support Enabled
INFO - 2025-05-03 11:59:10 --> Utf8 Class Initialized
INFO - 2025-05-03 11:59:10 --> URI Class Initialized
INFO - 2025-05-03 11:59:10 --> Router Class Initialized
INFO - 2025-05-03 11:59:10 --> Output Class Initialized
INFO - 2025-05-03 11:59:10 --> Security Class Initialized
DEBUG - 2025-05-03 11:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 11:59:10 --> Input Class Initialized
INFO - 2025-05-03 11:59:10 --> Language Class Initialized
INFO - 2025-05-03 11:59:10 --> Loader Class Initialized
INFO - 2025-05-03 11:59:10 --> Helper loaded: form_helper
INFO - 2025-05-03 11:59:10 --> Helper loaded: url_helper
INFO - 2025-05-03 11:59:10 --> Database Driver Class Initialized
INFO - 2025-05-03 11:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 11:59:10 --> Form Validation Class Initialized
INFO - 2025-05-03 11:59:10 --> Controller Class Initialized
INFO - 2025-05-03 11:59:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 11:59:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 11:59:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 11:59:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 11:59:10 --> Final output sent to browser
DEBUG - 2025-05-03 11:59:10 --> Total execution time: 0.0416
INFO - 2025-05-03 12:01:33 --> Config Class Initialized
INFO - 2025-05-03 12:01:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:01:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:01:33 --> Utf8 Class Initialized
INFO - 2025-05-03 12:01:33 --> URI Class Initialized
INFO - 2025-05-03 12:01:33 --> Router Class Initialized
INFO - 2025-05-03 12:01:33 --> Output Class Initialized
INFO - 2025-05-03 12:01:33 --> Security Class Initialized
DEBUG - 2025-05-03 12:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:01:33 --> Input Class Initialized
INFO - 2025-05-03 12:01:33 --> Language Class Initialized
INFO - 2025-05-03 12:01:33 --> Loader Class Initialized
INFO - 2025-05-03 12:01:33 --> Helper loaded: form_helper
INFO - 2025-05-03 12:01:33 --> Helper loaded: url_helper
INFO - 2025-05-03 12:01:33 --> Database Driver Class Initialized
INFO - 2025-05-03 12:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:01:33 --> Form Validation Class Initialized
INFO - 2025-05-03 12:01:33 --> Controller Class Initialized
INFO - 2025-05-03 12:01:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:01:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:01:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:01:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 12:01:33 --> Final output sent to browser
DEBUG - 2025-05-03 12:01:33 --> Total execution time: 0.0428
INFO - 2025-05-03 12:05:09 --> Config Class Initialized
INFO - 2025-05-03 12:05:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:05:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:05:09 --> Utf8 Class Initialized
INFO - 2025-05-03 12:05:09 --> URI Class Initialized
INFO - 2025-05-03 12:05:09 --> Router Class Initialized
INFO - 2025-05-03 12:05:09 --> Output Class Initialized
INFO - 2025-05-03 12:05:09 --> Security Class Initialized
DEBUG - 2025-05-03 12:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:05:09 --> Input Class Initialized
INFO - 2025-05-03 12:05:09 --> Language Class Initialized
INFO - 2025-05-03 12:05:09 --> Loader Class Initialized
INFO - 2025-05-03 12:05:09 --> Helper loaded: form_helper
INFO - 2025-05-03 12:05:09 --> Helper loaded: url_helper
INFO - 2025-05-03 12:05:09 --> Database Driver Class Initialized
INFO - 2025-05-03 12:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:05:09 --> Form Validation Class Initialized
INFO - 2025-05-03 12:05:09 --> Controller Class Initialized
INFO - 2025-05-03 12:05:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:05:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:05:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-03 12:05:10 --> Config Class Initialized
INFO - 2025-05-03 12:05:10 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:05:10 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:05:10 --> Utf8 Class Initialized
INFO - 2025-05-03 12:05:10 --> URI Class Initialized
INFO - 2025-05-03 12:05:10 --> Router Class Initialized
INFO - 2025-05-03 12:05:10 --> Output Class Initialized
INFO - 2025-05-03 12:05:10 --> Security Class Initialized
DEBUG - 2025-05-03 12:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:05:10 --> Input Class Initialized
INFO - 2025-05-03 12:05:10 --> Language Class Initialized
INFO - 2025-05-03 12:05:10 --> Loader Class Initialized
INFO - 2025-05-03 12:05:10 --> Helper loaded: form_helper
INFO - 2025-05-03 12:05:10 --> Helper loaded: url_helper
INFO - 2025-05-03 12:05:10 --> Database Driver Class Initialized
INFO - 2025-05-03 12:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:05:10 --> Form Validation Class Initialized
INFO - 2025-05-03 12:05:10 --> Controller Class Initialized
INFO - 2025-05-03 12:05:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:05:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:05:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:05:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 12:05:10 --> Final output sent to browser
DEBUG - 2025-05-03 12:05:10 --> Total execution time: 0.0413
INFO - 2025-05-03 12:05:17 --> Config Class Initialized
INFO - 2025-05-03 12:05:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:05:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:05:17 --> Utf8 Class Initialized
INFO - 2025-05-03 12:05:17 --> URI Class Initialized
INFO - 2025-05-03 12:05:17 --> Router Class Initialized
INFO - 2025-05-03 12:05:17 --> Output Class Initialized
INFO - 2025-05-03 12:05:17 --> Security Class Initialized
DEBUG - 2025-05-03 12:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:05:17 --> Input Class Initialized
INFO - 2025-05-03 12:05:17 --> Language Class Initialized
INFO - 2025-05-03 12:05:17 --> Loader Class Initialized
INFO - 2025-05-03 12:05:17 --> Helper loaded: form_helper
INFO - 2025-05-03 12:05:17 --> Helper loaded: url_helper
INFO - 2025-05-03 12:05:17 --> Database Driver Class Initialized
INFO - 2025-05-03 12:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:05:17 --> Form Validation Class Initialized
INFO - 2025-05-03 12:05:17 --> Controller Class Initialized
INFO - 2025-05-03 12:05:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:05:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:05:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:05:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 12:05:17 --> Final output sent to browser
DEBUG - 2025-05-03 12:05:17 --> Total execution time: 0.0479
INFO - 2025-05-03 12:05:19 --> Config Class Initialized
INFO - 2025-05-03 12:05:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:05:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:05:19 --> Utf8 Class Initialized
INFO - 2025-05-03 12:05:19 --> URI Class Initialized
INFO - 2025-05-03 12:05:19 --> Router Class Initialized
INFO - 2025-05-03 12:05:19 --> Output Class Initialized
INFO - 2025-05-03 12:05:19 --> Security Class Initialized
DEBUG - 2025-05-03 12:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:05:19 --> Input Class Initialized
INFO - 2025-05-03 12:05:19 --> Language Class Initialized
INFO - 2025-05-03 12:05:19 --> Loader Class Initialized
INFO - 2025-05-03 12:05:19 --> Helper loaded: form_helper
INFO - 2025-05-03 12:05:19 --> Helper loaded: url_helper
INFO - 2025-05-03 12:05:19 --> Database Driver Class Initialized
INFO - 2025-05-03 12:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:05:19 --> Form Validation Class Initialized
INFO - 2025-05-03 12:05:19 --> Controller Class Initialized
INFO - 2025-05-03 12:05:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:05:19 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:05:19 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:05:19 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 12:05:19 --> Final output sent to browser
DEBUG - 2025-05-03 12:05:19 --> Total execution time: 0.0393
INFO - 2025-05-03 12:05:33 --> Config Class Initialized
INFO - 2025-05-03 12:05:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:05:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:05:33 --> Utf8 Class Initialized
INFO - 2025-05-03 12:05:33 --> URI Class Initialized
INFO - 2025-05-03 12:05:33 --> Router Class Initialized
INFO - 2025-05-03 12:05:33 --> Output Class Initialized
INFO - 2025-05-03 12:05:33 --> Security Class Initialized
DEBUG - 2025-05-03 12:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:05:33 --> Input Class Initialized
INFO - 2025-05-03 12:05:33 --> Language Class Initialized
INFO - 2025-05-03 12:05:33 --> Loader Class Initialized
INFO - 2025-05-03 12:05:33 --> Helper loaded: form_helper
INFO - 2025-05-03 12:05:33 --> Helper loaded: url_helper
INFO - 2025-05-03 12:05:33 --> Database Driver Class Initialized
INFO - 2025-05-03 12:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:05:33 --> Form Validation Class Initialized
INFO - 2025-05-03 12:05:33 --> Controller Class Initialized
INFO - 2025-05-03 12:05:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:05:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:05:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-03 12:05:33 --> Final output sent to browser
DEBUG - 2025-05-03 12:05:33 --> Total execution time: 0.0425
INFO - 2025-05-03 12:07:14 --> Config Class Initialized
INFO - 2025-05-03 12:07:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:07:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:07:14 --> Utf8 Class Initialized
INFO - 2025-05-03 12:07:14 --> URI Class Initialized
INFO - 2025-05-03 12:07:14 --> Router Class Initialized
INFO - 2025-05-03 12:07:14 --> Output Class Initialized
INFO - 2025-05-03 12:07:14 --> Security Class Initialized
DEBUG - 2025-05-03 12:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:07:14 --> Input Class Initialized
INFO - 2025-05-03 12:07:14 --> Language Class Initialized
INFO - 2025-05-03 12:07:14 --> Loader Class Initialized
INFO - 2025-05-03 12:07:14 --> Helper loaded: form_helper
INFO - 2025-05-03 12:07:14 --> Helper loaded: url_helper
INFO - 2025-05-03 12:07:14 --> Database Driver Class Initialized
INFO - 2025-05-03 12:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:07:14 --> Form Validation Class Initialized
INFO - 2025-05-03 12:07:14 --> Controller Class Initialized
INFO - 2025-05-03 12:07:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:07:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:07:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:07:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:07:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-03 12:07:14 --> Final output sent to browser
DEBUG - 2025-05-03 12:07:14 --> Total execution time: 0.0381
INFO - 2025-05-03 12:07:20 --> Config Class Initialized
INFO - 2025-05-03 12:07:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:07:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:07:20 --> Utf8 Class Initialized
INFO - 2025-05-03 12:07:20 --> URI Class Initialized
INFO - 2025-05-03 12:07:20 --> Router Class Initialized
INFO - 2025-05-03 12:07:20 --> Output Class Initialized
INFO - 2025-05-03 12:07:20 --> Security Class Initialized
DEBUG - 2025-05-03 12:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:07:20 --> Input Class Initialized
INFO - 2025-05-03 12:07:20 --> Language Class Initialized
INFO - 2025-05-03 12:07:20 --> Loader Class Initialized
INFO - 2025-05-03 12:07:20 --> Helper loaded: form_helper
INFO - 2025-05-03 12:07:20 --> Helper loaded: url_helper
INFO - 2025-05-03 12:07:20 --> Database Driver Class Initialized
INFO - 2025-05-03 12:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:07:20 --> Form Validation Class Initialized
INFO - 2025-05-03 12:07:20 --> Controller Class Initialized
INFO - 2025-05-03 12:07:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:07:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:07:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:07:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 12:07:20 --> Final output sent to browser
DEBUG - 2025-05-03 12:07:20 --> Total execution time: 0.0397
INFO - 2025-05-03 12:07:26 --> Config Class Initialized
INFO - 2025-05-03 12:07:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:07:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:07:26 --> Utf8 Class Initialized
INFO - 2025-05-03 12:07:26 --> URI Class Initialized
INFO - 2025-05-03 12:07:26 --> Router Class Initialized
INFO - 2025-05-03 12:07:26 --> Output Class Initialized
INFO - 2025-05-03 12:07:26 --> Security Class Initialized
DEBUG - 2025-05-03 12:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:07:26 --> Input Class Initialized
INFO - 2025-05-03 12:07:26 --> Language Class Initialized
INFO - 2025-05-03 12:07:26 --> Loader Class Initialized
INFO - 2025-05-03 12:07:26 --> Helper loaded: form_helper
INFO - 2025-05-03 12:07:26 --> Helper loaded: url_helper
INFO - 2025-05-03 12:07:26 --> Database Driver Class Initialized
INFO - 2025-05-03 12:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:07:26 --> Form Validation Class Initialized
INFO - 2025-05-03 12:07:26 --> Controller Class Initialized
INFO - 2025-05-03 12:07:26 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:07:26 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:07:26 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:07:26 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 12:07:26 --> Final output sent to browser
DEBUG - 2025-05-03 12:07:26 --> Total execution time: 0.0480
INFO - 2025-05-03 12:07:28 --> Config Class Initialized
INFO - 2025-05-03 12:07:28 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:07:28 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:07:28 --> Utf8 Class Initialized
INFO - 2025-05-03 12:07:28 --> URI Class Initialized
INFO - 2025-05-03 12:07:28 --> Router Class Initialized
INFO - 2025-05-03 12:07:28 --> Output Class Initialized
INFO - 2025-05-03 12:07:28 --> Security Class Initialized
DEBUG - 2025-05-03 12:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:07:28 --> Input Class Initialized
INFO - 2025-05-03 12:07:28 --> Language Class Initialized
INFO - 2025-05-03 12:07:28 --> Loader Class Initialized
INFO - 2025-05-03 12:07:28 --> Helper loaded: form_helper
INFO - 2025-05-03 12:07:28 --> Helper loaded: url_helper
INFO - 2025-05-03 12:07:28 --> Database Driver Class Initialized
INFO - 2025-05-03 12:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:07:28 --> Form Validation Class Initialized
INFO - 2025-05-03 12:07:28 --> Controller Class Initialized
INFO - 2025-05-03 12:07:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:07:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:07:28 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:07:28 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 12:07:28 --> Final output sent to browser
DEBUG - 2025-05-03 12:07:28 --> Total execution time: 0.0371
INFO - 2025-05-03 12:07:36 --> Config Class Initialized
INFO - 2025-05-03 12:07:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:07:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:07:36 --> Utf8 Class Initialized
INFO - 2025-05-03 12:07:36 --> URI Class Initialized
INFO - 2025-05-03 12:07:36 --> Router Class Initialized
INFO - 2025-05-03 12:07:36 --> Output Class Initialized
INFO - 2025-05-03 12:07:36 --> Security Class Initialized
DEBUG - 2025-05-03 12:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:07:36 --> Input Class Initialized
INFO - 2025-05-03 12:07:36 --> Language Class Initialized
INFO - 2025-05-03 12:07:36 --> Loader Class Initialized
INFO - 2025-05-03 12:07:36 --> Helper loaded: form_helper
INFO - 2025-05-03 12:07:36 --> Helper loaded: url_helper
INFO - 2025-05-03 12:07:36 --> Database Driver Class Initialized
INFO - 2025-05-03 12:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:07:36 --> Form Validation Class Initialized
INFO - 2025-05-03 12:07:36 --> Controller Class Initialized
INFO - 2025-05-03 12:07:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:07:36 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:07:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:07:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 12:07:36 --> Final output sent to browser
DEBUG - 2025-05-03 12:07:36 --> Total execution time: 0.0396
INFO - 2025-05-03 12:09:33 --> Config Class Initialized
INFO - 2025-05-03 12:09:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:09:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:09:33 --> Utf8 Class Initialized
INFO - 2025-05-03 12:09:33 --> URI Class Initialized
INFO - 2025-05-03 12:09:33 --> Router Class Initialized
INFO - 2025-05-03 12:09:33 --> Output Class Initialized
INFO - 2025-05-03 12:09:33 --> Security Class Initialized
DEBUG - 2025-05-03 12:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:09:33 --> Input Class Initialized
INFO - 2025-05-03 12:09:33 --> Language Class Initialized
INFO - 2025-05-03 12:09:33 --> Loader Class Initialized
INFO - 2025-05-03 12:09:33 --> Helper loaded: form_helper
INFO - 2025-05-03 12:09:33 --> Helper loaded: url_helper
INFO - 2025-05-03 12:09:33 --> Database Driver Class Initialized
INFO - 2025-05-03 12:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:09:33 --> Form Validation Class Initialized
INFO - 2025-05-03 12:09:33 --> Controller Class Initialized
INFO - 2025-05-03 12:09:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:09:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:09:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:09:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 12:09:33 --> Final output sent to browser
DEBUG - 2025-05-03 12:09:33 --> Total execution time: 0.0358
INFO - 2025-05-03 12:09:45 --> Config Class Initialized
INFO - 2025-05-03 12:09:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:09:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:09:45 --> Utf8 Class Initialized
INFO - 2025-05-03 12:09:45 --> URI Class Initialized
INFO - 2025-05-03 12:09:45 --> Router Class Initialized
INFO - 2025-05-03 12:09:45 --> Output Class Initialized
INFO - 2025-05-03 12:09:45 --> Security Class Initialized
DEBUG - 2025-05-03 12:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:09:45 --> Input Class Initialized
INFO - 2025-05-03 12:09:45 --> Language Class Initialized
INFO - 2025-05-03 12:09:45 --> Loader Class Initialized
INFO - 2025-05-03 12:09:45 --> Helper loaded: form_helper
INFO - 2025-05-03 12:09:45 --> Helper loaded: url_helper
INFO - 2025-05-03 12:09:45 --> Database Driver Class Initialized
INFO - 2025-05-03 12:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:09:45 --> Form Validation Class Initialized
INFO - 2025-05-03 12:09:45 --> Controller Class Initialized
INFO - 2025-05-03 12:09:45 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:09:45 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:09:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:09:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 12:09:45 --> Final output sent to browser
DEBUG - 2025-05-03 12:09:45 --> Total execution time: 0.0410
INFO - 2025-05-03 12:10:00 --> Config Class Initialized
INFO - 2025-05-03 12:10:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:10:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:10:00 --> Utf8 Class Initialized
INFO - 2025-05-03 12:10:00 --> URI Class Initialized
INFO - 2025-05-03 12:10:00 --> Router Class Initialized
INFO - 2025-05-03 12:10:00 --> Output Class Initialized
INFO - 2025-05-03 12:10:00 --> Security Class Initialized
DEBUG - 2025-05-03 12:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:10:00 --> Input Class Initialized
INFO - 2025-05-03 12:10:00 --> Language Class Initialized
INFO - 2025-05-03 12:10:00 --> Loader Class Initialized
INFO - 2025-05-03 12:10:00 --> Helper loaded: form_helper
INFO - 2025-05-03 12:10:00 --> Helper loaded: url_helper
INFO - 2025-05-03 12:10:00 --> Database Driver Class Initialized
INFO - 2025-05-03 12:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:10:00 --> Form Validation Class Initialized
INFO - 2025-05-03 12:10:00 --> Controller Class Initialized
INFO - 2025-05-03 12:10:00 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:10:00 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:10:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-03 12:10:00 --> Final output sent to browser
DEBUG - 2025-05-03 12:10:00 --> Total execution time: 0.0328
INFO - 2025-05-03 12:11:13 --> Config Class Initialized
INFO - 2025-05-03 12:11:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:11:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:11:13 --> Utf8 Class Initialized
INFO - 2025-05-03 12:11:13 --> URI Class Initialized
INFO - 2025-05-03 12:11:13 --> Router Class Initialized
INFO - 2025-05-03 12:11:13 --> Output Class Initialized
INFO - 2025-05-03 12:11:13 --> Security Class Initialized
DEBUG - 2025-05-03 12:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:11:13 --> Input Class Initialized
INFO - 2025-05-03 12:11:13 --> Language Class Initialized
INFO - 2025-05-03 12:11:13 --> Loader Class Initialized
INFO - 2025-05-03 12:11:13 --> Helper loaded: form_helper
INFO - 2025-05-03 12:11:13 --> Helper loaded: url_helper
INFO - 2025-05-03 12:11:13 --> Database Driver Class Initialized
INFO - 2025-05-03 12:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:11:13 --> Form Validation Class Initialized
INFO - 2025-05-03 12:11:13 --> Controller Class Initialized
INFO - 2025-05-03 12:11:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:11:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:11:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:11:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 12:11:13 --> Final output sent to browser
DEBUG - 2025-05-03 12:11:13 --> Total execution time: 0.0368
INFO - 2025-05-03 12:16:26 --> Config Class Initialized
INFO - 2025-05-03 12:16:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:16:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:16:26 --> Utf8 Class Initialized
INFO - 2025-05-03 12:16:26 --> URI Class Initialized
INFO - 2025-05-03 12:16:26 --> Router Class Initialized
INFO - 2025-05-03 12:16:26 --> Output Class Initialized
INFO - 2025-05-03 12:16:26 --> Security Class Initialized
DEBUG - 2025-05-03 12:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:16:26 --> Input Class Initialized
INFO - 2025-05-03 12:16:26 --> Language Class Initialized
INFO - 2025-05-03 12:16:26 --> Loader Class Initialized
INFO - 2025-05-03 12:16:26 --> Helper loaded: form_helper
INFO - 2025-05-03 12:16:26 --> Helper loaded: url_helper
INFO - 2025-05-03 12:16:26 --> Database Driver Class Initialized
INFO - 2025-05-03 12:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:16:26 --> Form Validation Class Initialized
INFO - 2025-05-03 12:16:26 --> Controller Class Initialized
INFO - 2025-05-03 12:16:26 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:16:26 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:16:26 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:16:26 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 12:16:26 --> Final output sent to browser
DEBUG - 2025-05-03 12:16:26 --> Total execution time: 0.0481
INFO - 2025-05-03 12:50:20 --> Config Class Initialized
INFO - 2025-05-03 12:50:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:50:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:50:20 --> Utf8 Class Initialized
INFO - 2025-05-03 12:50:20 --> URI Class Initialized
DEBUG - 2025-05-03 12:50:20 --> No URI present. Default controller set.
INFO - 2025-05-03 12:50:20 --> Router Class Initialized
INFO - 2025-05-03 12:50:20 --> Output Class Initialized
INFO - 2025-05-03 12:50:20 --> Security Class Initialized
DEBUG - 2025-05-03 12:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:50:20 --> Input Class Initialized
INFO - 2025-05-03 12:50:20 --> Language Class Initialized
INFO - 2025-05-03 12:50:20 --> Loader Class Initialized
INFO - 2025-05-03 12:50:20 --> Helper loaded: form_helper
INFO - 2025-05-03 12:50:20 --> Helper loaded: url_helper
INFO - 2025-05-03 12:50:20 --> Database Driver Class Initialized
INFO - 2025-05-03 12:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:50:20 --> Form Validation Class Initialized
INFO - 2025-05-03 12:50:20 --> Controller Class Initialized
INFO - 2025-05-03 12:50:20 --> Final output sent to browser
DEBUG - 2025-05-03 12:50:20 --> Total execution time: 0.0352
INFO - 2025-05-03 12:56:59 --> Config Class Initialized
INFO - 2025-05-03 12:56:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:56:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:56:59 --> Utf8 Class Initialized
INFO - 2025-05-03 12:56:59 --> URI Class Initialized
INFO - 2025-05-03 12:56:59 --> Router Class Initialized
INFO - 2025-05-03 12:56:59 --> Output Class Initialized
INFO - 2025-05-03 12:56:59 --> Security Class Initialized
DEBUG - 2025-05-03 12:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:56:59 --> Input Class Initialized
INFO - 2025-05-03 12:56:59 --> Language Class Initialized
INFO - 2025-05-03 12:56:59 --> Loader Class Initialized
INFO - 2025-05-03 12:56:59 --> Helper loaded: form_helper
INFO - 2025-05-03 12:56:59 --> Helper loaded: url_helper
INFO - 2025-05-03 12:56:59 --> Database Driver Class Initialized
INFO - 2025-05-03 12:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:56:59 --> Form Validation Class Initialized
INFO - 2025-05-03 12:56:59 --> Controller Class Initialized
INFO - 2025-05-03 12:56:59 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:56:59 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:56:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:56:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 12:56:59 --> Final output sent to browser
DEBUG - 2025-05-03 12:56:59 --> Total execution time: 0.0388
INFO - 2025-05-03 12:57:07 --> Config Class Initialized
INFO - 2025-05-03 12:57:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:57:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:57:07 --> Utf8 Class Initialized
INFO - 2025-05-03 12:57:07 --> URI Class Initialized
INFO - 2025-05-03 12:57:07 --> Router Class Initialized
INFO - 2025-05-03 12:57:07 --> Output Class Initialized
INFO - 2025-05-03 12:57:07 --> Security Class Initialized
DEBUG - 2025-05-03 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:57:07 --> Input Class Initialized
INFO - 2025-05-03 12:57:07 --> Language Class Initialized
INFO - 2025-05-03 12:57:07 --> Loader Class Initialized
INFO - 2025-05-03 12:57:07 --> Helper loaded: form_helper
INFO - 2025-05-03 12:57:07 --> Helper loaded: url_helper
INFO - 2025-05-03 12:57:07 --> Database Driver Class Initialized
INFO - 2025-05-03 12:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:57:07 --> Form Validation Class Initialized
INFO - 2025-05-03 12:57:07 --> Controller Class Initialized
INFO - 2025-05-03 12:57:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:57:07 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:57:07 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:57:07 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-03 12:57:07 --> Final output sent to browser
DEBUG - 2025-05-03 12:57:07 --> Total execution time: 0.0527
INFO - 2025-05-03 12:57:15 --> Config Class Initialized
INFO - 2025-05-03 12:57:15 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:57:15 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:57:15 --> Utf8 Class Initialized
INFO - 2025-05-03 12:57:15 --> URI Class Initialized
INFO - 2025-05-03 12:57:15 --> Router Class Initialized
INFO - 2025-05-03 12:57:15 --> Output Class Initialized
INFO - 2025-05-03 12:57:15 --> Security Class Initialized
DEBUG - 2025-05-03 12:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:57:15 --> Input Class Initialized
INFO - 2025-05-03 12:57:15 --> Language Class Initialized
INFO - 2025-05-03 12:57:15 --> Loader Class Initialized
INFO - 2025-05-03 12:57:15 --> Helper loaded: form_helper
INFO - 2025-05-03 12:57:15 --> Helper loaded: url_helper
INFO - 2025-05-03 12:57:15 --> Database Driver Class Initialized
INFO - 2025-05-03 12:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:57:15 --> Form Validation Class Initialized
INFO - 2025-05-03 12:57:15 --> Controller Class Initialized
INFO - 2025-05-03 12:57:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:57:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:57:15 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:57:15 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 12:57:15 --> Final output sent to browser
DEBUG - 2025-05-03 12:57:15 --> Total execution time: 0.0406
INFO - 2025-05-03 12:57:21 --> Config Class Initialized
INFO - 2025-05-03 12:57:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:57:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:57:21 --> Utf8 Class Initialized
INFO - 2025-05-03 12:57:21 --> URI Class Initialized
INFO - 2025-05-03 12:57:21 --> Router Class Initialized
INFO - 2025-05-03 12:57:21 --> Output Class Initialized
INFO - 2025-05-03 12:57:21 --> Security Class Initialized
DEBUG - 2025-05-03 12:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:57:21 --> Input Class Initialized
INFO - 2025-05-03 12:57:21 --> Language Class Initialized
INFO - 2025-05-03 12:57:21 --> Loader Class Initialized
INFO - 2025-05-03 12:57:21 --> Helper loaded: form_helper
INFO - 2025-05-03 12:57:21 --> Helper loaded: url_helper
INFO - 2025-05-03 12:57:21 --> Database Driver Class Initialized
INFO - 2025-05-03 12:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:57:21 --> Form Validation Class Initialized
INFO - 2025-05-03 12:57:21 --> Controller Class Initialized
INFO - 2025-05-03 12:57:21 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:57:21 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:57:21 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:57:21 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-03 12:57:21 --> Final output sent to browser
DEBUG - 2025-05-03 12:57:21 --> Total execution time: 0.0417
INFO - 2025-05-03 12:57:31 --> Config Class Initialized
INFO - 2025-05-03 12:57:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:57:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:57:31 --> Utf8 Class Initialized
INFO - 2025-05-03 12:57:31 --> URI Class Initialized
INFO - 2025-05-03 12:57:31 --> Router Class Initialized
INFO - 2025-05-03 12:57:31 --> Output Class Initialized
INFO - 2025-05-03 12:57:31 --> Security Class Initialized
DEBUG - 2025-05-03 12:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:57:31 --> Input Class Initialized
INFO - 2025-05-03 12:57:31 --> Language Class Initialized
INFO - 2025-05-03 12:57:31 --> Loader Class Initialized
INFO - 2025-05-03 12:57:31 --> Helper loaded: form_helper
INFO - 2025-05-03 12:57:31 --> Helper loaded: url_helper
INFO - 2025-05-03 12:57:31 --> Database Driver Class Initialized
INFO - 2025-05-03 12:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:57:31 --> Form Validation Class Initialized
INFO - 2025-05-03 12:57:31 --> Controller Class Initialized
INFO - 2025-05-03 12:57:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:57:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:57:31 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:57:31 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 12:57:31 --> Final output sent to browser
DEBUG - 2025-05-03 12:57:31 --> Total execution time: 0.0362
INFO - 2025-05-03 12:57:34 --> Config Class Initialized
INFO - 2025-05-03 12:57:34 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:57:34 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:57:34 --> Utf8 Class Initialized
INFO - 2025-05-03 12:57:34 --> URI Class Initialized
INFO - 2025-05-03 12:57:34 --> Router Class Initialized
INFO - 2025-05-03 12:57:34 --> Output Class Initialized
INFO - 2025-05-03 12:57:34 --> Security Class Initialized
DEBUG - 2025-05-03 12:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:57:34 --> Input Class Initialized
INFO - 2025-05-03 12:57:34 --> Language Class Initialized
INFO - 2025-05-03 12:57:34 --> Loader Class Initialized
INFO - 2025-05-03 12:57:34 --> Helper loaded: form_helper
INFO - 2025-05-03 12:57:34 --> Helper loaded: url_helper
INFO - 2025-05-03 12:57:34 --> Database Driver Class Initialized
INFO - 2025-05-03 12:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:57:34 --> Form Validation Class Initialized
INFO - 2025-05-03 12:57:34 --> Controller Class Initialized
INFO - 2025-05-03 12:57:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:57:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:57:34 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:57:34 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 12:57:34 --> Final output sent to browser
DEBUG - 2025-05-03 12:57:34 --> Total execution time: 0.0391
INFO - 2025-05-03 12:57:50 --> Config Class Initialized
INFO - 2025-05-03 12:57:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:57:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:57:50 --> Utf8 Class Initialized
INFO - 2025-05-03 12:57:50 --> URI Class Initialized
INFO - 2025-05-03 12:57:50 --> Router Class Initialized
INFO - 2025-05-03 12:57:50 --> Output Class Initialized
INFO - 2025-05-03 12:57:50 --> Security Class Initialized
DEBUG - 2025-05-03 12:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:57:50 --> Input Class Initialized
INFO - 2025-05-03 12:57:50 --> Language Class Initialized
INFO - 2025-05-03 12:57:50 --> Loader Class Initialized
INFO - 2025-05-03 12:57:50 --> Helper loaded: form_helper
INFO - 2025-05-03 12:57:50 --> Helper loaded: url_helper
INFO - 2025-05-03 12:57:50 --> Database Driver Class Initialized
INFO - 2025-05-03 12:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:57:50 --> Form Validation Class Initialized
INFO - 2025-05-03 12:57:50 --> Controller Class Initialized
INFO - 2025-05-03 12:57:50 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:57:50 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:57:50 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:57:50 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 12:57:50 --> Final output sent to browser
DEBUG - 2025-05-03 12:57:50 --> Total execution time: 0.0415
INFO - 2025-05-03 12:57:52 --> Config Class Initialized
INFO - 2025-05-03 12:57:52 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:57:52 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:57:52 --> Utf8 Class Initialized
INFO - 2025-05-03 12:57:52 --> URI Class Initialized
INFO - 2025-05-03 12:57:52 --> Router Class Initialized
INFO - 2025-05-03 12:57:52 --> Output Class Initialized
INFO - 2025-05-03 12:57:52 --> Security Class Initialized
DEBUG - 2025-05-03 12:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:57:52 --> Input Class Initialized
INFO - 2025-05-03 12:57:52 --> Language Class Initialized
INFO - 2025-05-03 12:57:52 --> Loader Class Initialized
INFO - 2025-05-03 12:57:52 --> Helper loaded: form_helper
INFO - 2025-05-03 12:57:52 --> Helper loaded: url_helper
INFO - 2025-05-03 12:57:52 --> Database Driver Class Initialized
INFO - 2025-05-03 12:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:57:52 --> Form Validation Class Initialized
INFO - 2025-05-03 12:57:52 --> Controller Class Initialized
INFO - 2025-05-03 12:57:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:57:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:57:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:57:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-03 12:57:52 --> Final output sent to browser
DEBUG - 2025-05-03 12:57:52 --> Total execution time: 0.0401
INFO - 2025-05-03 12:57:54 --> Config Class Initialized
INFO - 2025-05-03 12:57:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 12:57:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 12:57:54 --> Utf8 Class Initialized
INFO - 2025-05-03 12:57:54 --> URI Class Initialized
INFO - 2025-05-03 12:57:54 --> Router Class Initialized
INFO - 2025-05-03 12:57:54 --> Output Class Initialized
INFO - 2025-05-03 12:57:54 --> Security Class Initialized
DEBUG - 2025-05-03 12:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 12:57:54 --> Input Class Initialized
INFO - 2025-05-03 12:57:54 --> Language Class Initialized
INFO - 2025-05-03 12:57:54 --> Loader Class Initialized
INFO - 2025-05-03 12:57:54 --> Helper loaded: form_helper
INFO - 2025-05-03 12:57:54 --> Helper loaded: url_helper
INFO - 2025-05-03 12:57:54 --> Database Driver Class Initialized
INFO - 2025-05-03 12:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 12:57:54 --> Form Validation Class Initialized
INFO - 2025-05-03 12:57:54 --> Controller Class Initialized
INFO - 2025-05-03 12:57:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 12:57:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 12:57:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 12:57:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-03 12:57:54 --> Final output sent to browser
DEBUG - 2025-05-03 12:57:54 --> Total execution time: 0.0387
INFO - 2025-05-03 13:01:46 --> Config Class Initialized
INFO - 2025-05-03 13:01:46 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:01:46 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:01:46 --> Utf8 Class Initialized
INFO - 2025-05-03 13:01:46 --> URI Class Initialized
INFO - 2025-05-03 13:01:46 --> Router Class Initialized
INFO - 2025-05-03 13:01:46 --> Output Class Initialized
INFO - 2025-05-03 13:01:46 --> Security Class Initialized
DEBUG - 2025-05-03 13:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:01:46 --> Input Class Initialized
INFO - 2025-05-03 13:01:46 --> Language Class Initialized
INFO - 2025-05-03 13:01:46 --> Loader Class Initialized
INFO - 2025-05-03 13:01:46 --> Helper loaded: form_helper
INFO - 2025-05-03 13:01:46 --> Helper loaded: url_helper
INFO - 2025-05-03 13:01:46 --> Database Driver Class Initialized
INFO - 2025-05-03 13:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:01:46 --> Form Validation Class Initialized
INFO - 2025-05-03 13:01:46 --> Controller Class Initialized
INFO - 2025-05-03 13:01:46 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:01:46 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:01:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:01:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 13:01:46 --> Final output sent to browser
DEBUG - 2025-05-03 13:01:46 --> Total execution time: 0.0468
INFO - 2025-05-03 13:12:25 --> Config Class Initialized
INFO - 2025-05-03 13:12:25 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:12:25 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:12:25 --> Utf8 Class Initialized
INFO - 2025-05-03 13:12:25 --> URI Class Initialized
INFO - 2025-05-03 13:12:25 --> Router Class Initialized
INFO - 2025-05-03 13:12:25 --> Output Class Initialized
INFO - 2025-05-03 13:12:25 --> Security Class Initialized
DEBUG - 2025-05-03 13:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:12:25 --> Input Class Initialized
INFO - 2025-05-03 13:12:25 --> Language Class Initialized
INFO - 2025-05-03 13:12:25 --> Loader Class Initialized
INFO - 2025-05-03 13:12:25 --> Helper loaded: form_helper
INFO - 2025-05-03 13:12:25 --> Helper loaded: url_helper
INFO - 2025-05-03 13:12:25 --> Database Driver Class Initialized
INFO - 2025-05-03 13:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:12:25 --> Form Validation Class Initialized
INFO - 2025-05-03 13:12:25 --> Controller Class Initialized
INFO - 2025-05-03 13:12:25 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:12:25 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:12:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:12:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 13:12:25 --> Final output sent to browser
DEBUG - 2025-05-03 13:12:25 --> Total execution time: 0.0478
INFO - 2025-05-03 13:12:27 --> Config Class Initialized
INFO - 2025-05-03 13:12:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:12:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:12:27 --> Utf8 Class Initialized
INFO - 2025-05-03 13:12:27 --> URI Class Initialized
INFO - 2025-05-03 13:12:27 --> Router Class Initialized
INFO - 2025-05-03 13:12:27 --> Output Class Initialized
INFO - 2025-05-03 13:12:27 --> Security Class Initialized
DEBUG - 2025-05-03 13:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:12:27 --> Input Class Initialized
INFO - 2025-05-03 13:12:27 --> Language Class Initialized
INFO - 2025-05-03 13:12:27 --> Loader Class Initialized
INFO - 2025-05-03 13:12:27 --> Helper loaded: form_helper
INFO - 2025-05-03 13:12:27 --> Helper loaded: url_helper
INFO - 2025-05-03 13:12:27 --> Database Driver Class Initialized
INFO - 2025-05-03 13:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:12:27 --> Form Validation Class Initialized
INFO - 2025-05-03 13:12:27 --> Controller Class Initialized
INFO - 2025-05-03 13:12:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:12:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:12:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-03 13:12:27 --> Final output sent to browser
DEBUG - 2025-05-03 13:12:27 --> Total execution time: 0.0392
INFO - 2025-05-03 13:24:17 --> Config Class Initialized
INFO - 2025-05-03 13:24:17 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:24:17 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:24:17 --> Utf8 Class Initialized
INFO - 2025-05-03 13:24:17 --> URI Class Initialized
INFO - 2025-05-03 13:24:17 --> Router Class Initialized
INFO - 2025-05-03 13:24:17 --> Output Class Initialized
INFO - 2025-05-03 13:24:17 --> Security Class Initialized
DEBUG - 2025-05-03 13:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:24:17 --> Input Class Initialized
INFO - 2025-05-03 13:24:17 --> Language Class Initialized
INFO - 2025-05-03 13:24:17 --> Loader Class Initialized
INFO - 2025-05-03 13:24:17 --> Helper loaded: form_helper
INFO - 2025-05-03 13:24:17 --> Helper loaded: url_helper
INFO - 2025-05-03 13:24:17 --> Database Driver Class Initialized
INFO - 2025-05-03 13:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:24:17 --> Form Validation Class Initialized
INFO - 2025-05-03 13:24:17 --> Controller Class Initialized
DEBUG - 2025-05-03 13:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 13:24:17 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 13:24:17 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 13:24:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 13:24:17 --> Final output sent to browser
DEBUG - 2025-05-03 13:24:17 --> Total execution time: 0.0384
INFO - 2025-05-03 13:25:13 --> Config Class Initialized
INFO - 2025-05-03 13:25:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:25:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:25:13 --> Utf8 Class Initialized
INFO - 2025-05-03 13:25:13 --> URI Class Initialized
DEBUG - 2025-05-03 13:25:13 --> No URI present. Default controller set.
INFO - 2025-05-03 13:25:13 --> Router Class Initialized
INFO - 2025-05-03 13:25:13 --> Output Class Initialized
INFO - 2025-05-03 13:25:13 --> Security Class Initialized
DEBUG - 2025-05-03 13:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:25:13 --> Input Class Initialized
INFO - 2025-05-03 13:25:13 --> Language Class Initialized
INFO - 2025-05-03 13:25:13 --> Loader Class Initialized
INFO - 2025-05-03 13:25:13 --> Helper loaded: form_helper
INFO - 2025-05-03 13:25:13 --> Helper loaded: url_helper
INFO - 2025-05-03 13:25:13 --> Database Driver Class Initialized
INFO - 2025-05-03 13:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:25:13 --> Form Validation Class Initialized
INFO - 2025-05-03 13:25:13 --> Controller Class Initialized
INFO - 2025-05-03 13:25:13 --> Final output sent to browser
DEBUG - 2025-05-03 13:25:13 --> Total execution time: 0.0309
INFO - 2025-05-03 13:25:20 --> Config Class Initialized
INFO - 2025-05-03 13:25:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:25:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:25:20 --> Utf8 Class Initialized
INFO - 2025-05-03 13:25:20 --> URI Class Initialized
INFO - 2025-05-03 13:25:20 --> Router Class Initialized
INFO - 2025-05-03 13:25:20 --> Output Class Initialized
INFO - 2025-05-03 13:25:20 --> Security Class Initialized
DEBUG - 2025-05-03 13:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:25:20 --> Input Class Initialized
INFO - 2025-05-03 13:25:20 --> Language Class Initialized
INFO - 2025-05-03 13:25:20 --> Loader Class Initialized
INFO - 2025-05-03 13:25:20 --> Helper loaded: form_helper
INFO - 2025-05-03 13:25:20 --> Helper loaded: url_helper
INFO - 2025-05-03 13:25:20 --> Database Driver Class Initialized
INFO - 2025-05-03 13:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:25:20 --> Form Validation Class Initialized
INFO - 2025-05-03 13:25:20 --> Controller Class Initialized
DEBUG - 2025-05-03 13:25:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 13:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 13:25:20 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 13:25:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 13:25:20 --> Final output sent to browser
DEBUG - 2025-05-03 13:25:20 --> Total execution time: 0.0309
INFO - 2025-05-03 13:25:20 --> Config Class Initialized
INFO - 2025-05-03 13:25:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:25:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:25:20 --> Utf8 Class Initialized
INFO - 2025-05-03 13:25:20 --> URI Class Initialized
DEBUG - 2025-05-03 13:25:20 --> No URI present. Default controller set.
INFO - 2025-05-03 13:25:20 --> Router Class Initialized
INFO - 2025-05-03 13:25:20 --> Output Class Initialized
INFO - 2025-05-03 13:25:20 --> Security Class Initialized
DEBUG - 2025-05-03 13:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:25:20 --> Input Class Initialized
INFO - 2025-05-03 13:25:20 --> Language Class Initialized
INFO - 2025-05-03 13:25:20 --> Loader Class Initialized
INFO - 2025-05-03 13:25:20 --> Helper loaded: form_helper
INFO - 2025-05-03 13:25:20 --> Helper loaded: url_helper
INFO - 2025-05-03 13:25:20 --> Database Driver Class Initialized
INFO - 2025-05-03 13:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:25:20 --> Form Validation Class Initialized
INFO - 2025-05-03 13:25:20 --> Controller Class Initialized
INFO - 2025-05-03 13:25:20 --> Final output sent to browser
DEBUG - 2025-05-03 13:25:20 --> Total execution time: 0.0310
INFO - 2025-05-03 13:25:21 --> Config Class Initialized
INFO - 2025-05-03 13:25:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:25:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:25:21 --> Utf8 Class Initialized
INFO - 2025-05-03 13:25:21 --> URI Class Initialized
DEBUG - 2025-05-03 13:25:21 --> No URI present. Default controller set.
INFO - 2025-05-03 13:25:21 --> Router Class Initialized
INFO - 2025-05-03 13:25:21 --> Output Class Initialized
INFO - 2025-05-03 13:25:21 --> Security Class Initialized
DEBUG - 2025-05-03 13:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:25:21 --> Input Class Initialized
INFO - 2025-05-03 13:25:21 --> Language Class Initialized
INFO - 2025-05-03 13:25:21 --> Loader Class Initialized
INFO - 2025-05-03 13:25:21 --> Helper loaded: form_helper
INFO - 2025-05-03 13:25:21 --> Helper loaded: url_helper
INFO - 2025-05-03 13:25:21 --> Database Driver Class Initialized
INFO - 2025-05-03 13:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:25:21 --> Form Validation Class Initialized
INFO - 2025-05-03 13:25:21 --> Controller Class Initialized
INFO - 2025-05-03 13:25:21 --> Final output sent to browser
DEBUG - 2025-05-03 13:25:21 --> Total execution time: 0.0315
INFO - 2025-05-03 13:25:21 --> Config Class Initialized
INFO - 2025-05-03 13:25:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:25:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:25:21 --> Utf8 Class Initialized
INFO - 2025-05-03 13:25:21 --> URI Class Initialized
INFO - 2025-05-03 13:25:21 --> Router Class Initialized
INFO - 2025-05-03 13:25:21 --> Output Class Initialized
INFO - 2025-05-03 13:25:21 --> Security Class Initialized
DEBUG - 2025-05-03 13:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:25:21 --> Input Class Initialized
INFO - 2025-05-03 13:25:21 --> Language Class Initialized
ERROR - 2025-05-03 13:25:21 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 13:32:52 --> Config Class Initialized
INFO - 2025-05-03 13:32:52 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:32:52 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:32:52 --> Utf8 Class Initialized
INFO - 2025-05-03 13:32:52 --> URI Class Initialized
DEBUG - 2025-05-03 13:32:52 --> No URI present. Default controller set.
INFO - 2025-05-03 13:32:52 --> Router Class Initialized
INFO - 2025-05-03 13:32:52 --> Output Class Initialized
INFO - 2025-05-03 13:32:52 --> Security Class Initialized
DEBUG - 2025-05-03 13:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:32:52 --> Input Class Initialized
INFO - 2025-05-03 13:32:52 --> Language Class Initialized
INFO - 2025-05-03 13:32:52 --> Loader Class Initialized
INFO - 2025-05-03 13:32:52 --> Helper loaded: form_helper
INFO - 2025-05-03 13:32:52 --> Helper loaded: url_helper
INFO - 2025-05-03 13:32:52 --> Database Driver Class Initialized
INFO - 2025-05-03 13:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:32:52 --> Form Validation Class Initialized
INFO - 2025-05-03 13:32:52 --> Controller Class Initialized
INFO - 2025-05-03 13:32:52 --> Final output sent to browser
DEBUG - 2025-05-03 13:32:52 --> Total execution time: 0.0342
INFO - 2025-05-03 13:32:57 --> Config Class Initialized
INFO - 2025-05-03 13:32:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:32:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:32:57 --> Utf8 Class Initialized
INFO - 2025-05-03 13:32:57 --> URI Class Initialized
INFO - 2025-05-03 13:32:57 --> Router Class Initialized
INFO - 2025-05-03 13:32:57 --> Output Class Initialized
INFO - 2025-05-03 13:32:57 --> Security Class Initialized
DEBUG - 2025-05-03 13:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:32:57 --> Input Class Initialized
INFO - 2025-05-03 13:32:57 --> Language Class Initialized
INFO - 2025-05-03 13:32:57 --> Loader Class Initialized
INFO - 2025-05-03 13:32:57 --> Helper loaded: form_helper
INFO - 2025-05-03 13:32:57 --> Helper loaded: url_helper
INFO - 2025-05-03 13:32:57 --> Database Driver Class Initialized
INFO - 2025-05-03 13:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:32:57 --> Form Validation Class Initialized
INFO - 2025-05-03 13:32:57 --> Controller Class Initialized
DEBUG - 2025-05-03 13:32:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 13:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 13:32:57 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 13:32:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 13:32:57 --> Final output sent to browser
DEBUG - 2025-05-03 13:32:57 --> Total execution time: 0.0338
INFO - 2025-05-03 13:33:02 --> Config Class Initialized
INFO - 2025-05-03 13:33:02 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:33:02 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:33:02 --> Utf8 Class Initialized
INFO - 2025-05-03 13:33:02 --> URI Class Initialized
INFO - 2025-05-03 13:33:02 --> Router Class Initialized
INFO - 2025-05-03 13:33:02 --> Output Class Initialized
INFO - 2025-05-03 13:33:02 --> Security Class Initialized
DEBUG - 2025-05-03 13:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:33:02 --> Input Class Initialized
INFO - 2025-05-03 13:33:02 --> Language Class Initialized
INFO - 2025-05-03 13:33:02 --> Loader Class Initialized
INFO - 2025-05-03 13:33:02 --> Helper loaded: form_helper
INFO - 2025-05-03 13:33:02 --> Helper loaded: url_helper
INFO - 2025-05-03 13:33:02 --> Database Driver Class Initialized
INFO - 2025-05-03 13:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:33:02 --> Form Validation Class Initialized
INFO - 2025-05-03 13:33:02 --> Controller Class Initialized
INFO - 2025-05-03 13:33:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:33:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:33:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:33:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 13:33:02 --> Final output sent to browser
DEBUG - 2025-05-03 13:33:02 --> Total execution time: 0.0394
INFO - 2025-05-03 13:33:11 --> Config Class Initialized
INFO - 2025-05-03 13:33:11 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:33:11 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:33:11 --> Utf8 Class Initialized
INFO - 2025-05-03 13:33:11 --> URI Class Initialized
INFO - 2025-05-03 13:33:11 --> Router Class Initialized
INFO - 2025-05-03 13:33:11 --> Output Class Initialized
INFO - 2025-05-03 13:33:11 --> Security Class Initialized
DEBUG - 2025-05-03 13:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:33:11 --> Input Class Initialized
INFO - 2025-05-03 13:33:11 --> Language Class Initialized
INFO - 2025-05-03 13:33:11 --> Loader Class Initialized
INFO - 2025-05-03 13:33:11 --> Helper loaded: form_helper
INFO - 2025-05-03 13:33:11 --> Helper loaded: url_helper
INFO - 2025-05-03 13:33:11 --> Database Driver Class Initialized
INFO - 2025-05-03 13:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:33:11 --> Form Validation Class Initialized
INFO - 2025-05-03 13:33:11 --> Controller Class Initialized
INFO - 2025-05-03 13:33:11 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:33:11 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:33:11 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:33:11 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 13:33:11 --> Final output sent to browser
DEBUG - 2025-05-03 13:33:11 --> Total execution time: 0.0368
INFO - 2025-05-03 13:37:26 --> Config Class Initialized
INFO - 2025-05-03 13:37:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:37:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:37:26 --> Utf8 Class Initialized
INFO - 2025-05-03 13:37:26 --> URI Class Initialized
INFO - 2025-05-03 13:37:26 --> Router Class Initialized
INFO - 2025-05-03 13:37:26 --> Output Class Initialized
INFO - 2025-05-03 13:37:26 --> Security Class Initialized
DEBUG - 2025-05-03 13:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:37:26 --> Input Class Initialized
INFO - 2025-05-03 13:37:26 --> Language Class Initialized
INFO - 2025-05-03 13:37:26 --> Loader Class Initialized
INFO - 2025-05-03 13:37:26 --> Helper loaded: form_helper
INFO - 2025-05-03 13:37:26 --> Helper loaded: url_helper
INFO - 2025-05-03 13:37:26 --> Database Driver Class Initialized
INFO - 2025-05-03 13:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:37:26 --> Form Validation Class Initialized
INFO - 2025-05-03 13:37:26 --> Controller Class Initialized
DEBUG - 2025-05-03 13:37:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 13:37:26 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 13:37:26 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-03 13:37:26 --> POST data: Array
(
    [nama_siswa] => NIA UMAMI AZKIA
    [jenis_kelamin] => P
    [tempat_lahir] => PEMALANG
    [tanggal_lahir] => 2010-07-11
    [tempat_tanggal_lahir] => PEMALANG, 11 Juli 2010
    [rekomendasi] => MASFUFI
    [pilihan_program] => AGM
    [no_hp_siswa] => 0858702554965
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => TAMBELANG
    [rt] => 012
    [rw] => 004
    [desa] => TLAGASANA
    [kecamatan] => WATUKUMPUL
    [kabupaten] => PEMALANG
    [provinsi] => JAWA TENGAH
    [alamat_lengkap] => TAMBELANG, RT 012/RW 004, TLAGASANA, WATUKUMPUL, PEMALANG, JAWA TENGAH
    [nama_ayah] => HAMAM NASIRUDIN
    [nama_ibu] => MASLAHATUN NISA
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => KARYAWAN SWASTA
    [pekerjaan_ibu] => IBU RUMAH TANGGA
    [no_hp_ayah] => 0
    [no_hp_ibu] => 0858702554965
    [alamat_ortu] => DK. TEMBELANG, DS. TLAGASANA, KEC.WATUKUMPUL, PEMALANG, JAWA TENGAH
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MTS SYARIF HIDAYATULLAH
    [nisn] => 
    [alamat_sekolah] => Wonopringgo, Kab. Pekalongan
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => melanjutkan pendidikan
    [tanggal_lahir_db] => 2010-07-11
)

INFO - 2025-05-03 13:37:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-03 13:37:26 --> Generated registration number: A-2526/0159
DEBUG - 2025-05-03 13:37:26 --> Form data to save: Array
(
    [nama_siswa] => NIA UMAMI AZKIA
    [jenis_kelamin] => P
    [tempat_lahir] => PEMALANG
    [tanggal_lahir] => 2010-07-11
    [no_hp_siswa] => 0858702554965
    [rekomendasi] => MASFUFI
    [pilihan_program] => AGM
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => TAMBELANG
    [rt] => 012
    [rw] => 004
    [desa] => TLAGASANA
    [kecamatan] => WATUKUMPUL
    [kabupaten] => PEMALANG
    [provinsi] => JAWA TENGAH
    [nama_ayah] => HAMAM NASIRUDIN
    [nama_ibu] => MASLAHATUN NISA
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => KARYAWAN SWASTA
    [pekerjaan_ibu] => IBU RUMAH TANGGA
    [no_hp_ayah] => 0
    [no_hp_ibu] => 0858702554965
    [alamat_ortu] => DK. TEMBELANG, DS. TLAGASANA, KEC.WATUKUMPUL, PEMALANG, JAWA TENGAH
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MTS SYARIF HIDAYATULLAH
    [nisn] => 
    [alamat_sekolah] => Wonopringgo, Kab. Pekalongan
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => melanjutkan pendidikan
    [tanggal_daftar] => 2025-05-03 13:37:26
    [status] => Baru
    [no_pendaftaran] => A-2526/0159
)

DEBUG - 2025-05-03 13:37:26 --> Attempting to save data to pendaftaran table
DEBUG - 2025-05-03 13:37:26 --> Data: Array
(
    [nama_siswa] => NIA UMAMI AZKIA
    [jenis_kelamin] => P
    [tempat_lahir] => PEMALANG
    [tanggal_lahir] => 2010-07-11
    [no_hp_siswa] => 0858702554965
    [rekomendasi] => MASFUFI
    [pilihan_program] => AGM
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => TAMBELANG
    [rt] => 012
    [rw] => 004
    [desa] => TLAGASANA
    [kecamatan] => WATUKUMPUL
    [kabupaten] => PEMALANG
    [provinsi] => JAWA TENGAH
    [nama_ayah] => HAMAM NASIRUDIN
    [nama_ibu] => MASLAHATUN NISA
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => KARYAWAN SWASTA
    [pekerjaan_ibu] => IBU RUMAH TANGGA
    [no_hp_ayah] => 0
    [no_hp_ibu] => 0858702554965
    [alamat_ortu] => DK. TEMBELANG, DS. TLAGASANA, KEC.WATUKUMPUL, PEMALANG, JAWA TENGAH
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MTS SYARIF HIDAYATULLAH
    [nisn] => 
    [alamat_sekolah] => Wonopringgo, Kab. Pekalongan
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => melanjutkan pendidikan
    [tanggal_daftar] => 2025-05-03 13:37:26
    [status] => Baru
    [no_pendaftaran] => A-2526/0159
)

DEBUG - 2025-05-03 13:37:26 --> Data inserted successfully with ID: 168
INFO - 2025-05-03 13:37:29 --> Config Class Initialized
INFO - 2025-05-03 13:37:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:37:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:37:29 --> Utf8 Class Initialized
INFO - 2025-05-03 13:37:29 --> URI Class Initialized
INFO - 2025-05-03 13:37:29 --> Router Class Initialized
INFO - 2025-05-03 13:37:29 --> Output Class Initialized
INFO - 2025-05-03 13:37:29 --> Security Class Initialized
DEBUG - 2025-05-03 13:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:37:29 --> Input Class Initialized
INFO - 2025-05-03 13:37:29 --> Language Class Initialized
INFO - 2025-05-03 13:37:29 --> Loader Class Initialized
INFO - 2025-05-03 13:37:29 --> Helper loaded: form_helper
INFO - 2025-05-03 13:37:29 --> Helper loaded: url_helper
INFO - 2025-05-03 13:37:29 --> Database Driver Class Initialized
INFO - 2025-05-03 13:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:37:29 --> Form Validation Class Initialized
INFO - 2025-05-03 13:37:29 --> Controller Class Initialized
DEBUG - 2025-05-03 13:37:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 13:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 13:37:29 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 13:37:29 --> Config Class Initialized
INFO - 2025-05-03 13:37:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:37:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:37:29 --> Utf8 Class Initialized
INFO - 2025-05-03 13:37:29 --> URI Class Initialized
INFO - 2025-05-03 13:37:29 --> Router Class Initialized
INFO - 2025-05-03 13:37:29 --> Output Class Initialized
INFO - 2025-05-03 13:37:29 --> Security Class Initialized
DEBUG - 2025-05-03 13:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:37:29 --> Input Class Initialized
INFO - 2025-05-03 13:37:29 --> Language Class Initialized
INFO - 2025-05-03 13:37:29 --> Loader Class Initialized
INFO - 2025-05-03 13:37:29 --> Helper loaded: form_helper
INFO - 2025-05-03 13:37:29 --> Helper loaded: url_helper
INFO - 2025-05-03 13:37:29 --> Database Driver Class Initialized
INFO - 2025-05-03 13:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:37:29 --> Form Validation Class Initialized
INFO - 2025-05-03 13:37:29 --> Controller Class Initialized
DEBUG - 2025-05-03 13:37:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 13:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 13:37:29 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 13:37:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 13:37:29 --> Final output sent to browser
DEBUG - 2025-05-03 13:37:29 --> Total execution time: 0.0294
INFO - 2025-05-03 13:37:36 --> Config Class Initialized
INFO - 2025-05-03 13:37:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:37:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:37:36 --> Utf8 Class Initialized
INFO - 2025-05-03 13:37:36 --> URI Class Initialized
INFO - 2025-05-03 13:37:36 --> Router Class Initialized
INFO - 2025-05-03 13:37:36 --> Output Class Initialized
INFO - 2025-05-03 13:37:36 --> Security Class Initialized
DEBUG - 2025-05-03 13:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:37:36 --> Input Class Initialized
INFO - 2025-05-03 13:37:36 --> Language Class Initialized
INFO - 2025-05-03 13:37:36 --> Loader Class Initialized
INFO - 2025-05-03 13:37:36 --> Helper loaded: form_helper
INFO - 2025-05-03 13:37:36 --> Helper loaded: url_helper
INFO - 2025-05-03 13:37:36 --> Database Driver Class Initialized
INFO - 2025-05-03 13:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:37:36 --> Form Validation Class Initialized
INFO - 2025-05-03 13:37:36 --> Controller Class Initialized
INFO - 2025-05-03 13:37:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:37:36 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:37:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:37:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 13:37:36 --> Final output sent to browser
DEBUG - 2025-05-03 13:37:36 --> Total execution time: 0.0447
INFO - 2025-05-03 13:37:42 --> Config Class Initialized
INFO - 2025-05-03 13:37:42 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:37:42 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:37:42 --> Utf8 Class Initialized
INFO - 2025-05-03 13:37:42 --> URI Class Initialized
INFO - 2025-05-03 13:37:42 --> Router Class Initialized
INFO - 2025-05-03 13:37:42 --> Output Class Initialized
INFO - 2025-05-03 13:37:42 --> Security Class Initialized
DEBUG - 2025-05-03 13:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:37:42 --> Input Class Initialized
INFO - 2025-05-03 13:37:42 --> Language Class Initialized
INFO - 2025-05-03 13:37:42 --> Loader Class Initialized
INFO - 2025-05-03 13:37:42 --> Helper loaded: form_helper
INFO - 2025-05-03 13:37:42 --> Helper loaded: url_helper
INFO - 2025-05-03 13:37:42 --> Database Driver Class Initialized
INFO - 2025-05-03 13:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:37:42 --> Form Validation Class Initialized
INFO - 2025-05-03 13:37:42 --> Controller Class Initialized
INFO - 2025-05-03 13:37:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:37:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:37:42 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-03 13:37:42 --> Final output sent to browser
DEBUG - 2025-05-03 13:37:42 --> Total execution time: 0.0351
INFO - 2025-05-03 13:38:47 --> Config Class Initialized
INFO - 2025-05-03 13:38:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:38:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:38:47 --> Utf8 Class Initialized
INFO - 2025-05-03 13:38:47 --> URI Class Initialized
INFO - 2025-05-03 13:38:47 --> Router Class Initialized
INFO - 2025-05-03 13:38:47 --> Output Class Initialized
INFO - 2025-05-03 13:38:47 --> Security Class Initialized
DEBUG - 2025-05-03 13:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:38:47 --> Input Class Initialized
INFO - 2025-05-03 13:38:47 --> Language Class Initialized
INFO - 2025-05-03 13:38:47 --> Loader Class Initialized
INFO - 2025-05-03 13:38:47 --> Helper loaded: form_helper
INFO - 2025-05-03 13:38:47 --> Helper loaded: url_helper
INFO - 2025-05-03 13:38:47 --> Database Driver Class Initialized
INFO - 2025-05-03 13:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:38:47 --> Form Validation Class Initialized
INFO - 2025-05-03 13:38:47 --> Controller Class Initialized
INFO - 2025-05-03 13:38:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:38:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:38:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:38:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 13:38:47 --> Final output sent to browser
DEBUG - 2025-05-03 13:38:47 --> Total execution time: 0.0330
INFO - 2025-05-03 13:38:47 --> Config Class Initialized
INFO - 2025-05-03 13:38:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:38:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:38:47 --> Utf8 Class Initialized
INFO - 2025-05-03 13:38:47 --> URI Class Initialized
INFO - 2025-05-03 13:38:47 --> Router Class Initialized
INFO - 2025-05-03 13:38:47 --> Output Class Initialized
INFO - 2025-05-03 13:38:47 --> Security Class Initialized
DEBUG - 2025-05-03 13:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:38:47 --> Input Class Initialized
INFO - 2025-05-03 13:38:47 --> Language Class Initialized
INFO - 2025-05-03 13:38:47 --> Loader Class Initialized
INFO - 2025-05-03 13:38:47 --> Helper loaded: form_helper
INFO - 2025-05-03 13:38:47 --> Helper loaded: url_helper
INFO - 2025-05-03 13:38:47 --> Database Driver Class Initialized
INFO - 2025-05-03 13:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:38:47 --> Form Validation Class Initialized
INFO - 2025-05-03 13:38:47 --> Controller Class Initialized
INFO - 2025-05-03 13:38:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:38:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:38:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:38:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 13:38:47 --> Final output sent to browser
DEBUG - 2025-05-03 13:38:47 --> Total execution time: 0.0343
INFO - 2025-05-03 13:38:59 --> Config Class Initialized
INFO - 2025-05-03 13:38:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:38:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:38:59 --> Utf8 Class Initialized
INFO - 2025-05-03 13:38:59 --> URI Class Initialized
INFO - 2025-05-03 13:38:59 --> Router Class Initialized
INFO - 2025-05-03 13:39:00 --> Output Class Initialized
INFO - 2025-05-03 13:39:00 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:00 --> Input Class Initialized
INFO - 2025-05-03 13:39:00 --> Language Class Initialized
INFO - 2025-05-03 13:39:00 --> Loader Class Initialized
INFO - 2025-05-03 13:39:00 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:00 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:00 --> Database Driver Class Initialized
INFO - 2025-05-03 13:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:00 --> Form Validation Class Initialized
INFO - 2025-05-03 13:39:00 --> Controller Class Initialized
INFO - 2025-05-03 13:39:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 13:39:00 --> Final output sent to browser
DEBUG - 2025-05-03 13:39:00 --> Total execution time: 0.0329
INFO - 2025-05-03 13:39:00 --> Config Class Initialized
INFO - 2025-05-03 13:39:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:00 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:00 --> URI Class Initialized
INFO - 2025-05-03 13:39:00 --> Router Class Initialized
INFO - 2025-05-03 13:39:00 --> Output Class Initialized
INFO - 2025-05-03 13:39:00 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:00 --> Input Class Initialized
INFO - 2025-05-03 13:39:00 --> Language Class Initialized
ERROR - 2025-05-03 13:39:00 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 13:39:06 --> Config Class Initialized
INFO - 2025-05-03 13:39:06 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:06 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:06 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:06 --> URI Class Initialized
INFO - 2025-05-03 13:39:06 --> Router Class Initialized
INFO - 2025-05-03 13:39:06 --> Output Class Initialized
INFO - 2025-05-03 13:39:06 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:06 --> Input Class Initialized
INFO - 2025-05-03 13:39:06 --> Language Class Initialized
INFO - 2025-05-03 13:39:06 --> Loader Class Initialized
INFO - 2025-05-03 13:39:06 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:06 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:06 --> Database Driver Class Initialized
INFO - 2025-05-03 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:06 --> Form Validation Class Initialized
INFO - 2025-05-03 13:39:06 --> Controller Class Initialized
INFO - 2025-05-03 13:39:07 --> Config Class Initialized
INFO - 2025-05-03 13:39:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:07 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:07 --> URI Class Initialized
INFO - 2025-05-03 13:39:07 --> Router Class Initialized
INFO - 2025-05-03 13:39:07 --> Output Class Initialized
INFO - 2025-05-03 13:39:07 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:07 --> Input Class Initialized
INFO - 2025-05-03 13:39:07 --> Language Class Initialized
INFO - 2025-05-03 13:39:07 --> Loader Class Initialized
INFO - 2025-05-03 13:39:07 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:07 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:07 --> Database Driver Class Initialized
INFO - 2025-05-03 13:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:07 --> Form Validation Class Initialized
INFO - 2025-05-03 13:39:07 --> Controller Class Initialized
INFO - 2025-05-03 13:39:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:39:07 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:39:07 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:39:07 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 13:39:07 --> Final output sent to browser
DEBUG - 2025-05-03 13:39:07 --> Total execution time: 0.0384
INFO - 2025-05-03 13:39:14 --> Config Class Initialized
INFO - 2025-05-03 13:39:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:14 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:14 --> URI Class Initialized
INFO - 2025-05-03 13:39:14 --> Router Class Initialized
INFO - 2025-05-03 13:39:14 --> Output Class Initialized
INFO - 2025-05-03 13:39:14 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:14 --> Input Class Initialized
INFO - 2025-05-03 13:39:14 --> Language Class Initialized
INFO - 2025-05-03 13:39:14 --> Loader Class Initialized
INFO - 2025-05-03 13:39:14 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:14 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:14 --> Database Driver Class Initialized
INFO - 2025-05-03 13:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:14 --> Form Validation Class Initialized
INFO - 2025-05-03 13:39:14 --> Controller Class Initialized
INFO - 2025-05-03 13:39:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:39:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:39:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:39:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 13:39:14 --> Final output sent to browser
DEBUG - 2025-05-03 13:39:14 --> Total execution time: 0.0421
INFO - 2025-05-03 13:39:23 --> Config Class Initialized
INFO - 2025-05-03 13:39:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:39:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:39:23 --> Utf8 Class Initialized
INFO - 2025-05-03 13:39:23 --> URI Class Initialized
INFO - 2025-05-03 13:39:23 --> Router Class Initialized
INFO - 2025-05-03 13:39:23 --> Output Class Initialized
INFO - 2025-05-03 13:39:23 --> Security Class Initialized
DEBUG - 2025-05-03 13:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:39:23 --> Input Class Initialized
INFO - 2025-05-03 13:39:23 --> Language Class Initialized
INFO - 2025-05-03 13:39:23 --> Loader Class Initialized
INFO - 2025-05-03 13:39:23 --> Helper loaded: form_helper
INFO - 2025-05-03 13:39:23 --> Helper loaded: url_helper
INFO - 2025-05-03 13:39:23 --> Database Driver Class Initialized
INFO - 2025-05-03 13:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:39:23 --> Form Validation Class Initialized
INFO - 2025-05-03 13:39:23 --> Controller Class Initialized
INFO - 2025-05-03 13:39:23 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:39:23 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:39:23 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-03 13:39:23 --> Final output sent to browser
DEBUG - 2025-05-03 13:39:23 --> Total execution time: 0.0348
INFO - 2025-05-03 13:41:09 --> Config Class Initialized
INFO - 2025-05-03 13:41:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:09 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:09 --> URI Class Initialized
INFO - 2025-05-03 13:41:09 --> Router Class Initialized
INFO - 2025-05-03 13:41:09 --> Output Class Initialized
INFO - 2025-05-03 13:41:09 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:09 --> Input Class Initialized
INFO - 2025-05-03 13:41:09 --> Language Class Initialized
INFO - 2025-05-03 13:41:09 --> Loader Class Initialized
INFO - 2025-05-03 13:41:09 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:09 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:10 --> Database Driver Class Initialized
INFO - 2025-05-03 13:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:10 --> Form Validation Class Initialized
INFO - 2025-05-03 13:41:10 --> Controller Class Initialized
INFO - 2025-05-03 13:41:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:41:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:41:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:41:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 13:41:10 --> Final output sent to browser
DEBUG - 2025-05-03 13:41:10 --> Total execution time: 0.0357
INFO - 2025-05-03 13:41:54 --> Config Class Initialized
INFO - 2025-05-03 13:41:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:54 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:54 --> URI Class Initialized
INFO - 2025-05-03 13:41:54 --> Router Class Initialized
INFO - 2025-05-03 13:41:54 --> Output Class Initialized
INFO - 2025-05-03 13:41:54 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:54 --> Input Class Initialized
INFO - 2025-05-03 13:41:54 --> Language Class Initialized
INFO - 2025-05-03 13:41:54 --> Loader Class Initialized
INFO - 2025-05-03 13:41:54 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:54 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:54 --> Database Driver Class Initialized
INFO - 2025-05-03 13:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:54 --> Form Validation Class Initialized
INFO - 2025-05-03 13:41:54 --> Controller Class Initialized
INFO - 2025-05-03 13:41:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:41:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:41:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-03 13:41:54 --> Config Class Initialized
INFO - 2025-05-03 13:41:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:41:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:41:54 --> Utf8 Class Initialized
INFO - 2025-05-03 13:41:54 --> URI Class Initialized
INFO - 2025-05-03 13:41:54 --> Router Class Initialized
INFO - 2025-05-03 13:41:54 --> Output Class Initialized
INFO - 2025-05-03 13:41:54 --> Security Class Initialized
DEBUG - 2025-05-03 13:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:41:54 --> Input Class Initialized
INFO - 2025-05-03 13:41:54 --> Language Class Initialized
INFO - 2025-05-03 13:41:54 --> Loader Class Initialized
INFO - 2025-05-03 13:41:54 --> Helper loaded: form_helper
INFO - 2025-05-03 13:41:54 --> Helper loaded: url_helper
INFO - 2025-05-03 13:41:54 --> Database Driver Class Initialized
INFO - 2025-05-03 13:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:41:54 --> Form Validation Class Initialized
INFO - 2025-05-03 13:41:54 --> Controller Class Initialized
INFO - 2025-05-03 13:41:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:41:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:41:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:41:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 13:41:54 --> Final output sent to browser
DEBUG - 2025-05-03 13:41:54 --> Total execution time: 0.0384
INFO - 2025-05-03 13:42:01 --> Config Class Initialized
INFO - 2025-05-03 13:42:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:42:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:42:01 --> Utf8 Class Initialized
INFO - 2025-05-03 13:42:01 --> URI Class Initialized
INFO - 2025-05-03 13:42:01 --> Router Class Initialized
INFO - 2025-05-03 13:42:01 --> Output Class Initialized
INFO - 2025-05-03 13:42:01 --> Security Class Initialized
DEBUG - 2025-05-03 13:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:42:01 --> Input Class Initialized
INFO - 2025-05-03 13:42:01 --> Language Class Initialized
INFO - 2025-05-03 13:42:01 --> Loader Class Initialized
INFO - 2025-05-03 13:42:01 --> Helper loaded: form_helper
INFO - 2025-05-03 13:42:01 --> Helper loaded: url_helper
INFO - 2025-05-03 13:42:01 --> Database Driver Class Initialized
INFO - 2025-05-03 13:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:42:01 --> Form Validation Class Initialized
INFO - 2025-05-03 13:42:01 --> Controller Class Initialized
INFO - 2025-05-03 13:42:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:42:01 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:42:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 13:42:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 13:42:01 --> Final output sent to browser
DEBUG - 2025-05-03 13:42:01 --> Total execution time: 0.0451
INFO - 2025-05-03 13:42:04 --> Config Class Initialized
INFO - 2025-05-03 13:42:04 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:42:04 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:42:04 --> Utf8 Class Initialized
INFO - 2025-05-03 13:42:04 --> URI Class Initialized
INFO - 2025-05-03 13:42:04 --> Router Class Initialized
INFO - 2025-05-03 13:42:04 --> Output Class Initialized
INFO - 2025-05-03 13:42:04 --> Security Class Initialized
DEBUG - 2025-05-03 13:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:42:04 --> Input Class Initialized
INFO - 2025-05-03 13:42:04 --> Language Class Initialized
INFO - 2025-05-03 13:42:04 --> Loader Class Initialized
INFO - 2025-05-03 13:42:04 --> Helper loaded: form_helper
INFO - 2025-05-03 13:42:04 --> Helper loaded: url_helper
INFO - 2025-05-03 13:42:04 --> Database Driver Class Initialized
INFO - 2025-05-03 13:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:42:04 --> Form Validation Class Initialized
INFO - 2025-05-03 13:42:04 --> Controller Class Initialized
INFO - 2025-05-03 13:42:04 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 13:42:04 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 13:42:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-03 13:42:04 --> Final output sent to browser
DEBUG - 2025-05-03 13:42:04 --> Total execution time: 0.0347
INFO - 2025-05-03 13:49:45 --> Config Class Initialized
INFO - 2025-05-03 13:49:45 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:49:45 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:49:45 --> Utf8 Class Initialized
INFO - 2025-05-03 13:49:45 --> URI Class Initialized
DEBUG - 2025-05-03 13:49:45 --> No URI present. Default controller set.
INFO - 2025-05-03 13:49:45 --> Router Class Initialized
INFO - 2025-05-03 13:49:45 --> Output Class Initialized
INFO - 2025-05-03 13:49:45 --> Security Class Initialized
DEBUG - 2025-05-03 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:49:45 --> Input Class Initialized
INFO - 2025-05-03 13:49:45 --> Language Class Initialized
INFO - 2025-05-03 13:49:45 --> Loader Class Initialized
INFO - 2025-05-03 13:49:45 --> Helper loaded: form_helper
INFO - 2025-05-03 13:49:45 --> Helper loaded: url_helper
INFO - 2025-05-03 13:49:45 --> Database Driver Class Initialized
INFO - 2025-05-03 13:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:49:45 --> Form Validation Class Initialized
INFO - 2025-05-03 13:49:45 --> Controller Class Initialized
INFO - 2025-05-03 13:49:45 --> Final output sent to browser
DEBUG - 2025-05-03 13:49:45 --> Total execution time: 0.0273
INFO - 2025-05-03 13:52:31 --> Config Class Initialized
INFO - 2025-05-03 13:52:31 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:52:31 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:52:31 --> Utf8 Class Initialized
INFO - 2025-05-03 13:52:31 --> URI Class Initialized
INFO - 2025-05-03 13:52:31 --> Router Class Initialized
INFO - 2025-05-03 13:52:31 --> Output Class Initialized
INFO - 2025-05-03 13:52:31 --> Security Class Initialized
DEBUG - 2025-05-03 13:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:52:31 --> Input Class Initialized
INFO - 2025-05-03 13:52:31 --> Language Class Initialized
INFO - 2025-05-03 13:52:31 --> Loader Class Initialized
INFO - 2025-05-03 13:52:31 --> Helper loaded: form_helper
INFO - 2025-05-03 13:52:31 --> Helper loaded: url_helper
INFO - 2025-05-03 13:52:31 --> Database Driver Class Initialized
INFO - 2025-05-03 13:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:52:31 --> Form Validation Class Initialized
INFO - 2025-05-03 13:52:31 --> Controller Class Initialized
INFO - 2025-05-03 13:52:31 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 13:52:31 --> Final output sent to browser
DEBUG - 2025-05-03 13:52:31 --> Total execution time: 0.0311
INFO - 2025-05-03 13:52:32 --> Config Class Initialized
INFO - 2025-05-03 13:52:32 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:52:32 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:52:32 --> Utf8 Class Initialized
INFO - 2025-05-03 13:52:32 --> URI Class Initialized
INFO - 2025-05-03 13:52:32 --> Router Class Initialized
INFO - 2025-05-03 13:52:32 --> Output Class Initialized
INFO - 2025-05-03 13:52:32 --> Security Class Initialized
DEBUG - 2025-05-03 13:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:52:32 --> Input Class Initialized
INFO - 2025-05-03 13:52:32 --> Language Class Initialized
ERROR - 2025-05-03 13:52:32 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 13:56:00 --> Config Class Initialized
INFO - 2025-05-03 13:56:00 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:56:00 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:56:00 --> Utf8 Class Initialized
INFO - 2025-05-03 13:56:00 --> URI Class Initialized
DEBUG - 2025-05-03 13:56:00 --> No URI present. Default controller set.
INFO - 2025-05-03 13:56:00 --> Router Class Initialized
INFO - 2025-05-03 13:56:00 --> Output Class Initialized
INFO - 2025-05-03 13:56:00 --> Security Class Initialized
DEBUG - 2025-05-03 13:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:56:00 --> Input Class Initialized
INFO - 2025-05-03 13:56:00 --> Language Class Initialized
INFO - 2025-05-03 13:56:00 --> Loader Class Initialized
INFO - 2025-05-03 13:56:00 --> Helper loaded: form_helper
INFO - 2025-05-03 13:56:00 --> Helper loaded: url_helper
INFO - 2025-05-03 13:56:00 --> Database Driver Class Initialized
INFO - 2025-05-03 13:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:56:00 --> Form Validation Class Initialized
INFO - 2025-05-03 13:56:00 --> Controller Class Initialized
INFO - 2025-05-03 13:56:00 --> Final output sent to browser
DEBUG - 2025-05-03 13:56:00 --> Total execution time: 0.0360
INFO - 2025-05-03 13:56:26 --> Config Class Initialized
INFO - 2025-05-03 13:56:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:56:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:56:26 --> Utf8 Class Initialized
INFO - 2025-05-03 13:56:26 --> URI Class Initialized
INFO - 2025-05-03 13:56:26 --> Router Class Initialized
INFO - 2025-05-03 13:56:26 --> Output Class Initialized
INFO - 2025-05-03 13:56:26 --> Security Class Initialized
DEBUG - 2025-05-03 13:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:56:26 --> Input Class Initialized
INFO - 2025-05-03 13:56:26 --> Language Class Initialized
INFO - 2025-05-03 13:56:26 --> Loader Class Initialized
INFO - 2025-05-03 13:56:26 --> Helper loaded: form_helper
INFO - 2025-05-03 13:56:26 --> Helper loaded: url_helper
INFO - 2025-05-03 13:56:26 --> Database Driver Class Initialized
INFO - 2025-05-03 13:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:56:26 --> Form Validation Class Initialized
INFO - 2025-05-03 13:56:26 --> Controller Class Initialized
DEBUG - 2025-05-03 13:56:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 13:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 13:56:26 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 13:56:26 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 13:56:26 --> Final output sent to browser
DEBUG - 2025-05-03 13:56:26 --> Total execution time: 0.0344
INFO - 2025-05-03 13:56:27 --> Config Class Initialized
INFO - 2025-05-03 13:56:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:56:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:56:27 --> Utf8 Class Initialized
INFO - 2025-05-03 13:56:27 --> URI Class Initialized
INFO - 2025-05-03 13:56:27 --> Router Class Initialized
INFO - 2025-05-03 13:56:27 --> Output Class Initialized
INFO - 2025-05-03 13:56:27 --> Security Class Initialized
DEBUG - 2025-05-03 13:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:56:27 --> Input Class Initialized
INFO - 2025-05-03 13:56:27 --> Language Class Initialized
ERROR - 2025-05-03 13:56:27 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 13:58:16 --> Config Class Initialized
INFO - 2025-05-03 13:58:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 13:58:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 13:58:16 --> Utf8 Class Initialized
INFO - 2025-05-03 13:58:16 --> URI Class Initialized
DEBUG - 2025-05-03 13:58:16 --> No URI present. Default controller set.
INFO - 2025-05-03 13:58:16 --> Router Class Initialized
INFO - 2025-05-03 13:58:16 --> Output Class Initialized
INFO - 2025-05-03 13:58:16 --> Security Class Initialized
DEBUG - 2025-05-03 13:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 13:58:16 --> Input Class Initialized
INFO - 2025-05-03 13:58:16 --> Language Class Initialized
INFO - 2025-05-03 13:58:16 --> Loader Class Initialized
INFO - 2025-05-03 13:58:16 --> Helper loaded: form_helper
INFO - 2025-05-03 13:58:16 --> Helper loaded: url_helper
INFO - 2025-05-03 13:58:16 --> Database Driver Class Initialized
INFO - 2025-05-03 13:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 13:58:16 --> Form Validation Class Initialized
INFO - 2025-05-03 13:58:16 --> Controller Class Initialized
INFO - 2025-05-03 13:58:16 --> Final output sent to browser
DEBUG - 2025-05-03 13:58:16 --> Total execution time: 0.0322
INFO - 2025-05-03 14:19:14 --> Config Class Initialized
INFO - 2025-05-03 14:19:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:19:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:19:14 --> Utf8 Class Initialized
INFO - 2025-05-03 14:19:14 --> URI Class Initialized
INFO - 2025-05-03 14:19:14 --> Router Class Initialized
INFO - 2025-05-03 14:19:14 --> Output Class Initialized
INFO - 2025-05-03 14:19:14 --> Security Class Initialized
DEBUG - 2025-05-03 14:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:19:14 --> Input Class Initialized
INFO - 2025-05-03 14:19:14 --> Language Class Initialized
ERROR - 2025-05-03 14:19:14 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-03 14:21:36 --> Config Class Initialized
INFO - 2025-05-03 14:21:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:36 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:36 --> URI Class Initialized
INFO - 2025-05-03 14:21:36 --> Router Class Initialized
INFO - 2025-05-03 14:21:36 --> Output Class Initialized
INFO - 2025-05-03 14:21:36 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:36 --> Input Class Initialized
INFO - 2025-05-03 14:21:36 --> Language Class Initialized
INFO - 2025-05-03 14:21:36 --> Loader Class Initialized
INFO - 2025-05-03 14:21:36 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:36 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:36 --> Database Driver Class Initialized
INFO - 2025-05-03 14:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:36 --> Form Validation Class Initialized
INFO - 2025-05-03 14:21:36 --> Controller Class Initialized
INFO - 2025-05-03 14:21:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:21:36 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:21:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:21:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 14:21:36 --> Final output sent to browser
DEBUG - 2025-05-03 14:21:36 --> Total execution time: 0.0452
INFO - 2025-05-03 14:21:44 --> Config Class Initialized
INFO - 2025-05-03 14:21:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:21:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:21:44 --> Utf8 Class Initialized
INFO - 2025-05-03 14:21:44 --> URI Class Initialized
INFO - 2025-05-03 14:21:44 --> Router Class Initialized
INFO - 2025-05-03 14:21:44 --> Output Class Initialized
INFO - 2025-05-03 14:21:44 --> Security Class Initialized
DEBUG - 2025-05-03 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:21:44 --> Input Class Initialized
INFO - 2025-05-03 14:21:44 --> Language Class Initialized
INFO - 2025-05-03 14:21:44 --> Loader Class Initialized
INFO - 2025-05-03 14:21:44 --> Helper loaded: form_helper
INFO - 2025-05-03 14:21:44 --> Helper loaded: url_helper
INFO - 2025-05-03 14:21:44 --> Database Driver Class Initialized
INFO - 2025-05-03 14:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:21:44 --> Form Validation Class Initialized
INFO - 2025-05-03 14:21:44 --> Controller Class Initialized
INFO - 2025-05-03 14:21:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:21:44 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:21:44 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-03 14:21:44 --> Final output sent to browser
DEBUG - 2025-05-03 14:21:44 --> Total execution time: 0.0369
INFO - 2025-05-03 14:23:20 --> Config Class Initialized
INFO - 2025-05-03 14:23:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:23:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:23:20 --> Utf8 Class Initialized
INFO - 2025-05-03 14:23:20 --> URI Class Initialized
INFO - 2025-05-03 14:23:20 --> Router Class Initialized
INFO - 2025-05-03 14:23:20 --> Output Class Initialized
INFO - 2025-05-03 14:23:20 --> Security Class Initialized
DEBUG - 2025-05-03 14:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:23:20 --> Input Class Initialized
INFO - 2025-05-03 14:23:20 --> Language Class Initialized
INFO - 2025-05-03 14:23:20 --> Loader Class Initialized
INFO - 2025-05-03 14:23:20 --> Helper loaded: form_helper
INFO - 2025-05-03 14:23:20 --> Helper loaded: url_helper
INFO - 2025-05-03 14:23:20 --> Database Driver Class Initialized
INFO - 2025-05-03 14:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:23:20 --> Form Validation Class Initialized
INFO - 2025-05-03 14:23:20 --> Controller Class Initialized
INFO - 2025-05-03 14:23:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:23:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:23:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:23:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 14:23:20 --> Final output sent to browser
DEBUG - 2025-05-03 14:23:20 --> Total execution time: 0.0371
INFO - 2025-05-03 14:28:53 --> Config Class Initialized
INFO - 2025-05-03 14:28:53 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:53 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:53 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:53 --> URI Class Initialized
INFO - 2025-05-03 14:28:53 --> Router Class Initialized
INFO - 2025-05-03 14:28:53 --> Output Class Initialized
INFO - 2025-05-03 14:28:53 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:53 --> Input Class Initialized
INFO - 2025-05-03 14:28:53 --> Language Class Initialized
INFO - 2025-05-03 14:28:53 --> Loader Class Initialized
INFO - 2025-05-03 14:28:54 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:54 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:54 --> Database Driver Class Initialized
INFO - 2025-05-03 14:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:54 --> Form Validation Class Initialized
INFO - 2025-05-03 14:28:54 --> Controller Class Initialized
INFO - 2025-05-03 14:28:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:28:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:28:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-03 14:28:54 --> Config Class Initialized
INFO - 2025-05-03 14:28:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:54 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:54 --> URI Class Initialized
INFO - 2025-05-03 14:28:54 --> Router Class Initialized
INFO - 2025-05-03 14:28:54 --> Output Class Initialized
INFO - 2025-05-03 14:28:54 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:54 --> Input Class Initialized
INFO - 2025-05-03 14:28:54 --> Language Class Initialized
INFO - 2025-05-03 14:28:54 --> Loader Class Initialized
INFO - 2025-05-03 14:28:54 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:54 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:54 --> Database Driver Class Initialized
INFO - 2025-05-03 14:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:54 --> Form Validation Class Initialized
INFO - 2025-05-03 14:28:54 --> Controller Class Initialized
INFO - 2025-05-03 14:28:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:28:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:28:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:28:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 14:28:54 --> Final output sent to browser
DEBUG - 2025-05-03 14:28:54 --> Total execution time: 0.0391
INFO - 2025-05-03 14:28:57 --> Config Class Initialized
INFO - 2025-05-03 14:28:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:28:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:28:58 --> Utf8 Class Initialized
INFO - 2025-05-03 14:28:58 --> URI Class Initialized
INFO - 2025-05-03 14:28:58 --> Router Class Initialized
INFO - 2025-05-03 14:28:58 --> Output Class Initialized
INFO - 2025-05-03 14:28:58 --> Security Class Initialized
DEBUG - 2025-05-03 14:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:28:58 --> Input Class Initialized
INFO - 2025-05-03 14:28:58 --> Language Class Initialized
INFO - 2025-05-03 14:28:58 --> Loader Class Initialized
INFO - 2025-05-03 14:28:58 --> Helper loaded: form_helper
INFO - 2025-05-03 14:28:58 --> Helper loaded: url_helper
INFO - 2025-05-03 14:28:58 --> Database Driver Class Initialized
INFO - 2025-05-03 14:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:28:58 --> Form Validation Class Initialized
INFO - 2025-05-03 14:28:58 --> Controller Class Initialized
INFO - 2025-05-03 14:28:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:28:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:28:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:28:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 14:28:58 --> Final output sent to browser
DEBUG - 2025-05-03 14:28:58 --> Total execution time: 0.0379
INFO - 2025-05-03 14:29:01 --> Config Class Initialized
INFO - 2025-05-03 14:29:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:01 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:01 --> URI Class Initialized
INFO - 2025-05-03 14:29:01 --> Router Class Initialized
INFO - 2025-05-03 14:29:01 --> Output Class Initialized
INFO - 2025-05-03 14:29:01 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:01 --> Input Class Initialized
INFO - 2025-05-03 14:29:01 --> Language Class Initialized
INFO - 2025-05-03 14:29:01 --> Loader Class Initialized
INFO - 2025-05-03 14:29:01 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:01 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:01 --> Database Driver Class Initialized
INFO - 2025-05-03 14:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:01 --> Form Validation Class Initialized
INFO - 2025-05-03 14:29:01 --> Controller Class Initialized
INFO - 2025-05-03 14:29:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:29:01 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:29:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-03 14:29:01 --> Final output sent to browser
DEBUG - 2025-05-03 14:29:01 --> Total execution time: 0.0353
INFO - 2025-05-03 14:29:05 --> Config Class Initialized
INFO - 2025-05-03 14:29:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:29:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:29:05 --> Utf8 Class Initialized
INFO - 2025-05-03 14:29:05 --> URI Class Initialized
INFO - 2025-05-03 14:29:05 --> Router Class Initialized
INFO - 2025-05-03 14:29:05 --> Output Class Initialized
INFO - 2025-05-03 14:29:05 --> Security Class Initialized
DEBUG - 2025-05-03 14:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:29:05 --> Input Class Initialized
INFO - 2025-05-03 14:29:05 --> Language Class Initialized
INFO - 2025-05-03 14:29:05 --> Loader Class Initialized
INFO - 2025-05-03 14:29:05 --> Helper loaded: form_helper
INFO - 2025-05-03 14:29:05 --> Helper loaded: url_helper
INFO - 2025-05-03 14:29:05 --> Database Driver Class Initialized
INFO - 2025-05-03 14:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:29:05 --> Form Validation Class Initialized
INFO - 2025-05-03 14:29:05 --> Controller Class Initialized
INFO - 2025-05-03 14:29:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:29:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:29:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:29:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:29:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-03 14:29:05 --> Final output sent to browser
DEBUG - 2025-05-03 14:29:05 --> Total execution time: 0.0410
INFO - 2025-05-03 14:30:55 --> Config Class Initialized
INFO - 2025-05-03 14:30:55 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:30:55 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:30:55 --> Utf8 Class Initialized
INFO - 2025-05-03 14:30:55 --> URI Class Initialized
INFO - 2025-05-03 14:30:55 --> Router Class Initialized
INFO - 2025-05-03 14:30:55 --> Output Class Initialized
INFO - 2025-05-03 14:30:55 --> Security Class Initialized
DEBUG - 2025-05-03 14:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:30:55 --> Input Class Initialized
INFO - 2025-05-03 14:30:55 --> Language Class Initialized
INFO - 2025-05-03 14:30:55 --> Loader Class Initialized
INFO - 2025-05-03 14:30:55 --> Helper loaded: form_helper
INFO - 2025-05-03 14:30:55 --> Helper loaded: url_helper
INFO - 2025-05-03 14:30:55 --> Database Driver Class Initialized
INFO - 2025-05-03 14:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:30:55 --> Form Validation Class Initialized
INFO - 2025-05-03 14:30:55 --> Controller Class Initialized
INFO - 2025-05-03 14:30:55 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:30:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:30:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:30:56 --> Config Class Initialized
INFO - 2025-05-03 14:30:56 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:30:56 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:30:56 --> Utf8 Class Initialized
INFO - 2025-05-03 14:30:56 --> URI Class Initialized
INFO - 2025-05-03 14:30:56 --> Router Class Initialized
INFO - 2025-05-03 14:30:56 --> Output Class Initialized
INFO - 2025-05-03 14:30:56 --> Security Class Initialized
DEBUG - 2025-05-03 14:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:30:56 --> Input Class Initialized
INFO - 2025-05-03 14:30:56 --> Language Class Initialized
INFO - 2025-05-03 14:30:56 --> Loader Class Initialized
INFO - 2025-05-03 14:30:56 --> Helper loaded: form_helper
INFO - 2025-05-03 14:30:56 --> Helper loaded: url_helper
INFO - 2025-05-03 14:30:56 --> Database Driver Class Initialized
INFO - 2025-05-03 14:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:30:56 --> Form Validation Class Initialized
INFO - 2025-05-03 14:30:56 --> Controller Class Initialized
INFO - 2025-05-03 14:30:56 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:30:56 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:30:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:30:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 14:30:56 --> Final output sent to browser
DEBUG - 2025-05-03 14:30:56 --> Total execution time: 0.0388
INFO - 2025-05-03 14:30:58 --> Config Class Initialized
INFO - 2025-05-03 14:30:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:30:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:30:58 --> Utf8 Class Initialized
INFO - 2025-05-03 14:30:58 --> URI Class Initialized
INFO - 2025-05-03 14:30:58 --> Router Class Initialized
INFO - 2025-05-03 14:30:58 --> Output Class Initialized
INFO - 2025-05-03 14:30:58 --> Security Class Initialized
DEBUG - 2025-05-03 14:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:30:59 --> Input Class Initialized
INFO - 2025-05-03 14:30:59 --> Language Class Initialized
INFO - 2025-05-03 14:30:59 --> Loader Class Initialized
INFO - 2025-05-03 14:30:59 --> Helper loaded: form_helper
INFO - 2025-05-03 14:30:59 --> Helper loaded: url_helper
INFO - 2025-05-03 14:30:59 --> Database Driver Class Initialized
INFO - 2025-05-03 14:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:30:59 --> Form Validation Class Initialized
INFO - 2025-05-03 14:30:59 --> Controller Class Initialized
INFO - 2025-05-03 14:30:59 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:30:59 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:30:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-03 14:30:59 --> Final output sent to browser
DEBUG - 2025-05-03 14:30:59 --> Total execution time: 0.0342
INFO - 2025-05-03 14:39:22 --> Config Class Initialized
INFO - 2025-05-03 14:39:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:39:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:39:22 --> Utf8 Class Initialized
INFO - 2025-05-03 14:39:22 --> URI Class Initialized
INFO - 2025-05-03 14:39:22 --> Router Class Initialized
INFO - 2025-05-03 14:39:22 --> Output Class Initialized
INFO - 2025-05-03 14:39:22 --> Security Class Initialized
DEBUG - 2025-05-03 14:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:39:22 --> Input Class Initialized
INFO - 2025-05-03 14:39:22 --> Language Class Initialized
INFO - 2025-05-03 14:39:22 --> Loader Class Initialized
INFO - 2025-05-03 14:39:22 --> Helper loaded: form_helper
INFO - 2025-05-03 14:39:22 --> Helper loaded: url_helper
INFO - 2025-05-03 14:39:22 --> Database Driver Class Initialized
INFO - 2025-05-03 14:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:39:22 --> Form Validation Class Initialized
INFO - 2025-05-03 14:39:22 --> Controller Class Initialized
INFO - 2025-05-03 14:39:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:39:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:39:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:39:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 14:39:22 --> Final output sent to browser
DEBUG - 2025-05-03 14:39:22 --> Total execution time: 0.0425
INFO - 2025-05-03 14:52:29 --> Config Class Initialized
INFO - 2025-05-03 14:52:29 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:52:29 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:52:29 --> Utf8 Class Initialized
INFO - 2025-05-03 14:52:29 --> URI Class Initialized
INFO - 2025-05-03 14:52:29 --> Router Class Initialized
INFO - 2025-05-03 14:52:29 --> Output Class Initialized
INFO - 2025-05-03 14:52:29 --> Security Class Initialized
DEBUG - 2025-05-03 14:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:52:29 --> Input Class Initialized
INFO - 2025-05-03 14:52:29 --> Language Class Initialized
INFO - 2025-05-03 14:52:29 --> Loader Class Initialized
INFO - 2025-05-03 14:52:29 --> Helper loaded: form_helper
INFO - 2025-05-03 14:52:29 --> Helper loaded: url_helper
INFO - 2025-05-03 14:52:29 --> Database Driver Class Initialized
INFO - 2025-05-03 14:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:52:29 --> Form Validation Class Initialized
INFO - 2025-05-03 14:52:29 --> Controller Class Initialized
INFO - 2025-05-03 14:52:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:52:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:52:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:52:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 14:52:29 --> Final output sent to browser
DEBUG - 2025-05-03 14:52:29 --> Total execution time: 0.0524
INFO - 2025-05-03 14:52:37 --> Config Class Initialized
INFO - 2025-05-03 14:52:37 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:52:37 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:52:37 --> Utf8 Class Initialized
INFO - 2025-05-03 14:52:37 --> URI Class Initialized
INFO - 2025-05-03 14:52:37 --> Router Class Initialized
INFO - 2025-05-03 14:52:37 --> Output Class Initialized
INFO - 2025-05-03 14:52:37 --> Security Class Initialized
DEBUG - 2025-05-03 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:52:37 --> Input Class Initialized
INFO - 2025-05-03 14:52:37 --> Language Class Initialized
INFO - 2025-05-03 14:52:37 --> Loader Class Initialized
INFO - 2025-05-03 14:52:37 --> Helper loaded: form_helper
INFO - 2025-05-03 14:52:37 --> Helper loaded: url_helper
INFO - 2025-05-03 14:52:37 --> Database Driver Class Initialized
INFO - 2025-05-03 14:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:52:37 --> Form Validation Class Initialized
INFO - 2025-05-03 14:52:37 --> Controller Class Initialized
INFO - 2025-05-03 14:52:37 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:52:37 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:52:37 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:52:37 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 14:52:37 --> Final output sent to browser
DEBUG - 2025-05-03 14:52:37 --> Total execution time: 0.0372
INFO - 2025-05-03 14:52:39 --> Config Class Initialized
INFO - 2025-05-03 14:52:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:52:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:52:39 --> Utf8 Class Initialized
INFO - 2025-05-03 14:52:39 --> URI Class Initialized
INFO - 2025-05-03 14:52:39 --> Router Class Initialized
INFO - 2025-05-03 14:52:39 --> Output Class Initialized
INFO - 2025-05-03 14:52:39 --> Security Class Initialized
DEBUG - 2025-05-03 14:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:52:39 --> Input Class Initialized
INFO - 2025-05-03 14:52:39 --> Language Class Initialized
INFO - 2025-05-03 14:52:39 --> Loader Class Initialized
INFO - 2025-05-03 14:52:39 --> Helper loaded: form_helper
INFO - 2025-05-03 14:52:39 --> Helper loaded: url_helper
INFO - 2025-05-03 14:52:39 --> Database Driver Class Initialized
INFO - 2025-05-03 14:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:52:39 --> Form Validation Class Initialized
INFO - 2025-05-03 14:52:39 --> Controller Class Initialized
INFO - 2025-05-03 14:52:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:52:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:52:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:52:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 14:52:39 --> Final output sent to browser
DEBUG - 2025-05-03 14:52:39 --> Total execution time: 0.0372
INFO - 2025-05-03 14:53:23 --> Config Class Initialized
INFO - 2025-05-03 14:53:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:53:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:53:23 --> Utf8 Class Initialized
INFO - 2025-05-03 14:53:23 --> URI Class Initialized
INFO - 2025-05-03 14:53:23 --> Router Class Initialized
INFO - 2025-05-03 14:53:23 --> Output Class Initialized
INFO - 2025-05-03 14:53:23 --> Security Class Initialized
DEBUG - 2025-05-03 14:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:53:23 --> Input Class Initialized
INFO - 2025-05-03 14:53:23 --> Language Class Initialized
INFO - 2025-05-03 14:53:23 --> Loader Class Initialized
INFO - 2025-05-03 14:53:23 --> Helper loaded: form_helper
INFO - 2025-05-03 14:53:23 --> Helper loaded: url_helper
INFO - 2025-05-03 14:53:23 --> Database Driver Class Initialized
INFO - 2025-05-03 14:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:53:23 --> Form Validation Class Initialized
INFO - 2025-05-03 14:53:23 --> Controller Class Initialized
INFO - 2025-05-03 14:53:23 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:53:23 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:53:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:53:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-03 14:53:24 --> Final output sent to browser
DEBUG - 2025-05-03 14:53:24 --> Total execution time: 0.0412
INFO - 2025-05-03 14:53:48 --> Config Class Initialized
INFO - 2025-05-03 14:53:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:53:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:53:48 --> Utf8 Class Initialized
INFO - 2025-05-03 14:53:48 --> URI Class Initialized
INFO - 2025-05-03 14:53:48 --> Router Class Initialized
INFO - 2025-05-03 14:53:48 --> Output Class Initialized
INFO - 2025-05-03 14:53:48 --> Security Class Initialized
DEBUG - 2025-05-03 14:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:53:48 --> Input Class Initialized
INFO - 2025-05-03 14:53:48 --> Language Class Initialized
INFO - 2025-05-03 14:53:48 --> Loader Class Initialized
INFO - 2025-05-03 14:53:48 --> Helper loaded: form_helper
INFO - 2025-05-03 14:53:48 --> Helper loaded: url_helper
INFO - 2025-05-03 14:53:48 --> Database Driver Class Initialized
INFO - 2025-05-03 14:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:53:48 --> Form Validation Class Initialized
INFO - 2025-05-03 14:53:48 --> Controller Class Initialized
INFO - 2025-05-03 14:53:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:53:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:53:48 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:53:48 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 14:53:48 --> Final output sent to browser
DEBUG - 2025-05-03 14:53:48 --> Total execution time: 0.0343
INFO - 2025-05-03 14:53:50 --> Config Class Initialized
INFO - 2025-05-03 14:53:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:53:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:53:50 --> Utf8 Class Initialized
INFO - 2025-05-03 14:53:50 --> URI Class Initialized
INFO - 2025-05-03 14:53:50 --> Router Class Initialized
INFO - 2025-05-03 14:53:50 --> Output Class Initialized
INFO - 2025-05-03 14:53:50 --> Security Class Initialized
DEBUG - 2025-05-03 14:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:53:50 --> Input Class Initialized
INFO - 2025-05-03 14:53:50 --> Language Class Initialized
INFO - 2025-05-03 14:53:50 --> Loader Class Initialized
INFO - 2025-05-03 14:53:50 --> Helper loaded: form_helper
INFO - 2025-05-03 14:53:50 --> Helper loaded: url_helper
INFO - 2025-05-03 14:53:50 --> Database Driver Class Initialized
INFO - 2025-05-03 14:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:53:50 --> Form Validation Class Initialized
INFO - 2025-05-03 14:53:50 --> Controller Class Initialized
INFO - 2025-05-03 14:53:50 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:53:50 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:53:50 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-03 14:53:50 --> Final output sent to browser
DEBUG - 2025-05-03 14:53:50 --> Total execution time: 0.0340
INFO - 2025-05-03 14:54:01 --> Config Class Initialized
INFO - 2025-05-03 14:54:01 --> Hooks Class Initialized
DEBUG - 2025-05-03 14:54:01 --> UTF-8 Support Enabled
INFO - 2025-05-03 14:54:01 --> Utf8 Class Initialized
INFO - 2025-05-03 14:54:01 --> URI Class Initialized
INFO - 2025-05-03 14:54:01 --> Router Class Initialized
INFO - 2025-05-03 14:54:01 --> Output Class Initialized
INFO - 2025-05-03 14:54:01 --> Security Class Initialized
DEBUG - 2025-05-03 14:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 14:54:01 --> Input Class Initialized
INFO - 2025-05-03 14:54:01 --> Language Class Initialized
INFO - 2025-05-03 14:54:01 --> Loader Class Initialized
INFO - 2025-05-03 14:54:01 --> Helper loaded: form_helper
INFO - 2025-05-03 14:54:01 --> Helper loaded: url_helper
INFO - 2025-05-03 14:54:01 --> Database Driver Class Initialized
INFO - 2025-05-03 14:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 14:54:01 --> Form Validation Class Initialized
INFO - 2025-05-03 14:54:01 --> Controller Class Initialized
INFO - 2025-05-03 14:54:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 14:54:01 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 14:54:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 14:54:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 14:54:01 --> Final output sent to browser
DEBUG - 2025-05-03 14:54:01 --> Total execution time: 0.0334
INFO - 2025-05-03 15:29:07 --> Config Class Initialized
INFO - 2025-05-03 15:29:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:29:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:29:07 --> Utf8 Class Initialized
INFO - 2025-05-03 15:29:07 --> URI Class Initialized
DEBUG - 2025-05-03 15:29:07 --> No URI present. Default controller set.
INFO - 2025-05-03 15:29:07 --> Router Class Initialized
INFO - 2025-05-03 15:29:07 --> Output Class Initialized
INFO - 2025-05-03 15:29:07 --> Security Class Initialized
DEBUG - 2025-05-03 15:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:29:07 --> Input Class Initialized
INFO - 2025-05-03 15:29:07 --> Language Class Initialized
INFO - 2025-05-03 15:29:07 --> Loader Class Initialized
INFO - 2025-05-03 15:29:07 --> Helper loaded: form_helper
INFO - 2025-05-03 15:29:07 --> Helper loaded: url_helper
INFO - 2025-05-03 15:29:07 --> Database Driver Class Initialized
INFO - 2025-05-03 15:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:29:07 --> Form Validation Class Initialized
INFO - 2025-05-03 15:29:07 --> Controller Class Initialized
INFO - 2025-05-03 15:29:07 --> Final output sent to browser
DEBUG - 2025-05-03 15:29:07 --> Total execution time: 0.0318
INFO - 2025-05-03 15:29:08 --> Config Class Initialized
INFO - 2025-05-03 15:29:08 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:29:08 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:29:08 --> Utf8 Class Initialized
INFO - 2025-05-03 15:29:08 --> URI Class Initialized
DEBUG - 2025-05-03 15:29:08 --> No URI present. Default controller set.
INFO - 2025-05-03 15:29:08 --> Router Class Initialized
INFO - 2025-05-03 15:29:08 --> Output Class Initialized
INFO - 2025-05-03 15:29:08 --> Security Class Initialized
DEBUG - 2025-05-03 15:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:29:08 --> Input Class Initialized
INFO - 2025-05-03 15:29:08 --> Language Class Initialized
INFO - 2025-05-03 15:29:08 --> Loader Class Initialized
INFO - 2025-05-03 15:29:08 --> Helper loaded: form_helper
INFO - 2025-05-03 15:29:08 --> Helper loaded: url_helper
INFO - 2025-05-03 15:29:08 --> Database Driver Class Initialized
INFO - 2025-05-03 15:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:29:08 --> Form Validation Class Initialized
INFO - 2025-05-03 15:29:08 --> Controller Class Initialized
INFO - 2025-05-03 15:29:08 --> Final output sent to browser
DEBUG - 2025-05-03 15:29:08 --> Total execution time: 0.0302
INFO - 2025-05-03 15:29:09 --> Config Class Initialized
INFO - 2025-05-03 15:29:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:29:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:29:09 --> Utf8 Class Initialized
INFO - 2025-05-03 15:29:09 --> URI Class Initialized
INFO - 2025-05-03 15:29:09 --> Router Class Initialized
INFO - 2025-05-03 15:29:09 --> Output Class Initialized
INFO - 2025-05-03 15:29:09 --> Security Class Initialized
DEBUG - 2025-05-03 15:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:29:09 --> Input Class Initialized
INFO - 2025-05-03 15:29:09 --> Language Class Initialized
ERROR - 2025-05-03 15:29:09 --> 404 Page Not Found: Wp-admin/install.php
INFO - 2025-05-03 15:29:09 --> Config Class Initialized
INFO - 2025-05-03 15:29:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:29:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:29:09 --> Utf8 Class Initialized
INFO - 2025-05-03 15:29:09 --> URI Class Initialized
INFO - 2025-05-03 15:29:09 --> Router Class Initialized
INFO - 2025-05-03 15:29:09 --> Output Class Initialized
INFO - 2025-05-03 15:29:09 --> Security Class Initialized
DEBUG - 2025-05-03 15:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:29:09 --> Input Class Initialized
INFO - 2025-05-03 15:29:09 --> Language Class Initialized
ERROR - 2025-05-03 15:29:09 --> 404 Page Not Found: Wp-admin/setup-config.php
INFO - 2025-05-03 15:29:10 --> Config Class Initialized
INFO - 2025-05-03 15:29:10 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:29:10 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:29:10 --> Utf8 Class Initialized
INFO - 2025-05-03 15:29:10 --> URI Class Initialized
INFO - 2025-05-03 15:29:10 --> Router Class Initialized
INFO - 2025-05-03 15:29:10 --> Output Class Initialized
INFO - 2025-05-03 15:29:10 --> Security Class Initialized
DEBUG - 2025-05-03 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:29:10 --> Input Class Initialized
INFO - 2025-05-03 15:29:10 --> Language Class Initialized
INFO - 2025-05-03 15:29:10 --> Loader Class Initialized
INFO - 2025-05-03 15:29:10 --> Helper loaded: form_helper
INFO - 2025-05-03 15:29:10 --> Helper loaded: url_helper
INFO - 2025-05-03 15:29:10 --> Database Driver Class Initialized
INFO - 2025-05-03 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:29:10 --> Form Validation Class Initialized
INFO - 2025-05-03 15:29:10 --> Controller Class Initialized
INFO - 2025-05-03 15:29:10 --> Config Class Initialized
INFO - 2025-05-03 15:29:10 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:29:10 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:29:10 --> Utf8 Class Initialized
INFO - 2025-05-03 15:29:10 --> URI Class Initialized
INFO - 2025-05-03 15:29:10 --> Router Class Initialized
INFO - 2025-05-03 15:29:10 --> Output Class Initialized
INFO - 2025-05-03 15:29:10 --> Security Class Initialized
DEBUG - 2025-05-03 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:29:10 --> Input Class Initialized
INFO - 2025-05-03 15:29:10 --> Language Class Initialized
INFO - 2025-05-03 15:29:10 --> Loader Class Initialized
INFO - 2025-05-03 15:29:10 --> Helper loaded: form_helper
INFO - 2025-05-03 15:29:10 --> Helper loaded: url_helper
INFO - 2025-05-03 15:29:10 --> Database Driver Class Initialized
INFO - 2025-05-03 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:29:10 --> Form Validation Class Initialized
INFO - 2025-05-03 15:29:10 --> Controller Class Initialized
INFO - 2025-05-03 15:29:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 15:29:10 --> Final output sent to browser
DEBUG - 2025-05-03 15:29:10 --> Total execution time: 0.0284
INFO - 2025-05-03 15:29:50 --> Config Class Initialized
INFO - 2025-05-03 15:29:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:29:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:29:50 --> Utf8 Class Initialized
INFO - 2025-05-03 15:29:50 --> URI Class Initialized
INFO - 2025-05-03 15:29:50 --> Router Class Initialized
INFO - 2025-05-03 15:29:50 --> Output Class Initialized
INFO - 2025-05-03 15:29:50 --> Security Class Initialized
DEBUG - 2025-05-03 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:29:50 --> Input Class Initialized
INFO - 2025-05-03 15:29:50 --> Language Class Initialized
INFO - 2025-05-03 15:29:50 --> Loader Class Initialized
INFO - 2025-05-03 15:29:50 --> Helper loaded: form_helper
INFO - 2025-05-03 15:29:50 --> Helper loaded: url_helper
INFO - 2025-05-03 15:29:50 --> Database Driver Class Initialized
INFO - 2025-05-03 15:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:29:50 --> Form Validation Class Initialized
INFO - 2025-05-03 15:29:50 --> Controller Class Initialized
INFO - 2025-05-03 15:29:50 --> Config Class Initialized
INFO - 2025-05-03 15:29:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:29:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:29:50 --> Utf8 Class Initialized
INFO - 2025-05-03 15:29:50 --> URI Class Initialized
INFO - 2025-05-03 15:29:50 --> Router Class Initialized
INFO - 2025-05-03 15:29:50 --> Output Class Initialized
INFO - 2025-05-03 15:29:50 --> Security Class Initialized
DEBUG - 2025-05-03 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:29:50 --> Input Class Initialized
INFO - 2025-05-03 15:29:50 --> Language Class Initialized
INFO - 2025-05-03 15:29:50 --> Loader Class Initialized
INFO - 2025-05-03 15:29:50 --> Helper loaded: form_helper
INFO - 2025-05-03 15:29:50 --> Helper loaded: url_helper
INFO - 2025-05-03 15:29:50 --> Database Driver Class Initialized
INFO - 2025-05-03 15:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:29:50 --> Form Validation Class Initialized
INFO - 2025-05-03 15:29:50 --> Controller Class Initialized
INFO - 2025-05-03 15:29:50 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:29:50 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:29:50 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:29:50 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 15:29:50 --> Final output sent to browser
DEBUG - 2025-05-03 15:29:50 --> Total execution time: 0.0303
INFO - 2025-05-03 15:29:52 --> Config Class Initialized
INFO - 2025-05-03 15:29:52 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:29:52 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:29:52 --> Utf8 Class Initialized
INFO - 2025-05-03 15:29:52 --> URI Class Initialized
INFO - 2025-05-03 15:29:52 --> Router Class Initialized
INFO - 2025-05-03 15:29:52 --> Output Class Initialized
INFO - 2025-05-03 15:29:52 --> Security Class Initialized
DEBUG - 2025-05-03 15:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:29:52 --> Input Class Initialized
INFO - 2025-05-03 15:29:52 --> Language Class Initialized
INFO - 2025-05-03 15:29:52 --> Loader Class Initialized
INFO - 2025-05-03 15:29:52 --> Helper loaded: form_helper
INFO - 2025-05-03 15:29:52 --> Helper loaded: url_helper
INFO - 2025-05-03 15:29:52 --> Database Driver Class Initialized
INFO - 2025-05-03 15:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:29:52 --> Form Validation Class Initialized
INFO - 2025-05-03 15:29:52 --> Controller Class Initialized
INFO - 2025-05-03 15:29:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:29:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:29:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:29:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 15:29:52 --> Final output sent to browser
DEBUG - 2025-05-03 15:29:52 --> Total execution time: 0.0364
INFO - 2025-05-03 15:30:22 --> Config Class Initialized
INFO - 2025-05-03 15:30:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:30:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:30:22 --> Utf8 Class Initialized
INFO - 2025-05-03 15:30:22 --> URI Class Initialized
INFO - 2025-05-03 15:30:22 --> Router Class Initialized
INFO - 2025-05-03 15:30:22 --> Output Class Initialized
INFO - 2025-05-03 15:30:22 --> Security Class Initialized
DEBUG - 2025-05-03 15:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:30:22 --> Input Class Initialized
INFO - 2025-05-03 15:30:22 --> Language Class Initialized
INFO - 2025-05-03 15:30:22 --> Loader Class Initialized
INFO - 2025-05-03 15:30:22 --> Helper loaded: form_helper
INFO - 2025-05-03 15:30:22 --> Helper loaded: url_helper
INFO - 2025-05-03 15:30:22 --> Database Driver Class Initialized
INFO - 2025-05-03 15:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:30:22 --> Form Validation Class Initialized
INFO - 2025-05-03 15:30:22 --> Controller Class Initialized
INFO - 2025-05-03 15:30:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:30:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:30:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:30:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 15:30:22 --> Final output sent to browser
DEBUG - 2025-05-03 15:30:22 --> Total execution time: 0.0451
INFO - 2025-05-03 15:30:25 --> Config Class Initialized
INFO - 2025-05-03 15:30:25 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:30:25 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:30:25 --> Utf8 Class Initialized
INFO - 2025-05-03 15:30:25 --> URI Class Initialized
INFO - 2025-05-03 15:30:25 --> Router Class Initialized
INFO - 2025-05-03 15:30:25 --> Output Class Initialized
INFO - 2025-05-03 15:30:25 --> Security Class Initialized
DEBUG - 2025-05-03 15:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:30:25 --> Input Class Initialized
INFO - 2025-05-03 15:30:25 --> Language Class Initialized
INFO - 2025-05-03 15:30:25 --> Loader Class Initialized
INFO - 2025-05-03 15:30:25 --> Helper loaded: form_helper
INFO - 2025-05-03 15:30:25 --> Helper loaded: url_helper
INFO - 2025-05-03 15:30:25 --> Database Driver Class Initialized
INFO - 2025-05-03 15:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:30:25 --> Form Validation Class Initialized
INFO - 2025-05-03 15:30:25 --> Controller Class Initialized
INFO - 2025-05-03 15:30:25 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:30:25 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:30:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:30:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 15:30:25 --> Final output sent to browser
DEBUG - 2025-05-03 15:30:25 --> Total execution time: 0.0418
INFO - 2025-05-03 15:30:27 --> Config Class Initialized
INFO - 2025-05-03 15:30:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:30:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:30:27 --> Utf8 Class Initialized
INFO - 2025-05-03 15:30:27 --> URI Class Initialized
INFO - 2025-05-03 15:30:27 --> Router Class Initialized
INFO - 2025-05-03 15:30:27 --> Output Class Initialized
INFO - 2025-05-03 15:30:27 --> Security Class Initialized
DEBUG - 2025-05-03 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:30:27 --> Input Class Initialized
INFO - 2025-05-03 15:30:27 --> Language Class Initialized
INFO - 2025-05-03 15:30:27 --> Loader Class Initialized
INFO - 2025-05-03 15:30:27 --> Helper loaded: form_helper
INFO - 2025-05-03 15:30:27 --> Helper loaded: url_helper
INFO - 2025-05-03 15:30:27 --> Database Driver Class Initialized
INFO - 2025-05-03 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:30:27 --> Form Validation Class Initialized
INFO - 2025-05-03 15:30:27 --> Controller Class Initialized
INFO - 2025-05-03 15:30:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:30:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:30:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:30:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 15:30:27 --> Final output sent to browser
DEBUG - 2025-05-03 15:30:27 --> Total execution time: 0.0431
INFO - 2025-05-03 15:30:35 --> Config Class Initialized
INFO - 2025-05-03 15:30:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:30:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:30:35 --> Utf8 Class Initialized
INFO - 2025-05-03 15:30:35 --> URI Class Initialized
INFO - 2025-05-03 15:30:35 --> Router Class Initialized
INFO - 2025-05-03 15:30:35 --> Output Class Initialized
INFO - 2025-05-03 15:30:35 --> Security Class Initialized
DEBUG - 2025-05-03 15:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:30:35 --> Input Class Initialized
INFO - 2025-05-03 15:30:35 --> Language Class Initialized
INFO - 2025-05-03 15:30:35 --> Loader Class Initialized
INFO - 2025-05-03 15:30:35 --> Helper loaded: form_helper
INFO - 2025-05-03 15:30:35 --> Helper loaded: url_helper
INFO - 2025-05-03 15:30:35 --> Database Driver Class Initialized
INFO - 2025-05-03 15:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:30:35 --> Form Validation Class Initialized
INFO - 2025-05-03 15:30:35 --> Controller Class Initialized
INFO - 2025-05-03 15:30:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:30:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:30:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:30:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 15:30:35 --> Final output sent to browser
DEBUG - 2025-05-03 15:30:35 --> Total execution time: 0.0384
INFO - 2025-05-03 15:34:32 --> Config Class Initialized
INFO - 2025-05-03 15:34:32 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:34:32 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:34:32 --> Utf8 Class Initialized
INFO - 2025-05-03 15:34:32 --> URI Class Initialized
INFO - 2025-05-03 15:34:32 --> Router Class Initialized
INFO - 2025-05-03 15:34:32 --> Output Class Initialized
INFO - 2025-05-03 15:34:32 --> Security Class Initialized
DEBUG - 2025-05-03 15:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:34:32 --> Input Class Initialized
INFO - 2025-05-03 15:34:32 --> Language Class Initialized
INFO - 2025-05-03 15:34:32 --> Loader Class Initialized
INFO - 2025-05-03 15:34:32 --> Helper loaded: form_helper
INFO - 2025-05-03 15:34:32 --> Helper loaded: url_helper
INFO - 2025-05-03 15:34:32 --> Database Driver Class Initialized
INFO - 2025-05-03 15:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:34:32 --> Form Validation Class Initialized
INFO - 2025-05-03 15:34:32 --> Controller Class Initialized
INFO - 2025-05-03 15:34:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:34:32 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:34:32 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:34:32 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 15:34:32 --> Final output sent to browser
DEBUG - 2025-05-03 15:34:32 --> Total execution time: 0.0382
INFO - 2025-05-03 15:34:40 --> Config Class Initialized
INFO - 2025-05-03 15:34:40 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:34:40 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:34:40 --> Utf8 Class Initialized
INFO - 2025-05-03 15:34:40 --> URI Class Initialized
INFO - 2025-05-03 15:34:40 --> Router Class Initialized
INFO - 2025-05-03 15:34:40 --> Output Class Initialized
INFO - 2025-05-03 15:34:40 --> Security Class Initialized
DEBUG - 2025-05-03 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:34:40 --> Input Class Initialized
INFO - 2025-05-03 15:34:40 --> Language Class Initialized
INFO - 2025-05-03 15:34:40 --> Loader Class Initialized
INFO - 2025-05-03 15:34:40 --> Helper loaded: form_helper
INFO - 2025-05-03 15:34:40 --> Helper loaded: url_helper
INFO - 2025-05-03 15:34:40 --> Database Driver Class Initialized
INFO - 2025-05-03 15:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:34:40 --> Form Validation Class Initialized
INFO - 2025-05-03 15:34:40 --> Controller Class Initialized
INFO - 2025-05-03 15:34:40 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:34:40 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:34:40 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:34:40 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-03 15:34:40 --> Final output sent to browser
DEBUG - 2025-05-03 15:34:40 --> Total execution time: 0.0358
INFO - 2025-05-03 15:34:44 --> Config Class Initialized
INFO - 2025-05-03 15:34:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:34:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:34:44 --> Utf8 Class Initialized
INFO - 2025-05-03 15:34:44 --> URI Class Initialized
INFO - 2025-05-03 15:34:44 --> Router Class Initialized
INFO - 2025-05-03 15:34:44 --> Output Class Initialized
INFO - 2025-05-03 15:34:44 --> Security Class Initialized
DEBUG - 2025-05-03 15:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:34:44 --> Input Class Initialized
INFO - 2025-05-03 15:34:44 --> Language Class Initialized
INFO - 2025-05-03 15:34:44 --> Loader Class Initialized
INFO - 2025-05-03 15:34:44 --> Helper loaded: form_helper
INFO - 2025-05-03 15:34:44 --> Helper loaded: url_helper
INFO - 2025-05-03 15:34:44 --> Database Driver Class Initialized
INFO - 2025-05-03 15:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:34:44 --> Form Validation Class Initialized
INFO - 2025-05-03 15:34:44 --> Controller Class Initialized
INFO - 2025-05-03 15:34:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:34:44 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:34:44 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:34:44 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-03 15:34:44 --> Final output sent to browser
DEBUG - 2025-05-03 15:34:44 --> Total execution time: 0.0415
INFO - 2025-05-03 15:35:38 --> Config Class Initialized
INFO - 2025-05-03 15:35:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:35:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:35:38 --> Utf8 Class Initialized
INFO - 2025-05-03 15:35:38 --> URI Class Initialized
INFO - 2025-05-03 15:35:38 --> Router Class Initialized
INFO - 2025-05-03 15:35:38 --> Output Class Initialized
INFO - 2025-05-03 15:35:38 --> Security Class Initialized
DEBUG - 2025-05-03 15:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:35:38 --> Input Class Initialized
INFO - 2025-05-03 15:35:38 --> Language Class Initialized
INFO - 2025-05-03 15:35:38 --> Loader Class Initialized
INFO - 2025-05-03 15:35:38 --> Helper loaded: form_helper
INFO - 2025-05-03 15:35:38 --> Helper loaded: url_helper
INFO - 2025-05-03 15:35:38 --> Database Driver Class Initialized
INFO - 2025-05-03 15:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:35:38 --> Form Validation Class Initialized
INFO - 2025-05-03 15:35:38 --> Controller Class Initialized
INFO - 2025-05-03 15:35:38 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:35:38 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:35:38 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:35:38 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 15:35:38 --> Final output sent to browser
DEBUG - 2025-05-03 15:35:38 --> Total execution time: 0.0410
INFO - 2025-05-03 15:36:05 --> Config Class Initialized
INFO - 2025-05-03 15:36:05 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:36:05 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:36:05 --> Utf8 Class Initialized
INFO - 2025-05-03 15:36:05 --> URI Class Initialized
DEBUG - 2025-05-03 15:36:05 --> No URI present. Default controller set.
INFO - 2025-05-03 15:36:05 --> Router Class Initialized
INFO - 2025-05-03 15:36:05 --> Output Class Initialized
INFO - 2025-05-03 15:36:05 --> Security Class Initialized
DEBUG - 2025-05-03 15:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:36:05 --> Input Class Initialized
INFO - 2025-05-03 15:36:05 --> Language Class Initialized
INFO - 2025-05-03 15:36:05 --> Loader Class Initialized
INFO - 2025-05-03 15:36:05 --> Helper loaded: form_helper
INFO - 2025-05-03 15:36:05 --> Helper loaded: url_helper
INFO - 2025-05-03 15:36:05 --> Database Driver Class Initialized
INFO - 2025-05-03 15:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:36:05 --> Form Validation Class Initialized
INFO - 2025-05-03 15:36:05 --> Controller Class Initialized
INFO - 2025-05-03 15:36:05 --> Final output sent to browser
DEBUG - 2025-05-03 15:36:05 --> Total execution time: 0.0312
INFO - 2025-05-03 15:36:09 --> Config Class Initialized
INFO - 2025-05-03 15:36:09 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:36:09 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:36:09 --> Utf8 Class Initialized
INFO - 2025-05-03 15:36:09 --> URI Class Initialized
INFO - 2025-05-03 15:36:09 --> Router Class Initialized
INFO - 2025-05-03 15:36:09 --> Output Class Initialized
INFO - 2025-05-03 15:36:09 --> Security Class Initialized
DEBUG - 2025-05-03 15:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:36:09 --> Input Class Initialized
INFO - 2025-05-03 15:36:09 --> Language Class Initialized
INFO - 2025-05-03 15:36:09 --> Loader Class Initialized
INFO - 2025-05-03 15:36:09 --> Helper loaded: form_helper
INFO - 2025-05-03 15:36:09 --> Helper loaded: url_helper
INFO - 2025-05-03 15:36:09 --> Database Driver Class Initialized
INFO - 2025-05-03 15:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:36:09 --> Form Validation Class Initialized
INFO - 2025-05-03 15:36:09 --> Controller Class Initialized
DEBUG - 2025-05-03 15:36:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 15:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 15:36:09 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 15:36:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 15:36:09 --> Final output sent to browser
DEBUG - 2025-05-03 15:36:09 --> Total execution time: 0.0381
INFO - 2025-05-03 15:37:16 --> Config Class Initialized
INFO - 2025-05-03 15:37:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:37:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:37:16 --> Utf8 Class Initialized
INFO - 2025-05-03 15:37:16 --> URI Class Initialized
INFO - 2025-05-03 15:37:16 --> Router Class Initialized
INFO - 2025-05-03 15:37:16 --> Output Class Initialized
INFO - 2025-05-03 15:37:16 --> Security Class Initialized
DEBUG - 2025-05-03 15:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:37:16 --> Input Class Initialized
INFO - 2025-05-03 15:37:16 --> Language Class Initialized
INFO - 2025-05-03 15:37:16 --> Loader Class Initialized
INFO - 2025-05-03 15:37:16 --> Helper loaded: form_helper
INFO - 2025-05-03 15:37:16 --> Helper loaded: url_helper
INFO - 2025-05-03 15:37:16 --> Database Driver Class Initialized
INFO - 2025-05-03 15:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:37:16 --> Form Validation Class Initialized
INFO - 2025-05-03 15:37:16 --> Controller Class Initialized
DEBUG - 2025-05-03 15:37:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 15:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 15:37:16 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-03 15:37:16 --> POST data: Array
(
    [nama_siswa] => Akhmad Lutfi hehehe
    [jenis_kelamin] => L
    [tempat_lahir] => Batang 
    [tanggal_lahir] => 2025-05-20
    [tempat_tanggal_lahir] => Batang , 20 Mei 2025
    [rekomendasi] => Guru PAI MTs
    [pilihan_program] => MIPA
    [no_hp_siswa] => 085747110787
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Lokojoyo
    [rt] => 003
    [rw] => 004
    [desa] => rowosari
    [kecamatan] => Banyuputih
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Lokojoyo, RT 003/RW 004, rowosari, Banyuputih, Batang, Jawa Tengah
    [nama_ayah] => Supriyanto
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => Tidak Sekolah
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => FAHRUTORI
    [hubungan_wali] => sdsdsd
    [pendidikan_wali] => 
    [pekerjaan_wali] => BURUH
    [no_hp_wali] => 085747110787
    [alamat_wali] => Dukuh Adiloko Desa Rowosari
    [nama_sekolah] => MTs NU 01 Banyuputih
    [nisn] => 1234567890
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => tgrg gergw
    [tanggal_lahir_db] => 2025-05-20
)

INFO - 2025-05-03 15:37:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-03 15:37:16 --> Generated registration number: A-2526/0160
DEBUG - 2025-05-03 15:37:16 --> Form data to save: Array
(
    [nama_siswa] => Akhmad Lutfi hehehe
    [jenis_kelamin] => L
    [tempat_lahir] => Batang 
    [tanggal_lahir] => 2025-05-20
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Guru PAI MTs
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Lokojoyo
    [rt] => 003
    [rw] => 004
    [desa] => rowosari
    [kecamatan] => Banyuputih
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Supriyanto
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => Tidak Sekolah
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => FAHRUTORI
    [hubungan_wali] => sdsdsd
    [pendidikan_wali] => 
    [pekerjaan_wali] => BURUH
    [no_hp_wali] => 085747110787
    [alamat_wali] => Dukuh Adiloko Desa Rowosari
    [nama_sekolah] => MTs NU 01 Banyuputih
    [nisn] => 1234567890
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => tgrg gergw
    [tanggal_daftar] => 2025-05-03 15:37:16
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-03 15:37:16 --> Attempting to save data to pendaftaran table
DEBUG - 2025-05-03 15:37:16 --> Data: Array
(
    [nama_siswa] => Akhmad Lutfi hehehe
    [jenis_kelamin] => L
    [tempat_lahir] => Batang 
    [tanggal_lahir] => 2025-05-20
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Guru PAI MTs
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Lokojoyo
    [rt] => 003
    [rw] => 004
    [desa] => rowosari
    [kecamatan] => Banyuputih
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Supriyanto
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => Tidak Sekolah
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => FAHRUTORI
    [hubungan_wali] => sdsdsd
    [pendidikan_wali] => 
    [pekerjaan_wali] => BURUH
    [no_hp_wali] => 085747110787
    [alamat_wali] => Dukuh Adiloko Desa Rowosari
    [nama_sekolah] => MTs NU 01 Banyuputih
    [nisn] => 1234567890
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => tgrg gergw
    [tanggal_daftar] => 2025-05-03 15:37:16
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-03 15:37:16 --> Data inserted successfully with ID: 169
INFO - 2025-05-03 15:37:18 --> Config Class Initialized
INFO - 2025-05-03 15:37:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:37:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:37:18 --> Utf8 Class Initialized
INFO - 2025-05-03 15:37:18 --> URI Class Initialized
INFO - 2025-05-03 15:37:18 --> Router Class Initialized
INFO - 2025-05-03 15:37:18 --> Output Class Initialized
INFO - 2025-05-03 15:37:18 --> Security Class Initialized
DEBUG - 2025-05-03 15:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:37:18 --> Input Class Initialized
INFO - 2025-05-03 15:37:18 --> Language Class Initialized
INFO - 2025-05-03 15:37:18 --> Loader Class Initialized
INFO - 2025-05-03 15:37:18 --> Helper loaded: form_helper
INFO - 2025-05-03 15:37:18 --> Helper loaded: url_helper
INFO - 2025-05-03 15:37:18 --> Database Driver Class Initialized
INFO - 2025-05-03 15:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:37:18 --> Form Validation Class Initialized
INFO - 2025-05-03 15:37:18 --> Controller Class Initialized
DEBUG - 2025-05-03 15:37:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 15:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 15:37:18 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 15:37:18 --> Config Class Initialized
INFO - 2025-05-03 15:37:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:37:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:37:18 --> Utf8 Class Initialized
INFO - 2025-05-03 15:37:18 --> URI Class Initialized
INFO - 2025-05-03 15:37:18 --> Router Class Initialized
INFO - 2025-05-03 15:37:18 --> Output Class Initialized
INFO - 2025-05-03 15:37:18 --> Security Class Initialized
DEBUG - 2025-05-03 15:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:37:18 --> Input Class Initialized
INFO - 2025-05-03 15:37:18 --> Language Class Initialized
INFO - 2025-05-03 15:37:18 --> Loader Class Initialized
INFO - 2025-05-03 15:37:18 --> Helper loaded: form_helper
INFO - 2025-05-03 15:37:18 --> Helper loaded: url_helper
INFO - 2025-05-03 15:37:18 --> Database Driver Class Initialized
INFO - 2025-05-03 15:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:37:18 --> Form Validation Class Initialized
INFO - 2025-05-03 15:37:18 --> Controller Class Initialized
DEBUG - 2025-05-03 15:37:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 15:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 15:37:18 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 15:37:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 15:37:18 --> Final output sent to browser
DEBUG - 2025-05-03 15:37:18 --> Total execution time: 0.0337
INFO - 2025-05-03 15:37:27 --> Config Class Initialized
INFO - 2025-05-03 15:37:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:37:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:37:27 --> Utf8 Class Initialized
INFO - 2025-05-03 15:37:27 --> URI Class Initialized
INFO - 2025-05-03 15:37:27 --> Router Class Initialized
INFO - 2025-05-03 15:37:27 --> Output Class Initialized
INFO - 2025-05-03 15:37:27 --> Security Class Initialized
DEBUG - 2025-05-03 15:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:37:27 --> Input Class Initialized
INFO - 2025-05-03 15:37:27 --> Language Class Initialized
INFO - 2025-05-03 15:37:27 --> Loader Class Initialized
INFO - 2025-05-03 15:37:27 --> Helper loaded: form_helper
INFO - 2025-05-03 15:37:27 --> Helper loaded: url_helper
INFO - 2025-05-03 15:37:27 --> Database Driver Class Initialized
INFO - 2025-05-03 15:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:37:27 --> Form Validation Class Initialized
INFO - 2025-05-03 15:37:27 --> Controller Class Initialized
INFO - 2025-05-03 15:37:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:37:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:37:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:37:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 15:37:27 --> Final output sent to browser
DEBUG - 2025-05-03 15:37:27 --> Total execution time: 0.0357
INFO - 2025-05-03 15:37:33 --> Config Class Initialized
INFO - 2025-05-03 15:37:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:37:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:37:33 --> Utf8 Class Initialized
INFO - 2025-05-03 15:37:33 --> URI Class Initialized
INFO - 2025-05-03 15:37:33 --> Router Class Initialized
INFO - 2025-05-03 15:37:33 --> Output Class Initialized
INFO - 2025-05-03 15:37:33 --> Security Class Initialized
DEBUG - 2025-05-03 15:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:37:33 --> Input Class Initialized
INFO - 2025-05-03 15:37:33 --> Language Class Initialized
INFO - 2025-05-03 15:37:33 --> Loader Class Initialized
INFO - 2025-05-03 15:37:33 --> Helper loaded: form_helper
INFO - 2025-05-03 15:37:33 --> Helper loaded: url_helper
INFO - 2025-05-03 15:37:33 --> Database Driver Class Initialized
INFO - 2025-05-03 15:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:37:33 --> Form Validation Class Initialized
INFO - 2025-05-03 15:37:33 --> Controller Class Initialized
INFO - 2025-05-03 15:37:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:37:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:37:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:37:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-03 15:37:33 --> Final output sent to browser
DEBUG - 2025-05-03 15:37:33 --> Total execution time: 0.0382
INFO - 2025-05-03 15:37:36 --> Config Class Initialized
INFO - 2025-05-03 15:37:36 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:37:36 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:37:36 --> Utf8 Class Initialized
INFO - 2025-05-03 15:37:36 --> URI Class Initialized
INFO - 2025-05-03 15:37:36 --> Router Class Initialized
INFO - 2025-05-03 15:37:36 --> Output Class Initialized
INFO - 2025-05-03 15:37:36 --> Security Class Initialized
DEBUG - 2025-05-03 15:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:37:36 --> Input Class Initialized
INFO - 2025-05-03 15:37:36 --> Language Class Initialized
INFO - 2025-05-03 15:37:36 --> Loader Class Initialized
INFO - 2025-05-03 15:37:36 --> Helper loaded: form_helper
INFO - 2025-05-03 15:37:36 --> Helper loaded: url_helper
INFO - 2025-05-03 15:37:36 --> Database Driver Class Initialized
INFO - 2025-05-03 15:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:37:36 --> Form Validation Class Initialized
INFO - 2025-05-03 15:37:36 --> Controller Class Initialized
INFO - 2025-05-03 15:37:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:37:36 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:37:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:37:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 15:37:36 --> Final output sent to browser
DEBUG - 2025-05-03 15:37:36 --> Total execution time: 0.0397
INFO - 2025-05-03 15:37:48 --> Config Class Initialized
INFO - 2025-05-03 15:37:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:37:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:37:48 --> Utf8 Class Initialized
INFO - 2025-05-03 15:37:48 --> URI Class Initialized
INFO - 2025-05-03 15:37:48 --> Router Class Initialized
INFO - 2025-05-03 15:37:48 --> Output Class Initialized
INFO - 2025-05-03 15:37:48 --> Security Class Initialized
DEBUG - 2025-05-03 15:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:37:48 --> Input Class Initialized
INFO - 2025-05-03 15:37:48 --> Language Class Initialized
INFO - 2025-05-03 15:37:48 --> Loader Class Initialized
INFO - 2025-05-03 15:37:48 --> Helper loaded: form_helper
INFO - 2025-05-03 15:37:48 --> Helper loaded: url_helper
INFO - 2025-05-03 15:37:48 --> Database Driver Class Initialized
INFO - 2025-05-03 15:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:37:48 --> Form Validation Class Initialized
INFO - 2025-05-03 15:37:48 --> Controller Class Initialized
INFO - 2025-05-03 15:37:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:37:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:37:48 --> Final output sent to browser
DEBUG - 2025-05-03 15:37:48 --> Total execution time: 0.0778
INFO - 2025-05-03 15:38:59 --> Config Class Initialized
INFO - 2025-05-03 15:38:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:38:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:38:59 --> Utf8 Class Initialized
INFO - 2025-05-03 15:38:59 --> URI Class Initialized
DEBUG - 2025-05-03 15:38:59 --> No URI present. Default controller set.
INFO - 2025-05-03 15:38:59 --> Router Class Initialized
INFO - 2025-05-03 15:38:59 --> Output Class Initialized
INFO - 2025-05-03 15:38:59 --> Security Class Initialized
DEBUG - 2025-05-03 15:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:38:59 --> Input Class Initialized
INFO - 2025-05-03 15:38:59 --> Language Class Initialized
INFO - 2025-05-03 15:38:59 --> Loader Class Initialized
INFO - 2025-05-03 15:38:59 --> Helper loaded: form_helper
INFO - 2025-05-03 15:38:59 --> Helper loaded: url_helper
INFO - 2025-05-03 15:38:59 --> Database Driver Class Initialized
INFO - 2025-05-03 15:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:38:59 --> Form Validation Class Initialized
INFO - 2025-05-03 15:38:59 --> Controller Class Initialized
INFO - 2025-05-03 15:38:59 --> Final output sent to browser
DEBUG - 2025-05-03 15:38:59 --> Total execution time: 0.0322
INFO - 2025-05-03 15:39:03 --> Config Class Initialized
INFO - 2025-05-03 15:39:03 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:39:03 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:39:03 --> Utf8 Class Initialized
INFO - 2025-05-03 15:39:03 --> URI Class Initialized
INFO - 2025-05-03 15:39:03 --> Router Class Initialized
INFO - 2025-05-03 15:39:03 --> Output Class Initialized
INFO - 2025-05-03 15:39:03 --> Security Class Initialized
DEBUG - 2025-05-03 15:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:39:03 --> Input Class Initialized
INFO - 2025-05-03 15:39:03 --> Language Class Initialized
INFO - 2025-05-03 15:39:03 --> Loader Class Initialized
INFO - 2025-05-03 15:39:03 --> Helper loaded: form_helper
INFO - 2025-05-03 15:39:03 --> Helper loaded: url_helper
INFO - 2025-05-03 15:39:03 --> Database Driver Class Initialized
INFO - 2025-05-03 15:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:39:03 --> Form Validation Class Initialized
INFO - 2025-05-03 15:39:03 --> Controller Class Initialized
INFO - 2025-05-03 15:39:03 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:39:03 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:39:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:39:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 15:39:03 --> Final output sent to browser
DEBUG - 2025-05-03 15:39:03 --> Total execution time: 0.0391
INFO - 2025-05-03 15:39:30 --> Config Class Initialized
INFO - 2025-05-03 15:39:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:39:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:39:30 --> Utf8 Class Initialized
INFO - 2025-05-03 15:39:30 --> URI Class Initialized
INFO - 2025-05-03 15:39:30 --> Router Class Initialized
INFO - 2025-05-03 15:39:30 --> Output Class Initialized
INFO - 2025-05-03 15:39:30 --> Security Class Initialized
DEBUG - 2025-05-03 15:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:39:30 --> Input Class Initialized
INFO - 2025-05-03 15:39:30 --> Language Class Initialized
INFO - 2025-05-03 15:39:30 --> Loader Class Initialized
INFO - 2025-05-03 15:39:30 --> Helper loaded: form_helper
INFO - 2025-05-03 15:39:30 --> Helper loaded: url_helper
INFO - 2025-05-03 15:39:30 --> Database Driver Class Initialized
INFO - 2025-05-03 15:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:39:30 --> Form Validation Class Initialized
INFO - 2025-05-03 15:39:30 --> Controller Class Initialized
INFO - 2025-05-03 15:39:30 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:39:30 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:39:30 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:39:30 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 15:39:30 --> Final output sent to browser
DEBUG - 2025-05-03 15:39:30 --> Total execution time: 0.0676
INFO - 2025-05-03 15:39:33 --> Config Class Initialized
INFO - 2025-05-03 15:39:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:39:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:39:33 --> Utf8 Class Initialized
INFO - 2025-05-03 15:39:33 --> URI Class Initialized
INFO - 2025-05-03 15:39:33 --> Router Class Initialized
INFO - 2025-05-03 15:39:33 --> Output Class Initialized
INFO - 2025-05-03 15:39:33 --> Security Class Initialized
DEBUG - 2025-05-03 15:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:39:33 --> Input Class Initialized
INFO - 2025-05-03 15:39:33 --> Language Class Initialized
INFO - 2025-05-03 15:39:33 --> Loader Class Initialized
INFO - 2025-05-03 15:39:33 --> Helper loaded: form_helper
INFO - 2025-05-03 15:39:33 --> Helper loaded: url_helper
INFO - 2025-05-03 15:39:33 --> Database Driver Class Initialized
INFO - 2025-05-03 15:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:39:33 --> Form Validation Class Initialized
INFO - 2025-05-03 15:39:33 --> Controller Class Initialized
INFO - 2025-05-03 15:39:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:39:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:39:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:39:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-03 15:39:33 --> Final output sent to browser
DEBUG - 2025-05-03 15:39:33 --> Total execution time: 0.0389
INFO - 2025-05-03 15:40:58 --> Config Class Initialized
INFO - 2025-05-03 15:40:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:40:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:40:58 --> Utf8 Class Initialized
INFO - 2025-05-03 15:40:58 --> URI Class Initialized
INFO - 2025-05-03 15:40:58 --> Router Class Initialized
INFO - 2025-05-03 15:40:58 --> Output Class Initialized
INFO - 2025-05-03 15:40:58 --> Security Class Initialized
DEBUG - 2025-05-03 15:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:40:58 --> Input Class Initialized
INFO - 2025-05-03 15:40:58 --> Language Class Initialized
INFO - 2025-05-03 15:40:58 --> Loader Class Initialized
INFO - 2025-05-03 15:40:58 --> Helper loaded: form_helper
INFO - 2025-05-03 15:40:58 --> Helper loaded: url_helper
INFO - 2025-05-03 15:40:58 --> Database Driver Class Initialized
INFO - 2025-05-03 15:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:40:58 --> Form Validation Class Initialized
INFO - 2025-05-03 15:40:58 --> Controller Class Initialized
INFO - 2025-05-03 15:40:58 --> Config Class Initialized
INFO - 2025-05-03 15:40:58 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:40:58 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:40:58 --> Utf8 Class Initialized
INFO - 2025-05-03 15:40:58 --> URI Class Initialized
INFO - 2025-05-03 15:40:58 --> Router Class Initialized
INFO - 2025-05-03 15:40:58 --> Output Class Initialized
INFO - 2025-05-03 15:40:58 --> Security Class Initialized
DEBUG - 2025-05-03 15:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:40:58 --> Input Class Initialized
INFO - 2025-05-03 15:40:58 --> Language Class Initialized
INFO - 2025-05-03 15:40:58 --> Loader Class Initialized
INFO - 2025-05-03 15:40:58 --> Helper loaded: form_helper
INFO - 2025-05-03 15:40:58 --> Helper loaded: url_helper
INFO - 2025-05-03 15:40:58 --> Database Driver Class Initialized
INFO - 2025-05-03 15:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:40:58 --> Form Validation Class Initialized
INFO - 2025-05-03 15:40:58 --> Controller Class Initialized
INFO - 2025-05-03 15:40:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 15:40:58 --> Final output sent to browser
DEBUG - 2025-05-03 15:40:58 --> Total execution time: 0.0286
INFO - 2025-05-03 15:41:39 --> Config Class Initialized
INFO - 2025-05-03 15:41:39 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:41:39 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:41:39 --> Utf8 Class Initialized
INFO - 2025-05-03 15:41:39 --> URI Class Initialized
INFO - 2025-05-03 15:41:39 --> Router Class Initialized
INFO - 2025-05-03 15:41:39 --> Output Class Initialized
INFO - 2025-05-03 15:41:39 --> Security Class Initialized
DEBUG - 2025-05-03 15:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:41:39 --> Input Class Initialized
INFO - 2025-05-03 15:41:39 --> Language Class Initialized
INFO - 2025-05-03 15:41:39 --> Loader Class Initialized
INFO - 2025-05-03 15:41:39 --> Helper loaded: form_helper
INFO - 2025-05-03 15:41:39 --> Helper loaded: url_helper
INFO - 2025-05-03 15:41:39 --> Database Driver Class Initialized
INFO - 2025-05-03 15:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:41:39 --> Form Validation Class Initialized
INFO - 2025-05-03 15:41:39 --> Controller Class Initialized
INFO - 2025-05-03 15:41:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:41:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:41:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:41:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 15:41:39 --> Final output sent to browser
DEBUG - 2025-05-03 15:41:39 --> Total execution time: 0.0439
INFO - 2025-05-03 15:43:44 --> Config Class Initialized
INFO - 2025-05-03 15:43:44 --> Hooks Class Initialized
DEBUG - 2025-05-03 15:43:44 --> UTF-8 Support Enabled
INFO - 2025-05-03 15:43:44 --> Utf8 Class Initialized
INFO - 2025-05-03 15:43:44 --> URI Class Initialized
INFO - 2025-05-03 15:43:44 --> Router Class Initialized
INFO - 2025-05-03 15:43:44 --> Output Class Initialized
INFO - 2025-05-03 15:43:44 --> Security Class Initialized
DEBUG - 2025-05-03 15:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 15:43:44 --> Input Class Initialized
INFO - 2025-05-03 15:43:44 --> Language Class Initialized
INFO - 2025-05-03 15:43:44 --> Loader Class Initialized
INFO - 2025-05-03 15:43:44 --> Helper loaded: form_helper
INFO - 2025-05-03 15:43:44 --> Helper loaded: url_helper
INFO - 2025-05-03 15:43:44 --> Database Driver Class Initialized
INFO - 2025-05-03 15:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 15:43:44 --> Form Validation Class Initialized
INFO - 2025-05-03 15:43:44 --> Controller Class Initialized
INFO - 2025-05-03 15:43:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 15:43:44 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 15:43:44 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 15:43:44 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 15:43:44 --> Final output sent to browser
DEBUG - 2025-05-03 15:43:44 --> Total execution time: 0.0404
INFO - 2025-05-03 16:13:20 --> Config Class Initialized
INFO - 2025-05-03 16:13:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 16:13:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 16:13:20 --> Utf8 Class Initialized
INFO - 2025-05-03 16:13:20 --> URI Class Initialized
INFO - 2025-05-03 16:13:20 --> Router Class Initialized
INFO - 2025-05-03 16:13:20 --> Output Class Initialized
INFO - 2025-05-03 16:13:20 --> Security Class Initialized
DEBUG - 2025-05-03 16:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 16:13:20 --> Input Class Initialized
INFO - 2025-05-03 16:13:20 --> Language Class Initialized
INFO - 2025-05-03 16:13:20 --> Loader Class Initialized
INFO - 2025-05-03 16:13:20 --> Helper loaded: form_helper
INFO - 2025-05-03 16:13:20 --> Helper loaded: url_helper
INFO - 2025-05-03 16:13:20 --> Database Driver Class Initialized
INFO - 2025-05-03 16:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 16:13:20 --> Form Validation Class Initialized
INFO - 2025-05-03 16:13:20 --> Controller Class Initialized
INFO - 2025-05-03 16:13:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 16:13:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 16:13:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 16:13:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-03 16:13:20 --> Final output sent to browser
DEBUG - 2025-05-03 16:13:20 --> Total execution time: 0.0724
INFO - 2025-05-03 16:13:22 --> Config Class Initialized
INFO - 2025-05-03 16:13:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 16:13:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 16:13:22 --> Utf8 Class Initialized
INFO - 2025-05-03 16:13:22 --> URI Class Initialized
INFO - 2025-05-03 16:13:22 --> Router Class Initialized
INFO - 2025-05-03 16:13:22 --> Output Class Initialized
INFO - 2025-05-03 16:13:22 --> Security Class Initialized
DEBUG - 2025-05-03 16:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 16:13:22 --> Input Class Initialized
INFO - 2025-05-03 16:13:22 --> Language Class Initialized
INFO - 2025-05-03 16:13:22 --> Loader Class Initialized
INFO - 2025-05-03 16:13:22 --> Helper loaded: form_helper
INFO - 2025-05-03 16:13:22 --> Helper loaded: url_helper
INFO - 2025-05-03 16:13:22 --> Database Driver Class Initialized
INFO - 2025-05-03 16:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 16:13:22 --> Form Validation Class Initialized
INFO - 2025-05-03 16:13:22 --> Controller Class Initialized
INFO - 2025-05-03 16:13:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 16:13:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 16:13:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 16:13:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 16:13:22 --> Final output sent to browser
DEBUG - 2025-05-03 16:13:22 --> Total execution time: 0.0420
INFO - 2025-05-03 16:13:24 --> Config Class Initialized
INFO - 2025-05-03 16:13:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 16:13:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 16:13:24 --> Utf8 Class Initialized
INFO - 2025-05-03 16:13:24 --> URI Class Initialized
INFO - 2025-05-03 16:13:24 --> Router Class Initialized
INFO - 2025-05-03 16:13:24 --> Output Class Initialized
INFO - 2025-05-03 16:13:24 --> Security Class Initialized
DEBUG - 2025-05-03 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 16:13:24 --> Input Class Initialized
INFO - 2025-05-03 16:13:24 --> Language Class Initialized
INFO - 2025-05-03 16:13:24 --> Loader Class Initialized
INFO - 2025-05-03 16:13:24 --> Helper loaded: form_helper
INFO - 2025-05-03 16:13:24 --> Helper loaded: url_helper
INFO - 2025-05-03 16:13:24 --> Database Driver Class Initialized
INFO - 2025-05-03 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 16:13:24 --> Form Validation Class Initialized
INFO - 2025-05-03 16:13:24 --> Controller Class Initialized
INFO - 2025-05-03 16:13:24 --> Config Class Initialized
INFO - 2025-05-03 16:13:24 --> Hooks Class Initialized
DEBUG - 2025-05-03 16:13:24 --> UTF-8 Support Enabled
INFO - 2025-05-03 16:13:24 --> Utf8 Class Initialized
INFO - 2025-05-03 16:13:24 --> URI Class Initialized
INFO - 2025-05-03 16:13:24 --> Router Class Initialized
INFO - 2025-05-03 16:13:24 --> Output Class Initialized
INFO - 2025-05-03 16:13:24 --> Security Class Initialized
DEBUG - 2025-05-03 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 16:13:24 --> Input Class Initialized
INFO - 2025-05-03 16:13:24 --> Language Class Initialized
INFO - 2025-05-03 16:13:24 --> Loader Class Initialized
INFO - 2025-05-03 16:13:24 --> Helper loaded: form_helper
INFO - 2025-05-03 16:13:24 --> Helper loaded: url_helper
INFO - 2025-05-03 16:13:24 --> Database Driver Class Initialized
INFO - 2025-05-03 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 16:13:24 --> Form Validation Class Initialized
INFO - 2025-05-03 16:13:24 --> Controller Class Initialized
INFO - 2025-05-03 16:13:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 16:13:24 --> Final output sent to browser
DEBUG - 2025-05-03 16:13:24 --> Total execution time: 0.0318
INFO - 2025-05-03 19:29:14 --> Config Class Initialized
INFO - 2025-05-03 19:29:14 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:14 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:14 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:14 --> URI Class Initialized
INFO - 2025-05-03 19:29:14 --> Router Class Initialized
INFO - 2025-05-03 19:29:14 --> Output Class Initialized
INFO - 2025-05-03 19:29:14 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:14 --> Input Class Initialized
INFO - 2025-05-03 19:29:14 --> Language Class Initialized
ERROR - 2025-05-03 19:29:14 --> 404 Page Not Found: Wp-content/uploads
INFO - 2025-05-03 19:29:16 --> Config Class Initialized
INFO - 2025-05-03 19:29:16 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:16 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:16 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:16 --> URI Class Initialized
INFO - 2025-05-03 19:29:16 --> Router Class Initialized
INFO - 2025-05-03 19:29:16 --> Output Class Initialized
INFO - 2025-05-03 19:29:16 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:16 --> Input Class Initialized
INFO - 2025-05-03 19:29:16 --> Language Class Initialized
ERROR - 2025-05-03 19:29:16 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-05-03 19:29:18 --> Config Class Initialized
INFO - 2025-05-03 19:29:18 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:18 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:18 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:18 --> URI Class Initialized
INFO - 2025-05-03 19:29:18 --> Router Class Initialized
INFO - 2025-05-03 19:29:18 --> Output Class Initialized
INFO - 2025-05-03 19:29:18 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:18 --> Input Class Initialized
INFO - 2025-05-03 19:29:18 --> Language Class Initialized
ERROR - 2025-05-03 19:29:18 --> 404 Page Not Found: Defaultsphp/index
INFO - 2025-05-03 19:29:19 --> Config Class Initialized
INFO - 2025-05-03 19:29:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:19 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:19 --> URI Class Initialized
INFO - 2025-05-03 19:29:19 --> Router Class Initialized
INFO - 2025-05-03 19:29:19 --> Output Class Initialized
INFO - 2025-05-03 19:29:19 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:19 --> Input Class Initialized
INFO - 2025-05-03 19:29:19 --> Language Class Initialized
ERROR - 2025-05-03 19:29:19 --> 404 Page Not Found: Dropdownphp/index
INFO - 2025-05-03 19:29:21 --> Config Class Initialized
INFO - 2025-05-03 19:29:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:21 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:21 --> URI Class Initialized
INFO - 2025-05-03 19:29:21 --> Router Class Initialized
INFO - 2025-05-03 19:29:21 --> Output Class Initialized
INFO - 2025-05-03 19:29:21 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:21 --> Input Class Initialized
INFO - 2025-05-03 19:29:21 --> Language Class Initialized
ERROR - 2025-05-03 19:29:21 --> 404 Page Not Found: Wp-admin/user
INFO - 2025-05-03 19:29:22 --> Config Class Initialized
INFO - 2025-05-03 19:29:22 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:22 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:22 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:22 --> URI Class Initialized
INFO - 2025-05-03 19:29:22 --> Router Class Initialized
INFO - 2025-05-03 19:29:22 --> Output Class Initialized
INFO - 2025-05-03 19:29:22 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:22 --> Input Class Initialized
INFO - 2025-05-03 19:29:22 --> Language Class Initialized
ERROR - 2025-05-03 19:29:22 --> 404 Page Not Found: Simplephp/index
INFO - 2025-05-03 19:29:23 --> Config Class Initialized
INFO - 2025-05-03 19:29:23 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:23 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:23 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:23 --> URI Class Initialized
INFO - 2025-05-03 19:29:23 --> Router Class Initialized
INFO - 2025-05-03 19:29:23 --> Output Class Initialized
INFO - 2025-05-03 19:29:23 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:23 --> Input Class Initialized
INFO - 2025-05-03 19:29:23 --> Language Class Initialized
ERROR - 2025-05-03 19:29:23 --> 404 Page Not Found: Wp-includes/install.php
INFO - 2025-05-03 19:29:25 --> Config Class Initialized
INFO - 2025-05-03 19:29:25 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:25 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:25 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:25 --> URI Class Initialized
INFO - 2025-05-03 19:29:25 --> Router Class Initialized
INFO - 2025-05-03 19:29:25 --> Output Class Initialized
INFO - 2025-05-03 19:29:25 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:25 --> Input Class Initialized
INFO - 2025-05-03 19:29:25 --> Language Class Initialized
ERROR - 2025-05-03 19:29:25 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-05-03 19:29:26 --> Config Class Initialized
INFO - 2025-05-03 19:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:26 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:26 --> URI Class Initialized
INFO - 2025-05-03 19:29:26 --> Router Class Initialized
INFO - 2025-05-03 19:29:26 --> Output Class Initialized
INFO - 2025-05-03 19:29:26 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:26 --> Input Class Initialized
INFO - 2025-05-03 19:29:26 --> Language Class Initialized
ERROR - 2025-05-03 19:29:26 --> 404 Page Not Found: Installphp/index
INFO - 2025-05-03 19:29:27 --> Config Class Initialized
INFO - 2025-05-03 19:29:27 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:27 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:27 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:27 --> URI Class Initialized
INFO - 2025-05-03 19:29:27 --> Router Class Initialized
INFO - 2025-05-03 19:29:27 --> Output Class Initialized
INFO - 2025-05-03 19:29:27 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:27 --> Input Class Initialized
INFO - 2025-05-03 19:29:27 --> Language Class Initialized
ERROR - 2025-05-03 19:29:27 --> 404 Page Not Found: Wp-content/uploads
INFO - 2025-05-03 19:29:30 --> Config Class Initialized
INFO - 2025-05-03 19:29:30 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:30 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:30 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:30 --> URI Class Initialized
INFO - 2025-05-03 19:29:30 --> Router Class Initialized
INFO - 2025-05-03 19:29:30 --> Output Class Initialized
INFO - 2025-05-03 19:29:30 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:30 --> Input Class Initialized
INFO - 2025-05-03 19:29:30 --> Language Class Initialized
ERROR - 2025-05-03 19:29:30 --> 404 Page Not Found: Wp-admin/install.php
INFO - 2025-05-03 19:29:33 --> Config Class Initialized
INFO - 2025-05-03 19:29:33 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:33 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:33 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:33 --> URI Class Initialized
INFO - 2025-05-03 19:29:33 --> Router Class Initialized
INFO - 2025-05-03 19:29:33 --> Output Class Initialized
INFO - 2025-05-03 19:29:33 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:33 --> Input Class Initialized
INFO - 2025-05-03 19:29:33 --> Language Class Initialized
ERROR - 2025-05-03 19:29:33 --> 404 Page Not Found: Aboutphp/index
INFO - 2025-05-03 19:29:35 --> Config Class Initialized
INFO - 2025-05-03 19:29:35 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:35 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:35 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:35 --> URI Class Initialized
INFO - 2025-05-03 19:29:35 --> Router Class Initialized
INFO - 2025-05-03 19:29:35 --> Output Class Initialized
INFO - 2025-05-03 19:29:35 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:35 --> Input Class Initialized
INFO - 2025-05-03 19:29:35 --> Language Class Initialized
ERROR - 2025-05-03 19:29:35 --> 404 Page Not Found: Simplephp/index
INFO - 2025-05-03 19:29:38 --> Config Class Initialized
INFO - 2025-05-03 19:29:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:29:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:29:38 --> Utf8 Class Initialized
INFO - 2025-05-03 19:29:38 --> URI Class Initialized
INFO - 2025-05-03 19:29:38 --> Router Class Initialized
INFO - 2025-05-03 19:29:38 --> Output Class Initialized
INFO - 2025-05-03 19:29:38 --> Security Class Initialized
DEBUG - 2025-05-03 19:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:29:38 --> Input Class Initialized
INFO - 2025-05-03 19:29:38 --> Language Class Initialized
ERROR - 2025-05-03 19:29:38 --> 404 Page Not Found: Dropdownphp/index
INFO - 2025-05-03 19:36:59 --> Config Class Initialized
INFO - 2025-05-03 19:36:59 --> Hooks Class Initialized
DEBUG - 2025-05-03 19:36:59 --> UTF-8 Support Enabled
INFO - 2025-05-03 19:36:59 --> Utf8 Class Initialized
INFO - 2025-05-03 19:36:59 --> URI Class Initialized
DEBUG - 2025-05-03 19:36:59 --> No URI present. Default controller set.
INFO - 2025-05-03 19:36:59 --> Router Class Initialized
INFO - 2025-05-03 19:36:59 --> Output Class Initialized
INFO - 2025-05-03 19:36:59 --> Security Class Initialized
DEBUG - 2025-05-03 19:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 19:36:59 --> Input Class Initialized
INFO - 2025-05-03 19:36:59 --> Language Class Initialized
INFO - 2025-05-03 19:36:59 --> Loader Class Initialized
INFO - 2025-05-03 19:36:59 --> Helper loaded: form_helper
INFO - 2025-05-03 19:36:59 --> Helper loaded: url_helper
INFO - 2025-05-03 19:36:59 --> Database Driver Class Initialized
INFO - 2025-05-03 19:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 19:36:59 --> Form Validation Class Initialized
INFO - 2025-05-03 19:36:59 --> Controller Class Initialized
INFO - 2025-05-03 19:36:59 --> Final output sent to browser
DEBUG - 2025-05-03 19:36:59 --> Total execution time: 0.0405
INFO - 2025-05-03 21:22:50 --> Config Class Initialized
INFO - 2025-05-03 21:22:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:22:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:22:50 --> Utf8 Class Initialized
INFO - 2025-05-03 21:22:50 --> URI Class Initialized
INFO - 2025-05-03 21:22:50 --> Router Class Initialized
INFO - 2025-05-03 21:22:50 --> Output Class Initialized
INFO - 2025-05-03 21:22:50 --> Security Class Initialized
DEBUG - 2025-05-03 21:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:22:50 --> Input Class Initialized
INFO - 2025-05-03 21:22:50 --> Language Class Initialized
INFO - 2025-05-03 21:22:50 --> Loader Class Initialized
INFO - 2025-05-03 21:22:50 --> Helper loaded: form_helper
INFO - 2025-05-03 21:22:50 --> Helper loaded: url_helper
INFO - 2025-05-03 21:22:50 --> Database Driver Class Initialized
INFO - 2025-05-03 21:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 21:22:50 --> Form Validation Class Initialized
INFO - 2025-05-03 21:22:50 --> Controller Class Initialized
INFO - 2025-05-03 21:22:50 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-03 21:22:50 --> Final output sent to browser
DEBUG - 2025-05-03 21:22:50 --> Total execution time: 0.0290
INFO - 2025-05-03 21:22:50 --> Config Class Initialized
INFO - 2025-05-03 21:22:50 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:22:50 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:22:50 --> Utf8 Class Initialized
INFO - 2025-05-03 21:22:50 --> URI Class Initialized
INFO - 2025-05-03 21:22:50 --> Router Class Initialized
INFO - 2025-05-03 21:22:50 --> Output Class Initialized
INFO - 2025-05-03 21:22:50 --> Security Class Initialized
DEBUG - 2025-05-03 21:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:22:50 --> Input Class Initialized
INFO - 2025-05-03 21:22:50 --> Language Class Initialized
ERROR - 2025-05-03 21:22:50 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 21:22:54 --> Config Class Initialized
INFO - 2025-05-03 21:22:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:22:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:22:54 --> Utf8 Class Initialized
INFO - 2025-05-03 21:22:54 --> URI Class Initialized
INFO - 2025-05-03 21:22:54 --> Router Class Initialized
INFO - 2025-05-03 21:22:54 --> Output Class Initialized
INFO - 2025-05-03 21:22:54 --> Security Class Initialized
DEBUG - 2025-05-03 21:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:22:54 --> Input Class Initialized
INFO - 2025-05-03 21:22:54 --> Language Class Initialized
INFO - 2025-05-03 21:22:54 --> Loader Class Initialized
INFO - 2025-05-03 21:22:54 --> Helper loaded: form_helper
INFO - 2025-05-03 21:22:54 --> Helper loaded: url_helper
INFO - 2025-05-03 21:22:54 --> Database Driver Class Initialized
INFO - 2025-05-03 21:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 21:22:54 --> Form Validation Class Initialized
INFO - 2025-05-03 21:22:54 --> Controller Class Initialized
INFO - 2025-05-03 21:22:54 --> Config Class Initialized
INFO - 2025-05-03 21:22:54 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:22:54 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:22:54 --> Utf8 Class Initialized
INFO - 2025-05-03 21:22:54 --> URI Class Initialized
INFO - 2025-05-03 21:22:54 --> Router Class Initialized
INFO - 2025-05-03 21:22:54 --> Output Class Initialized
INFO - 2025-05-03 21:22:54 --> Security Class Initialized
DEBUG - 2025-05-03 21:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:22:54 --> Input Class Initialized
INFO - 2025-05-03 21:22:54 --> Language Class Initialized
INFO - 2025-05-03 21:22:54 --> Loader Class Initialized
INFO - 2025-05-03 21:22:54 --> Helper loaded: form_helper
INFO - 2025-05-03 21:22:54 --> Helper loaded: url_helper
INFO - 2025-05-03 21:22:54 --> Database Driver Class Initialized
INFO - 2025-05-03 21:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 21:22:54 --> Form Validation Class Initialized
INFO - 2025-05-03 21:22:54 --> Controller Class Initialized
INFO - 2025-05-03 21:22:54 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-03 21:22:54 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-03 21:22:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-03 21:22:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-03 21:22:54 --> Final output sent to browser
DEBUG - 2025-05-03 21:22:54 --> Total execution time: 0.0326
INFO - 2025-05-03 21:23:57 --> Config Class Initialized
INFO - 2025-05-03 21:23:57 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:23:57 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:23:57 --> Utf8 Class Initialized
INFO - 2025-05-03 21:23:57 --> URI Class Initialized
INFO - 2025-05-03 21:23:57 --> Router Class Initialized
INFO - 2025-05-03 21:23:57 --> Output Class Initialized
INFO - 2025-05-03 21:23:57 --> Security Class Initialized
DEBUG - 2025-05-03 21:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:23:57 --> Input Class Initialized
INFO - 2025-05-03 21:23:57 --> Language Class Initialized
INFO - 2025-05-03 21:23:57 --> Loader Class Initialized
INFO - 2025-05-03 21:23:57 --> Helper loaded: form_helper
INFO - 2025-05-03 21:23:57 --> Helper loaded: url_helper
INFO - 2025-05-03 21:23:57 --> Database Driver Class Initialized
INFO - 2025-05-03 21:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 21:23:57 --> Form Validation Class Initialized
INFO - 2025-05-03 21:23:57 --> Controller Class Initialized
DEBUG - 2025-05-03 21:23:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 21:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 21:23:57 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-03 21:23:57 --> POST data: Array
(
    [nama_siswa] => Akhmad Lutfi ytytyt
    [jenis_kelamin] => L
    [tempat_lahir] => BATANG
    [tanggal_lahir] => 2025-05-19
    [tempat_tanggal_lahir] => BATANG, 19 Mei 2025
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [no_hp_siswa] => 085747110787
    [jalur_pendaftaran] => Prestasi
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 03
    [rw] => 03
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Ngebong, RT 03/RW 03, Banyuputih, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => SLTP Sederajat
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => ewewewe
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => mansbaa
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => mansaba
    [tanggal_lahir_db] => 2025-05-19
)

INFO - 2025-05-03 21:23:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-03 21:23:57 --> Generated registration number: A-2526/0160
DEBUG - 2025-05-03 21:23:57 --> Form data to save: Array
(
    [nama_siswa] => Akhmad Lutfi ytytyt
    [jenis_kelamin] => L
    [tempat_lahir] => BATANG
    [tanggal_lahir] => 2025-05-19
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Prestasi
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 03
    [rw] => 03
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => SLTP Sederajat
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => ewewewe
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => mansbaa
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => mansaba
    [tanggal_daftar] => 2025-05-03 21:23:57
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-03 21:23:57 --> Attempting to save data to pendaftaran table
DEBUG - 2025-05-03 21:23:57 --> Data: Array
(
    [nama_siswa] => Akhmad Lutfi ytytyt
    [jenis_kelamin] => L
    [tempat_lahir] => BATANG
    [tanggal_lahir] => 2025-05-19
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Prestasi
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 03
    [rw] => 03
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => SLTP Sederajat
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => ewewewe
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => mansbaa
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => mansaba
    [tanggal_daftar] => 2025-05-03 21:23:57
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-03 21:23:57 --> Data inserted successfully with ID: 170
INFO - 2025-05-03 21:27:13 --> Config Class Initialized
INFO - 2025-05-03 21:27:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:27:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:27:13 --> Utf8 Class Initialized
INFO - 2025-05-03 21:27:13 --> URI Class Initialized
INFO - 2025-05-03 21:27:13 --> Router Class Initialized
INFO - 2025-05-03 21:27:13 --> Output Class Initialized
INFO - 2025-05-03 21:27:13 --> Security Class Initialized
DEBUG - 2025-05-03 21:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:27:13 --> Input Class Initialized
INFO - 2025-05-03 21:27:13 --> Language Class Initialized
INFO - 2025-05-03 21:27:13 --> Loader Class Initialized
INFO - 2025-05-03 21:27:13 --> Helper loaded: form_helper
INFO - 2025-05-03 21:27:13 --> Helper loaded: url_helper
INFO - 2025-05-03 21:27:13 --> Database Driver Class Initialized
INFO - 2025-05-03 21:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 21:27:13 --> Form Validation Class Initialized
INFO - 2025-05-03 21:27:13 --> Controller Class Initialized
DEBUG - 2025-05-03 21:27:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 21:27:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 21:27:13 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-03 21:27:13 --> POST data: Array
(
    [nama_siswa] => Akhmad Lutfi ytytyt
    [jenis_kelamin] => L
    [tempat_lahir] => BATANG
    [tanggal_lahir] => 2025-05-19
    [tempat_tanggal_lahir] => BATANG, 19 Mei 2025
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [no_hp_siswa] => 085747110787
    [jalur_pendaftaran] => Prestasi
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 03
    [rw] => 03
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Ngebong, RT 03/RW 03, Banyuputih, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => SLTP Sederajat
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => ewewewe
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => mansbaa
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => mansaba
    [tanggal_lahir_db] => 2025-05-19
)

INFO - 2025-05-03 21:27:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-03 21:27:13 --> Generated registration number: A-2526/0161
DEBUG - 2025-05-03 21:27:13 --> Form data to save: Array
(
    [nama_siswa] => Akhmad Lutfi ytytyt
    [jenis_kelamin] => L
    [tempat_lahir] => BATANG
    [tanggal_lahir] => 2025-05-19
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Prestasi
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 03
    [rw] => 03
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => SLTP Sederajat
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => ewewewe
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => mansbaa
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => mansaba
    [tanggal_daftar] => 2025-05-03 21:27:13
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-03 21:27:13 --> Attempting to save data to pendaftaran table
DEBUG - 2025-05-03 21:27:13 --> Data: Array
(
    [nama_siswa] => Akhmad Lutfi ytytyt
    [jenis_kelamin] => L
    [tempat_lahir] => BATANG
    [tanggal_lahir] => 2025-05-19
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Prestasi
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 03
    [rw] => 03
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => SLTP Sederajat
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => ewewewe
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => mansbaa
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => mansaba
    [tanggal_daftar] => 2025-05-03 21:27:13
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-03 21:27:13 --> Data inserted successfully with ID: 171
INFO - 2025-05-03 21:28:28 --> Config Class Initialized
INFO - 2025-05-03 21:28:28 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:28:28 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:28:28 --> Utf8 Class Initialized
INFO - 2025-05-03 21:28:28 --> URI Class Initialized
INFO - 2025-05-03 21:28:28 --> Router Class Initialized
INFO - 2025-05-03 21:28:28 --> Output Class Initialized
INFO - 2025-05-03 21:28:28 --> Security Class Initialized
DEBUG - 2025-05-03 21:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:28:28 --> Input Class Initialized
INFO - 2025-05-03 21:28:28 --> Language Class Initialized
INFO - 2025-05-03 21:28:28 --> Loader Class Initialized
INFO - 2025-05-03 21:28:28 --> Helper loaded: form_helper
INFO - 2025-05-03 21:28:28 --> Helper loaded: url_helper
INFO - 2025-05-03 21:28:28 --> Database Driver Class Initialized
INFO - 2025-05-03 21:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 21:28:28 --> Form Validation Class Initialized
INFO - 2025-05-03 21:28:28 --> Controller Class Initialized
DEBUG - 2025-05-03 21:28:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 21:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 21:28:28 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-03 21:28:28 --> POST data: Array
(
    [nama_siswa] => Akhmad Lutfi fdfdfd
    [jenis_kelamin] => L
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2017-06-13
    [tempat_tanggal_lahir] => Batang, 13 Juni 2017
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [no_hp_siswa] => 085747110787
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 002
    [rw] => 02
    [desa] => Luwung
    [kecamatan] => Banyuputih 
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Ngebong, RT 002/RW 02, Luwung, Banyuputih , Batang, Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => aaaaa
    [pekerjaan_ibu] => ewewewe
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Dukuh Adiloko Desa Rowosari
    [tanggal_lahir_db] => 2017-06-13
)

INFO - 2025-05-03 21:28:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-03 21:28:28 --> Generated registration number: A-2526/0162
DEBUG - 2025-05-03 21:28:28 --> Form data to save: Array
(
    [nama_siswa] => Akhmad Lutfi fdfdfd
    [jenis_kelamin] => L
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2017-06-13
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 002
    [rw] => 02
    [desa] => Luwung
    [kecamatan] => Banyuputih 
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => aaaaa
    [pekerjaan_ibu] => ewewewe
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Dukuh Adiloko Desa Rowosari
    [tanggal_daftar] => 2025-05-03 21:28:28
    [status] => Baru
    [no_pendaftaran] => A-2526/0162
)

DEBUG - 2025-05-03 21:28:28 --> Attempting to save data to pendaftaran table
DEBUG - 2025-05-03 21:28:28 --> Data: Array
(
    [nama_siswa] => Akhmad Lutfi fdfdfd
    [jenis_kelamin] => L
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2017-06-13
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 002
    [rw] => 02
    [desa] => Luwung
    [kecamatan] => Banyuputih 
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => Tidak Sekolah
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => aaaaa
    [pekerjaan_ibu] => ewewewe
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Dukuh Adiloko Desa Rowosari
    [tanggal_daftar] => 2025-05-03 21:28:28
    [status] => Baru
    [no_pendaftaran] => A-2526/0162
)

DEBUG - 2025-05-03 21:28:28 --> Data inserted successfully with ID: 172
INFO - 2025-05-03 21:51:47 --> Config Class Initialized
INFO - 2025-05-03 21:51:47 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:51:47 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:51:47 --> Utf8 Class Initialized
INFO - 2025-05-03 21:51:47 --> URI Class Initialized
DEBUG - 2025-05-03 21:51:47 --> No URI present. Default controller set.
INFO - 2025-05-03 21:51:47 --> Router Class Initialized
INFO - 2025-05-03 21:51:47 --> Output Class Initialized
INFO - 2025-05-03 21:51:47 --> Security Class Initialized
DEBUG - 2025-05-03 21:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:51:47 --> Input Class Initialized
INFO - 2025-05-03 21:51:47 --> Language Class Initialized
INFO - 2025-05-03 21:51:47 --> Loader Class Initialized
INFO - 2025-05-03 21:51:47 --> Helper loaded: form_helper
INFO - 2025-05-03 21:51:47 --> Helper loaded: url_helper
INFO - 2025-05-03 21:51:47 --> Database Driver Class Initialized
INFO - 2025-05-03 21:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 21:51:47 --> Form Validation Class Initialized
INFO - 2025-05-03 21:51:47 --> Controller Class Initialized
INFO - 2025-05-03 21:51:47 --> Final output sent to browser
DEBUG - 2025-05-03 21:51:47 --> Total execution time: 0.0263
INFO - 2025-05-03 21:51:48 --> Config Class Initialized
INFO - 2025-05-03 21:51:48 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:51:48 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:51:49 --> Utf8 Class Initialized
INFO - 2025-05-03 21:51:49 --> URI Class Initialized
DEBUG - 2025-05-03 21:51:49 --> No URI present. Default controller set.
INFO - 2025-05-03 21:51:49 --> Router Class Initialized
INFO - 2025-05-03 21:51:49 --> Output Class Initialized
INFO - 2025-05-03 21:51:49 --> Security Class Initialized
DEBUG - 2025-05-03 21:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:51:49 --> Input Class Initialized
INFO - 2025-05-03 21:51:49 --> Language Class Initialized
INFO - 2025-05-03 21:51:49 --> Loader Class Initialized
INFO - 2025-05-03 21:51:49 --> Helper loaded: form_helper
INFO - 2025-05-03 21:51:49 --> Helper loaded: url_helper
INFO - 2025-05-03 21:51:49 --> Database Driver Class Initialized
INFO - 2025-05-03 21:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 21:51:49 --> Form Validation Class Initialized
INFO - 2025-05-03 21:51:49 --> Controller Class Initialized
INFO - 2025-05-03 21:51:49 --> Final output sent to browser
DEBUG - 2025-05-03 21:51:49 --> Total execution time: 0.0295
INFO - 2025-05-03 21:52:19 --> Config Class Initialized
INFO - 2025-05-03 21:52:19 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:52:19 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:52:19 --> Utf8 Class Initialized
INFO - 2025-05-03 21:52:19 --> URI Class Initialized
INFO - 2025-05-03 21:52:19 --> Router Class Initialized
INFO - 2025-05-03 21:52:19 --> Output Class Initialized
INFO - 2025-05-03 21:52:19 --> Security Class Initialized
DEBUG - 2025-05-03 21:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:52:19 --> Input Class Initialized
INFO - 2025-05-03 21:52:19 --> Language Class Initialized
INFO - 2025-05-03 21:52:19 --> Loader Class Initialized
INFO - 2025-05-03 21:52:19 --> Helper loaded: form_helper
INFO - 2025-05-03 21:52:19 --> Helper loaded: url_helper
INFO - 2025-05-03 21:52:19 --> Database Driver Class Initialized
INFO - 2025-05-03 21:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 21:52:19 --> Form Validation Class Initialized
INFO - 2025-05-03 21:52:19 --> Controller Class Initialized
DEBUG - 2025-05-03 21:52:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 21:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 21:52:19 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 21:52:19 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 21:52:19 --> Final output sent to browser
DEBUG - 2025-05-03 21:52:19 --> Total execution time: 0.0303
INFO - 2025-05-03 21:52:20 --> Config Class Initialized
INFO - 2025-05-03 21:52:20 --> Hooks Class Initialized
DEBUG - 2025-05-03 21:52:20 --> UTF-8 Support Enabled
INFO - 2025-05-03 21:52:20 --> Utf8 Class Initialized
INFO - 2025-05-03 21:52:20 --> URI Class Initialized
INFO - 2025-05-03 21:52:20 --> Router Class Initialized
INFO - 2025-05-03 21:52:20 --> Output Class Initialized
INFO - 2025-05-03 21:52:20 --> Security Class Initialized
DEBUG - 2025-05-03 21:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 21:52:20 --> Input Class Initialized
INFO - 2025-05-03 21:52:20 --> Language Class Initialized
ERROR - 2025-05-03 21:52:20 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 22:11:38 --> Config Class Initialized
INFO - 2025-05-03 22:11:38 --> Hooks Class Initialized
DEBUG - 2025-05-03 22:11:38 --> UTF-8 Support Enabled
INFO - 2025-05-03 22:11:38 --> Utf8 Class Initialized
INFO - 2025-05-03 22:11:38 --> URI Class Initialized
DEBUG - 2025-05-03 22:11:38 --> No URI present. Default controller set.
INFO - 2025-05-03 22:11:38 --> Router Class Initialized
INFO - 2025-05-03 22:11:38 --> Output Class Initialized
INFO - 2025-05-03 22:11:38 --> Security Class Initialized
DEBUG - 2025-05-03 22:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 22:11:38 --> Input Class Initialized
INFO - 2025-05-03 22:11:38 --> Language Class Initialized
INFO - 2025-05-03 22:11:38 --> Loader Class Initialized
INFO - 2025-05-03 22:11:38 --> Helper loaded: form_helper
INFO - 2025-05-03 22:11:38 --> Helper loaded: url_helper
INFO - 2025-05-03 22:11:38 --> Database Driver Class Initialized
INFO - 2025-05-03 22:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 22:11:38 --> Form Validation Class Initialized
INFO - 2025-05-03 22:11:38 --> Controller Class Initialized
INFO - 2025-05-03 22:11:38 --> Final output sent to browser
DEBUG - 2025-05-03 22:11:38 --> Total execution time: 0.0295
INFO - 2025-05-03 22:12:43 --> Config Class Initialized
INFO - 2025-05-03 22:12:43 --> Hooks Class Initialized
DEBUG - 2025-05-03 22:12:43 --> UTF-8 Support Enabled
INFO - 2025-05-03 22:12:43 --> Utf8 Class Initialized
INFO - 2025-05-03 22:12:43 --> URI Class Initialized
DEBUG - 2025-05-03 22:12:43 --> No URI present. Default controller set.
INFO - 2025-05-03 22:12:43 --> Router Class Initialized
INFO - 2025-05-03 22:12:43 --> Output Class Initialized
INFO - 2025-05-03 22:12:43 --> Security Class Initialized
DEBUG - 2025-05-03 22:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 22:12:43 --> Input Class Initialized
INFO - 2025-05-03 22:12:43 --> Language Class Initialized
INFO - 2025-05-03 22:12:43 --> Loader Class Initialized
INFO - 2025-05-03 22:12:43 --> Helper loaded: form_helper
INFO - 2025-05-03 22:12:43 --> Helper loaded: url_helper
INFO - 2025-05-03 22:12:43 --> Database Driver Class Initialized
INFO - 2025-05-03 22:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 22:12:43 --> Form Validation Class Initialized
INFO - 2025-05-03 22:12:43 --> Controller Class Initialized
INFO - 2025-05-03 22:12:43 --> Final output sent to browser
DEBUG - 2025-05-03 22:12:43 --> Total execution time: 0.0287
INFO - 2025-05-03 22:13:07 --> Config Class Initialized
INFO - 2025-05-03 22:13:07 --> Hooks Class Initialized
DEBUG - 2025-05-03 22:13:07 --> UTF-8 Support Enabled
INFO - 2025-05-03 22:13:07 --> Utf8 Class Initialized
INFO - 2025-05-03 22:13:07 --> URI Class Initialized
DEBUG - 2025-05-03 22:13:07 --> No URI present. Default controller set.
INFO - 2025-05-03 22:13:07 --> Router Class Initialized
INFO - 2025-05-03 22:13:07 --> Output Class Initialized
INFO - 2025-05-03 22:13:07 --> Security Class Initialized
DEBUG - 2025-05-03 22:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 22:13:07 --> Input Class Initialized
INFO - 2025-05-03 22:13:07 --> Language Class Initialized
INFO - 2025-05-03 22:13:07 --> Loader Class Initialized
INFO - 2025-05-03 22:13:07 --> Helper loaded: form_helper
INFO - 2025-05-03 22:13:07 --> Helper loaded: url_helper
INFO - 2025-05-03 22:13:07 --> Database Driver Class Initialized
INFO - 2025-05-03 22:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 22:13:07 --> Form Validation Class Initialized
INFO - 2025-05-03 22:13:07 --> Controller Class Initialized
INFO - 2025-05-03 22:13:07 --> Final output sent to browser
DEBUG - 2025-05-03 22:13:07 --> Total execution time: 0.0295
INFO - 2025-05-03 22:13:12 --> Config Class Initialized
INFO - 2025-05-03 22:13:12 --> Hooks Class Initialized
DEBUG - 2025-05-03 22:13:12 --> UTF-8 Support Enabled
INFO - 2025-05-03 22:13:12 --> Utf8 Class Initialized
INFO - 2025-05-03 22:13:12 --> URI Class Initialized
INFO - 2025-05-03 22:13:12 --> Router Class Initialized
INFO - 2025-05-03 22:13:12 --> Output Class Initialized
INFO - 2025-05-03 22:13:12 --> Security Class Initialized
DEBUG - 2025-05-03 22:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 22:13:12 --> Input Class Initialized
INFO - 2025-05-03 22:13:12 --> Language Class Initialized
INFO - 2025-05-03 22:13:12 --> Loader Class Initialized
INFO - 2025-05-03 22:13:12 --> Helper loaded: form_helper
INFO - 2025-05-03 22:13:12 --> Helper loaded: url_helper
INFO - 2025-05-03 22:13:12 --> Database Driver Class Initialized
INFO - 2025-05-03 22:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 22:13:12 --> Form Validation Class Initialized
INFO - 2025-05-03 22:13:12 --> Controller Class Initialized
DEBUG - 2025-05-03 22:13:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 22:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 22:13:12 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 22:13:12 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 22:13:12 --> Final output sent to browser
DEBUG - 2025-05-03 22:13:12 --> Total execution time: 0.0291
INFO - 2025-05-03 22:13:13 --> Config Class Initialized
INFO - 2025-05-03 22:13:13 --> Hooks Class Initialized
DEBUG - 2025-05-03 22:13:13 --> UTF-8 Support Enabled
INFO - 2025-05-03 22:13:13 --> Utf8 Class Initialized
INFO - 2025-05-03 22:13:13 --> URI Class Initialized
INFO - 2025-05-03 22:13:13 --> Router Class Initialized
INFO - 2025-05-03 22:13:13 --> Output Class Initialized
INFO - 2025-05-03 22:13:13 --> Security Class Initialized
DEBUG - 2025-05-03 22:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 22:13:13 --> Input Class Initialized
INFO - 2025-05-03 22:13:13 --> Language Class Initialized
ERROR - 2025-05-03 22:13:13 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-03 22:13:21 --> Config Class Initialized
INFO - 2025-05-03 22:13:21 --> Hooks Class Initialized
DEBUG - 2025-05-03 22:13:21 --> UTF-8 Support Enabled
INFO - 2025-05-03 22:13:21 --> Utf8 Class Initialized
INFO - 2025-05-03 22:13:21 --> URI Class Initialized
INFO - 2025-05-03 22:13:21 --> Router Class Initialized
INFO - 2025-05-03 22:13:21 --> Output Class Initialized
INFO - 2025-05-03 22:13:21 --> Security Class Initialized
DEBUG - 2025-05-03 22:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-03 22:13:21 --> Input Class Initialized
INFO - 2025-05-03 22:13:21 --> Language Class Initialized
INFO - 2025-05-03 22:13:21 --> Loader Class Initialized
INFO - 2025-05-03 22:13:21 --> Helper loaded: form_helper
INFO - 2025-05-03 22:13:21 --> Helper loaded: url_helper
INFO - 2025-05-03 22:13:21 --> Database Driver Class Initialized
INFO - 2025-05-03 22:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-03 22:13:21 --> Form Validation Class Initialized
INFO - 2025-05-03 22:13:21 --> Controller Class Initialized
DEBUG - 2025-05-03 22:13:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-03 22:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-03 22:13:21 --> Model "Ppdb_model" initialized
INFO - 2025-05-03 22:13:21 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-03 22:13:21 --> Final output sent to browser
DEBUG - 2025-05-03 22:13:21 --> Total execution time: 0.0322
