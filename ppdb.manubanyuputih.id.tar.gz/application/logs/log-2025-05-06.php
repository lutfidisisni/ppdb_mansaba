<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-06 00:57:09 --> Config Class Initialized
INFO - 2025-05-06 00:57:09 --> Hooks Class Initialized
DEBUG - 2025-05-06 00:57:09 --> UTF-8 Support Enabled
INFO - 2025-05-06 00:57:09 --> Utf8 Class Initialized
INFO - 2025-05-06 00:57:09 --> URI Class Initialized
INFO - 2025-05-06 00:57:09 --> Router Class Initialized
INFO - 2025-05-06 00:57:09 --> Output Class Initialized
INFO - 2025-05-06 00:57:09 --> Security Class Initialized
DEBUG - 2025-05-06 00:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 00:57:09 --> Input Class Initialized
INFO - 2025-05-06 00:57:09 --> Language Class Initialized
ERROR - 2025-05-06 00:57:09 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-06 00:57:16 --> Config Class Initialized
INFO - 2025-05-06 00:57:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 00:57:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 00:57:16 --> Utf8 Class Initialized
INFO - 2025-05-06 00:57:16 --> URI Class Initialized
DEBUG - 2025-05-06 00:57:16 --> No URI present. Default controller set.
INFO - 2025-05-06 00:57:16 --> Router Class Initialized
INFO - 2025-05-06 00:57:16 --> Output Class Initialized
INFO - 2025-05-06 00:57:16 --> Security Class Initialized
DEBUG - 2025-05-06 00:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 00:57:16 --> Input Class Initialized
INFO - 2025-05-06 00:57:16 --> Language Class Initialized
INFO - 2025-05-06 00:57:16 --> Loader Class Initialized
INFO - 2025-05-06 00:57:16 --> Helper loaded: form_helper
INFO - 2025-05-06 00:57:16 --> Helper loaded: url_helper
INFO - 2025-05-06 00:57:16 --> Database Driver Class Initialized
INFO - 2025-05-06 00:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 00:57:16 --> Form Validation Class Initialized
INFO - 2025-05-06 00:57:16 --> Controller Class Initialized
INFO - 2025-05-06 00:57:16 --> Final output sent to browser
DEBUG - 2025-05-06 00:57:16 --> Total execution time: 0.0312
INFO - 2025-05-06 01:05:11 --> Config Class Initialized
INFO - 2025-05-06 01:05:11 --> Hooks Class Initialized
DEBUG - 2025-05-06 01:05:11 --> UTF-8 Support Enabled
INFO - 2025-05-06 01:05:11 --> Utf8 Class Initialized
INFO - 2025-05-06 01:05:11 --> URI Class Initialized
DEBUG - 2025-05-06 01:05:11 --> No URI present. Default controller set.
INFO - 2025-05-06 01:05:11 --> Router Class Initialized
INFO - 2025-05-06 01:05:11 --> Output Class Initialized
INFO - 2025-05-06 01:05:11 --> Security Class Initialized
DEBUG - 2025-05-06 01:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 01:05:11 --> Input Class Initialized
INFO - 2025-05-06 01:05:11 --> Language Class Initialized
INFO - 2025-05-06 01:05:11 --> Loader Class Initialized
INFO - 2025-05-06 01:05:11 --> Helper loaded: form_helper
INFO - 2025-05-06 01:05:11 --> Helper loaded: url_helper
INFO - 2025-05-06 01:05:11 --> Database Driver Class Initialized
INFO - 2025-05-06 01:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 01:05:11 --> Form Validation Class Initialized
INFO - 2025-05-06 01:05:11 --> Controller Class Initialized
INFO - 2025-05-06 01:05:11 --> Final output sent to browser
DEBUG - 2025-05-06 01:05:11 --> Total execution time: 0.0315
INFO - 2025-05-06 04:32:06 --> Config Class Initialized
INFO - 2025-05-06 04:32:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 04:32:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 04:32:06 --> Utf8 Class Initialized
INFO - 2025-05-06 04:32:06 --> URI Class Initialized
INFO - 2025-05-06 04:32:06 --> Router Class Initialized
INFO - 2025-05-06 04:32:06 --> Output Class Initialized
INFO - 2025-05-06 04:32:06 --> Security Class Initialized
DEBUG - 2025-05-06 04:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 04:32:06 --> Input Class Initialized
INFO - 2025-05-06 04:32:06 --> Language Class Initialized
ERROR - 2025-05-06 04:32:06 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2025-05-06 04:32:08 --> Config Class Initialized
INFO - 2025-05-06 04:32:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 04:32:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 04:32:08 --> Utf8 Class Initialized
INFO - 2025-05-06 04:32:08 --> URI Class Initialized
INFO - 2025-05-06 04:32:08 --> Router Class Initialized
INFO - 2025-05-06 04:32:08 --> Output Class Initialized
INFO - 2025-05-06 04:32:08 --> Security Class Initialized
DEBUG - 2025-05-06 04:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 04:32:08 --> Input Class Initialized
INFO - 2025-05-06 04:32:08 --> Language Class Initialized
ERROR - 2025-05-06 04:32:08 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2025-05-06 05:58:46 --> Config Class Initialized
INFO - 2025-05-06 05:58:46 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:58:46 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:58:46 --> Utf8 Class Initialized
INFO - 2025-05-06 05:58:46 --> URI Class Initialized
INFO - 2025-05-06 05:58:46 --> Router Class Initialized
INFO - 2025-05-06 05:58:46 --> Output Class Initialized
INFO - 2025-05-06 05:58:46 --> Security Class Initialized
DEBUG - 2025-05-06 05:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:58:46 --> Input Class Initialized
INFO - 2025-05-06 05:58:46 --> Language Class Initialized
ERROR - 2025-05-06 05:58:46 --> 404 Page Not Found: Vendor/phpunit
INFO - 2025-05-06 05:58:47 --> Config Class Initialized
INFO - 2025-05-06 05:58:47 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:58:47 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:58:47 --> Utf8 Class Initialized
INFO - 2025-05-06 05:58:47 --> URI Class Initialized
INFO - 2025-05-06 05:58:47 --> Router Class Initialized
INFO - 2025-05-06 05:58:47 --> Output Class Initialized
INFO - 2025-05-06 05:58:47 --> Security Class Initialized
DEBUG - 2025-05-06 05:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:58:47 --> Input Class Initialized
INFO - 2025-05-06 05:58:47 --> Language Class Initialized
ERROR - 2025-05-06 05:58:47 --> 404 Page Not Found: Vendor/phpunit
INFO - 2025-05-06 05:58:48 --> Config Class Initialized
INFO - 2025-05-06 05:58:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 05:58:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 05:58:48 --> Utf8 Class Initialized
INFO - 2025-05-06 05:58:48 --> URI Class Initialized
INFO - 2025-05-06 05:58:48 --> Router Class Initialized
INFO - 2025-05-06 05:58:48 --> Output Class Initialized
INFO - 2025-05-06 05:58:48 --> Security Class Initialized
DEBUG - 2025-05-06 05:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 05:58:48 --> Input Class Initialized
INFO - 2025-05-06 05:58:48 --> Language Class Initialized
ERROR - 2025-05-06 05:58:48 --> 404 Page Not Found: Vendor/phpunit
INFO - 2025-05-06 06:54:15 --> Config Class Initialized
INFO - 2025-05-06 06:54:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 06:54:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 06:54:15 --> Utf8 Class Initialized
INFO - 2025-05-06 06:54:15 --> URI Class Initialized
INFO - 2025-05-06 06:54:15 --> Router Class Initialized
INFO - 2025-05-06 06:54:15 --> Output Class Initialized
INFO - 2025-05-06 06:54:15 --> Security Class Initialized
DEBUG - 2025-05-06 06:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 06:54:15 --> Input Class Initialized
INFO - 2025-05-06 06:54:15 --> Language Class Initialized
ERROR - 2025-05-06 06:54:15 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-06 08:34:20 --> Config Class Initialized
INFO - 2025-05-06 08:34:20 --> Hooks Class Initialized
DEBUG - 2025-05-06 08:34:20 --> UTF-8 Support Enabled
INFO - 2025-05-06 08:34:20 --> Utf8 Class Initialized
INFO - 2025-05-06 08:34:20 --> URI Class Initialized
INFO - 2025-05-06 08:34:20 --> Router Class Initialized
INFO - 2025-05-06 08:34:20 --> Output Class Initialized
INFO - 2025-05-06 08:34:20 --> Security Class Initialized
DEBUG - 2025-05-06 08:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 08:34:20 --> Input Class Initialized
INFO - 2025-05-06 08:34:20 --> Language Class Initialized
ERROR - 2025-05-06 08:34:20 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-06 09:25:11 --> Config Class Initialized
INFO - 2025-05-06 09:25:11 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:11 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:11 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:11 --> URI Class Initialized
INFO - 2025-05-06 09:25:11 --> Router Class Initialized
INFO - 2025-05-06 09:25:11 --> Output Class Initialized
INFO - 2025-05-06 09:25:11 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:11 --> Input Class Initialized
INFO - 2025-05-06 09:25:11 --> Language Class Initialized
INFO - 2025-05-06 09:25:11 --> Loader Class Initialized
INFO - 2025-05-06 09:25:11 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:11 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:11 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:11 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:11 --> Controller Class Initialized
INFO - 2025-05-06 09:25:11 --> Config Class Initialized
INFO - 2025-05-06 09:25:11 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:11 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:11 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:11 --> URI Class Initialized
INFO - 2025-05-06 09:25:11 --> Router Class Initialized
INFO - 2025-05-06 09:25:11 --> Output Class Initialized
INFO - 2025-05-06 09:25:11 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:11 --> Input Class Initialized
INFO - 2025-05-06 09:25:11 --> Language Class Initialized
INFO - 2025-05-06 09:25:11 --> Loader Class Initialized
INFO - 2025-05-06 09:25:11 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:11 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:11 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:11 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:11 --> Controller Class Initialized
INFO - 2025-05-06 09:25:11 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 09:25:11 --> Final output sent to browser
DEBUG - 2025-05-06 09:25:11 --> Total execution time: 0.0352
INFO - 2025-05-06 09:25:14 --> Config Class Initialized
INFO - 2025-05-06 09:25:14 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:14 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:14 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:14 --> URI Class Initialized
INFO - 2025-05-06 09:25:14 --> Router Class Initialized
INFO - 2025-05-06 09:25:14 --> Output Class Initialized
INFO - 2025-05-06 09:25:14 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:14 --> Input Class Initialized
INFO - 2025-05-06 09:25:14 --> Language Class Initialized
INFO - 2025-05-06 09:25:14 --> Loader Class Initialized
INFO - 2025-05-06 09:25:14 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:14 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:14 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:14 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:14 --> Controller Class Initialized
INFO - 2025-05-06 09:25:14 --> Config Class Initialized
INFO - 2025-05-06 09:25:14 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:14 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:14 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:14 --> URI Class Initialized
INFO - 2025-05-06 09:25:14 --> Router Class Initialized
INFO - 2025-05-06 09:25:14 --> Output Class Initialized
INFO - 2025-05-06 09:25:14 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:14 --> Input Class Initialized
INFO - 2025-05-06 09:25:14 --> Language Class Initialized
INFO - 2025-05-06 09:25:14 --> Loader Class Initialized
INFO - 2025-05-06 09:25:14 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:14 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:14 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:14 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:14 --> Controller Class Initialized
INFO - 2025-05-06 09:25:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:25:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:25:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:25:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 09:25:14 --> Final output sent to browser
DEBUG - 2025-05-06 09:25:14 --> Total execution time: 0.0354
INFO - 2025-05-06 09:25:16 --> Config Class Initialized
INFO - 2025-05-06 09:25:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:16 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:16 --> URI Class Initialized
INFO - 2025-05-06 09:25:16 --> Router Class Initialized
INFO - 2025-05-06 09:25:16 --> Output Class Initialized
INFO - 2025-05-06 09:25:16 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:16 --> Input Class Initialized
INFO - 2025-05-06 09:25:16 --> Language Class Initialized
INFO - 2025-05-06 09:25:16 --> Loader Class Initialized
INFO - 2025-05-06 09:25:16 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:16 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:16 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:16 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:16 --> Controller Class Initialized
INFO - 2025-05-06 09:25:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:25:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:25:16 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:25:16 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 09:25:16 --> Final output sent to browser
DEBUG - 2025-05-06 09:25:16 --> Total execution time: 0.0462
INFO - 2025-05-06 09:25:19 --> Config Class Initialized
INFO - 2025-05-06 09:25:19 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:19 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:19 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:19 --> URI Class Initialized
INFO - 2025-05-06 09:25:19 --> Router Class Initialized
INFO - 2025-05-06 09:25:19 --> Output Class Initialized
INFO - 2025-05-06 09:25:19 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:19 --> Input Class Initialized
INFO - 2025-05-06 09:25:19 --> Language Class Initialized
INFO - 2025-05-06 09:25:19 --> Loader Class Initialized
INFO - 2025-05-06 09:25:19 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:19 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:19 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:19 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:19 --> Controller Class Initialized
INFO - 2025-05-06 09:25:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:25:19 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:25:19 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:25:19 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 09:25:19 --> Final output sent to browser
DEBUG - 2025-05-06 09:25:19 --> Total execution time: 0.0420
INFO - 2025-05-06 09:25:22 --> Config Class Initialized
INFO - 2025-05-06 09:25:22 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:22 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:22 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:22 --> URI Class Initialized
INFO - 2025-05-06 09:25:22 --> Router Class Initialized
INFO - 2025-05-06 09:25:22 --> Output Class Initialized
INFO - 2025-05-06 09:25:22 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:22 --> Input Class Initialized
INFO - 2025-05-06 09:25:22 --> Language Class Initialized
INFO - 2025-05-06 09:25:22 --> Loader Class Initialized
INFO - 2025-05-06 09:25:22 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:22 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:22 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:22 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:22 --> Controller Class Initialized
INFO - 2025-05-06 09:25:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:25:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:25:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:25:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 09:25:22 --> Final output sent to browser
DEBUG - 2025-05-06 09:25:22 --> Total execution time: 0.0491
INFO - 2025-05-06 09:25:24 --> Config Class Initialized
INFO - 2025-05-06 09:25:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:24 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:24 --> URI Class Initialized
INFO - 2025-05-06 09:25:24 --> Router Class Initialized
INFO - 2025-05-06 09:25:24 --> Output Class Initialized
INFO - 2025-05-06 09:25:24 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:24 --> Input Class Initialized
INFO - 2025-05-06 09:25:24 --> Language Class Initialized
INFO - 2025-05-06 09:25:24 --> Loader Class Initialized
INFO - 2025-05-06 09:25:24 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:24 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:24 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:24 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:24 --> Controller Class Initialized
INFO - 2025-05-06 09:25:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:25:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:25:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:25:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 09:25:24 --> Final output sent to browser
DEBUG - 2025-05-06 09:25:24 --> Total execution time: 0.0450
INFO - 2025-05-06 09:25:32 --> Config Class Initialized
INFO - 2025-05-06 09:25:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:32 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:32 --> URI Class Initialized
INFO - 2025-05-06 09:25:32 --> Router Class Initialized
INFO - 2025-05-06 09:25:32 --> Output Class Initialized
INFO - 2025-05-06 09:25:32 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:32 --> Input Class Initialized
INFO - 2025-05-06 09:25:32 --> Language Class Initialized
INFO - 2025-05-06 09:25:32 --> Loader Class Initialized
INFO - 2025-05-06 09:25:32 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:32 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:32 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:32 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:32 --> Controller Class Initialized
INFO - 2025-05-06 09:25:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:25:32 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:25:32 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/edit_pendaftar.php
INFO - 2025-05-06 09:25:32 --> Final output sent to browser
DEBUG - 2025-05-06 09:25:32 --> Total execution time: 0.0374
INFO - 2025-05-06 09:25:58 --> Config Class Initialized
INFO - 2025-05-06 09:25:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:25:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:25:58 --> Utf8 Class Initialized
INFO - 2025-05-06 09:25:58 --> URI Class Initialized
INFO - 2025-05-06 09:25:58 --> Router Class Initialized
INFO - 2025-05-06 09:25:58 --> Output Class Initialized
INFO - 2025-05-06 09:25:58 --> Security Class Initialized
DEBUG - 2025-05-06 09:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:25:58 --> Input Class Initialized
INFO - 2025-05-06 09:25:58 --> Language Class Initialized
INFO - 2025-05-06 09:25:58 --> Loader Class Initialized
INFO - 2025-05-06 09:25:58 --> Helper loaded: form_helper
INFO - 2025-05-06 09:25:58 --> Helper loaded: url_helper
INFO - 2025-05-06 09:25:58 --> Database Driver Class Initialized
INFO - 2025-05-06 09:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:25:58 --> Form Validation Class Initialized
INFO - 2025-05-06 09:25:58 --> Controller Class Initialized
INFO - 2025-05-06 09:25:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:25:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:25:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:25:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 09:25:58 --> Final output sent to browser
DEBUG - 2025-05-06 09:25:58 --> Total execution time: 0.0485
INFO - 2025-05-06 09:26:03 --> Config Class Initialized
INFO - 2025-05-06 09:26:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:26:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:26:03 --> Utf8 Class Initialized
INFO - 2025-05-06 09:26:03 --> URI Class Initialized
INFO - 2025-05-06 09:26:03 --> Router Class Initialized
INFO - 2025-05-06 09:26:03 --> Output Class Initialized
INFO - 2025-05-06 09:26:03 --> Security Class Initialized
DEBUG - 2025-05-06 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:26:03 --> Input Class Initialized
INFO - 2025-05-06 09:26:03 --> Language Class Initialized
INFO - 2025-05-06 09:26:03 --> Loader Class Initialized
INFO - 2025-05-06 09:26:03 --> Helper loaded: form_helper
INFO - 2025-05-06 09:26:03 --> Helper loaded: url_helper
INFO - 2025-05-06 09:26:03 --> Database Driver Class Initialized
INFO - 2025-05-06 09:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:26:03 --> Form Validation Class Initialized
INFO - 2025-05-06 09:26:03 --> Controller Class Initialized
INFO - 2025-05-06 09:26:03 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:26:03 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:26:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:26:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 09:26:03 --> Final output sent to browser
DEBUG - 2025-05-06 09:26:03 --> Total execution time: 0.0427
INFO - 2025-05-06 09:27:28 --> Config Class Initialized
INFO - 2025-05-06 09:27:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:27:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:27:28 --> Utf8 Class Initialized
INFO - 2025-05-06 09:27:28 --> URI Class Initialized
INFO - 2025-05-06 09:27:28 --> Router Class Initialized
INFO - 2025-05-06 09:27:28 --> Output Class Initialized
INFO - 2025-05-06 09:27:28 --> Security Class Initialized
DEBUG - 2025-05-06 09:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:27:28 --> Input Class Initialized
INFO - 2025-05-06 09:27:28 --> Language Class Initialized
INFO - 2025-05-06 09:27:28 --> Loader Class Initialized
INFO - 2025-05-06 09:27:28 --> Helper loaded: form_helper
INFO - 2025-05-06 09:27:28 --> Helper loaded: url_helper
INFO - 2025-05-06 09:27:28 --> Database Driver Class Initialized
INFO - 2025-05-06 09:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:27:28 --> Form Validation Class Initialized
INFO - 2025-05-06 09:27:28 --> Controller Class Initialized
INFO - 2025-05-06 09:27:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:27:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:27:28 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:27:28 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/belum_daftar_ulang.php
INFO - 2025-05-06 09:27:28 --> Final output sent to browser
DEBUG - 2025-05-06 09:27:28 --> Total execution time: 0.0399
INFO - 2025-05-06 09:27:42 --> Config Class Initialized
INFO - 2025-05-06 09:27:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:27:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:27:42 --> Utf8 Class Initialized
INFO - 2025-05-06 09:27:42 --> URI Class Initialized
INFO - 2025-05-06 09:27:42 --> Router Class Initialized
INFO - 2025-05-06 09:27:42 --> Output Class Initialized
INFO - 2025-05-06 09:27:42 --> Security Class Initialized
DEBUG - 2025-05-06 09:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:27:42 --> Input Class Initialized
INFO - 2025-05-06 09:27:42 --> Language Class Initialized
INFO - 2025-05-06 09:27:42 --> Loader Class Initialized
INFO - 2025-05-06 09:27:42 --> Helper loaded: form_helper
INFO - 2025-05-06 09:27:42 --> Helper loaded: url_helper
INFO - 2025-05-06 09:27:42 --> Database Driver Class Initialized
INFO - 2025-05-06 09:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:27:42 --> Form Validation Class Initialized
INFO - 2025-05-06 09:27:42 --> Controller Class Initialized
INFO - 2025-05-06 09:27:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:27:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:27:42 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:27:42 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_sekolah.php
INFO - 2025-05-06 09:27:42 --> Final output sent to browser
DEBUG - 2025-05-06 09:27:42 --> Total execution time: 0.0397
INFO - 2025-05-06 09:27:45 --> Config Class Initialized
INFO - 2025-05-06 09:27:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:27:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:27:45 --> Utf8 Class Initialized
INFO - 2025-05-06 09:27:45 --> URI Class Initialized
INFO - 2025-05-06 09:27:45 --> Router Class Initialized
INFO - 2025-05-06 09:27:45 --> Output Class Initialized
INFO - 2025-05-06 09:27:45 --> Security Class Initialized
DEBUG - 2025-05-06 09:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:27:45 --> Input Class Initialized
INFO - 2025-05-06 09:27:45 --> Language Class Initialized
INFO - 2025-05-06 09:27:45 --> Loader Class Initialized
INFO - 2025-05-06 09:27:45 --> Helper loaded: form_helper
INFO - 2025-05-06 09:27:45 --> Helper loaded: url_helper
INFO - 2025-05-06 09:27:45 --> Database Driver Class Initialized
INFO - 2025-05-06 09:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:27:45 --> Form Validation Class Initialized
INFO - 2025-05-06 09:27:45 --> Controller Class Initialized
INFO - 2025-05-06 09:27:45 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:27:45 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:27:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:27:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_rekomendasi.php
INFO - 2025-05-06 09:27:45 --> Final output sent to browser
DEBUG - 2025-05-06 09:27:45 --> Total execution time: 0.0457
INFO - 2025-05-06 09:27:47 --> Config Class Initialized
INFO - 2025-05-06 09:27:47 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:27:47 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:27:47 --> Utf8 Class Initialized
INFO - 2025-05-06 09:27:47 --> URI Class Initialized
INFO - 2025-05-06 09:27:47 --> Router Class Initialized
INFO - 2025-05-06 09:27:47 --> Output Class Initialized
INFO - 2025-05-06 09:27:47 --> Security Class Initialized
DEBUG - 2025-05-06 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:27:47 --> Input Class Initialized
INFO - 2025-05-06 09:27:47 --> Language Class Initialized
INFO - 2025-05-06 09:27:47 --> Loader Class Initialized
INFO - 2025-05-06 09:27:47 --> Helper loaded: form_helper
INFO - 2025-05-06 09:27:47 --> Helper loaded: url_helper
INFO - 2025-05-06 09:27:47 --> Database Driver Class Initialized
INFO - 2025-05-06 09:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:27:47 --> Form Validation Class Initialized
INFO - 2025-05-06 09:27:47 --> Controller Class Initialized
INFO - 2025-05-06 09:27:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:27:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:27:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:27:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-06 09:27:47 --> Final output sent to browser
DEBUG - 2025-05-06 09:27:47 --> Total execution time: 0.0480
INFO - 2025-05-06 09:28:49 --> Config Class Initialized
INFO - 2025-05-06 09:28:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:28:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:28:49 --> Utf8 Class Initialized
INFO - 2025-05-06 09:28:49 --> URI Class Initialized
INFO - 2025-05-06 09:28:49 --> Router Class Initialized
INFO - 2025-05-06 09:28:49 --> Output Class Initialized
INFO - 2025-05-06 09:28:49 --> Security Class Initialized
DEBUG - 2025-05-06 09:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:28:49 --> Input Class Initialized
INFO - 2025-05-06 09:28:49 --> Language Class Initialized
INFO - 2025-05-06 09:28:49 --> Loader Class Initialized
INFO - 2025-05-06 09:28:49 --> Helper loaded: form_helper
INFO - 2025-05-06 09:28:49 --> Helper loaded: url_helper
INFO - 2025-05-06 09:28:49 --> Database Driver Class Initialized
INFO - 2025-05-06 09:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:28:49 --> Form Validation Class Initialized
INFO - 2025-05-06 09:28:49 --> Controller Class Initialized
INFO - 2025-05-06 09:28:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:28:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:28:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:28:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_rekomendasi.php
INFO - 2025-05-06 09:28:49 --> Final output sent to browser
DEBUG - 2025-05-06 09:28:49 --> Total execution time: 0.0366
INFO - 2025-05-06 09:30:58 --> Config Class Initialized
INFO - 2025-05-06 09:30:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:30:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:30:58 --> Utf8 Class Initialized
INFO - 2025-05-06 09:30:58 --> URI Class Initialized
INFO - 2025-05-06 09:30:58 --> Router Class Initialized
INFO - 2025-05-06 09:30:58 --> Output Class Initialized
INFO - 2025-05-06 09:30:58 --> Security Class Initialized
DEBUG - 2025-05-06 09:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:30:58 --> Input Class Initialized
INFO - 2025-05-06 09:30:58 --> Language Class Initialized
INFO - 2025-05-06 09:30:58 --> Loader Class Initialized
INFO - 2025-05-06 09:30:58 --> Helper loaded: form_helper
INFO - 2025-05-06 09:30:58 --> Helper loaded: url_helper
INFO - 2025-05-06 09:30:58 --> Database Driver Class Initialized
INFO - 2025-05-06 09:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:30:58 --> Form Validation Class Initialized
INFO - 2025-05-06 09:30:58 --> Controller Class Initialized
INFO - 2025-05-06 09:30:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:30:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:30:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:30:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-06 09:30:58 --> Final output sent to browser
DEBUG - 2025-05-06 09:30:58 --> Total execution time: 0.0470
INFO - 2025-05-06 09:31:05 --> Config Class Initialized
INFO - 2025-05-06 09:31:05 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:31:05 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:31:05 --> Utf8 Class Initialized
INFO - 2025-05-06 09:31:05 --> URI Class Initialized
INFO - 2025-05-06 09:31:05 --> Router Class Initialized
INFO - 2025-05-06 09:31:05 --> Output Class Initialized
INFO - 2025-05-06 09:31:05 --> Security Class Initialized
DEBUG - 2025-05-06 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:31:05 --> Input Class Initialized
INFO - 2025-05-06 09:31:05 --> Language Class Initialized
INFO - 2025-05-06 09:31:05 --> Loader Class Initialized
INFO - 2025-05-06 09:31:05 --> Helper loaded: form_helper
INFO - 2025-05-06 09:31:05 --> Helper loaded: url_helper
INFO - 2025-05-06 09:31:05 --> Database Driver Class Initialized
INFO - 2025-05-06 09:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:31:05 --> Form Validation Class Initialized
INFO - 2025-05-06 09:31:05 --> Controller Class Initialized
INFO - 2025-05-06 09:31:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:31:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:31:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:31:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-06 09:31:05 --> Final output sent to browser
DEBUG - 2025-05-06 09:31:05 --> Total execution time: 0.0533
INFO - 2025-05-06 09:31:18 --> Config Class Initialized
INFO - 2025-05-06 09:31:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:31:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:31:18 --> Utf8 Class Initialized
INFO - 2025-05-06 09:31:18 --> URI Class Initialized
INFO - 2025-05-06 09:31:18 --> Router Class Initialized
INFO - 2025-05-06 09:31:18 --> Output Class Initialized
INFO - 2025-05-06 09:31:18 --> Security Class Initialized
DEBUG - 2025-05-06 09:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:31:18 --> Input Class Initialized
INFO - 2025-05-06 09:31:18 --> Language Class Initialized
INFO - 2025-05-06 09:31:18 --> Loader Class Initialized
INFO - 2025-05-06 09:31:18 --> Helper loaded: form_helper
INFO - 2025-05-06 09:31:18 --> Helper loaded: url_helper
INFO - 2025-05-06 09:31:18 --> Database Driver Class Initialized
INFO - 2025-05-06 09:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:31:18 --> Form Validation Class Initialized
INFO - 2025-05-06 09:31:18 --> Controller Class Initialized
INFO - 2025-05-06 09:31:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:31:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:31:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:31:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 09:31:18 --> Final output sent to browser
DEBUG - 2025-05-06 09:31:18 --> Total execution time: 0.0356
INFO - 2025-05-06 09:31:20 --> Config Class Initialized
INFO - 2025-05-06 09:31:20 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:31:20 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:31:20 --> Utf8 Class Initialized
INFO - 2025-05-06 09:31:20 --> URI Class Initialized
INFO - 2025-05-06 09:31:20 --> Router Class Initialized
INFO - 2025-05-06 09:31:20 --> Output Class Initialized
INFO - 2025-05-06 09:31:20 --> Security Class Initialized
DEBUG - 2025-05-06 09:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:31:20 --> Input Class Initialized
INFO - 2025-05-06 09:31:20 --> Language Class Initialized
INFO - 2025-05-06 09:31:20 --> Loader Class Initialized
INFO - 2025-05-06 09:31:20 --> Helper loaded: form_helper
INFO - 2025-05-06 09:31:20 --> Helper loaded: url_helper
INFO - 2025-05-06 09:31:20 --> Database Driver Class Initialized
INFO - 2025-05-06 09:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:31:20 --> Form Validation Class Initialized
INFO - 2025-05-06 09:31:20 --> Controller Class Initialized
INFO - 2025-05-06 09:31:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:31:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:31:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:31:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 09:31:20 --> Final output sent to browser
DEBUG - 2025-05-06 09:31:20 --> Total execution time: 0.0395
INFO - 2025-05-06 09:31:24 --> Config Class Initialized
INFO - 2025-05-06 09:31:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:31:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:31:24 --> Utf8 Class Initialized
INFO - 2025-05-06 09:31:24 --> URI Class Initialized
INFO - 2025-05-06 09:31:24 --> Router Class Initialized
INFO - 2025-05-06 09:31:24 --> Output Class Initialized
INFO - 2025-05-06 09:31:24 --> Security Class Initialized
DEBUG - 2025-05-06 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:31:24 --> Input Class Initialized
INFO - 2025-05-06 09:31:24 --> Language Class Initialized
INFO - 2025-05-06 09:31:24 --> Loader Class Initialized
INFO - 2025-05-06 09:31:24 --> Helper loaded: form_helper
INFO - 2025-05-06 09:31:24 --> Helper loaded: url_helper
INFO - 2025-05-06 09:31:24 --> Database Driver Class Initialized
INFO - 2025-05-06 09:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:31:24 --> Form Validation Class Initialized
INFO - 2025-05-06 09:31:24 --> Controller Class Initialized
INFO - 2025-05-06 09:31:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:31:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:31:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:31:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 09:31:24 --> Final output sent to browser
DEBUG - 2025-05-06 09:31:24 --> Total execution time: 0.0364
INFO - 2025-05-06 09:31:33 --> Config Class Initialized
INFO - 2025-05-06 09:31:33 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:31:33 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:31:33 --> Utf8 Class Initialized
INFO - 2025-05-06 09:31:33 --> URI Class Initialized
INFO - 2025-05-06 09:31:33 --> Router Class Initialized
INFO - 2025-05-06 09:31:33 --> Output Class Initialized
INFO - 2025-05-06 09:31:33 --> Security Class Initialized
DEBUG - 2025-05-06 09:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:31:33 --> Input Class Initialized
INFO - 2025-05-06 09:31:33 --> Language Class Initialized
INFO - 2025-05-06 09:31:33 --> Loader Class Initialized
INFO - 2025-05-06 09:31:33 --> Helper loaded: form_helper
INFO - 2025-05-06 09:31:33 --> Helper loaded: url_helper
INFO - 2025-05-06 09:31:33 --> Database Driver Class Initialized
INFO - 2025-05-06 09:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:31:33 --> Form Validation Class Initialized
INFO - 2025-05-06 09:31:33 --> Controller Class Initialized
INFO - 2025-05-06 09:31:33 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:31:33 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:31:33 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/tambah_petugas.php
INFO - 2025-05-06 09:31:33 --> Final output sent to browser
DEBUG - 2025-05-06 09:31:33 --> Total execution time: 0.0348
INFO - 2025-05-06 09:31:39 --> Config Class Initialized
INFO - 2025-05-06 09:31:39 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:31:39 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:31:39 --> Utf8 Class Initialized
INFO - 2025-05-06 09:31:39 --> URI Class Initialized
DEBUG - 2025-05-06 09:31:39 --> No URI present. Default controller set.
INFO - 2025-05-06 09:31:39 --> Router Class Initialized
INFO - 2025-05-06 09:31:39 --> Output Class Initialized
INFO - 2025-05-06 09:31:39 --> Security Class Initialized
DEBUG - 2025-05-06 09:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:31:39 --> Input Class Initialized
INFO - 2025-05-06 09:31:39 --> Language Class Initialized
INFO - 2025-05-06 09:31:39 --> Loader Class Initialized
INFO - 2025-05-06 09:31:39 --> Helper loaded: form_helper
INFO - 2025-05-06 09:31:39 --> Helper loaded: url_helper
INFO - 2025-05-06 09:31:39 --> Database Driver Class Initialized
INFO - 2025-05-06 09:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:31:39 --> Form Validation Class Initialized
INFO - 2025-05-06 09:31:39 --> Controller Class Initialized
INFO - 2025-05-06 09:31:39 --> Final output sent to browser
DEBUG - 2025-05-06 09:31:39 --> Total execution time: 0.0299
INFO - 2025-05-06 09:31:54 --> Config Class Initialized
INFO - 2025-05-06 09:31:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:31:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:31:54 --> Utf8 Class Initialized
INFO - 2025-05-06 09:31:54 --> URI Class Initialized
INFO - 2025-05-06 09:31:54 --> Router Class Initialized
INFO - 2025-05-06 09:31:54 --> Output Class Initialized
INFO - 2025-05-06 09:31:54 --> Security Class Initialized
DEBUG - 2025-05-06 09:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:31:54 --> Input Class Initialized
INFO - 2025-05-06 09:31:54 --> Language Class Initialized
INFO - 2025-05-06 09:31:54 --> Loader Class Initialized
INFO - 2025-05-06 09:31:54 --> Helper loaded: form_helper
INFO - 2025-05-06 09:31:54 --> Helper loaded: url_helper
INFO - 2025-05-06 09:31:54 --> Database Driver Class Initialized
INFO - 2025-05-06 09:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:31:54 --> Form Validation Class Initialized
INFO - 2025-05-06 09:31:54 --> Controller Class Initialized
DEBUG - 2025-05-06 09:31:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-06 09:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-06 09:31:54 --> Model "Ppdb_model" initialized
INFO - 2025-05-06 09:31:54 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-06 09:31:54 --> Final output sent to browser
DEBUG - 2025-05-06 09:31:54 --> Total execution time: 0.0334
INFO - 2025-05-06 09:48:07 --> Config Class Initialized
INFO - 2025-05-06 09:48:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:48:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:48:07 --> Utf8 Class Initialized
INFO - 2025-05-06 09:48:07 --> URI Class Initialized
INFO - 2025-05-06 09:48:07 --> Router Class Initialized
INFO - 2025-05-06 09:48:07 --> Output Class Initialized
INFO - 2025-05-06 09:48:07 --> Security Class Initialized
DEBUG - 2025-05-06 09:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:48:07 --> Input Class Initialized
INFO - 2025-05-06 09:48:07 --> Language Class Initialized
INFO - 2025-05-06 09:48:07 --> Loader Class Initialized
INFO - 2025-05-06 09:48:07 --> Helper loaded: form_helper
INFO - 2025-05-06 09:48:07 --> Helper loaded: url_helper
INFO - 2025-05-06 09:48:07 --> Database Driver Class Initialized
INFO - 2025-05-06 09:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:48:07 --> Form Validation Class Initialized
INFO - 2025-05-06 09:48:07 --> Controller Class Initialized
DEBUG - 2025-05-06 09:48:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-06 09:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-06 09:48:07 --> Model "Ppdb_model" initialized
INFO - 2025-05-06 09:48:07 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-06 09:48:07 --> Final output sent to browser
DEBUG - 2025-05-06 09:48:07 --> Total execution time: 0.0345
INFO - 2025-05-06 09:59:48 --> Config Class Initialized
INFO - 2025-05-06 09:59:48 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:59:48 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:59:48 --> Utf8 Class Initialized
INFO - 2025-05-06 09:59:48 --> URI Class Initialized
DEBUG - 2025-05-06 09:59:48 --> No URI present. Default controller set.
INFO - 2025-05-06 09:59:48 --> Router Class Initialized
INFO - 2025-05-06 09:59:48 --> Output Class Initialized
INFO - 2025-05-06 09:59:48 --> Security Class Initialized
DEBUG - 2025-05-06 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:59:48 --> Input Class Initialized
INFO - 2025-05-06 09:59:48 --> Language Class Initialized
INFO - 2025-05-06 09:59:48 --> Loader Class Initialized
INFO - 2025-05-06 09:59:48 --> Helper loaded: form_helper
INFO - 2025-05-06 09:59:48 --> Helper loaded: url_helper
INFO - 2025-05-06 09:59:48 --> Database Driver Class Initialized
INFO - 2025-05-06 09:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:59:48 --> Form Validation Class Initialized
INFO - 2025-05-06 09:59:48 --> Controller Class Initialized
INFO - 2025-05-06 09:59:48 --> Final output sent to browser
DEBUG - 2025-05-06 09:59:48 --> Total execution time: 0.0300
INFO - 2025-05-06 09:59:55 --> Config Class Initialized
INFO - 2025-05-06 09:59:55 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:59:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:59:55 --> Utf8 Class Initialized
INFO - 2025-05-06 09:59:55 --> URI Class Initialized
INFO - 2025-05-06 09:59:55 --> Router Class Initialized
INFO - 2025-05-06 09:59:55 --> Output Class Initialized
INFO - 2025-05-06 09:59:55 --> Security Class Initialized
DEBUG - 2025-05-06 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:59:55 --> Input Class Initialized
INFO - 2025-05-06 09:59:55 --> Language Class Initialized
INFO - 2025-05-06 09:59:55 --> Loader Class Initialized
INFO - 2025-05-06 09:59:55 --> Helper loaded: form_helper
INFO - 2025-05-06 09:59:55 --> Helper loaded: url_helper
INFO - 2025-05-06 09:59:55 --> Database Driver Class Initialized
INFO - 2025-05-06 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:59:55 --> Form Validation Class Initialized
INFO - 2025-05-06 09:59:55 --> Controller Class Initialized
INFO - 2025-05-06 09:59:55 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:59:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:59:55 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:59:55 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 09:59:55 --> Final output sent to browser
DEBUG - 2025-05-06 09:59:55 --> Total execution time: 0.0330
INFO - 2025-05-06 09:59:57 --> Config Class Initialized
INFO - 2025-05-06 09:59:57 --> Hooks Class Initialized
DEBUG - 2025-05-06 09:59:57 --> UTF-8 Support Enabled
INFO - 2025-05-06 09:59:57 --> Utf8 Class Initialized
INFO - 2025-05-06 09:59:57 --> URI Class Initialized
INFO - 2025-05-06 09:59:57 --> Router Class Initialized
INFO - 2025-05-06 09:59:57 --> Output Class Initialized
INFO - 2025-05-06 09:59:57 --> Security Class Initialized
DEBUG - 2025-05-06 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 09:59:57 --> Input Class Initialized
INFO - 2025-05-06 09:59:57 --> Language Class Initialized
INFO - 2025-05-06 09:59:57 --> Loader Class Initialized
INFO - 2025-05-06 09:59:57 --> Helper loaded: form_helper
INFO - 2025-05-06 09:59:57 --> Helper loaded: url_helper
INFO - 2025-05-06 09:59:57 --> Database Driver Class Initialized
INFO - 2025-05-06 09:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 09:59:57 --> Form Validation Class Initialized
INFO - 2025-05-06 09:59:57 --> Controller Class Initialized
INFO - 2025-05-06 09:59:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 09:59:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 09:59:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 09:59:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 09:59:57 --> Final output sent to browser
DEBUG - 2025-05-06 09:59:57 --> Total execution time: 0.0394
INFO - 2025-05-06 10:00:00 --> Config Class Initialized
INFO - 2025-05-06 10:00:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:00 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:00 --> URI Class Initialized
INFO - 2025-05-06 10:00:00 --> Router Class Initialized
INFO - 2025-05-06 10:00:00 --> Output Class Initialized
INFO - 2025-05-06 10:00:00 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:00 --> Input Class Initialized
INFO - 2025-05-06 10:00:00 --> Language Class Initialized
INFO - 2025-05-06 10:00:00 --> Loader Class Initialized
INFO - 2025-05-06 10:00:00 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:00 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:00 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:00 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:00 --> Controller Class Initialized
INFO - 2025-05-06 10:00:00 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:00:00 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:00:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:00:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 10:00:00 --> Final output sent to browser
DEBUG - 2025-05-06 10:00:00 --> Total execution time: 0.0479
INFO - 2025-05-06 10:00:04 --> Config Class Initialized
INFO - 2025-05-06 10:00:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:04 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:04 --> URI Class Initialized
INFO - 2025-05-06 10:00:04 --> Router Class Initialized
INFO - 2025-05-06 10:00:04 --> Output Class Initialized
INFO - 2025-05-06 10:00:04 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:04 --> Input Class Initialized
INFO - 2025-05-06 10:00:04 --> Language Class Initialized
INFO - 2025-05-06 10:00:04 --> Loader Class Initialized
INFO - 2025-05-06 10:00:04 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:04 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:04 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:04 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:04 --> Controller Class Initialized
INFO - 2025-05-06 10:00:04 --> Config Class Initialized
INFO - 2025-05-06 10:00:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:04 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:04 --> URI Class Initialized
INFO - 2025-05-06 10:00:04 --> Router Class Initialized
INFO - 2025-05-06 10:00:04 --> Output Class Initialized
INFO - 2025-05-06 10:00:04 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:04 --> Input Class Initialized
INFO - 2025-05-06 10:00:04 --> Language Class Initialized
INFO - 2025-05-06 10:00:04 --> Loader Class Initialized
INFO - 2025-05-06 10:00:04 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:04 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:04 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:04 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:04 --> Controller Class Initialized
INFO - 2025-05-06 10:00:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 10:00:04 --> Final output sent to browser
DEBUG - 2025-05-06 10:00:04 --> Total execution time: 0.0387
INFO - 2025-05-06 10:00:10 --> Config Class Initialized
INFO - 2025-05-06 10:00:10 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:10 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:10 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:10 --> URI Class Initialized
INFO - 2025-05-06 10:00:10 --> Router Class Initialized
INFO - 2025-05-06 10:00:10 --> Output Class Initialized
INFO - 2025-05-06 10:00:10 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:10 --> Input Class Initialized
INFO - 2025-05-06 10:00:10 --> Language Class Initialized
INFO - 2025-05-06 10:00:10 --> Loader Class Initialized
INFO - 2025-05-06 10:00:10 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:10 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:10 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:10 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:10 --> Controller Class Initialized
INFO - 2025-05-06 10:00:10 --> Config Class Initialized
INFO - 2025-05-06 10:00:10 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:10 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:10 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:10 --> URI Class Initialized
INFO - 2025-05-06 10:00:10 --> Router Class Initialized
INFO - 2025-05-06 10:00:10 --> Output Class Initialized
INFO - 2025-05-06 10:00:10 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:10 --> Input Class Initialized
INFO - 2025-05-06 10:00:10 --> Language Class Initialized
INFO - 2025-05-06 10:00:10 --> Loader Class Initialized
INFO - 2025-05-06 10:00:10 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:10 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:10 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:10 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:10 --> Controller Class Initialized
INFO - 2025-05-06 10:00:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:00:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:00:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:00:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 10:00:10 --> Final output sent to browser
DEBUG - 2025-05-06 10:00:10 --> Total execution time: 0.0414
INFO - 2025-05-06 10:00:13 --> Config Class Initialized
INFO - 2025-05-06 10:00:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:13 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:13 --> URI Class Initialized
INFO - 2025-05-06 10:00:13 --> Router Class Initialized
INFO - 2025-05-06 10:00:13 --> Output Class Initialized
INFO - 2025-05-06 10:00:13 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:13 --> Input Class Initialized
INFO - 2025-05-06 10:00:13 --> Language Class Initialized
INFO - 2025-05-06 10:00:13 --> Loader Class Initialized
INFO - 2025-05-06 10:00:14 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:14 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:14 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:14 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:14 --> Controller Class Initialized
INFO - 2025-05-06 10:00:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:00:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:00:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:00:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 10:00:14 --> Final output sent to browser
DEBUG - 2025-05-06 10:00:14 --> Total execution time: 0.0419
INFO - 2025-05-06 10:00:18 --> Config Class Initialized
INFO - 2025-05-06 10:00:18 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:18 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:18 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:18 --> URI Class Initialized
INFO - 2025-05-06 10:00:18 --> Router Class Initialized
INFO - 2025-05-06 10:00:18 --> Output Class Initialized
INFO - 2025-05-06 10:00:18 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:18 --> Input Class Initialized
INFO - 2025-05-06 10:00:18 --> Language Class Initialized
INFO - 2025-05-06 10:00:18 --> Loader Class Initialized
INFO - 2025-05-06 10:00:18 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:18 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:18 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:18 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:18 --> Controller Class Initialized
INFO - 2025-05-06 10:00:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:00:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:00:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:00:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 10:00:18 --> Final output sent to browser
DEBUG - 2025-05-06 10:00:18 --> Total execution time: 0.0434
INFO - 2025-05-06 10:00:24 --> Config Class Initialized
INFO - 2025-05-06 10:00:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:24 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:24 --> URI Class Initialized
INFO - 2025-05-06 10:00:24 --> Router Class Initialized
INFO - 2025-05-06 10:00:24 --> Output Class Initialized
INFO - 2025-05-06 10:00:24 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:24 --> Input Class Initialized
INFO - 2025-05-06 10:00:24 --> Language Class Initialized
INFO - 2025-05-06 10:00:24 --> Loader Class Initialized
INFO - 2025-05-06 10:00:24 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:24 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:24 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:24 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:24 --> Controller Class Initialized
INFO - 2025-05-06 10:00:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:00:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:00:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:00:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 10:00:24 --> Final output sent to browser
DEBUG - 2025-05-06 10:00:24 --> Total execution time: 0.0419
INFO - 2025-05-06 10:00:35 --> Config Class Initialized
INFO - 2025-05-06 10:00:35 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:35 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:35 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:35 --> URI Class Initialized
INFO - 2025-05-06 10:00:35 --> Router Class Initialized
INFO - 2025-05-06 10:00:35 --> Output Class Initialized
INFO - 2025-05-06 10:00:35 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:35 --> Input Class Initialized
INFO - 2025-05-06 10:00:35 --> Language Class Initialized
INFO - 2025-05-06 10:00:35 --> Loader Class Initialized
INFO - 2025-05-06 10:00:35 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:35 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:35 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:35 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:35 --> Controller Class Initialized
INFO - 2025-05-06 10:00:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:00:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:00:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:00:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:00:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-06 10:00:35 --> Final output sent to browser
DEBUG - 2025-05-06 10:00:35 --> Total execution time: 0.0364
INFO - 2025-05-06 10:00:46 --> Config Class Initialized
INFO - 2025-05-06 10:00:46 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:00:46 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:00:46 --> Utf8 Class Initialized
INFO - 2025-05-06 10:00:46 --> URI Class Initialized
INFO - 2025-05-06 10:00:46 --> Router Class Initialized
INFO - 2025-05-06 10:00:46 --> Output Class Initialized
INFO - 2025-05-06 10:00:46 --> Security Class Initialized
DEBUG - 2025-05-06 10:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:00:46 --> Input Class Initialized
INFO - 2025-05-06 10:00:46 --> Language Class Initialized
INFO - 2025-05-06 10:00:46 --> Loader Class Initialized
INFO - 2025-05-06 10:00:46 --> Helper loaded: form_helper
INFO - 2025-05-06 10:00:46 --> Helper loaded: url_helper
INFO - 2025-05-06 10:00:46 --> Database Driver Class Initialized
INFO - 2025-05-06 10:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:00:46 --> Form Validation Class Initialized
INFO - 2025-05-06 10:00:46 --> Controller Class Initialized
INFO - 2025-05-06 10:00:46 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:00:46 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:00:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:00:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 10:00:46 --> Final output sent to browser
DEBUG - 2025-05-06 10:00:46 --> Total execution time: 0.0393
INFO - 2025-05-06 10:01:31 --> Config Class Initialized
INFO - 2025-05-06 10:01:31 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:01:31 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:01:31 --> Utf8 Class Initialized
INFO - 2025-05-06 10:01:31 --> URI Class Initialized
INFO - 2025-05-06 10:01:31 --> Router Class Initialized
INFO - 2025-05-06 10:01:31 --> Output Class Initialized
INFO - 2025-05-06 10:01:31 --> Security Class Initialized
DEBUG - 2025-05-06 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:01:31 --> Input Class Initialized
INFO - 2025-05-06 10:01:31 --> Language Class Initialized
INFO - 2025-05-06 10:01:31 --> Loader Class Initialized
INFO - 2025-05-06 10:01:31 --> Helper loaded: form_helper
INFO - 2025-05-06 10:01:31 --> Helper loaded: url_helper
INFO - 2025-05-06 10:01:31 --> Database Driver Class Initialized
INFO - 2025-05-06 10:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:01:31 --> Form Validation Class Initialized
INFO - 2025-05-06 10:01:31 --> Controller Class Initialized
INFO - 2025-05-06 10:01:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:01:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:01:31 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:01:31 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 10:01:31 --> Final output sent to browser
DEBUG - 2025-05-06 10:01:31 --> Total execution time: 0.0459
INFO - 2025-05-06 10:01:37 --> Config Class Initialized
INFO - 2025-05-06 10:01:37 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:01:37 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:01:37 --> Utf8 Class Initialized
INFO - 2025-05-06 10:01:37 --> URI Class Initialized
INFO - 2025-05-06 10:01:37 --> Router Class Initialized
INFO - 2025-05-06 10:01:37 --> Output Class Initialized
INFO - 2025-05-06 10:01:37 --> Security Class Initialized
DEBUG - 2025-05-06 10:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:01:37 --> Input Class Initialized
INFO - 2025-05-06 10:01:37 --> Language Class Initialized
INFO - 2025-05-06 10:01:37 --> Loader Class Initialized
INFO - 2025-05-06 10:01:37 --> Helper loaded: form_helper
INFO - 2025-05-06 10:01:37 --> Helper loaded: url_helper
INFO - 2025-05-06 10:01:37 --> Database Driver Class Initialized
INFO - 2025-05-06 10:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:01:37 --> Form Validation Class Initialized
INFO - 2025-05-06 10:01:37 --> Controller Class Initialized
INFO - 2025-05-06 10:01:37 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:01:37 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:01:37 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:01:37 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/belum_daftar_ulang.php
INFO - 2025-05-06 10:01:37 --> Final output sent to browser
DEBUG - 2025-05-06 10:01:37 --> Total execution time: 0.0339
INFO - 2025-05-06 10:01:45 --> Config Class Initialized
INFO - 2025-05-06 10:01:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:01:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:01:45 --> Utf8 Class Initialized
INFO - 2025-05-06 10:01:45 --> URI Class Initialized
DEBUG - 2025-05-06 10:01:45 --> No URI present. Default controller set.
INFO - 2025-05-06 10:01:45 --> Router Class Initialized
INFO - 2025-05-06 10:01:45 --> Output Class Initialized
INFO - 2025-05-06 10:01:45 --> Security Class Initialized
DEBUG - 2025-05-06 10:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:01:45 --> Input Class Initialized
INFO - 2025-05-06 10:01:45 --> Language Class Initialized
INFO - 2025-05-06 10:01:45 --> Loader Class Initialized
INFO - 2025-05-06 10:01:45 --> Helper loaded: form_helper
INFO - 2025-05-06 10:01:45 --> Helper loaded: url_helper
INFO - 2025-05-06 10:01:45 --> Database Driver Class Initialized
INFO - 2025-05-06 10:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:01:45 --> Form Validation Class Initialized
INFO - 2025-05-06 10:01:45 --> Controller Class Initialized
INFO - 2025-05-06 10:01:45 --> Final output sent to browser
DEBUG - 2025-05-06 10:01:45 --> Total execution time: 0.0298
INFO - 2025-05-06 10:01:49 --> Config Class Initialized
INFO - 2025-05-06 10:01:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:01:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:01:49 --> Utf8 Class Initialized
INFO - 2025-05-06 10:01:49 --> URI Class Initialized
INFO - 2025-05-06 10:01:49 --> Router Class Initialized
INFO - 2025-05-06 10:01:49 --> Output Class Initialized
INFO - 2025-05-06 10:01:49 --> Security Class Initialized
DEBUG - 2025-05-06 10:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:01:49 --> Input Class Initialized
INFO - 2025-05-06 10:01:49 --> Language Class Initialized
INFO - 2025-05-06 10:01:49 --> Loader Class Initialized
INFO - 2025-05-06 10:01:49 --> Helper loaded: form_helper
INFO - 2025-05-06 10:01:49 --> Helper loaded: url_helper
INFO - 2025-05-06 10:01:49 --> Database Driver Class Initialized
INFO - 2025-05-06 10:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:01:49 --> Form Validation Class Initialized
INFO - 2025-05-06 10:01:49 --> Controller Class Initialized
INFO - 2025-05-06 10:01:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:01:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:01:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:01:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 10:01:49 --> Final output sent to browser
DEBUG - 2025-05-06 10:01:49 --> Total execution time: 0.0338
INFO - 2025-05-06 10:01:58 --> Config Class Initialized
INFO - 2025-05-06 10:01:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:01:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:01:58 --> Utf8 Class Initialized
INFO - 2025-05-06 10:01:58 --> URI Class Initialized
INFO - 2025-05-06 10:01:58 --> Router Class Initialized
INFO - 2025-05-06 10:01:58 --> Output Class Initialized
INFO - 2025-05-06 10:01:58 --> Security Class Initialized
DEBUG - 2025-05-06 10:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:01:58 --> Input Class Initialized
INFO - 2025-05-06 10:01:58 --> Language Class Initialized
INFO - 2025-05-06 10:01:58 --> Loader Class Initialized
INFO - 2025-05-06 10:01:58 --> Helper loaded: form_helper
INFO - 2025-05-06 10:01:58 --> Helper loaded: url_helper
INFO - 2025-05-06 10:01:58 --> Database Driver Class Initialized
INFO - 2025-05-06 10:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:01:58 --> Form Validation Class Initialized
INFO - 2025-05-06 10:01:58 --> Controller Class Initialized
INFO - 2025-05-06 10:01:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:01:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:01:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:01:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 10:01:58 --> Final output sent to browser
DEBUG - 2025-05-06 10:01:58 --> Total execution time: 0.0359
INFO - 2025-05-06 10:02:02 --> Config Class Initialized
INFO - 2025-05-06 10:02:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:02:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:02:02 --> Utf8 Class Initialized
INFO - 2025-05-06 10:02:02 --> URI Class Initialized
INFO - 2025-05-06 10:02:02 --> Router Class Initialized
INFO - 2025-05-06 10:02:02 --> Output Class Initialized
INFO - 2025-05-06 10:02:02 --> Security Class Initialized
DEBUG - 2025-05-06 10:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:02:02 --> Input Class Initialized
INFO - 2025-05-06 10:02:02 --> Language Class Initialized
INFO - 2025-05-06 10:02:02 --> Loader Class Initialized
INFO - 2025-05-06 10:02:02 --> Helper loaded: form_helper
INFO - 2025-05-06 10:02:02 --> Helper loaded: url_helper
INFO - 2025-05-06 10:02:02 --> Database Driver Class Initialized
INFO - 2025-05-06 10:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:02:02 --> Form Validation Class Initialized
INFO - 2025-05-06 10:02:02 --> Controller Class Initialized
INFO - 2025-05-06 10:02:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:02:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:02:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:02:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 10:02:02 --> Final output sent to browser
DEBUG - 2025-05-06 10:02:02 --> Total execution time: 0.0445
INFO - 2025-05-06 10:02:05 --> Config Class Initialized
INFO - 2025-05-06 10:02:05 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:02:05 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:02:05 --> Utf8 Class Initialized
INFO - 2025-05-06 10:02:05 --> URI Class Initialized
INFO - 2025-05-06 10:02:05 --> Router Class Initialized
INFO - 2025-05-06 10:02:05 --> Output Class Initialized
INFO - 2025-05-06 10:02:05 --> Security Class Initialized
DEBUG - 2025-05-06 10:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:02:05 --> Input Class Initialized
INFO - 2025-05-06 10:02:05 --> Language Class Initialized
INFO - 2025-05-06 10:02:05 --> Loader Class Initialized
INFO - 2025-05-06 10:02:05 --> Helper loaded: form_helper
INFO - 2025-05-06 10:02:05 --> Helper loaded: url_helper
INFO - 2025-05-06 10:02:05 --> Database Driver Class Initialized
INFO - 2025-05-06 10:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:02:05 --> Form Validation Class Initialized
INFO - 2025-05-06 10:02:05 --> Controller Class Initialized
INFO - 2025-05-06 10:02:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:02:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:02:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:02:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 10:02:05 --> Final output sent to browser
DEBUG - 2025-05-06 10:02:05 --> Total execution time: 0.0428
INFO - 2025-05-06 10:02:08 --> Config Class Initialized
INFO - 2025-05-06 10:02:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:02:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:02:08 --> Utf8 Class Initialized
INFO - 2025-05-06 10:02:08 --> URI Class Initialized
INFO - 2025-05-06 10:02:08 --> Router Class Initialized
INFO - 2025-05-06 10:02:08 --> Output Class Initialized
INFO - 2025-05-06 10:02:08 --> Security Class Initialized
DEBUG - 2025-05-06 10:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:02:08 --> Input Class Initialized
INFO - 2025-05-06 10:02:08 --> Language Class Initialized
INFO - 2025-05-06 10:02:08 --> Loader Class Initialized
INFO - 2025-05-06 10:02:08 --> Helper loaded: form_helper
INFO - 2025-05-06 10:02:08 --> Helper loaded: url_helper
INFO - 2025-05-06 10:02:08 --> Database Driver Class Initialized
INFO - 2025-05-06 10:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:02:08 --> Form Validation Class Initialized
INFO - 2025-05-06 10:02:08 --> Controller Class Initialized
INFO - 2025-05-06 10:02:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:02:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:02:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:02:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/belum_daftar_ulang.php
INFO - 2025-05-06 10:02:08 --> Final output sent to browser
DEBUG - 2025-05-06 10:02:08 --> Total execution time: 0.0393
INFO - 2025-05-06 10:02:11 --> Config Class Initialized
INFO - 2025-05-06 10:02:11 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:02:11 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:02:11 --> Utf8 Class Initialized
INFO - 2025-05-06 10:02:11 --> URI Class Initialized
INFO - 2025-05-06 10:02:11 --> Router Class Initialized
INFO - 2025-05-06 10:02:11 --> Output Class Initialized
INFO - 2025-05-06 10:02:11 --> Security Class Initialized
DEBUG - 2025-05-06 10:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:02:11 --> Input Class Initialized
INFO - 2025-05-06 10:02:11 --> Language Class Initialized
INFO - 2025-05-06 10:02:11 --> Loader Class Initialized
INFO - 2025-05-06 10:02:11 --> Helper loaded: form_helper
INFO - 2025-05-06 10:02:11 --> Helper loaded: url_helper
INFO - 2025-05-06 10:02:11 --> Database Driver Class Initialized
INFO - 2025-05-06 10:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:02:11 --> Form Validation Class Initialized
INFO - 2025-05-06 10:02:11 --> Controller Class Initialized
INFO - 2025-05-06 10:02:11 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:02:11 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:02:11 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:02:11 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 10:02:11 --> Final output sent to browser
DEBUG - 2025-05-06 10:02:11 --> Total execution time: 0.0381
INFO - 2025-05-06 10:02:13 --> Config Class Initialized
INFO - 2025-05-06 10:02:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:02:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:02:13 --> Utf8 Class Initialized
INFO - 2025-05-06 10:02:13 --> URI Class Initialized
INFO - 2025-05-06 10:02:13 --> Router Class Initialized
INFO - 2025-05-06 10:02:13 --> Output Class Initialized
INFO - 2025-05-06 10:02:13 --> Security Class Initialized
DEBUG - 2025-05-06 10:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:02:13 --> Input Class Initialized
INFO - 2025-05-06 10:02:13 --> Language Class Initialized
INFO - 2025-05-06 10:02:13 --> Loader Class Initialized
INFO - 2025-05-06 10:02:13 --> Helper loaded: form_helper
INFO - 2025-05-06 10:02:13 --> Helper loaded: url_helper
INFO - 2025-05-06 10:02:13 --> Database Driver Class Initialized
INFO - 2025-05-06 10:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:02:13 --> Form Validation Class Initialized
INFO - 2025-05-06 10:02:13 --> Controller Class Initialized
INFO - 2025-05-06 10:02:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:02:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:02:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:02:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 10:02:13 --> Final output sent to browser
DEBUG - 2025-05-06 10:02:13 --> Total execution time: 0.0313
INFO - 2025-05-06 10:02:50 --> Config Class Initialized
INFO - 2025-05-06 10:02:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:02:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:02:50 --> Utf8 Class Initialized
INFO - 2025-05-06 10:02:50 --> URI Class Initialized
INFO - 2025-05-06 10:02:50 --> Router Class Initialized
INFO - 2025-05-06 10:02:50 --> Output Class Initialized
INFO - 2025-05-06 10:02:50 --> Security Class Initialized
DEBUG - 2025-05-06 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:02:50 --> Input Class Initialized
INFO - 2025-05-06 10:02:50 --> Language Class Initialized
INFO - 2025-05-06 10:02:50 --> Loader Class Initialized
INFO - 2025-05-06 10:02:50 --> Helper loaded: form_helper
INFO - 2025-05-06 10:02:50 --> Helper loaded: url_helper
INFO - 2025-05-06 10:02:51 --> Database Driver Class Initialized
INFO - 2025-05-06 10:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:02:51 --> Form Validation Class Initialized
INFO - 2025-05-06 10:02:51 --> Controller Class Initialized
INFO - 2025-05-06 10:02:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:02:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:02:51 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:02:51 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 10:02:51 --> Final output sent to browser
DEBUG - 2025-05-06 10:02:51 --> Total execution time: 0.0380
INFO - 2025-05-06 10:03:09 --> Config Class Initialized
INFO - 2025-05-06 10:03:09 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:03:09 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:03:09 --> Utf8 Class Initialized
INFO - 2025-05-06 10:03:09 --> URI Class Initialized
INFO - 2025-05-06 10:03:09 --> Router Class Initialized
INFO - 2025-05-06 10:03:09 --> Output Class Initialized
INFO - 2025-05-06 10:03:09 --> Security Class Initialized
DEBUG - 2025-05-06 10:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:03:09 --> Input Class Initialized
INFO - 2025-05-06 10:03:09 --> Language Class Initialized
INFO - 2025-05-06 10:03:09 --> Loader Class Initialized
INFO - 2025-05-06 10:03:09 --> Helper loaded: form_helper
INFO - 2025-05-06 10:03:09 --> Helper loaded: url_helper
INFO - 2025-05-06 10:03:09 --> Database Driver Class Initialized
INFO - 2025-05-06 10:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:03:09 --> Form Validation Class Initialized
INFO - 2025-05-06 10:03:09 --> Controller Class Initialized
INFO - 2025-05-06 10:03:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:03:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:03:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:03:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_sekolah.php
INFO - 2025-05-06 10:03:09 --> Final output sent to browser
DEBUG - 2025-05-06 10:03:09 --> Total execution time: 0.0431
INFO - 2025-05-06 10:03:10 --> Config Class Initialized
INFO - 2025-05-06 10:03:10 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:03:10 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:03:10 --> Utf8 Class Initialized
INFO - 2025-05-06 10:03:10 --> URI Class Initialized
INFO - 2025-05-06 10:03:10 --> Router Class Initialized
INFO - 2025-05-06 10:03:10 --> Output Class Initialized
INFO - 2025-05-06 10:03:10 --> Security Class Initialized
DEBUG - 2025-05-06 10:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:03:10 --> Input Class Initialized
INFO - 2025-05-06 10:03:10 --> Language Class Initialized
INFO - 2025-05-06 10:03:10 --> Loader Class Initialized
INFO - 2025-05-06 10:03:10 --> Helper loaded: form_helper
INFO - 2025-05-06 10:03:10 --> Helper loaded: url_helper
INFO - 2025-05-06 10:03:10 --> Database Driver Class Initialized
INFO - 2025-05-06 10:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:03:10 --> Form Validation Class Initialized
INFO - 2025-05-06 10:03:10 --> Controller Class Initialized
INFO - 2025-05-06 10:03:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:03:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:03:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:03:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-06 10:03:10 --> Final output sent to browser
DEBUG - 2025-05-06 10:03:10 --> Total execution time: 0.0426
INFO - 2025-05-06 10:03:57 --> Config Class Initialized
INFO - 2025-05-06 10:03:57 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:03:57 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:03:57 --> Utf8 Class Initialized
INFO - 2025-05-06 10:03:57 --> URI Class Initialized
INFO - 2025-05-06 10:03:57 --> Router Class Initialized
INFO - 2025-05-06 10:03:57 --> Output Class Initialized
INFO - 2025-05-06 10:03:57 --> Security Class Initialized
DEBUG - 2025-05-06 10:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:03:57 --> Input Class Initialized
INFO - 2025-05-06 10:03:57 --> Language Class Initialized
INFO - 2025-05-06 10:03:57 --> Loader Class Initialized
INFO - 2025-05-06 10:03:57 --> Helper loaded: form_helper
INFO - 2025-05-06 10:03:57 --> Helper loaded: url_helper
INFO - 2025-05-06 10:03:57 --> Database Driver Class Initialized
INFO - 2025-05-06 10:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:03:57 --> Form Validation Class Initialized
INFO - 2025-05-06 10:03:57 --> Controller Class Initialized
INFO - 2025-05-06 10:03:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:03:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:03:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:03:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/pengaturan.php
INFO - 2025-05-06 10:03:57 --> Final output sent to browser
DEBUG - 2025-05-06 10:03:57 --> Total execution time: 0.0439
INFO - 2025-05-06 10:04:17 --> Config Class Initialized
INFO - 2025-05-06 10:04:17 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:04:17 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:04:17 --> Utf8 Class Initialized
INFO - 2025-05-06 10:04:17 --> URI Class Initialized
INFO - 2025-05-06 10:04:17 --> Router Class Initialized
INFO - 2025-05-06 10:04:17 --> Output Class Initialized
INFO - 2025-05-06 10:04:17 --> Security Class Initialized
DEBUG - 2025-05-06 10:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:04:17 --> Input Class Initialized
INFO - 2025-05-06 10:04:17 --> Language Class Initialized
INFO - 2025-05-06 10:04:17 --> Loader Class Initialized
INFO - 2025-05-06 10:04:17 --> Helper loaded: form_helper
INFO - 2025-05-06 10:04:17 --> Helper loaded: url_helper
INFO - 2025-05-06 10:04:17 --> Database Driver Class Initialized
INFO - 2025-05-06 10:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:04:17 --> Form Validation Class Initialized
INFO - 2025-05-06 10:04:17 --> Controller Class Initialized
INFO - 2025-05-06 10:04:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:04:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:04:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:04:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 10:04:17 --> Final output sent to browser
DEBUG - 2025-05-06 10:04:17 --> Total execution time: 0.0366
INFO - 2025-05-06 10:04:22 --> Config Class Initialized
INFO - 2025-05-06 10:04:22 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:04:22 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:04:22 --> Utf8 Class Initialized
INFO - 2025-05-06 10:04:22 --> URI Class Initialized
INFO - 2025-05-06 10:04:22 --> Router Class Initialized
INFO - 2025-05-06 10:04:22 --> Output Class Initialized
INFO - 2025-05-06 10:04:22 --> Security Class Initialized
DEBUG - 2025-05-06 10:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:04:22 --> Input Class Initialized
INFO - 2025-05-06 10:04:22 --> Language Class Initialized
INFO - 2025-05-06 10:04:22 --> Loader Class Initialized
INFO - 2025-05-06 10:04:22 --> Helper loaded: form_helper
INFO - 2025-05-06 10:04:22 --> Helper loaded: url_helper
INFO - 2025-05-06 10:04:22 --> Database Driver Class Initialized
INFO - 2025-05-06 10:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:04:22 --> Form Validation Class Initialized
INFO - 2025-05-06 10:04:22 --> Controller Class Initialized
INFO - 2025-05-06 10:04:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:04:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:04:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:04:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 10:04:22 --> Final output sent to browser
DEBUG - 2025-05-06 10:04:22 --> Total execution time: 0.0390
INFO - 2025-05-06 10:04:34 --> Config Class Initialized
INFO - 2025-05-06 10:04:34 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:04:34 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:04:34 --> Utf8 Class Initialized
INFO - 2025-05-06 10:04:34 --> URI Class Initialized
INFO - 2025-05-06 10:04:34 --> Router Class Initialized
INFO - 2025-05-06 10:04:34 --> Output Class Initialized
INFO - 2025-05-06 10:04:34 --> Security Class Initialized
DEBUG - 2025-05-06 10:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:04:34 --> Input Class Initialized
INFO - 2025-05-06 10:04:34 --> Language Class Initialized
INFO - 2025-05-06 10:04:34 --> Loader Class Initialized
INFO - 2025-05-06 10:04:34 --> Helper loaded: form_helper
INFO - 2025-05-06 10:04:34 --> Helper loaded: url_helper
INFO - 2025-05-06 10:04:34 --> Database Driver Class Initialized
INFO - 2025-05-06 10:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:04:34 --> Form Validation Class Initialized
INFO - 2025-05-06 10:04:34 --> Controller Class Initialized
INFO - 2025-05-06 10:04:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:04:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:04:34 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:04:34 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 10:04:34 --> Final output sent to browser
DEBUG - 2025-05-06 10:04:34 --> Total execution time: 0.0387
INFO - 2025-05-06 10:04:36 --> Config Class Initialized
INFO - 2025-05-06 10:04:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:04:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:04:36 --> Utf8 Class Initialized
INFO - 2025-05-06 10:04:36 --> URI Class Initialized
INFO - 2025-05-06 10:04:36 --> Router Class Initialized
INFO - 2025-05-06 10:04:36 --> Output Class Initialized
INFO - 2025-05-06 10:04:36 --> Security Class Initialized
DEBUG - 2025-05-06 10:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:04:36 --> Input Class Initialized
INFO - 2025-05-06 10:04:36 --> Language Class Initialized
INFO - 2025-05-06 10:04:36 --> Loader Class Initialized
INFO - 2025-05-06 10:04:36 --> Helper loaded: form_helper
INFO - 2025-05-06 10:04:36 --> Helper loaded: url_helper
INFO - 2025-05-06 10:04:36 --> Database Driver Class Initialized
INFO - 2025-05-06 10:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:04:36 --> Form Validation Class Initialized
INFO - 2025-05-06 10:04:36 --> Controller Class Initialized
INFO - 2025-05-06 10:04:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:04:36 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:04:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:04:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 10:04:36 --> Final output sent to browser
DEBUG - 2025-05-06 10:04:36 --> Total execution time: 0.0352
INFO - 2025-05-06 10:04:57 --> Config Class Initialized
INFO - 2025-05-06 10:04:57 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:04:57 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:04:57 --> Utf8 Class Initialized
INFO - 2025-05-06 10:04:57 --> URI Class Initialized
INFO - 2025-05-06 10:04:57 --> Router Class Initialized
INFO - 2025-05-06 10:04:57 --> Output Class Initialized
INFO - 2025-05-06 10:04:57 --> Security Class Initialized
DEBUG - 2025-05-06 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:04:57 --> Input Class Initialized
INFO - 2025-05-06 10:04:57 --> Language Class Initialized
INFO - 2025-05-06 10:04:57 --> Loader Class Initialized
INFO - 2025-05-06 10:04:57 --> Helper loaded: form_helper
INFO - 2025-05-06 10:04:57 --> Helper loaded: url_helper
INFO - 2025-05-06 10:04:57 --> Database Driver Class Initialized
INFO - 2025-05-06 10:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:04:57 --> Form Validation Class Initialized
INFO - 2025-05-06 10:04:57 --> Controller Class Initialized
INFO - 2025-05-06 10:04:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:04:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:04:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:04:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/belum_daftar_ulang.php
INFO - 2025-05-06 10:04:57 --> Final output sent to browser
DEBUG - 2025-05-06 10:04:57 --> Total execution time: 0.0374
INFO - 2025-05-06 10:05:04 --> Config Class Initialized
INFO - 2025-05-06 10:05:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:05:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:05:04 --> Utf8 Class Initialized
INFO - 2025-05-06 10:05:04 --> URI Class Initialized
INFO - 2025-05-06 10:05:04 --> Router Class Initialized
INFO - 2025-05-06 10:05:04 --> Output Class Initialized
INFO - 2025-05-06 10:05:04 --> Security Class Initialized
DEBUG - 2025-05-06 10:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:05:04 --> Input Class Initialized
INFO - 2025-05-06 10:05:04 --> Language Class Initialized
INFO - 2025-05-06 10:05:04 --> Loader Class Initialized
INFO - 2025-05-06 10:05:04 --> Helper loaded: form_helper
INFO - 2025-05-06 10:05:04 --> Helper loaded: url_helper
INFO - 2025-05-06 10:05:04 --> Database Driver Class Initialized
INFO - 2025-05-06 10:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:05:04 --> Form Validation Class Initialized
INFO - 2025-05-06 10:05:04 --> Controller Class Initialized
INFO - 2025-05-06 10:05:04 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:05:04 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:05:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:05:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 10:05:04 --> Final output sent to browser
DEBUG - 2025-05-06 10:05:04 --> Total execution time: 0.0396
INFO - 2025-05-06 10:05:06 --> Config Class Initialized
INFO - 2025-05-06 10:05:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:05:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:05:06 --> Utf8 Class Initialized
INFO - 2025-05-06 10:05:06 --> URI Class Initialized
INFO - 2025-05-06 10:05:06 --> Router Class Initialized
INFO - 2025-05-06 10:05:06 --> Output Class Initialized
INFO - 2025-05-06 10:05:06 --> Security Class Initialized
DEBUG - 2025-05-06 10:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:05:06 --> Input Class Initialized
INFO - 2025-05-06 10:05:06 --> Language Class Initialized
INFO - 2025-05-06 10:05:06 --> Loader Class Initialized
INFO - 2025-05-06 10:05:06 --> Helper loaded: form_helper
INFO - 2025-05-06 10:05:06 --> Helper loaded: url_helper
INFO - 2025-05-06 10:05:06 --> Database Driver Class Initialized
INFO - 2025-05-06 10:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:05:06 --> Form Validation Class Initialized
INFO - 2025-05-06 10:05:06 --> Controller Class Initialized
INFO - 2025-05-06 10:05:06 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:05:06 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:05:06 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:05:06 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/belum_daftar_ulang.php
INFO - 2025-05-06 10:05:06 --> Final output sent to browser
DEBUG - 2025-05-06 10:05:06 --> Total execution time: 0.0340
INFO - 2025-05-06 10:10:41 --> Config Class Initialized
INFO - 2025-05-06 10:10:41 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:10:41 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:10:41 --> Utf8 Class Initialized
INFO - 2025-05-06 10:10:41 --> URI Class Initialized
INFO - 2025-05-06 10:10:41 --> Router Class Initialized
INFO - 2025-05-06 10:10:41 --> Output Class Initialized
INFO - 2025-05-06 10:10:41 --> Security Class Initialized
DEBUG - 2025-05-06 10:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:10:41 --> Input Class Initialized
INFO - 2025-05-06 10:10:41 --> Language Class Initialized
INFO - 2025-05-06 10:10:41 --> Loader Class Initialized
INFO - 2025-05-06 10:10:41 --> Helper loaded: form_helper
INFO - 2025-05-06 10:10:41 --> Helper loaded: url_helper
INFO - 2025-05-06 10:10:41 --> Database Driver Class Initialized
INFO - 2025-05-06 10:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:10:41 --> Form Validation Class Initialized
INFO - 2025-05-06 10:10:41 --> Controller Class Initialized
INFO - 2025-05-06 10:10:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:10:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:10:41 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:10:41 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_sekolah.php
INFO - 2025-05-06 10:10:41 --> Final output sent to browser
DEBUG - 2025-05-06 10:10:41 --> Total execution time: 0.0383
INFO - 2025-05-06 10:12:10 --> Config Class Initialized
INFO - 2025-05-06 10:12:10 --> Hooks Class Initialized
DEBUG - 2025-05-06 10:12:10 --> UTF-8 Support Enabled
INFO - 2025-05-06 10:12:10 --> Utf8 Class Initialized
INFO - 2025-05-06 10:12:10 --> URI Class Initialized
INFO - 2025-05-06 10:12:10 --> Router Class Initialized
INFO - 2025-05-06 10:12:10 --> Output Class Initialized
INFO - 2025-05-06 10:12:10 --> Security Class Initialized
DEBUG - 2025-05-06 10:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 10:12:10 --> Input Class Initialized
INFO - 2025-05-06 10:12:10 --> Language Class Initialized
INFO - 2025-05-06 10:12:10 --> Loader Class Initialized
INFO - 2025-05-06 10:12:10 --> Helper loaded: form_helper
INFO - 2025-05-06 10:12:10 --> Helper loaded: url_helper
INFO - 2025-05-06 10:12:10 --> Database Driver Class Initialized
INFO - 2025-05-06 10:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 10:12:10 --> Form Validation Class Initialized
INFO - 2025-05-06 10:12:10 --> Controller Class Initialized
INFO - 2025-05-06 10:12:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 10:12:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 10:12:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 10:12:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 10:12:10 --> Final output sent to browser
DEBUG - 2025-05-06 10:12:10 --> Total execution time: 0.0361
INFO - 2025-05-06 12:12:54 --> Config Class Initialized
INFO - 2025-05-06 12:12:54 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:12:54 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:12:54 --> Utf8 Class Initialized
INFO - 2025-05-06 12:12:54 --> URI Class Initialized
DEBUG - 2025-05-06 12:12:54 --> No URI present. Default controller set.
INFO - 2025-05-06 12:12:54 --> Router Class Initialized
INFO - 2025-05-06 12:12:54 --> Output Class Initialized
INFO - 2025-05-06 12:12:54 --> Security Class Initialized
DEBUG - 2025-05-06 12:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:12:54 --> Input Class Initialized
INFO - 2025-05-06 12:12:54 --> Language Class Initialized
INFO - 2025-05-06 12:12:54 --> Loader Class Initialized
INFO - 2025-05-06 12:12:54 --> Helper loaded: form_helper
INFO - 2025-05-06 12:12:54 --> Helper loaded: url_helper
INFO - 2025-05-06 12:12:54 --> Database Driver Class Initialized
INFO - 2025-05-06 12:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:12:54 --> Form Validation Class Initialized
INFO - 2025-05-06 12:12:54 --> Controller Class Initialized
INFO - 2025-05-06 12:12:54 --> Final output sent to browser
DEBUG - 2025-05-06 12:12:54 --> Total execution time: 0.0356
INFO - 2025-05-06 12:12:58 --> Config Class Initialized
INFO - 2025-05-06 12:12:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:12:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:12:58 --> Utf8 Class Initialized
INFO - 2025-05-06 12:12:58 --> URI Class Initialized
INFO - 2025-05-06 12:12:58 --> Router Class Initialized
INFO - 2025-05-06 12:12:58 --> Output Class Initialized
INFO - 2025-05-06 12:12:58 --> Security Class Initialized
DEBUG - 2025-05-06 12:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:12:58 --> Input Class Initialized
INFO - 2025-05-06 12:12:58 --> Language Class Initialized
INFO - 2025-05-06 12:12:58 --> Loader Class Initialized
INFO - 2025-05-06 12:12:58 --> Helper loaded: form_helper
INFO - 2025-05-06 12:12:58 --> Helper loaded: url_helper
INFO - 2025-05-06 12:12:58 --> Database Driver Class Initialized
INFO - 2025-05-06 12:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:12:58 --> Form Validation Class Initialized
INFO - 2025-05-06 12:12:58 --> Controller Class Initialized
DEBUG - 2025-05-06 12:12:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-06 12:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-06 12:12:58 --> Model "Ppdb_model" initialized
INFO - 2025-05-06 12:12:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-06 12:12:58 --> Final output sent to browser
DEBUG - 2025-05-06 12:12:58 --> Total execution time: 0.0409
INFO - 2025-05-06 12:12:58 --> Config Class Initialized
INFO - 2025-05-06 12:12:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:12:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:12:58 --> Utf8 Class Initialized
INFO - 2025-05-06 12:12:58 --> URI Class Initialized
INFO - 2025-05-06 12:12:58 --> Router Class Initialized
INFO - 2025-05-06 12:12:58 --> Output Class Initialized
INFO - 2025-05-06 12:12:58 --> Security Class Initialized
DEBUG - 2025-05-06 12:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:12:58 --> Input Class Initialized
INFO - 2025-05-06 12:12:58 --> Language Class Initialized
ERROR - 2025-05-06 12:12:58 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-06 12:13:04 --> Config Class Initialized
INFO - 2025-05-06 12:13:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:04 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:04 --> URI Class Initialized
DEBUG - 2025-05-06 12:13:04 --> No URI present. Default controller set.
INFO - 2025-05-06 12:13:04 --> Router Class Initialized
INFO - 2025-05-06 12:13:04 --> Output Class Initialized
INFO - 2025-05-06 12:13:04 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:04 --> Input Class Initialized
INFO - 2025-05-06 12:13:04 --> Language Class Initialized
INFO - 2025-05-06 12:13:04 --> Loader Class Initialized
INFO - 2025-05-06 12:13:04 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:04 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:04 --> Database Driver Class Initialized
INFO - 2025-05-06 12:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:04 --> Form Validation Class Initialized
INFO - 2025-05-06 12:13:04 --> Controller Class Initialized
INFO - 2025-05-06 12:13:04 --> Final output sent to browser
DEBUG - 2025-05-06 12:13:04 --> Total execution time: 0.0287
INFO - 2025-05-06 12:13:06 --> Config Class Initialized
INFO - 2025-05-06 12:13:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:06 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:06 --> URI Class Initialized
INFO - 2025-05-06 12:13:06 --> Router Class Initialized
INFO - 2025-05-06 12:13:06 --> Output Class Initialized
INFO - 2025-05-06 12:13:06 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:06 --> Input Class Initialized
INFO - 2025-05-06 12:13:06 --> Language Class Initialized
INFO - 2025-05-06 12:13:06 --> Loader Class Initialized
INFO - 2025-05-06 12:13:06 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:06 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:06 --> Database Driver Class Initialized
INFO - 2025-05-06 12:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:06 --> Form Validation Class Initialized
INFO - 2025-05-06 12:13:06 --> Controller Class Initialized
INFO - 2025-05-06 12:13:06 --> Config Class Initialized
INFO - 2025-05-06 12:13:06 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:06 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:06 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:06 --> URI Class Initialized
INFO - 2025-05-06 12:13:06 --> Router Class Initialized
INFO - 2025-05-06 12:13:06 --> Output Class Initialized
INFO - 2025-05-06 12:13:06 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:06 --> Input Class Initialized
INFO - 2025-05-06 12:13:06 --> Language Class Initialized
INFO - 2025-05-06 12:13:06 --> Loader Class Initialized
INFO - 2025-05-06 12:13:06 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:06 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:06 --> Database Driver Class Initialized
INFO - 2025-05-06 12:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:06 --> Form Validation Class Initialized
INFO - 2025-05-06 12:13:06 --> Controller Class Initialized
INFO - 2025-05-06 12:13:06 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 12:13:06 --> Final output sent to browser
DEBUG - 2025-05-06 12:13:06 --> Total execution time: 0.0301
INFO - 2025-05-06 12:13:08 --> Config Class Initialized
INFO - 2025-05-06 12:13:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:08 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:08 --> URI Class Initialized
INFO - 2025-05-06 12:13:08 --> Router Class Initialized
INFO - 2025-05-06 12:13:08 --> Output Class Initialized
INFO - 2025-05-06 12:13:08 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:08 --> Input Class Initialized
INFO - 2025-05-06 12:13:08 --> Language Class Initialized
INFO - 2025-05-06 12:13:08 --> Loader Class Initialized
INFO - 2025-05-06 12:13:08 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:08 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:08 --> Database Driver Class Initialized
INFO - 2025-05-06 12:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:08 --> Form Validation Class Initialized
INFO - 2025-05-06 12:13:08 --> Controller Class Initialized
INFO - 2025-05-06 12:13:08 --> Config Class Initialized
INFO - 2025-05-06 12:13:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:08 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:08 --> URI Class Initialized
INFO - 2025-05-06 12:13:08 --> Router Class Initialized
INFO - 2025-05-06 12:13:08 --> Output Class Initialized
INFO - 2025-05-06 12:13:08 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:08 --> Input Class Initialized
INFO - 2025-05-06 12:13:08 --> Language Class Initialized
INFO - 2025-05-06 12:13:08 --> Loader Class Initialized
INFO - 2025-05-06 12:13:08 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:08 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:08 --> Database Driver Class Initialized
INFO - 2025-05-06 12:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:08 --> Form Validation Class Initialized
INFO - 2025-05-06 12:13:08 --> Controller Class Initialized
INFO - 2025-05-06 12:13:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 12:13:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 12:13:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 12:13:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 12:13:08 --> Final output sent to browser
DEBUG - 2025-05-06 12:13:08 --> Total execution time: 0.0368
INFO - 2025-05-06 12:13:10 --> Config Class Initialized
INFO - 2025-05-06 12:13:10 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:10 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:10 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:10 --> URI Class Initialized
INFO - 2025-05-06 12:13:10 --> Router Class Initialized
INFO - 2025-05-06 12:13:10 --> Output Class Initialized
INFO - 2025-05-06 12:13:10 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:10 --> Input Class Initialized
INFO - 2025-05-06 12:13:10 --> Language Class Initialized
INFO - 2025-05-06 12:13:10 --> Loader Class Initialized
INFO - 2025-05-06 12:13:10 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:10 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:10 --> Database Driver Class Initialized
INFO - 2025-05-06 12:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:10 --> Form Validation Class Initialized
INFO - 2025-05-06 12:13:10 --> Controller Class Initialized
INFO - 2025-05-06 12:13:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 12:13:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 12:13:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 12:13:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 12:13:10 --> Final output sent to browser
DEBUG - 2025-05-06 12:13:10 --> Total execution time: 0.0397
INFO - 2025-05-06 12:13:14 --> Config Class Initialized
INFO - 2025-05-06 12:13:14 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:14 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:14 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:14 --> URI Class Initialized
INFO - 2025-05-06 12:13:14 --> Router Class Initialized
INFO - 2025-05-06 12:13:14 --> Output Class Initialized
INFO - 2025-05-06 12:13:14 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:14 --> Input Class Initialized
INFO - 2025-05-06 12:13:14 --> Language Class Initialized
INFO - 2025-05-06 12:13:14 --> Loader Class Initialized
INFO - 2025-05-06 12:13:14 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:14 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:14 --> Database Driver Class Initialized
INFO - 2025-05-06 12:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:14 --> Form Validation Class Initialized
INFO - 2025-05-06 12:13:14 --> Controller Class Initialized
INFO - 2025-05-06 12:13:14 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 12:13:14 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 12:13:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 12:13:14 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 12:13:14 --> Final output sent to browser
DEBUG - 2025-05-06 12:13:14 --> Total execution time: 0.0323
INFO - 2025-05-06 12:13:16 --> Config Class Initialized
INFO - 2025-05-06 12:13:16 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:13:16 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:13:16 --> Utf8 Class Initialized
INFO - 2025-05-06 12:13:16 --> URI Class Initialized
INFO - 2025-05-06 12:13:16 --> Router Class Initialized
INFO - 2025-05-06 12:13:16 --> Output Class Initialized
INFO - 2025-05-06 12:13:16 --> Security Class Initialized
DEBUG - 2025-05-06 12:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:13:16 --> Input Class Initialized
INFO - 2025-05-06 12:13:16 --> Language Class Initialized
INFO - 2025-05-06 12:13:16 --> Loader Class Initialized
INFO - 2025-05-06 12:13:16 --> Helper loaded: form_helper
INFO - 2025-05-06 12:13:16 --> Helper loaded: url_helper
INFO - 2025-05-06 12:13:16 --> Database Driver Class Initialized
INFO - 2025-05-06 12:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:13:16 --> Form Validation Class Initialized
INFO - 2025-05-06 12:13:16 --> Controller Class Initialized
INFO - 2025-05-06 12:13:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 12:13:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 12:13:16 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 12:13:16 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 12:13:16 --> Final output sent to browser
DEBUG - 2025-05-06 12:13:16 --> Total execution time: 0.0412
INFO - 2025-05-06 12:24:19 --> Config Class Initialized
INFO - 2025-05-06 12:24:19 --> Hooks Class Initialized
DEBUG - 2025-05-06 12:24:19 --> UTF-8 Support Enabled
INFO - 2025-05-06 12:24:19 --> Utf8 Class Initialized
INFO - 2025-05-06 12:24:19 --> URI Class Initialized
DEBUG - 2025-05-06 12:24:19 --> No URI present. Default controller set.
INFO - 2025-05-06 12:24:19 --> Router Class Initialized
INFO - 2025-05-06 12:24:19 --> Output Class Initialized
INFO - 2025-05-06 12:24:19 --> Security Class Initialized
DEBUG - 2025-05-06 12:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 12:24:19 --> Input Class Initialized
INFO - 2025-05-06 12:24:19 --> Language Class Initialized
INFO - 2025-05-06 12:24:19 --> Loader Class Initialized
INFO - 2025-05-06 12:24:19 --> Helper loaded: form_helper
INFO - 2025-05-06 12:24:19 --> Helper loaded: url_helper
INFO - 2025-05-06 12:24:19 --> Database Driver Class Initialized
INFO - 2025-05-06 12:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 12:24:19 --> Form Validation Class Initialized
INFO - 2025-05-06 12:24:19 --> Controller Class Initialized
INFO - 2025-05-06 12:24:19 --> Final output sent to browser
DEBUG - 2025-05-06 12:24:19 --> Total execution time: 0.0307
INFO - 2025-05-06 13:01:30 --> Config Class Initialized
INFO - 2025-05-06 13:01:30 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:30 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:30 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:30 --> URI Class Initialized
INFO - 2025-05-06 13:01:30 --> Router Class Initialized
INFO - 2025-05-06 13:01:30 --> Output Class Initialized
INFO - 2025-05-06 13:01:30 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:30 --> Input Class Initialized
INFO - 2025-05-06 13:01:30 --> Language Class Initialized
INFO - 2025-05-06 13:01:30 --> Loader Class Initialized
INFO - 2025-05-06 13:01:30 --> Helper loaded: form_helper
INFO - 2025-05-06 13:01:30 --> Helper loaded: url_helper
INFO - 2025-05-06 13:01:30 --> Database Driver Class Initialized
INFO - 2025-05-06 13:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:01:30 --> Form Validation Class Initialized
INFO - 2025-05-06 13:01:30 --> Controller Class Initialized
INFO - 2025-05-06 13:01:31 --> Config Class Initialized
INFO - 2025-05-06 13:01:31 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:31 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:31 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:31 --> URI Class Initialized
INFO - 2025-05-06 13:01:31 --> Router Class Initialized
INFO - 2025-05-06 13:01:31 --> Output Class Initialized
INFO - 2025-05-06 13:01:31 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:31 --> Input Class Initialized
INFO - 2025-05-06 13:01:31 --> Language Class Initialized
INFO - 2025-05-06 13:01:31 --> Loader Class Initialized
INFO - 2025-05-06 13:01:31 --> Helper loaded: form_helper
INFO - 2025-05-06 13:01:31 --> Helper loaded: url_helper
INFO - 2025-05-06 13:01:31 --> Database Driver Class Initialized
INFO - 2025-05-06 13:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:01:31 --> Form Validation Class Initialized
INFO - 2025-05-06 13:01:31 --> Controller Class Initialized
INFO - 2025-05-06 13:01:31 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 13:01:31 --> Final output sent to browser
DEBUG - 2025-05-06 13:01:31 --> Total execution time: 0.0346
INFO - 2025-05-06 13:01:31 --> Config Class Initialized
INFO - 2025-05-06 13:01:31 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:31 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:31 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:31 --> URI Class Initialized
INFO - 2025-05-06 13:01:31 --> Router Class Initialized
INFO - 2025-05-06 13:01:31 --> Output Class Initialized
INFO - 2025-05-06 13:01:31 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:31 --> Input Class Initialized
INFO - 2025-05-06 13:01:31 --> Language Class Initialized
ERROR - 2025-05-06 13:01:31 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-06 13:01:52 --> Config Class Initialized
INFO - 2025-05-06 13:01:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:52 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:52 --> URI Class Initialized
DEBUG - 2025-05-06 13:01:52 --> No URI present. Default controller set.
INFO - 2025-05-06 13:01:52 --> Router Class Initialized
INFO - 2025-05-06 13:01:52 --> Output Class Initialized
INFO - 2025-05-06 13:01:52 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:52 --> Input Class Initialized
INFO - 2025-05-06 13:01:52 --> Language Class Initialized
INFO - 2025-05-06 13:01:52 --> Loader Class Initialized
INFO - 2025-05-06 13:01:52 --> Helper loaded: form_helper
INFO - 2025-05-06 13:01:52 --> Helper loaded: url_helper
INFO - 2025-05-06 13:01:52 --> Database Driver Class Initialized
INFO - 2025-05-06 13:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:01:52 --> Form Validation Class Initialized
INFO - 2025-05-06 13:01:52 --> Controller Class Initialized
INFO - 2025-05-06 13:01:52 --> Final output sent to browser
DEBUG - 2025-05-06 13:01:52 --> Total execution time: 0.0346
INFO - 2025-05-06 13:01:55 --> Config Class Initialized
INFO - 2025-05-06 13:01:55 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:55 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:55 --> URI Class Initialized
INFO - 2025-05-06 13:01:55 --> Router Class Initialized
INFO - 2025-05-06 13:01:55 --> Output Class Initialized
INFO - 2025-05-06 13:01:55 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:55 --> Input Class Initialized
INFO - 2025-05-06 13:01:55 --> Language Class Initialized
INFO - 2025-05-06 13:01:55 --> Loader Class Initialized
INFO - 2025-05-06 13:01:55 --> Helper loaded: form_helper
INFO - 2025-05-06 13:01:55 --> Helper loaded: url_helper
INFO - 2025-05-06 13:01:55 --> Database Driver Class Initialized
INFO - 2025-05-06 13:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:01:55 --> Form Validation Class Initialized
INFO - 2025-05-06 13:01:55 --> Controller Class Initialized
INFO - 2025-05-06 13:01:55 --> Config Class Initialized
INFO - 2025-05-06 13:01:55 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:55 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:55 --> URI Class Initialized
INFO - 2025-05-06 13:01:55 --> Router Class Initialized
INFO - 2025-05-06 13:01:55 --> Output Class Initialized
INFO - 2025-05-06 13:01:55 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:55 --> Input Class Initialized
INFO - 2025-05-06 13:01:55 --> Language Class Initialized
INFO - 2025-05-06 13:01:55 --> Loader Class Initialized
INFO - 2025-05-06 13:01:55 --> Helper loaded: form_helper
INFO - 2025-05-06 13:01:55 --> Helper loaded: url_helper
INFO - 2025-05-06 13:01:55 --> Database Driver Class Initialized
INFO - 2025-05-06 13:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:01:55 --> Form Validation Class Initialized
INFO - 2025-05-06 13:01:55 --> Controller Class Initialized
INFO - 2025-05-06 13:01:55 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 13:01:55 --> Final output sent to browser
DEBUG - 2025-05-06 13:01:55 --> Total execution time: 0.0299
INFO - 2025-05-06 13:01:55 --> Config Class Initialized
INFO - 2025-05-06 13:01:55 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:55 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:55 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:55 --> URI Class Initialized
INFO - 2025-05-06 13:01:55 --> Router Class Initialized
INFO - 2025-05-06 13:01:55 --> Output Class Initialized
INFO - 2025-05-06 13:01:55 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:55 --> Input Class Initialized
INFO - 2025-05-06 13:01:55 --> Language Class Initialized
INFO - 2025-05-06 13:01:55 --> Loader Class Initialized
INFO - 2025-05-06 13:01:55 --> Helper loaded: form_helper
INFO - 2025-05-06 13:01:55 --> Helper loaded: url_helper
INFO - 2025-05-06 13:01:55 --> Database Driver Class Initialized
INFO - 2025-05-06 13:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:01:55 --> Form Validation Class Initialized
INFO - 2025-05-06 13:01:55 --> Controller Class Initialized
INFO - 2025-05-06 13:01:56 --> Config Class Initialized
INFO - 2025-05-06 13:01:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:56 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:56 --> URI Class Initialized
INFO - 2025-05-06 13:01:56 --> Router Class Initialized
INFO - 2025-05-06 13:01:56 --> Output Class Initialized
INFO - 2025-05-06 13:01:56 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:56 --> Input Class Initialized
INFO - 2025-05-06 13:01:56 --> Language Class Initialized
ERROR - 2025-05-06 13:01:56 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-06 13:01:56 --> Config Class Initialized
INFO - 2025-05-06 13:01:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:56 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:56 --> URI Class Initialized
INFO - 2025-05-06 13:01:56 --> Router Class Initialized
INFO - 2025-05-06 13:01:56 --> Output Class Initialized
INFO - 2025-05-06 13:01:56 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:56 --> Input Class Initialized
INFO - 2025-05-06 13:01:56 --> Language Class Initialized
INFO - 2025-05-06 13:01:56 --> Loader Class Initialized
INFO - 2025-05-06 13:01:56 --> Helper loaded: form_helper
INFO - 2025-05-06 13:01:56 --> Helper loaded: url_helper
INFO - 2025-05-06 13:01:56 --> Database Driver Class Initialized
INFO - 2025-05-06 13:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:01:56 --> Form Validation Class Initialized
INFO - 2025-05-06 13:01:56 --> Controller Class Initialized
INFO - 2025-05-06 13:01:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 13:01:56 --> Final output sent to browser
DEBUG - 2025-05-06 13:01:56 --> Total execution time: 0.0343
INFO - 2025-05-06 13:01:59 --> Config Class Initialized
INFO - 2025-05-06 13:01:59 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:59 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:59 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:59 --> URI Class Initialized
INFO - 2025-05-06 13:01:59 --> Router Class Initialized
INFO - 2025-05-06 13:01:59 --> Output Class Initialized
INFO - 2025-05-06 13:01:59 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:59 --> Input Class Initialized
INFO - 2025-05-06 13:01:59 --> Language Class Initialized
INFO - 2025-05-06 13:01:59 --> Loader Class Initialized
INFO - 2025-05-06 13:01:59 --> Helper loaded: form_helper
INFO - 2025-05-06 13:01:59 --> Helper loaded: url_helper
INFO - 2025-05-06 13:01:59 --> Database Driver Class Initialized
INFO - 2025-05-06 13:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:01:59 --> Form Validation Class Initialized
INFO - 2025-05-06 13:01:59 --> Controller Class Initialized
INFO - 2025-05-06 13:01:59 --> Config Class Initialized
INFO - 2025-05-06 13:01:59 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:01:59 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:01:59 --> Utf8 Class Initialized
INFO - 2025-05-06 13:01:59 --> URI Class Initialized
INFO - 2025-05-06 13:01:59 --> Router Class Initialized
INFO - 2025-05-06 13:01:59 --> Output Class Initialized
INFO - 2025-05-06 13:01:59 --> Security Class Initialized
DEBUG - 2025-05-06 13:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:01:59 --> Input Class Initialized
INFO - 2025-05-06 13:01:59 --> Language Class Initialized
INFO - 2025-05-06 13:01:59 --> Loader Class Initialized
INFO - 2025-05-06 13:01:59 --> Helper loaded: form_helper
INFO - 2025-05-06 13:01:59 --> Helper loaded: url_helper
INFO - 2025-05-06 13:01:59 --> Database Driver Class Initialized
INFO - 2025-05-06 13:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:01:59 --> Form Validation Class Initialized
INFO - 2025-05-06 13:01:59 --> Controller Class Initialized
INFO - 2025-05-06 13:01:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 13:01:59 --> Final output sent to browser
DEBUG - 2025-05-06 13:01:59 --> Total execution time: 0.0333
INFO - 2025-05-06 13:02:08 --> Config Class Initialized
INFO - 2025-05-06 13:02:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:02:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:02:08 --> Utf8 Class Initialized
INFO - 2025-05-06 13:02:08 --> URI Class Initialized
INFO - 2025-05-06 13:02:08 --> Router Class Initialized
INFO - 2025-05-06 13:02:08 --> Output Class Initialized
INFO - 2025-05-06 13:02:08 --> Security Class Initialized
DEBUG - 2025-05-06 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:02:08 --> Input Class Initialized
INFO - 2025-05-06 13:02:08 --> Language Class Initialized
INFO - 2025-05-06 13:02:08 --> Loader Class Initialized
INFO - 2025-05-06 13:02:08 --> Helper loaded: form_helper
INFO - 2025-05-06 13:02:08 --> Helper loaded: url_helper
INFO - 2025-05-06 13:02:08 --> Database Driver Class Initialized
INFO - 2025-05-06 13:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:02:08 --> Form Validation Class Initialized
INFO - 2025-05-06 13:02:08 --> Controller Class Initialized
INFO - 2025-05-06 13:02:08 --> Config Class Initialized
INFO - 2025-05-06 13:02:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:02:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:02:08 --> Utf8 Class Initialized
INFO - 2025-05-06 13:02:08 --> URI Class Initialized
INFO - 2025-05-06 13:02:08 --> Router Class Initialized
INFO - 2025-05-06 13:02:08 --> Output Class Initialized
INFO - 2025-05-06 13:02:08 --> Security Class Initialized
DEBUG - 2025-05-06 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:02:08 --> Input Class Initialized
INFO - 2025-05-06 13:02:08 --> Language Class Initialized
INFO - 2025-05-06 13:02:08 --> Loader Class Initialized
INFO - 2025-05-06 13:02:08 --> Helper loaded: form_helper
INFO - 2025-05-06 13:02:08 --> Helper loaded: url_helper
INFO - 2025-05-06 13:02:08 --> Database Driver Class Initialized
INFO - 2025-05-06 13:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:02:08 --> Form Validation Class Initialized
INFO - 2025-05-06 13:02:08 --> Controller Class Initialized
INFO - 2025-05-06 13:02:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:02:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:02:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:02:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:02:08 --> Final output sent to browser
DEBUG - 2025-05-06 13:02:08 --> Total execution time: 0.0380
INFO - 2025-05-06 13:02:13 --> Config Class Initialized
INFO - 2025-05-06 13:02:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:02:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:02:13 --> Utf8 Class Initialized
INFO - 2025-05-06 13:02:13 --> URI Class Initialized
INFO - 2025-05-06 13:02:13 --> Router Class Initialized
INFO - 2025-05-06 13:02:13 --> Output Class Initialized
INFO - 2025-05-06 13:02:13 --> Security Class Initialized
DEBUG - 2025-05-06 13:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:02:13 --> Input Class Initialized
INFO - 2025-05-06 13:02:13 --> Language Class Initialized
INFO - 2025-05-06 13:02:13 --> Loader Class Initialized
INFO - 2025-05-06 13:02:13 --> Helper loaded: form_helper
INFO - 2025-05-06 13:02:13 --> Helper loaded: url_helper
INFO - 2025-05-06 13:02:13 --> Database Driver Class Initialized
INFO - 2025-05-06 13:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:02:13 --> Form Validation Class Initialized
INFO - 2025-05-06 13:02:13 --> Controller Class Initialized
INFO - 2025-05-06 13:02:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:02:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:02:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/tambah_petugas.php
INFO - 2025-05-06 13:02:13 --> Final output sent to browser
DEBUG - 2025-05-06 13:02:13 --> Total execution time: 0.0446
INFO - 2025-05-06 13:02:50 --> Config Class Initialized
INFO - 2025-05-06 13:02:50 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:02:50 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:02:50 --> Utf8 Class Initialized
INFO - 2025-05-06 13:02:50 --> URI Class Initialized
INFO - 2025-05-06 13:02:50 --> Router Class Initialized
INFO - 2025-05-06 13:02:50 --> Output Class Initialized
INFO - 2025-05-06 13:02:50 --> Security Class Initialized
DEBUG - 2025-05-06 13:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:02:50 --> Input Class Initialized
INFO - 2025-05-06 13:02:50 --> Language Class Initialized
INFO - 2025-05-06 13:02:50 --> Loader Class Initialized
INFO - 2025-05-06 13:02:50 --> Helper loaded: form_helper
INFO - 2025-05-06 13:02:50 --> Helper loaded: url_helper
INFO - 2025-05-06 13:02:50 --> Database Driver Class Initialized
INFO - 2025-05-06 13:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:02:50 --> Form Validation Class Initialized
INFO - 2025-05-06 13:02:50 --> Controller Class Initialized
INFO - 2025-05-06 13:02:50 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:02:50 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:02:50 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/tambah_petugas.php
INFO - 2025-05-06 13:02:50 --> Final output sent to browser
DEBUG - 2025-05-06 13:02:50 --> Total execution time: 0.3173
INFO - 2025-05-06 13:02:53 --> Config Class Initialized
INFO - 2025-05-06 13:02:53 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:02:53 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:02:53 --> Utf8 Class Initialized
INFO - 2025-05-06 13:02:53 --> URI Class Initialized
INFO - 2025-05-06 13:02:53 --> Router Class Initialized
INFO - 2025-05-06 13:02:53 --> Output Class Initialized
INFO - 2025-05-06 13:02:53 --> Security Class Initialized
DEBUG - 2025-05-06 13:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:02:53 --> Input Class Initialized
INFO - 2025-05-06 13:02:53 --> Language Class Initialized
INFO - 2025-05-06 13:02:53 --> Loader Class Initialized
INFO - 2025-05-06 13:02:53 --> Helper loaded: form_helper
INFO - 2025-05-06 13:02:53 --> Helper loaded: url_helper
INFO - 2025-05-06 13:02:53 --> Database Driver Class Initialized
INFO - 2025-05-06 13:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:02:53 --> Form Validation Class Initialized
INFO - 2025-05-06 13:02:53 --> Controller Class Initialized
INFO - 2025-05-06 13:02:53 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:02:53 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:02:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:02:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:02:53 --> Final output sent to browser
DEBUG - 2025-05-06 13:02:53 --> Total execution time: 0.0353
INFO - 2025-05-06 13:03:05 --> Config Class Initialized
INFO - 2025-05-06 13:03:05 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:03:05 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:03:05 --> Utf8 Class Initialized
INFO - 2025-05-06 13:03:05 --> URI Class Initialized
INFO - 2025-05-06 13:03:05 --> Router Class Initialized
INFO - 2025-05-06 13:03:05 --> Output Class Initialized
INFO - 2025-05-06 13:03:05 --> Security Class Initialized
DEBUG - 2025-05-06 13:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:03:05 --> Input Class Initialized
INFO - 2025-05-06 13:03:05 --> Language Class Initialized
INFO - 2025-05-06 13:03:05 --> Loader Class Initialized
INFO - 2025-05-06 13:03:05 --> Helper loaded: form_helper
INFO - 2025-05-06 13:03:05 --> Helper loaded: url_helper
INFO - 2025-05-06 13:03:05 --> Database Driver Class Initialized
INFO - 2025-05-06 13:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:03:05 --> Form Validation Class Initialized
INFO - 2025-05-06 13:03:05 --> Controller Class Initialized
INFO - 2025-05-06 13:03:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:03:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:03:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:03:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 13:03:05 --> Final output sent to browser
DEBUG - 2025-05-06 13:03:05 --> Total execution time: 0.0421
INFO - 2025-05-06 13:03:07 --> Config Class Initialized
INFO - 2025-05-06 13:03:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:03:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:03:07 --> Utf8 Class Initialized
INFO - 2025-05-06 13:03:07 --> URI Class Initialized
INFO - 2025-05-06 13:03:07 --> Router Class Initialized
INFO - 2025-05-06 13:03:07 --> Output Class Initialized
INFO - 2025-05-06 13:03:07 --> Security Class Initialized
DEBUG - 2025-05-06 13:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:03:07 --> Input Class Initialized
INFO - 2025-05-06 13:03:07 --> Language Class Initialized
INFO - 2025-05-06 13:03:07 --> Loader Class Initialized
INFO - 2025-05-06 13:03:07 --> Helper loaded: form_helper
INFO - 2025-05-06 13:03:07 --> Helper loaded: url_helper
INFO - 2025-05-06 13:03:07 --> Database Driver Class Initialized
INFO - 2025-05-06 13:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:03:07 --> Form Validation Class Initialized
INFO - 2025-05-06 13:03:07 --> Controller Class Initialized
INFO - 2025-05-06 13:03:07 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:03:07 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:03:07 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:03:07 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:03:07 --> Final output sent to browser
DEBUG - 2025-05-06 13:03:07 --> Total execution time: 0.0451
INFO - 2025-05-06 13:03:08 --> Config Class Initialized
INFO - 2025-05-06 13:03:08 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:03:08 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:03:08 --> Utf8 Class Initialized
INFO - 2025-05-06 13:03:08 --> URI Class Initialized
INFO - 2025-05-06 13:03:08 --> Router Class Initialized
INFO - 2025-05-06 13:03:08 --> Output Class Initialized
INFO - 2025-05-06 13:03:08 --> Security Class Initialized
DEBUG - 2025-05-06 13:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:03:08 --> Input Class Initialized
INFO - 2025-05-06 13:03:08 --> Language Class Initialized
INFO - 2025-05-06 13:03:08 --> Loader Class Initialized
INFO - 2025-05-06 13:03:08 --> Helper loaded: form_helper
INFO - 2025-05-06 13:03:08 --> Helper loaded: url_helper
INFO - 2025-05-06 13:03:08 --> Database Driver Class Initialized
INFO - 2025-05-06 13:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:03:08 --> Form Validation Class Initialized
INFO - 2025-05-06 13:03:08 --> Controller Class Initialized
INFO - 2025-05-06 13:03:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:03:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:03:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:03:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 13:03:08 --> Final output sent to browser
DEBUG - 2025-05-06 13:03:08 --> Total execution time: 0.0452
INFO - 2025-05-06 13:04:03 --> Config Class Initialized
INFO - 2025-05-06 13:04:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:04:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:04:03 --> Utf8 Class Initialized
INFO - 2025-05-06 13:04:03 --> URI Class Initialized
INFO - 2025-05-06 13:04:03 --> Router Class Initialized
INFO - 2025-05-06 13:04:03 --> Output Class Initialized
INFO - 2025-05-06 13:04:03 --> Security Class Initialized
DEBUG - 2025-05-06 13:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:04:03 --> Input Class Initialized
INFO - 2025-05-06 13:04:03 --> Language Class Initialized
INFO - 2025-05-06 13:04:03 --> Loader Class Initialized
INFO - 2025-05-06 13:04:03 --> Helper loaded: form_helper
INFO - 2025-05-06 13:04:03 --> Helper loaded: url_helper
INFO - 2025-05-06 13:04:03 --> Database Driver Class Initialized
INFO - 2025-05-06 13:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:04:03 --> Form Validation Class Initialized
INFO - 2025-05-06 13:04:03 --> Controller Class Initialized
INFO - 2025-05-06 13:04:03 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:04:03 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:04:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:04:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 13:04:03 --> Final output sent to browser
DEBUG - 2025-05-06 13:04:03 --> Total execution time: 0.0554
INFO - 2025-05-06 13:04:10 --> Config Class Initialized
INFO - 2025-05-06 13:04:10 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:04:10 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:04:10 --> Utf8 Class Initialized
INFO - 2025-05-06 13:04:10 --> URI Class Initialized
INFO - 2025-05-06 13:04:10 --> Router Class Initialized
INFO - 2025-05-06 13:04:10 --> Output Class Initialized
INFO - 2025-05-06 13:04:10 --> Security Class Initialized
DEBUG - 2025-05-06 13:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:04:10 --> Input Class Initialized
INFO - 2025-05-06 13:04:10 --> Language Class Initialized
INFO - 2025-05-06 13:04:10 --> Loader Class Initialized
INFO - 2025-05-06 13:04:10 --> Helper loaded: form_helper
INFO - 2025-05-06 13:04:10 --> Helper loaded: url_helper
INFO - 2025-05-06 13:04:10 --> Database Driver Class Initialized
INFO - 2025-05-06 13:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:04:10 --> Form Validation Class Initialized
INFO - 2025-05-06 13:04:10 --> Controller Class Initialized
INFO - 2025-05-06 13:04:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:04:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:04:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-06 13:04:10 --> Final output sent to browser
DEBUG - 2025-05-06 13:04:10 --> Total execution time: 0.0385
INFO - 2025-05-06 13:04:38 --> Config Class Initialized
INFO - 2025-05-06 13:04:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:04:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:04:38 --> Utf8 Class Initialized
INFO - 2025-05-06 13:04:38 --> URI Class Initialized
INFO - 2025-05-06 13:04:38 --> Router Class Initialized
INFO - 2025-05-06 13:04:38 --> Output Class Initialized
INFO - 2025-05-06 13:04:38 --> Security Class Initialized
DEBUG - 2025-05-06 13:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:04:38 --> Input Class Initialized
INFO - 2025-05-06 13:04:38 --> Language Class Initialized
INFO - 2025-05-06 13:04:38 --> Loader Class Initialized
INFO - 2025-05-06 13:04:38 --> Helper loaded: form_helper
INFO - 2025-05-06 13:04:38 --> Helper loaded: url_helper
INFO - 2025-05-06 13:04:38 --> Database Driver Class Initialized
INFO - 2025-05-06 13:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:04:38 --> Form Validation Class Initialized
INFO - 2025-05-06 13:04:38 --> Controller Class Initialized
INFO - 2025-05-06 13:04:38 --> Config Class Initialized
INFO - 2025-05-06 13:04:38 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:04:38 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:04:38 --> Utf8 Class Initialized
INFO - 2025-05-06 13:04:38 --> URI Class Initialized
INFO - 2025-05-06 13:04:38 --> Router Class Initialized
INFO - 2025-05-06 13:04:38 --> Output Class Initialized
INFO - 2025-05-06 13:04:38 --> Security Class Initialized
DEBUG - 2025-05-06 13:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:04:38 --> Input Class Initialized
INFO - 2025-05-06 13:04:38 --> Language Class Initialized
INFO - 2025-05-06 13:04:38 --> Loader Class Initialized
INFO - 2025-05-06 13:04:38 --> Helper loaded: form_helper
INFO - 2025-05-06 13:04:38 --> Helper loaded: url_helper
INFO - 2025-05-06 13:04:38 --> Database Driver Class Initialized
INFO - 2025-05-06 13:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:04:38 --> Form Validation Class Initialized
INFO - 2025-05-06 13:04:38 --> Controller Class Initialized
INFO - 2025-05-06 13:04:38 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 13:04:38 --> Final output sent to browser
DEBUG - 2025-05-06 13:04:38 --> Total execution time: 0.0319
INFO - 2025-05-06 13:04:57 --> Config Class Initialized
INFO - 2025-05-06 13:04:57 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:04:57 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:04:57 --> Utf8 Class Initialized
INFO - 2025-05-06 13:04:57 --> URI Class Initialized
INFO - 2025-05-06 13:04:57 --> Router Class Initialized
INFO - 2025-05-06 13:04:57 --> Output Class Initialized
INFO - 2025-05-06 13:04:57 --> Security Class Initialized
DEBUG - 2025-05-06 13:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:04:57 --> Input Class Initialized
INFO - 2025-05-06 13:04:57 --> Language Class Initialized
INFO - 2025-05-06 13:04:57 --> Loader Class Initialized
INFO - 2025-05-06 13:04:57 --> Helper loaded: form_helper
INFO - 2025-05-06 13:04:57 --> Helper loaded: url_helper
INFO - 2025-05-06 13:04:57 --> Database Driver Class Initialized
INFO - 2025-05-06 13:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:04:57 --> Form Validation Class Initialized
INFO - 2025-05-06 13:04:57 --> Controller Class Initialized
INFO - 2025-05-06 13:04:57 --> Config Class Initialized
INFO - 2025-05-06 13:04:57 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:04:57 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:04:57 --> Utf8 Class Initialized
INFO - 2025-05-06 13:04:57 --> URI Class Initialized
INFO - 2025-05-06 13:04:57 --> Router Class Initialized
INFO - 2025-05-06 13:04:57 --> Output Class Initialized
INFO - 2025-05-06 13:04:57 --> Security Class Initialized
DEBUG - 2025-05-06 13:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:04:57 --> Input Class Initialized
INFO - 2025-05-06 13:04:57 --> Language Class Initialized
INFO - 2025-05-06 13:04:57 --> Loader Class Initialized
INFO - 2025-05-06 13:04:57 --> Helper loaded: form_helper
INFO - 2025-05-06 13:04:57 --> Helper loaded: url_helper
INFO - 2025-05-06 13:04:57 --> Database Driver Class Initialized
INFO - 2025-05-06 13:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:04:57 --> Form Validation Class Initialized
INFO - 2025-05-06 13:04:57 --> Controller Class Initialized
INFO - 2025-05-06 13:04:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:04:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:04:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:04:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:04:57 --> Final output sent to browser
DEBUG - 2025-05-06 13:04:57 --> Total execution time: 0.0366
INFO - 2025-05-06 13:05:03 --> Config Class Initialized
INFO - 2025-05-06 13:05:03 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:05:03 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:05:03 --> Utf8 Class Initialized
INFO - 2025-05-06 13:05:03 --> URI Class Initialized
INFO - 2025-05-06 13:05:03 --> Router Class Initialized
INFO - 2025-05-06 13:05:03 --> Output Class Initialized
INFO - 2025-05-06 13:05:03 --> Security Class Initialized
DEBUG - 2025-05-06 13:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:05:03 --> Input Class Initialized
INFO - 2025-05-06 13:05:03 --> Language Class Initialized
INFO - 2025-05-06 13:05:03 --> Loader Class Initialized
INFO - 2025-05-06 13:05:03 --> Helper loaded: form_helper
INFO - 2025-05-06 13:05:03 --> Helper loaded: url_helper
INFO - 2025-05-06 13:05:03 --> Database Driver Class Initialized
INFO - 2025-05-06 13:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:05:03 --> Form Validation Class Initialized
INFO - 2025-05-06 13:05:03 --> Controller Class Initialized
INFO - 2025-05-06 13:05:03 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:05:03 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:05:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:05:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 13:05:03 --> Final output sent to browser
DEBUG - 2025-05-06 13:05:03 --> Total execution time: 0.0407
INFO - 2025-05-06 13:05:42 --> Config Class Initialized
INFO - 2025-05-06 13:05:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:05:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:05:42 --> Utf8 Class Initialized
INFO - 2025-05-06 13:05:42 --> URI Class Initialized
INFO - 2025-05-06 13:05:42 --> Router Class Initialized
INFO - 2025-05-06 13:05:42 --> Output Class Initialized
INFO - 2025-05-06 13:05:42 --> Security Class Initialized
DEBUG - 2025-05-06 13:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:05:42 --> Input Class Initialized
INFO - 2025-05-06 13:05:42 --> Language Class Initialized
INFO - 2025-05-06 13:05:42 --> Loader Class Initialized
INFO - 2025-05-06 13:05:42 --> Helper loaded: form_helper
INFO - 2025-05-06 13:05:42 --> Helper loaded: url_helper
INFO - 2025-05-06 13:05:42 --> Database Driver Class Initialized
INFO - 2025-05-06 13:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:05:42 --> Form Validation Class Initialized
INFO - 2025-05-06 13:05:42 --> Controller Class Initialized
INFO - 2025-05-06 13:05:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:05:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:05:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-06 13:05:42 --> Config Class Initialized
INFO - 2025-05-06 13:05:42 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:05:42 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:05:42 --> Utf8 Class Initialized
INFO - 2025-05-06 13:05:42 --> URI Class Initialized
INFO - 2025-05-06 13:05:42 --> Router Class Initialized
INFO - 2025-05-06 13:05:42 --> Output Class Initialized
INFO - 2025-05-06 13:05:42 --> Security Class Initialized
DEBUG - 2025-05-06 13:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:05:42 --> Input Class Initialized
INFO - 2025-05-06 13:05:42 --> Language Class Initialized
INFO - 2025-05-06 13:05:42 --> Loader Class Initialized
INFO - 2025-05-06 13:05:42 --> Helper loaded: form_helper
INFO - 2025-05-06 13:05:42 --> Helper loaded: url_helper
INFO - 2025-05-06 13:05:42 --> Database Driver Class Initialized
INFO - 2025-05-06 13:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:05:42 --> Form Validation Class Initialized
INFO - 2025-05-06 13:05:42 --> Controller Class Initialized
INFO - 2025-05-06 13:05:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:05:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:05:42 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:05:42 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 13:05:42 --> Final output sent to browser
DEBUG - 2025-05-06 13:05:42 --> Total execution time: 0.0398
INFO - 2025-05-06 13:05:52 --> Config Class Initialized
INFO - 2025-05-06 13:05:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:05:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:05:52 --> Utf8 Class Initialized
INFO - 2025-05-06 13:05:52 --> URI Class Initialized
INFO - 2025-05-06 13:05:52 --> Router Class Initialized
INFO - 2025-05-06 13:05:52 --> Output Class Initialized
INFO - 2025-05-06 13:05:52 --> Security Class Initialized
DEBUG - 2025-05-06 13:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:05:52 --> Input Class Initialized
INFO - 2025-05-06 13:05:52 --> Language Class Initialized
INFO - 2025-05-06 13:05:52 --> Loader Class Initialized
INFO - 2025-05-06 13:05:52 --> Helper loaded: form_helper
INFO - 2025-05-06 13:05:52 --> Helper loaded: url_helper
INFO - 2025-05-06 13:05:52 --> Database Driver Class Initialized
INFO - 2025-05-06 13:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:05:52 --> Form Validation Class Initialized
INFO - 2025-05-06 13:05:52 --> Controller Class Initialized
INFO - 2025-05-06 13:05:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:05:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:05:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:05:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:05:52 --> Final output sent to browser
DEBUG - 2025-05-06 13:05:52 --> Total execution time: 0.0311
INFO - 2025-05-06 13:05:53 --> Config Class Initialized
INFO - 2025-05-06 13:05:53 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:05:53 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:05:53 --> Utf8 Class Initialized
INFO - 2025-05-06 13:05:53 --> URI Class Initialized
INFO - 2025-05-06 13:05:53 --> Router Class Initialized
INFO - 2025-05-06 13:05:53 --> Output Class Initialized
INFO - 2025-05-06 13:05:53 --> Security Class Initialized
DEBUG - 2025-05-06 13:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:05:53 --> Input Class Initialized
INFO - 2025-05-06 13:05:53 --> Language Class Initialized
INFO - 2025-05-06 13:05:53 --> Loader Class Initialized
INFO - 2025-05-06 13:05:53 --> Helper loaded: form_helper
INFO - 2025-05-06 13:05:53 --> Helper loaded: url_helper
INFO - 2025-05-06 13:05:53 --> Database Driver Class Initialized
INFO - 2025-05-06 13:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:05:53 --> Form Validation Class Initialized
INFO - 2025-05-06 13:05:53 --> Controller Class Initialized
INFO - 2025-05-06 13:05:53 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:05:53 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:05:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:05:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 13:05:53 --> Final output sent to browser
DEBUG - 2025-05-06 13:05:53 --> Total execution time: 0.0377
INFO - 2025-05-06 13:06:02 --> Config Class Initialized
INFO - 2025-05-06 13:06:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:06:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:06:02 --> Utf8 Class Initialized
INFO - 2025-05-06 13:06:02 --> URI Class Initialized
INFO - 2025-05-06 13:06:02 --> Router Class Initialized
INFO - 2025-05-06 13:06:02 --> Output Class Initialized
INFO - 2025-05-06 13:06:02 --> Security Class Initialized
DEBUG - 2025-05-06 13:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:06:02 --> Input Class Initialized
INFO - 2025-05-06 13:06:02 --> Language Class Initialized
INFO - 2025-05-06 13:06:02 --> Loader Class Initialized
INFO - 2025-05-06 13:06:02 --> Helper loaded: form_helper
INFO - 2025-05-06 13:06:02 --> Helper loaded: url_helper
INFO - 2025-05-06 13:06:02 --> Database Driver Class Initialized
INFO - 2025-05-06 13:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:06:02 --> Form Validation Class Initialized
INFO - 2025-05-06 13:06:02 --> Controller Class Initialized
INFO - 2025-05-06 13:06:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:06:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:06:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-06 13:06:02 --> Final output sent to browser
DEBUG - 2025-05-06 13:06:02 --> Total execution time: 0.0446
INFO - 2025-05-06 13:06:36 --> Config Class Initialized
INFO - 2025-05-06 13:06:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:06:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:06:36 --> Utf8 Class Initialized
INFO - 2025-05-06 13:06:36 --> URI Class Initialized
INFO - 2025-05-06 13:06:36 --> Router Class Initialized
INFO - 2025-05-06 13:06:36 --> Output Class Initialized
INFO - 2025-05-06 13:06:36 --> Security Class Initialized
DEBUG - 2025-05-06 13:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:06:36 --> Input Class Initialized
INFO - 2025-05-06 13:06:36 --> Language Class Initialized
INFO - 2025-05-06 13:06:36 --> Loader Class Initialized
INFO - 2025-05-06 13:06:36 --> Helper loaded: form_helper
INFO - 2025-05-06 13:06:36 --> Helper loaded: url_helper
INFO - 2025-05-06 13:06:36 --> Database Driver Class Initialized
INFO - 2025-05-06 13:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:06:36 --> Form Validation Class Initialized
INFO - 2025-05-06 13:06:36 --> Controller Class Initialized
INFO - 2025-05-06 13:06:36 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:06:36 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:06:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:06:36 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 13:06:36 --> Final output sent to browser
DEBUG - 2025-05-06 13:06:36 --> Total execution time: 0.0437
INFO - 2025-05-06 13:06:46 --> Config Class Initialized
INFO - 2025-05-06 13:06:46 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:06:46 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:06:46 --> Utf8 Class Initialized
INFO - 2025-05-06 13:06:46 --> URI Class Initialized
INFO - 2025-05-06 13:06:46 --> Router Class Initialized
INFO - 2025-05-06 13:06:46 --> Output Class Initialized
INFO - 2025-05-06 13:06:46 --> Security Class Initialized
DEBUG - 2025-05-06 13:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:06:46 --> Input Class Initialized
INFO - 2025-05-06 13:06:46 --> Language Class Initialized
INFO - 2025-05-06 13:06:46 --> Loader Class Initialized
INFO - 2025-05-06 13:06:46 --> Helper loaded: form_helper
INFO - 2025-05-06 13:06:46 --> Helper loaded: url_helper
INFO - 2025-05-06 13:06:46 --> Database Driver Class Initialized
INFO - 2025-05-06 13:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:06:46 --> Form Validation Class Initialized
INFO - 2025-05-06 13:06:46 --> Controller Class Initialized
INFO - 2025-05-06 13:06:46 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:06:46 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:06:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-06 13:06:46 --> Final output sent to browser
DEBUG - 2025-05-06 13:06:46 --> Total execution time: 0.0364
INFO - 2025-05-06 13:09:00 --> Config Class Initialized
INFO - 2025-05-06 13:09:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:09:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:09:00 --> Utf8 Class Initialized
INFO - 2025-05-06 13:09:00 --> URI Class Initialized
INFO - 2025-05-06 13:09:00 --> Router Class Initialized
INFO - 2025-05-06 13:09:00 --> Output Class Initialized
INFO - 2025-05-06 13:09:00 --> Security Class Initialized
DEBUG - 2025-05-06 13:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:09:00 --> Input Class Initialized
INFO - 2025-05-06 13:09:00 --> Language Class Initialized
INFO - 2025-05-06 13:09:00 --> Loader Class Initialized
INFO - 2025-05-06 13:09:00 --> Helper loaded: form_helper
INFO - 2025-05-06 13:09:00 --> Helper loaded: url_helper
INFO - 2025-05-06 13:09:00 --> Database Driver Class Initialized
INFO - 2025-05-06 13:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:09:00 --> Form Validation Class Initialized
INFO - 2025-05-06 13:09:00 --> Controller Class Initialized
INFO - 2025-05-06 13:09:00 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:09:00 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:09:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:09:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_rekomendasi.php
INFO - 2025-05-06 13:09:00 --> Final output sent to browser
DEBUG - 2025-05-06 13:09:00 --> Total execution time: 0.0362
INFO - 2025-05-06 13:10:49 --> Config Class Initialized
INFO - 2025-05-06 13:10:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:10:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:10:49 --> Utf8 Class Initialized
INFO - 2025-05-06 13:10:49 --> URI Class Initialized
INFO - 2025-05-06 13:10:49 --> Router Class Initialized
INFO - 2025-05-06 13:10:49 --> Output Class Initialized
INFO - 2025-05-06 13:10:49 --> Security Class Initialized
DEBUG - 2025-05-06 13:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:10:49 --> Input Class Initialized
INFO - 2025-05-06 13:10:49 --> Language Class Initialized
INFO - 2025-05-06 13:10:49 --> Loader Class Initialized
INFO - 2025-05-06 13:10:49 --> Helper loaded: form_helper
INFO - 2025-05-06 13:10:49 --> Helper loaded: url_helper
INFO - 2025-05-06 13:10:49 --> Database Driver Class Initialized
INFO - 2025-05-06 13:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:10:49 --> Form Validation Class Initialized
INFO - 2025-05-06 13:10:49 --> Controller Class Initialized
INFO - 2025-05-06 13:10:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:10:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:10:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:10:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_sekolah.php
INFO - 2025-05-06 13:10:49 --> Final output sent to browser
DEBUG - 2025-05-06 13:10:49 --> Total execution time: 0.0349
INFO - 2025-05-06 13:11:00 --> Config Class Initialized
INFO - 2025-05-06 13:11:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:11:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:11:00 --> Utf8 Class Initialized
INFO - 2025-05-06 13:11:00 --> URI Class Initialized
INFO - 2025-05-06 13:11:00 --> Router Class Initialized
INFO - 2025-05-06 13:11:00 --> Output Class Initialized
INFO - 2025-05-06 13:11:00 --> Security Class Initialized
DEBUG - 2025-05-06 13:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:11:00 --> Input Class Initialized
INFO - 2025-05-06 13:11:00 --> Language Class Initialized
INFO - 2025-05-06 13:11:00 --> Loader Class Initialized
INFO - 2025-05-06 13:11:00 --> Helper loaded: form_helper
INFO - 2025-05-06 13:11:00 --> Helper loaded: url_helper
INFO - 2025-05-06 13:11:00 --> Database Driver Class Initialized
INFO - 2025-05-06 13:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:11:01 --> Form Validation Class Initialized
INFO - 2025-05-06 13:11:01 --> Controller Class Initialized
INFO - 2025-05-06 13:11:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:11:01 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:11:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:11:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:11:01 --> Final output sent to browser
DEBUG - 2025-05-06 13:11:01 --> Total execution time: 0.0511
INFO - 2025-05-06 13:11:02 --> Config Class Initialized
INFO - 2025-05-06 13:11:02 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:11:02 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:11:02 --> Utf8 Class Initialized
INFO - 2025-05-06 13:11:02 --> URI Class Initialized
INFO - 2025-05-06 13:11:02 --> Router Class Initialized
INFO - 2025-05-06 13:11:02 --> Output Class Initialized
INFO - 2025-05-06 13:11:02 --> Security Class Initialized
DEBUG - 2025-05-06 13:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:11:02 --> Input Class Initialized
INFO - 2025-05-06 13:11:02 --> Language Class Initialized
INFO - 2025-05-06 13:11:02 --> Loader Class Initialized
INFO - 2025-05-06 13:11:02 --> Helper loaded: form_helper
INFO - 2025-05-06 13:11:02 --> Helper loaded: url_helper
INFO - 2025-05-06 13:11:02 --> Database Driver Class Initialized
INFO - 2025-05-06 13:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:11:02 --> Form Validation Class Initialized
INFO - 2025-05-06 13:11:02 --> Controller Class Initialized
INFO - 2025-05-06 13:11:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:11:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:11:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:11:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-06 13:11:02 --> Final output sent to browser
DEBUG - 2025-05-06 13:11:02 --> Total execution time: 0.0662
INFO - 2025-05-06 13:11:58 --> Config Class Initialized
INFO - 2025-05-06 13:11:58 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:11:58 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:11:58 --> Utf8 Class Initialized
INFO - 2025-05-06 13:11:58 --> URI Class Initialized
INFO - 2025-05-06 13:11:58 --> Router Class Initialized
INFO - 2025-05-06 13:11:58 --> Output Class Initialized
INFO - 2025-05-06 13:11:58 --> Security Class Initialized
DEBUG - 2025-05-06 13:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:11:58 --> Input Class Initialized
INFO - 2025-05-06 13:11:58 --> Language Class Initialized
INFO - 2025-05-06 13:11:58 --> Loader Class Initialized
INFO - 2025-05-06 13:11:58 --> Helper loaded: form_helper
INFO - 2025-05-06 13:11:58 --> Helper loaded: url_helper
INFO - 2025-05-06 13:11:58 --> Database Driver Class Initialized
INFO - 2025-05-06 13:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:11:58 --> Form Validation Class Initialized
INFO - 2025-05-06 13:11:58 --> Controller Class Initialized
INFO - 2025-05-06 13:11:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:11:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:11:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:11:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 13:11:58 --> Final output sent to browser
DEBUG - 2025-05-06 13:11:58 --> Total execution time: 0.0351
INFO - 2025-05-06 13:12:24 --> Config Class Initialized
INFO - 2025-05-06 13:12:24 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:12:24 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:12:24 --> Utf8 Class Initialized
INFO - 2025-05-06 13:12:24 --> URI Class Initialized
INFO - 2025-05-06 13:12:24 --> Router Class Initialized
INFO - 2025-05-06 13:12:24 --> Output Class Initialized
INFO - 2025-05-06 13:12:24 --> Security Class Initialized
DEBUG - 2025-05-06 13:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:12:24 --> Input Class Initialized
INFO - 2025-05-06 13:12:24 --> Language Class Initialized
INFO - 2025-05-06 13:12:24 --> Loader Class Initialized
INFO - 2025-05-06 13:12:24 --> Helper loaded: form_helper
INFO - 2025-05-06 13:12:25 --> Helper loaded: url_helper
INFO - 2025-05-06 13:12:25 --> Database Driver Class Initialized
INFO - 2025-05-06 13:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:12:25 --> Form Validation Class Initialized
INFO - 2025-05-06 13:12:25 --> Controller Class Initialized
INFO - 2025-05-06 13:12:25 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:12:25 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:12:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:12:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-06 13:12:25 --> Final output sent to browser
DEBUG - 2025-05-06 13:12:25 --> Total execution time: 0.0540
INFO - 2025-05-06 13:13:22 --> Config Class Initialized
INFO - 2025-05-06 13:13:22 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:13:22 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:13:22 --> Utf8 Class Initialized
INFO - 2025-05-06 13:13:22 --> URI Class Initialized
INFO - 2025-05-06 13:13:22 --> Router Class Initialized
INFO - 2025-05-06 13:13:22 --> Output Class Initialized
INFO - 2025-05-06 13:13:22 --> Security Class Initialized
DEBUG - 2025-05-06 13:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:13:22 --> Input Class Initialized
INFO - 2025-05-06 13:13:22 --> Language Class Initialized
INFO - 2025-05-06 13:13:22 --> Loader Class Initialized
INFO - 2025-05-06 13:13:22 --> Helper loaded: form_helper
INFO - 2025-05-06 13:13:22 --> Helper loaded: url_helper
INFO - 2025-05-06 13:13:22 --> Database Driver Class Initialized
INFO - 2025-05-06 13:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:13:22 --> Form Validation Class Initialized
INFO - 2025-05-06 13:13:22 --> Controller Class Initialized
DEBUG - 2025-05-06 13:13:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-06 13:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-06 13:13:22 --> Model "Ppdb_model" initialized
INFO - 2025-05-06 13:13:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-06 13:13:22 --> Final output sent to browser
DEBUG - 2025-05-06 13:13:22 --> Total execution time: 0.0350
INFO - 2025-05-06 13:13:22 --> Config Class Initialized
INFO - 2025-05-06 13:13:22 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:13:22 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:13:22 --> Utf8 Class Initialized
INFO - 2025-05-06 13:13:22 --> URI Class Initialized
INFO - 2025-05-06 13:13:22 --> Router Class Initialized
INFO - 2025-05-06 13:13:22 --> Output Class Initialized
INFO - 2025-05-06 13:13:22 --> Security Class Initialized
DEBUG - 2025-05-06 13:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:13:22 --> Input Class Initialized
INFO - 2025-05-06 13:13:22 --> Language Class Initialized
INFO - 2025-05-06 13:13:22 --> Loader Class Initialized
INFO - 2025-05-06 13:13:22 --> Helper loaded: form_helper
INFO - 2025-05-06 13:13:22 --> Helper loaded: url_helper
INFO - 2025-05-06 13:13:22 --> Database Driver Class Initialized
INFO - 2025-05-06 13:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:13:22 --> Form Validation Class Initialized
INFO - 2025-05-06 13:13:22 --> Controller Class Initialized
DEBUG - 2025-05-06 13:13:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-06 13:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-06 13:13:22 --> Model "Ppdb_model" initialized
INFO - 2025-05-06 13:13:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-06 13:13:22 --> Final output sent to browser
DEBUG - 2025-05-06 13:13:22 --> Total execution time: 0.0325
INFO - 2025-05-06 13:13:23 --> Config Class Initialized
INFO - 2025-05-06 13:13:23 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:13:23 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:13:23 --> Utf8 Class Initialized
INFO - 2025-05-06 13:13:23 --> URI Class Initialized
INFO - 2025-05-06 13:13:23 --> Router Class Initialized
INFO - 2025-05-06 13:13:23 --> Output Class Initialized
INFO - 2025-05-06 13:13:23 --> Security Class Initialized
DEBUG - 2025-05-06 13:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:13:23 --> Input Class Initialized
INFO - 2025-05-06 13:13:23 --> Language Class Initialized
ERROR - 2025-05-06 13:13:23 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-06 13:20:00 --> Config Class Initialized
INFO - 2025-05-06 13:20:00 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:20:00 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:20:00 --> Utf8 Class Initialized
INFO - 2025-05-06 13:20:00 --> URI Class Initialized
DEBUG - 2025-05-06 13:20:00 --> No URI present. Default controller set.
INFO - 2025-05-06 13:20:00 --> Router Class Initialized
INFO - 2025-05-06 13:20:00 --> Output Class Initialized
INFO - 2025-05-06 13:20:00 --> Security Class Initialized
DEBUG - 2025-05-06 13:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:20:00 --> Input Class Initialized
INFO - 2025-05-06 13:20:00 --> Language Class Initialized
INFO - 2025-05-06 13:20:00 --> Loader Class Initialized
INFO - 2025-05-06 13:20:00 --> Helper loaded: form_helper
INFO - 2025-05-06 13:20:00 --> Helper loaded: url_helper
INFO - 2025-05-06 13:20:00 --> Database Driver Class Initialized
INFO - 2025-05-06 13:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:20:00 --> Form Validation Class Initialized
INFO - 2025-05-06 13:20:00 --> Controller Class Initialized
INFO - 2025-05-06 13:20:00 --> Final output sent to browser
DEBUG - 2025-05-06 13:20:00 --> Total execution time: 0.0325
INFO - 2025-05-06 13:20:04 --> Config Class Initialized
INFO - 2025-05-06 13:20:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:20:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:20:04 --> Utf8 Class Initialized
INFO - 2025-05-06 13:20:04 --> URI Class Initialized
INFO - 2025-05-06 13:20:04 --> Router Class Initialized
INFO - 2025-05-06 13:20:04 --> Output Class Initialized
INFO - 2025-05-06 13:20:04 --> Security Class Initialized
DEBUG - 2025-05-06 13:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:20:04 --> Input Class Initialized
INFO - 2025-05-06 13:20:04 --> Language Class Initialized
INFO - 2025-05-06 13:20:04 --> Loader Class Initialized
INFO - 2025-05-06 13:20:04 --> Helper loaded: form_helper
INFO - 2025-05-06 13:20:04 --> Helper loaded: url_helper
INFO - 2025-05-06 13:20:04 --> Database Driver Class Initialized
INFO - 2025-05-06 13:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:20:04 --> Form Validation Class Initialized
INFO - 2025-05-06 13:20:04 --> Controller Class Initialized
INFO - 2025-05-06 13:20:04 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:20:04 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:20:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:20:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:20:04 --> Final output sent to browser
DEBUG - 2025-05-06 13:20:04 --> Total execution time: 0.0384
INFO - 2025-05-06 13:20:04 --> Config Class Initialized
INFO - 2025-05-06 13:20:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:20:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:20:04 --> Utf8 Class Initialized
INFO - 2025-05-06 13:20:04 --> URI Class Initialized
INFO - 2025-05-06 13:20:04 --> Router Class Initialized
INFO - 2025-05-06 13:20:04 --> Output Class Initialized
INFO - 2025-05-06 13:20:04 --> Security Class Initialized
DEBUG - 2025-05-06 13:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:20:04 --> Input Class Initialized
INFO - 2025-05-06 13:20:04 --> Language Class Initialized
ERROR - 2025-05-06 13:20:04 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-06 13:21:39 --> Config Class Initialized
INFO - 2025-05-06 13:21:39 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:21:39 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:21:39 --> Utf8 Class Initialized
INFO - 2025-05-06 13:21:39 --> URI Class Initialized
INFO - 2025-05-06 13:21:39 --> Router Class Initialized
INFO - 2025-05-06 13:21:39 --> Output Class Initialized
INFO - 2025-05-06 13:21:39 --> Security Class Initialized
DEBUG - 2025-05-06 13:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:21:39 --> Input Class Initialized
INFO - 2025-05-06 13:21:39 --> Language Class Initialized
INFO - 2025-05-06 13:21:39 --> Loader Class Initialized
INFO - 2025-05-06 13:21:39 --> Helper loaded: form_helper
INFO - 2025-05-06 13:21:39 --> Helper loaded: url_helper
INFO - 2025-05-06 13:21:39 --> Database Driver Class Initialized
INFO - 2025-05-06 13:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:21:39 --> Form Validation Class Initialized
INFO - 2025-05-06 13:21:39 --> Controller Class Initialized
DEBUG - 2025-05-06 13:21:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-06 13:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-06 13:21:39 --> Model "Ppdb_model" initialized
INFO - 2025-05-06 13:21:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-06 13:21:39 --> Final output sent to browser
DEBUG - 2025-05-06 13:21:39 --> Total execution time: 0.0335
INFO - 2025-05-06 13:21:40 --> Config Class Initialized
INFO - 2025-05-06 13:21:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:21:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:21:40 --> Utf8 Class Initialized
INFO - 2025-05-06 13:21:40 --> URI Class Initialized
INFO - 2025-05-06 13:21:40 --> Router Class Initialized
INFO - 2025-05-06 13:21:40 --> Output Class Initialized
INFO - 2025-05-06 13:21:40 --> Security Class Initialized
DEBUG - 2025-05-06 13:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:21:40 --> Input Class Initialized
INFO - 2025-05-06 13:21:40 --> Language Class Initialized
ERROR - 2025-05-06 13:21:40 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-06 13:25:21 --> Config Class Initialized
INFO - 2025-05-06 13:25:21 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:21 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:21 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:21 --> URI Class Initialized
DEBUG - 2025-05-06 13:25:21 --> No URI present. Default controller set.
INFO - 2025-05-06 13:25:21 --> Router Class Initialized
INFO - 2025-05-06 13:25:21 --> Output Class Initialized
INFO - 2025-05-06 13:25:21 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:21 --> Input Class Initialized
INFO - 2025-05-06 13:25:21 --> Language Class Initialized
INFO - 2025-05-06 13:25:21 --> Loader Class Initialized
INFO - 2025-05-06 13:25:21 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:21 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:21 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:21 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:21 --> Controller Class Initialized
INFO - 2025-05-06 13:25:21 --> Final output sent to browser
DEBUG - 2025-05-06 13:25:21 --> Total execution time: 0.0363
INFO - 2025-05-06 13:25:23 --> Config Class Initialized
INFO - 2025-05-06 13:25:23 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:23 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:23 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:23 --> URI Class Initialized
DEBUG - 2025-05-06 13:25:23 --> No URI present. Default controller set.
INFO - 2025-05-06 13:25:23 --> Router Class Initialized
INFO - 2025-05-06 13:25:23 --> Output Class Initialized
INFO - 2025-05-06 13:25:23 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:23 --> Input Class Initialized
INFO - 2025-05-06 13:25:23 --> Language Class Initialized
INFO - 2025-05-06 13:25:23 --> Loader Class Initialized
INFO - 2025-05-06 13:25:23 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:23 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:23 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:23 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:23 --> Controller Class Initialized
INFO - 2025-05-06 13:25:23 --> Final output sent to browser
DEBUG - 2025-05-06 13:25:23 --> Total execution time: 0.0276
INFO - 2025-05-06 13:25:27 --> Config Class Initialized
INFO - 2025-05-06 13:25:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:27 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:27 --> URI Class Initialized
INFO - 2025-05-06 13:25:27 --> Router Class Initialized
INFO - 2025-05-06 13:25:27 --> Output Class Initialized
INFO - 2025-05-06 13:25:27 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:27 --> Input Class Initialized
INFO - 2025-05-06 13:25:27 --> Language Class Initialized
INFO - 2025-05-06 13:25:27 --> Loader Class Initialized
INFO - 2025-05-06 13:25:27 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:27 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:27 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:27 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:27 --> Controller Class Initialized
INFO - 2025-05-06 13:25:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:25:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:25:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:25:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:25:27 --> Final output sent to browser
DEBUG - 2025-05-06 13:25:27 --> Total execution time: 0.0349
INFO - 2025-05-06 13:25:29 --> Config Class Initialized
INFO - 2025-05-06 13:25:29 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:29 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:29 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:29 --> URI Class Initialized
INFO - 2025-05-06 13:25:29 --> Router Class Initialized
INFO - 2025-05-06 13:25:29 --> Output Class Initialized
INFO - 2025-05-06 13:25:29 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:29 --> Input Class Initialized
INFO - 2025-05-06 13:25:29 --> Language Class Initialized
INFO - 2025-05-06 13:25:29 --> Loader Class Initialized
INFO - 2025-05-06 13:25:29 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:29 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:29 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:29 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:29 --> Controller Class Initialized
INFO - 2025-05-06 13:25:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:25:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:25:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:25:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 13:25:29 --> Final output sent to browser
DEBUG - 2025-05-06 13:25:29 --> Total execution time: 0.0321
INFO - 2025-05-06 13:25:32 --> Config Class Initialized
INFO - 2025-05-06 13:25:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:32 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:32 --> URI Class Initialized
INFO - 2025-05-06 13:25:32 --> Router Class Initialized
INFO - 2025-05-06 13:25:32 --> Output Class Initialized
INFO - 2025-05-06 13:25:32 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:32 --> Input Class Initialized
INFO - 2025-05-06 13:25:32 --> Language Class Initialized
INFO - 2025-05-06 13:25:32 --> Loader Class Initialized
INFO - 2025-05-06 13:25:32 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:32 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:32 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:32 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:32 --> Controller Class Initialized
INFO - 2025-05-06 13:25:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:25:32 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:25:32 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:25:32 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 13:25:32 --> Final output sent to browser
DEBUG - 2025-05-06 13:25:32 --> Total execution time: 0.0388
INFO - 2025-05-06 13:25:45 --> Config Class Initialized
INFO - 2025-05-06 13:25:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:45 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:45 --> URI Class Initialized
INFO - 2025-05-06 13:25:45 --> Router Class Initialized
INFO - 2025-05-06 13:25:45 --> Output Class Initialized
INFO - 2025-05-06 13:25:45 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:45 --> Input Class Initialized
INFO - 2025-05-06 13:25:45 --> Language Class Initialized
INFO - 2025-05-06 13:25:45 --> Loader Class Initialized
INFO - 2025-05-06 13:25:45 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:45 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:45 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:45 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:45 --> Controller Class Initialized
INFO - 2025-05-06 13:25:45 --> Config Class Initialized
INFO - 2025-05-06 13:25:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:45 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:45 --> URI Class Initialized
INFO - 2025-05-06 13:25:45 --> Router Class Initialized
INFO - 2025-05-06 13:25:45 --> Output Class Initialized
INFO - 2025-05-06 13:25:45 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:45 --> Input Class Initialized
INFO - 2025-05-06 13:25:45 --> Language Class Initialized
INFO - 2025-05-06 13:25:45 --> Loader Class Initialized
INFO - 2025-05-06 13:25:45 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:45 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:45 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:45 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:45 --> Controller Class Initialized
INFO - 2025-05-06 13:25:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 13:25:45 --> Final output sent to browser
DEBUG - 2025-05-06 13:25:45 --> Total execution time: 0.0344
INFO - 2025-05-06 13:25:52 --> Config Class Initialized
INFO - 2025-05-06 13:25:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:52 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:52 --> URI Class Initialized
INFO - 2025-05-06 13:25:52 --> Router Class Initialized
INFO - 2025-05-06 13:25:52 --> Output Class Initialized
INFO - 2025-05-06 13:25:52 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:52 --> Input Class Initialized
INFO - 2025-05-06 13:25:52 --> Language Class Initialized
INFO - 2025-05-06 13:25:52 --> Loader Class Initialized
INFO - 2025-05-06 13:25:52 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:52 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:52 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:52 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:52 --> Controller Class Initialized
INFO - 2025-05-06 13:25:52 --> Config Class Initialized
INFO - 2025-05-06 13:25:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:52 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:52 --> URI Class Initialized
INFO - 2025-05-06 13:25:52 --> Router Class Initialized
INFO - 2025-05-06 13:25:52 --> Output Class Initialized
INFO - 2025-05-06 13:25:52 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:52 --> Input Class Initialized
INFO - 2025-05-06 13:25:52 --> Language Class Initialized
INFO - 2025-05-06 13:25:52 --> Loader Class Initialized
INFO - 2025-05-06 13:25:52 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:52 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:52 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:52 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:52 --> Controller Class Initialized
INFO - 2025-05-06 13:25:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:25:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:25:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:25:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:25:52 --> Final output sent to browser
DEBUG - 2025-05-06 13:25:52 --> Total execution time: 0.0325
INFO - 2025-05-06 13:25:56 --> Config Class Initialized
INFO - 2025-05-06 13:25:56 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:25:56 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:25:56 --> Utf8 Class Initialized
INFO - 2025-05-06 13:25:56 --> URI Class Initialized
INFO - 2025-05-06 13:25:56 --> Router Class Initialized
INFO - 2025-05-06 13:25:56 --> Output Class Initialized
INFO - 2025-05-06 13:25:56 --> Security Class Initialized
DEBUG - 2025-05-06 13:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:25:56 --> Input Class Initialized
INFO - 2025-05-06 13:25:56 --> Language Class Initialized
INFO - 2025-05-06 13:25:56 --> Loader Class Initialized
INFO - 2025-05-06 13:25:56 --> Helper loaded: form_helper
INFO - 2025-05-06 13:25:56 --> Helper loaded: url_helper
INFO - 2025-05-06 13:25:56 --> Database Driver Class Initialized
INFO - 2025-05-06 13:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:25:56 --> Form Validation Class Initialized
INFO - 2025-05-06 13:25:56 --> Controller Class Initialized
INFO - 2025-05-06 13:25:56 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:25:56 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:25:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:25:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-06 13:25:56 --> Final output sent to browser
DEBUG - 2025-05-06 13:25:56 --> Total execution time: 0.0350
INFO - 2025-05-06 13:26:04 --> Config Class Initialized
INFO - 2025-05-06 13:26:04 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:26:04 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:26:04 --> Utf8 Class Initialized
INFO - 2025-05-06 13:26:04 --> URI Class Initialized
INFO - 2025-05-06 13:26:04 --> Router Class Initialized
INFO - 2025-05-06 13:26:04 --> Output Class Initialized
INFO - 2025-05-06 13:26:04 --> Security Class Initialized
DEBUG - 2025-05-06 13:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:26:04 --> Input Class Initialized
INFO - 2025-05-06 13:26:04 --> Language Class Initialized
INFO - 2025-05-06 13:26:04 --> Loader Class Initialized
INFO - 2025-05-06 13:26:04 --> Helper loaded: form_helper
INFO - 2025-05-06 13:26:04 --> Helper loaded: url_helper
INFO - 2025-05-06 13:26:04 --> Database Driver Class Initialized
INFO - 2025-05-06 13:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:26:04 --> Form Validation Class Initialized
INFO - 2025-05-06 13:26:04 --> Controller Class Initialized
INFO - 2025-05-06 13:26:04 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:26:04 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:26:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:26:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 13:26:04 --> Final output sent to browser
DEBUG - 2025-05-06 13:26:04 --> Total execution time: 0.0395
INFO - 2025-05-06 13:26:05 --> Config Class Initialized
INFO - 2025-05-06 13:26:05 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:26:05 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:26:05 --> Utf8 Class Initialized
INFO - 2025-05-06 13:26:05 --> URI Class Initialized
INFO - 2025-05-06 13:26:05 --> Router Class Initialized
INFO - 2025-05-06 13:26:05 --> Output Class Initialized
INFO - 2025-05-06 13:26:05 --> Security Class Initialized
DEBUG - 2025-05-06 13:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:26:05 --> Input Class Initialized
INFO - 2025-05-06 13:26:05 --> Language Class Initialized
INFO - 2025-05-06 13:26:05 --> Loader Class Initialized
INFO - 2025-05-06 13:26:05 --> Helper loaded: form_helper
INFO - 2025-05-06 13:26:05 --> Helper loaded: url_helper
INFO - 2025-05-06 13:26:05 --> Database Driver Class Initialized
INFO - 2025-05-06 13:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:26:05 --> Form Validation Class Initialized
INFO - 2025-05-06 13:26:05 --> Controller Class Initialized
INFO - 2025-05-06 13:26:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:26:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:26:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:26:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 13:26:05 --> Final output sent to browser
DEBUG - 2025-05-06 13:26:05 --> Total execution time: 0.0421
INFO - 2025-05-06 13:26:07 --> Config Class Initialized
INFO - 2025-05-06 13:26:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:26:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:26:07 --> Utf8 Class Initialized
INFO - 2025-05-06 13:26:07 --> URI Class Initialized
INFO - 2025-05-06 13:26:07 --> Router Class Initialized
INFO - 2025-05-06 13:26:07 --> Output Class Initialized
INFO - 2025-05-06 13:26:07 --> Security Class Initialized
DEBUG - 2025-05-06 13:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:26:07 --> Input Class Initialized
INFO - 2025-05-06 13:26:07 --> Language Class Initialized
INFO - 2025-05-06 13:26:07 --> Loader Class Initialized
INFO - 2025-05-06 13:26:07 --> Helper loaded: form_helper
INFO - 2025-05-06 13:26:07 --> Helper loaded: url_helper
INFO - 2025-05-06 13:26:07 --> Database Driver Class Initialized
INFO - 2025-05-06 13:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:26:07 --> Form Validation Class Initialized
INFO - 2025-05-06 13:26:07 --> Controller Class Initialized
INFO - 2025-05-06 13:26:07 --> Config Class Initialized
INFO - 2025-05-06 13:26:07 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:26:07 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:26:07 --> Utf8 Class Initialized
INFO - 2025-05-06 13:26:07 --> URI Class Initialized
INFO - 2025-05-06 13:26:07 --> Router Class Initialized
INFO - 2025-05-06 13:26:07 --> Output Class Initialized
INFO - 2025-05-06 13:26:07 --> Security Class Initialized
DEBUG - 2025-05-06 13:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:26:07 --> Input Class Initialized
INFO - 2025-05-06 13:26:07 --> Language Class Initialized
INFO - 2025-05-06 13:26:08 --> Loader Class Initialized
INFO - 2025-05-06 13:26:08 --> Helper loaded: form_helper
INFO - 2025-05-06 13:26:08 --> Helper loaded: url_helper
INFO - 2025-05-06 13:26:08 --> Database Driver Class Initialized
INFO - 2025-05-06 13:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:26:08 --> Form Validation Class Initialized
INFO - 2025-05-06 13:26:08 --> Controller Class Initialized
INFO - 2025-05-06 13:26:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 13:26:08 --> Final output sent to browser
DEBUG - 2025-05-06 13:26:08 --> Total execution time: 0.0322
INFO - 2025-05-06 13:35:13 --> Config Class Initialized
INFO - 2025-05-06 13:35:13 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:13 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:13 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:13 --> URI Class Initialized
DEBUG - 2025-05-06 13:35:13 --> No URI present. Default controller set.
INFO - 2025-05-06 13:35:13 --> Router Class Initialized
INFO - 2025-05-06 13:35:13 --> Output Class Initialized
INFO - 2025-05-06 13:35:13 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:13 --> Input Class Initialized
INFO - 2025-05-06 13:35:13 --> Language Class Initialized
INFO - 2025-05-06 13:35:13 --> Loader Class Initialized
INFO - 2025-05-06 13:35:13 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:13 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:13 --> Database Driver Class Initialized
INFO - 2025-05-06 13:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:13 --> Form Validation Class Initialized
INFO - 2025-05-06 13:35:13 --> Controller Class Initialized
INFO - 2025-05-06 13:35:13 --> Final output sent to browser
DEBUG - 2025-05-06 13:35:13 --> Total execution time: 0.0365
INFO - 2025-05-06 13:35:15 --> Config Class Initialized
INFO - 2025-05-06 13:35:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:15 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:15 --> URI Class Initialized
INFO - 2025-05-06 13:35:15 --> Router Class Initialized
INFO - 2025-05-06 13:35:15 --> Output Class Initialized
INFO - 2025-05-06 13:35:15 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:15 --> Input Class Initialized
INFO - 2025-05-06 13:35:15 --> Language Class Initialized
INFO - 2025-05-06 13:35:15 --> Loader Class Initialized
INFO - 2025-05-06 13:35:15 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:15 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:15 --> Database Driver Class Initialized
INFO - 2025-05-06 13:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:15 --> Form Validation Class Initialized
INFO - 2025-05-06 13:35:15 --> Controller Class Initialized
INFO - 2025-05-06 13:35:15 --> Config Class Initialized
INFO - 2025-05-06 13:35:15 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:15 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:15 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:15 --> URI Class Initialized
INFO - 2025-05-06 13:35:15 --> Router Class Initialized
INFO - 2025-05-06 13:35:15 --> Output Class Initialized
INFO - 2025-05-06 13:35:15 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:15 --> Input Class Initialized
INFO - 2025-05-06 13:35:15 --> Language Class Initialized
INFO - 2025-05-06 13:35:15 --> Loader Class Initialized
INFO - 2025-05-06 13:35:15 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:15 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:15 --> Database Driver Class Initialized
INFO - 2025-05-06 13:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:15 --> Form Validation Class Initialized
INFO - 2025-05-06 13:35:15 --> Controller Class Initialized
INFO - 2025-05-06 13:35:15 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-06 13:35:15 --> Final output sent to browser
DEBUG - 2025-05-06 13:35:15 --> Total execution time: 0.0273
INFO - 2025-05-06 13:35:17 --> Config Class Initialized
INFO - 2025-05-06 13:35:17 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:17 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:17 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:17 --> URI Class Initialized
INFO - 2025-05-06 13:35:17 --> Router Class Initialized
INFO - 2025-05-06 13:35:17 --> Output Class Initialized
INFO - 2025-05-06 13:35:17 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:17 --> Input Class Initialized
INFO - 2025-05-06 13:35:17 --> Language Class Initialized
INFO - 2025-05-06 13:35:17 --> Loader Class Initialized
INFO - 2025-05-06 13:35:17 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:17 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:17 --> Database Driver Class Initialized
INFO - 2025-05-06 13:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:17 --> Form Validation Class Initialized
INFO - 2025-05-06 13:35:17 --> Controller Class Initialized
INFO - 2025-05-06 13:35:17 --> Config Class Initialized
INFO - 2025-05-06 13:35:17 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:17 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:17 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:17 --> URI Class Initialized
INFO - 2025-05-06 13:35:17 --> Router Class Initialized
INFO - 2025-05-06 13:35:17 --> Output Class Initialized
INFO - 2025-05-06 13:35:17 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:17 --> Input Class Initialized
INFO - 2025-05-06 13:35:17 --> Language Class Initialized
INFO - 2025-05-06 13:35:17 --> Loader Class Initialized
INFO - 2025-05-06 13:35:17 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:17 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:17 --> Database Driver Class Initialized
INFO - 2025-05-06 13:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:17 --> Form Validation Class Initialized
INFO - 2025-05-06 13:35:17 --> Controller Class Initialized
INFO - 2025-05-06 13:35:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:35:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:35:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:35:17 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:35:17 --> Final output sent to browser
DEBUG - 2025-05-06 13:35:17 --> Total execution time: 0.0353
INFO - 2025-05-06 13:35:20 --> Config Class Initialized
INFO - 2025-05-06 13:35:20 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:20 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:20 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:20 --> URI Class Initialized
INFO - 2025-05-06 13:35:20 --> Router Class Initialized
INFO - 2025-05-06 13:35:20 --> Output Class Initialized
INFO - 2025-05-06 13:35:20 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:20 --> Input Class Initialized
INFO - 2025-05-06 13:35:20 --> Language Class Initialized
INFO - 2025-05-06 13:35:20 --> Loader Class Initialized
INFO - 2025-05-06 13:35:20 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:20 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:20 --> Database Driver Class Initialized
INFO - 2025-05-06 13:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:20 --> Form Validation Class Initialized
INFO - 2025-05-06 13:35:20 --> Controller Class Initialized
INFO - 2025-05-06 13:35:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:35:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:35:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:35:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 13:35:20 --> Final output sent to browser
DEBUG - 2025-05-06 13:35:20 --> Total execution time: 0.0421
INFO - 2025-05-06 13:35:26 --> Config Class Initialized
INFO - 2025-05-06 13:35:26 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:35:26 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:35:26 --> Utf8 Class Initialized
INFO - 2025-05-06 13:35:26 --> URI Class Initialized
INFO - 2025-05-06 13:35:26 --> Router Class Initialized
INFO - 2025-05-06 13:35:26 --> Output Class Initialized
INFO - 2025-05-06 13:35:26 --> Security Class Initialized
DEBUG - 2025-05-06 13:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:35:26 --> Input Class Initialized
INFO - 2025-05-06 13:35:26 --> Language Class Initialized
INFO - 2025-05-06 13:35:26 --> Loader Class Initialized
INFO - 2025-05-06 13:35:26 --> Helper loaded: form_helper
INFO - 2025-05-06 13:35:26 --> Helper loaded: url_helper
INFO - 2025-05-06 13:35:26 --> Database Driver Class Initialized
INFO - 2025-05-06 13:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:35:26 --> Form Validation Class Initialized
INFO - 2025-05-06 13:35:26 --> Controller Class Initialized
INFO - 2025-05-06 13:35:26 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:35:26 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:35:26 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-06 13:35:26 --> Final output sent to browser
DEBUG - 2025-05-06 13:35:26 --> Total execution time: 0.0361
INFO - 2025-05-06 13:36:20 --> Config Class Initialized
INFO - 2025-05-06 13:36:20 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:20 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:20 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:20 --> URI Class Initialized
INFO - 2025-05-06 13:36:20 --> Router Class Initialized
INFO - 2025-05-06 13:36:20 --> Output Class Initialized
INFO - 2025-05-06 13:36:20 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:20 --> Input Class Initialized
INFO - 2025-05-06 13:36:20 --> Language Class Initialized
INFO - 2025-05-06 13:36:20 --> Loader Class Initialized
INFO - 2025-05-06 13:36:20 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:20 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:20 --> Database Driver Class Initialized
INFO - 2025-05-06 13:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:20 --> Form Validation Class Initialized
INFO - 2025-05-06 13:36:20 --> Controller Class Initialized
INFO - 2025-05-06 13:36:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:36:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:36:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:36:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-06 13:36:20 --> Final output sent to browser
DEBUG - 2025-05-06 13:36:20 --> Total execution time: 0.0342
INFO - 2025-05-06 13:36:25 --> Config Class Initialized
INFO - 2025-05-06 13:36:25 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:25 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:25 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:25 --> URI Class Initialized
INFO - 2025-05-06 13:36:25 --> Router Class Initialized
INFO - 2025-05-06 13:36:25 --> Output Class Initialized
INFO - 2025-05-06 13:36:25 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:25 --> Input Class Initialized
INFO - 2025-05-06 13:36:25 --> Language Class Initialized
INFO - 2025-05-06 13:36:25 --> Loader Class Initialized
INFO - 2025-05-06 13:36:25 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:25 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:25 --> Database Driver Class Initialized
INFO - 2025-05-06 13:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:25 --> Form Validation Class Initialized
INFO - 2025-05-06 13:36:25 --> Controller Class Initialized
INFO - 2025-05-06 13:36:25 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:36:25 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:36:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:36:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-06 13:36:25 --> Final output sent to browser
DEBUG - 2025-05-06 13:36:25 --> Total execution time: 0.0440
INFO - 2025-05-06 13:36:28 --> Config Class Initialized
INFO - 2025-05-06 13:36:28 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:28 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:28 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:28 --> URI Class Initialized
INFO - 2025-05-06 13:36:28 --> Router Class Initialized
INFO - 2025-05-06 13:36:28 --> Output Class Initialized
INFO - 2025-05-06 13:36:28 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:28 --> Input Class Initialized
INFO - 2025-05-06 13:36:28 --> Language Class Initialized
INFO - 2025-05-06 13:36:28 --> Loader Class Initialized
INFO - 2025-05-06 13:36:28 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:28 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:28 --> Database Driver Class Initialized
INFO - 2025-05-06 13:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:28 --> Form Validation Class Initialized
INFO - 2025-05-06 13:36:28 --> Controller Class Initialized
INFO - 2025-05-06 13:36:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:36:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:36:28 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:36:28 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-06 13:36:28 --> Final output sent to browser
DEBUG - 2025-05-06 13:36:28 --> Total execution time: 0.0453
INFO - 2025-05-06 13:36:32 --> Config Class Initialized
INFO - 2025-05-06 13:36:32 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:32 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:32 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:32 --> URI Class Initialized
INFO - 2025-05-06 13:36:32 --> Router Class Initialized
INFO - 2025-05-06 13:36:32 --> Output Class Initialized
INFO - 2025-05-06 13:36:32 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:32 --> Input Class Initialized
INFO - 2025-05-06 13:36:32 --> Language Class Initialized
INFO - 2025-05-06 13:36:32 --> Loader Class Initialized
INFO - 2025-05-06 13:36:32 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:32 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:32 --> Database Driver Class Initialized
INFO - 2025-05-06 13:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:32 --> Form Validation Class Initialized
INFO - 2025-05-06 13:36:32 --> Controller Class Initialized
INFO - 2025-05-06 13:36:32 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:36:32 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:36:32 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:36:32 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-06 13:36:32 --> Final output sent to browser
DEBUG - 2025-05-06 13:36:32 --> Total execution time: 0.0371
INFO - 2025-05-06 13:36:49 --> Config Class Initialized
INFO - 2025-05-06 13:36:49 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:36:49 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:36:49 --> Utf8 Class Initialized
INFO - 2025-05-06 13:36:49 --> URI Class Initialized
INFO - 2025-05-06 13:36:49 --> Router Class Initialized
INFO - 2025-05-06 13:36:49 --> Output Class Initialized
INFO - 2025-05-06 13:36:49 --> Security Class Initialized
DEBUG - 2025-05-06 13:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:36:49 --> Input Class Initialized
INFO - 2025-05-06 13:36:49 --> Language Class Initialized
INFO - 2025-05-06 13:36:49 --> Loader Class Initialized
INFO - 2025-05-06 13:36:49 --> Helper loaded: form_helper
INFO - 2025-05-06 13:36:49 --> Helper loaded: url_helper
INFO - 2025-05-06 13:36:49 --> Database Driver Class Initialized
INFO - 2025-05-06 13:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:36:49 --> Form Validation Class Initialized
INFO - 2025-05-06 13:36:49 --> Controller Class Initialized
INFO - 2025-05-06 13:36:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:36:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:36:49 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-06 13:36:49 --> Final output sent to browser
DEBUG - 2025-05-06 13:36:49 --> Total execution time: 0.0351
INFO - 2025-05-06 13:38:40 --> Config Class Initialized
INFO - 2025-05-06 13:38:40 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:38:40 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:38:40 --> Utf8 Class Initialized
INFO - 2025-05-06 13:38:40 --> URI Class Initialized
INFO - 2025-05-06 13:38:40 --> Router Class Initialized
INFO - 2025-05-06 13:38:40 --> Output Class Initialized
INFO - 2025-05-06 13:38:40 --> Security Class Initialized
DEBUG - 2025-05-06 13:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:38:40 --> Input Class Initialized
INFO - 2025-05-06 13:38:40 --> Language Class Initialized
INFO - 2025-05-06 13:38:40 --> Loader Class Initialized
INFO - 2025-05-06 13:38:40 --> Helper loaded: form_helper
INFO - 2025-05-06 13:38:40 --> Helper loaded: url_helper
INFO - 2025-05-06 13:38:40 --> Database Driver Class Initialized
INFO - 2025-05-06 13:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:38:40 --> Form Validation Class Initialized
INFO - 2025-05-06 13:38:40 --> Controller Class Initialized
INFO - 2025-05-06 13:38:40 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:38:40 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:38:40 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:38:40 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 13:38:40 --> Final output sent to browser
DEBUG - 2025-05-06 13:38:40 --> Total execution time: 0.0387
INFO - 2025-05-06 13:38:52 --> Config Class Initialized
INFO - 2025-05-06 13:38:52 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:38:52 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:38:52 --> Utf8 Class Initialized
INFO - 2025-05-06 13:38:52 --> URI Class Initialized
INFO - 2025-05-06 13:38:52 --> Router Class Initialized
INFO - 2025-05-06 13:38:52 --> Output Class Initialized
INFO - 2025-05-06 13:38:52 --> Security Class Initialized
DEBUG - 2025-05-06 13:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:38:52 --> Input Class Initialized
INFO - 2025-05-06 13:38:52 --> Language Class Initialized
INFO - 2025-05-06 13:38:52 --> Loader Class Initialized
INFO - 2025-05-06 13:38:52 --> Helper loaded: form_helper
INFO - 2025-05-06 13:38:52 --> Helper loaded: url_helper
INFO - 2025-05-06 13:38:52 --> Database Driver Class Initialized
INFO - 2025-05-06 13:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:38:52 --> Form Validation Class Initialized
INFO - 2025-05-06 13:38:52 --> Controller Class Initialized
INFO - 2025-05-06 13:38:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:38:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:38:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:38:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-06 13:38:52 --> Final output sent to browser
DEBUG - 2025-05-06 13:38:52 --> Total execution time: 0.0382
INFO - 2025-05-06 13:38:53 --> Config Class Initialized
INFO - 2025-05-06 13:38:53 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:38:53 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:38:53 --> Utf8 Class Initialized
INFO - 2025-05-06 13:38:53 --> URI Class Initialized
INFO - 2025-05-06 13:38:53 --> Router Class Initialized
INFO - 2025-05-06 13:38:53 --> Output Class Initialized
INFO - 2025-05-06 13:38:53 --> Security Class Initialized
DEBUG - 2025-05-06 13:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:38:53 --> Input Class Initialized
INFO - 2025-05-06 13:38:53 --> Language Class Initialized
INFO - 2025-05-06 13:38:53 --> Loader Class Initialized
INFO - 2025-05-06 13:38:53 --> Helper loaded: form_helper
INFO - 2025-05-06 13:38:53 --> Helper loaded: url_helper
INFO - 2025-05-06 13:38:53 --> Database Driver Class Initialized
INFO - 2025-05-06 13:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:38:53 --> Form Validation Class Initialized
INFO - 2025-05-06 13:38:53 --> Controller Class Initialized
INFO - 2025-05-06 13:38:53 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-06 13:38:53 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-06 13:38:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-06 13:38:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/belum_daftar_ulang.php
INFO - 2025-05-06 13:38:53 --> Final output sent to browser
DEBUG - 2025-05-06 13:38:53 --> Total execution time: 0.0369
INFO - 2025-05-06 13:53:10 --> Config Class Initialized
INFO - 2025-05-06 13:53:10 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:53:10 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:53:10 --> Utf8 Class Initialized
INFO - 2025-05-06 13:53:10 --> URI Class Initialized
DEBUG - 2025-05-06 13:53:10 --> No URI present. Default controller set.
INFO - 2025-05-06 13:53:10 --> Router Class Initialized
INFO - 2025-05-06 13:53:10 --> Output Class Initialized
INFO - 2025-05-06 13:53:10 --> Security Class Initialized
DEBUG - 2025-05-06 13:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:53:10 --> Input Class Initialized
INFO - 2025-05-06 13:53:10 --> Language Class Initialized
INFO - 2025-05-06 13:53:10 --> Loader Class Initialized
INFO - 2025-05-06 13:53:10 --> Helper loaded: form_helper
INFO - 2025-05-06 13:53:10 --> Helper loaded: url_helper
INFO - 2025-05-06 13:53:10 --> Database Driver Class Initialized
INFO - 2025-05-06 13:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:53:10 --> Form Validation Class Initialized
INFO - 2025-05-06 13:53:10 --> Controller Class Initialized
INFO - 2025-05-06 13:53:10 --> Final output sent to browser
DEBUG - 2025-05-06 13:53:10 --> Total execution time: 0.0385
INFO - 2025-05-06 13:54:27 --> Config Class Initialized
INFO - 2025-05-06 13:54:27 --> Hooks Class Initialized
DEBUG - 2025-05-06 13:54:27 --> UTF-8 Support Enabled
INFO - 2025-05-06 13:54:27 --> Utf8 Class Initialized
INFO - 2025-05-06 13:54:27 --> URI Class Initialized
DEBUG - 2025-05-06 13:54:27 --> No URI present. Default controller set.
INFO - 2025-05-06 13:54:27 --> Router Class Initialized
INFO - 2025-05-06 13:54:27 --> Output Class Initialized
INFO - 2025-05-06 13:54:27 --> Security Class Initialized
DEBUG - 2025-05-06 13:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 13:54:27 --> Input Class Initialized
INFO - 2025-05-06 13:54:27 --> Language Class Initialized
INFO - 2025-05-06 13:54:27 --> Loader Class Initialized
INFO - 2025-05-06 13:54:27 --> Helper loaded: form_helper
INFO - 2025-05-06 13:54:27 --> Helper loaded: url_helper
INFO - 2025-05-06 13:54:27 --> Database Driver Class Initialized
INFO - 2025-05-06 13:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-06 13:54:27 --> Form Validation Class Initialized
INFO - 2025-05-06 13:54:27 --> Controller Class Initialized
INFO - 2025-05-06 13:54:27 --> Final output sent to browser
DEBUG - 2025-05-06 13:54:27 --> Total execution time: 0.0307
INFO - 2025-05-06 14:34:17 --> Config Class Initialized
INFO - 2025-05-06 14:34:17 --> Hooks Class Initialized
DEBUG - 2025-05-06 14:34:17 --> UTF-8 Support Enabled
INFO - 2025-05-06 14:34:17 --> Utf8 Class Initialized
INFO - 2025-05-06 14:34:17 --> URI Class Initialized
INFO - 2025-05-06 14:34:17 --> Router Class Initialized
INFO - 2025-05-06 14:34:17 --> Output Class Initialized
INFO - 2025-05-06 14:34:17 --> Security Class Initialized
DEBUG - 2025-05-06 14:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 14:34:17 --> Input Class Initialized
INFO - 2025-05-06 14:34:17 --> Language Class Initialized
ERROR - 2025-05-06 14:34:17 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-05-06 14:34:25 --> Config Class Initialized
INFO - 2025-05-06 14:34:25 --> Hooks Class Initialized
DEBUG - 2025-05-06 14:34:25 --> UTF-8 Support Enabled
INFO - 2025-05-06 14:34:25 --> Utf8 Class Initialized
INFO - 2025-05-06 14:34:25 --> URI Class Initialized
INFO - 2025-05-06 14:34:25 --> Router Class Initialized
INFO - 2025-05-06 14:34:25 --> Output Class Initialized
INFO - 2025-05-06 14:34:25 --> Security Class Initialized
DEBUG - 2025-05-06 14:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 14:34:25 --> Input Class Initialized
INFO - 2025-05-06 14:34:25 --> Language Class Initialized
ERROR - 2025-05-06 14:34:25 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-05-06 14:34:36 --> Config Class Initialized
INFO - 2025-05-06 14:34:36 --> Hooks Class Initialized
DEBUG - 2025-05-06 14:34:36 --> UTF-8 Support Enabled
INFO - 2025-05-06 14:34:36 --> Utf8 Class Initialized
INFO - 2025-05-06 14:34:36 --> URI Class Initialized
INFO - 2025-05-06 14:34:36 --> Router Class Initialized
INFO - 2025-05-06 14:34:36 --> Output Class Initialized
INFO - 2025-05-06 14:34:36 --> Security Class Initialized
DEBUG - 2025-05-06 14:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 14:34:36 --> Input Class Initialized
INFO - 2025-05-06 14:34:36 --> Language Class Initialized
ERROR - 2025-05-06 14:34:36 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-05-06 14:34:45 --> Config Class Initialized
INFO - 2025-05-06 14:34:45 --> Hooks Class Initialized
DEBUG - 2025-05-06 14:34:45 --> UTF-8 Support Enabled
INFO - 2025-05-06 14:34:45 --> Utf8 Class Initialized
INFO - 2025-05-06 14:34:45 --> URI Class Initialized
INFO - 2025-05-06 14:34:45 --> Router Class Initialized
INFO - 2025-05-06 14:34:45 --> Output Class Initialized
INFO - 2025-05-06 14:34:45 --> Security Class Initialized
DEBUG - 2025-05-06 14:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-06 14:34:45 --> Input Class Initialized
INFO - 2025-05-06 14:34:45 --> Language Class Initialized
ERROR - 2025-05-06 14:34:45 --> 404 Page Not Found: Wp-content/themes
