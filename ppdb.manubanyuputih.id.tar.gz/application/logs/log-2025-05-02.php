<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-02 00:12:26 --> Config Class Initialized
INFO - 2025-05-02 00:12:26 --> Hooks Class Initialized
DEBUG - 2025-05-02 00:12:26 --> UTF-8 Support Enabled
INFO - 2025-05-02 00:12:26 --> Utf8 Class Initialized
INFO - 2025-05-02 00:12:26 --> URI Class Initialized
DEBUG - 2025-05-02 00:12:26 --> No URI present. Default controller set.
INFO - 2025-05-02 00:12:26 --> Router Class Initialized
INFO - 2025-05-02 00:12:26 --> Output Class Initialized
INFO - 2025-05-02 00:12:26 --> Security Class Initialized
DEBUG - 2025-05-02 00:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 00:12:26 --> Input Class Initialized
INFO - 2025-05-02 00:12:26 --> Language Class Initialized
INFO - 2025-05-02 00:12:26 --> Loader Class Initialized
INFO - 2025-05-02 00:12:26 --> Helper loaded: form_helper
INFO - 2025-05-02 00:12:26 --> Helper loaded: url_helper
INFO - 2025-05-02 00:12:26 --> Database Driver Class Initialized
INFO - 2025-05-02 00:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 00:12:26 --> Form Validation Class Initialized
INFO - 2025-05-02 00:12:26 --> Controller Class Initialized
INFO - 2025-05-02 00:12:26 --> Final output sent to browser
DEBUG - 2025-05-02 00:12:26 --> Total execution time: 0.0296
INFO - 2025-05-02 01:54:22 --> Config Class Initialized
INFO - 2025-05-02 01:54:22 --> Hooks Class Initialized
DEBUG - 2025-05-02 01:54:22 --> UTF-8 Support Enabled
INFO - 2025-05-02 01:54:22 --> Utf8 Class Initialized
INFO - 2025-05-02 01:54:22 --> URI Class Initialized
INFO - 2025-05-02 01:54:22 --> Router Class Initialized
INFO - 2025-05-02 01:54:22 --> Output Class Initialized
INFO - 2025-05-02 01:54:22 --> Security Class Initialized
DEBUG - 2025-05-02 01:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 01:54:22 --> Input Class Initialized
INFO - 2025-05-02 01:54:22 --> Language Class Initialized
ERROR - 2025-05-02 01:54:22 --> 404 Page Not Found: Panel_admin/log_in
INFO - 2025-05-02 01:54:24 --> Config Class Initialized
INFO - 2025-05-02 01:54:24 --> Hooks Class Initialized
DEBUG - 2025-05-02 01:54:24 --> UTF-8 Support Enabled
INFO - 2025-05-02 01:54:24 --> Utf8 Class Initialized
INFO - 2025-05-02 01:54:24 --> URI Class Initialized
INFO - 2025-05-02 01:54:24 --> Router Class Initialized
INFO - 2025-05-02 01:54:24 --> Output Class Initialized
INFO - 2025-05-02 01:54:24 --> Security Class Initialized
DEBUG - 2025-05-02 01:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 01:54:24 --> Input Class Initialized
INFO - 2025-05-02 01:54:24 --> Language Class Initialized
ERROR - 2025-05-02 01:54:24 --> 404 Page Not Found: Panel_admin/log_in
INFO - 2025-05-02 01:54:26 --> Config Class Initialized
INFO - 2025-05-02 01:54:26 --> Hooks Class Initialized
DEBUG - 2025-05-02 01:54:26 --> UTF-8 Support Enabled
INFO - 2025-05-02 01:54:26 --> Utf8 Class Initialized
INFO - 2025-05-02 01:54:26 --> URI Class Initialized
INFO - 2025-05-02 01:54:26 --> Router Class Initialized
INFO - 2025-05-02 01:54:26 --> Output Class Initialized
INFO - 2025-05-02 01:54:26 --> Security Class Initialized
DEBUG - 2025-05-02 01:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 01:54:26 --> Input Class Initialized
INFO - 2025-05-02 01:54:26 --> Language Class Initialized
ERROR - 2025-05-02 01:54:26 --> 404 Page Not Found: Panel_admin/log_in
INFO - 2025-05-02 01:54:27 --> Config Class Initialized
INFO - 2025-05-02 01:54:27 --> Hooks Class Initialized
DEBUG - 2025-05-02 01:54:27 --> UTF-8 Support Enabled
INFO - 2025-05-02 01:54:27 --> Utf8 Class Initialized
INFO - 2025-05-02 01:54:27 --> URI Class Initialized
INFO - 2025-05-02 01:54:27 --> Router Class Initialized
INFO - 2025-05-02 01:54:27 --> Output Class Initialized
INFO - 2025-05-02 01:54:27 --> Security Class Initialized
DEBUG - 2025-05-02 01:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 01:54:27 --> Input Class Initialized
INFO - 2025-05-02 01:54:27 --> Language Class Initialized
ERROR - 2025-05-02 01:54:27 --> 404 Page Not Found: Panel_admin/log_in
INFO - 2025-05-02 01:54:28 --> Config Class Initialized
INFO - 2025-05-02 01:54:28 --> Hooks Class Initialized
DEBUG - 2025-05-02 01:54:28 --> UTF-8 Support Enabled
INFO - 2025-05-02 01:54:28 --> Utf8 Class Initialized
INFO - 2025-05-02 01:54:28 --> URI Class Initialized
INFO - 2025-05-02 01:54:28 --> Router Class Initialized
INFO - 2025-05-02 01:54:28 --> Output Class Initialized
INFO - 2025-05-02 01:54:28 --> Security Class Initialized
DEBUG - 2025-05-02 01:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 01:54:28 --> Input Class Initialized
INFO - 2025-05-02 01:54:28 --> Language Class Initialized
ERROR - 2025-05-02 01:54:28 --> 404 Page Not Found: Panel_admin/log_in
INFO - 2025-05-02 04:17:44 --> Config Class Initialized
INFO - 2025-05-02 04:17:44 --> Hooks Class Initialized
DEBUG - 2025-05-02 04:17:44 --> UTF-8 Support Enabled
INFO - 2025-05-02 04:17:44 --> Utf8 Class Initialized
INFO - 2025-05-02 04:17:44 --> URI Class Initialized
INFO - 2025-05-02 04:17:44 --> Router Class Initialized
INFO - 2025-05-02 04:17:44 --> Output Class Initialized
INFO - 2025-05-02 04:17:44 --> Security Class Initialized
DEBUG - 2025-05-02 04:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 04:17:44 --> Input Class Initialized
INFO - 2025-05-02 04:17:44 --> Language Class Initialized
ERROR - 2025-05-02 04:17:44 --> 404 Page Not Found: Vendor/htmlawed
INFO - 2025-05-02 04:17:45 --> Config Class Initialized
INFO - 2025-05-02 04:17:45 --> Hooks Class Initialized
DEBUG - 2025-05-02 04:17:45 --> UTF-8 Support Enabled
INFO - 2025-05-02 04:17:45 --> Utf8 Class Initialized
INFO - 2025-05-02 04:17:45 --> URI Class Initialized
INFO - 2025-05-02 04:17:45 --> Router Class Initialized
INFO - 2025-05-02 04:17:45 --> Output Class Initialized
INFO - 2025-05-02 04:17:45 --> Security Class Initialized
DEBUG - 2025-05-02 04:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 04:17:45 --> Input Class Initialized
INFO - 2025-05-02 04:17:45 --> Language Class Initialized
ERROR - 2025-05-02 04:17:45 --> 404 Page Not Found: Glpi/vendor
INFO - 2025-05-02 07:00:27 --> Config Class Initialized
INFO - 2025-05-02 07:00:27 --> Hooks Class Initialized
DEBUG - 2025-05-02 07:00:27 --> UTF-8 Support Enabled
INFO - 2025-05-02 07:00:27 --> Utf8 Class Initialized
INFO - 2025-05-02 07:00:27 --> URI Class Initialized
DEBUG - 2025-05-02 07:00:27 --> No URI present. Default controller set.
INFO - 2025-05-02 07:00:27 --> Router Class Initialized
INFO - 2025-05-02 07:00:27 --> Output Class Initialized
INFO - 2025-05-02 07:00:27 --> Security Class Initialized
DEBUG - 2025-05-02 07:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 07:00:27 --> Input Class Initialized
INFO - 2025-05-02 07:00:27 --> Language Class Initialized
INFO - 2025-05-02 07:00:27 --> Loader Class Initialized
INFO - 2025-05-02 07:00:27 --> Helper loaded: form_helper
INFO - 2025-05-02 07:00:27 --> Helper loaded: url_helper
INFO - 2025-05-02 07:00:27 --> Database Driver Class Initialized
INFO - 2025-05-02 07:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 07:00:27 --> Form Validation Class Initialized
INFO - 2025-05-02 07:00:27 --> Controller Class Initialized
INFO - 2025-05-02 07:00:27 --> Final output sent to browser
DEBUG - 2025-05-02 07:00:27 --> Total execution time: 0.0524
INFO - 2025-05-02 08:45:23 --> Config Class Initialized
INFO - 2025-05-02 08:45:23 --> Hooks Class Initialized
DEBUG - 2025-05-02 08:45:23 --> UTF-8 Support Enabled
INFO - 2025-05-02 08:45:23 --> Utf8 Class Initialized
INFO - 2025-05-02 08:45:23 --> URI Class Initialized
DEBUG - 2025-05-02 08:45:23 --> No URI present. Default controller set.
INFO - 2025-05-02 08:45:23 --> Router Class Initialized
INFO - 2025-05-02 08:45:23 --> Output Class Initialized
INFO - 2025-05-02 08:45:23 --> Security Class Initialized
DEBUG - 2025-05-02 08:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 08:45:23 --> Input Class Initialized
INFO - 2025-05-02 08:45:23 --> Language Class Initialized
INFO - 2025-05-02 08:45:23 --> Loader Class Initialized
INFO - 2025-05-02 08:45:23 --> Helper loaded: form_helper
INFO - 2025-05-02 08:45:23 --> Helper loaded: url_helper
INFO - 2025-05-02 08:45:23 --> Database Driver Class Initialized
INFO - 2025-05-02 08:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 08:45:23 --> Form Validation Class Initialized
INFO - 2025-05-02 08:45:23 --> Controller Class Initialized
INFO - 2025-05-02 08:45:23 --> Final output sent to browser
DEBUG - 2025-05-02 08:45:23 --> Total execution time: 0.0298
INFO - 2025-05-02 08:59:18 --> Config Class Initialized
INFO - 2025-05-02 08:59:18 --> Hooks Class Initialized
DEBUG - 2025-05-02 08:59:18 --> UTF-8 Support Enabled
INFO - 2025-05-02 08:59:18 --> Utf8 Class Initialized
INFO - 2025-05-02 08:59:18 --> URI Class Initialized
DEBUG - 2025-05-02 08:59:18 --> No URI present. Default controller set.
INFO - 2025-05-02 08:59:18 --> Router Class Initialized
INFO - 2025-05-02 08:59:18 --> Output Class Initialized
INFO - 2025-05-02 08:59:18 --> Security Class Initialized
DEBUG - 2025-05-02 08:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 08:59:18 --> Input Class Initialized
INFO - 2025-05-02 08:59:18 --> Language Class Initialized
INFO - 2025-05-02 08:59:18 --> Loader Class Initialized
INFO - 2025-05-02 08:59:18 --> Helper loaded: form_helper
INFO - 2025-05-02 08:59:18 --> Helper loaded: url_helper
INFO - 2025-05-02 08:59:18 --> Database Driver Class Initialized
INFO - 2025-05-02 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 08:59:18 --> Form Validation Class Initialized
INFO - 2025-05-02 08:59:18 --> Controller Class Initialized
INFO - 2025-05-02 08:59:18 --> Final output sent to browser
DEBUG - 2025-05-02 08:59:18 --> Total execution time: 0.0377
INFO - 2025-05-02 08:59:23 --> Config Class Initialized
INFO - 2025-05-02 08:59:23 --> Hooks Class Initialized
DEBUG - 2025-05-02 08:59:23 --> UTF-8 Support Enabled
INFO - 2025-05-02 08:59:23 --> Utf8 Class Initialized
INFO - 2025-05-02 08:59:23 --> URI Class Initialized
INFO - 2025-05-02 08:59:23 --> Router Class Initialized
INFO - 2025-05-02 08:59:23 --> Output Class Initialized
INFO - 2025-05-02 08:59:23 --> Security Class Initialized
DEBUG - 2025-05-02 08:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 08:59:23 --> Input Class Initialized
INFO - 2025-05-02 08:59:23 --> Language Class Initialized
INFO - 2025-05-02 08:59:23 --> Loader Class Initialized
INFO - 2025-05-02 08:59:23 --> Helper loaded: form_helper
INFO - 2025-05-02 08:59:23 --> Helper loaded: url_helper
INFO - 2025-05-02 08:59:23 --> Database Driver Class Initialized
INFO - 2025-05-02 08:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 08:59:23 --> Form Validation Class Initialized
INFO - 2025-05-02 08:59:23 --> Controller Class Initialized
DEBUG - 2025-05-02 08:59:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 08:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 08:59:23 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 08:59:23 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 08:59:23 --> Final output sent to browser
DEBUG - 2025-05-02 08:59:23 --> Total execution time: 0.0441
INFO - 2025-05-02 08:59:23 --> Config Class Initialized
INFO - 2025-05-02 08:59:23 --> Hooks Class Initialized
DEBUG - 2025-05-02 08:59:23 --> UTF-8 Support Enabled
INFO - 2025-05-02 08:59:23 --> Utf8 Class Initialized
INFO - 2025-05-02 08:59:23 --> URI Class Initialized
INFO - 2025-05-02 08:59:23 --> Router Class Initialized
INFO - 2025-05-02 08:59:23 --> Output Class Initialized
INFO - 2025-05-02 08:59:23 --> Security Class Initialized
DEBUG - 2025-05-02 08:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 08:59:23 --> Input Class Initialized
INFO - 2025-05-02 08:59:23 --> Language Class Initialized
ERROR - 2025-05-02 08:59:23 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 08:59:41 --> Config Class Initialized
INFO - 2025-05-02 08:59:41 --> Hooks Class Initialized
DEBUG - 2025-05-02 08:59:41 --> UTF-8 Support Enabled
INFO - 2025-05-02 08:59:41 --> Utf8 Class Initialized
INFO - 2025-05-02 08:59:41 --> URI Class Initialized
INFO - 2025-05-02 08:59:41 --> Router Class Initialized
INFO - 2025-05-02 08:59:41 --> Output Class Initialized
INFO - 2025-05-02 08:59:41 --> Security Class Initialized
DEBUG - 2025-05-02 08:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 08:59:41 --> Input Class Initialized
INFO - 2025-05-02 08:59:41 --> Language Class Initialized
INFO - 2025-05-02 08:59:41 --> Loader Class Initialized
INFO - 2025-05-02 08:59:41 --> Helper loaded: form_helper
INFO - 2025-05-02 08:59:41 --> Helper loaded: url_helper
INFO - 2025-05-02 08:59:41 --> Database Driver Class Initialized
INFO - 2025-05-02 08:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 08:59:41 --> Form Validation Class Initialized
INFO - 2025-05-02 08:59:41 --> Controller Class Initialized
DEBUG - 2025-05-02 08:59:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 08:59:41 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 08:59:41 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 08:59:41 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 08:59:41 --> Final output sent to browser
DEBUG - 2025-05-02 08:59:41 --> Total execution time: 0.0314
INFO - 2025-05-02 09:01:44 --> Config Class Initialized
INFO - 2025-05-02 09:01:44 --> Hooks Class Initialized
DEBUG - 2025-05-02 09:01:44 --> UTF-8 Support Enabled
INFO - 2025-05-02 09:01:44 --> Utf8 Class Initialized
INFO - 2025-05-02 09:01:44 --> URI Class Initialized
DEBUG - 2025-05-02 09:01:44 --> No URI present. Default controller set.
INFO - 2025-05-02 09:01:44 --> Router Class Initialized
INFO - 2025-05-02 09:01:44 --> Output Class Initialized
INFO - 2025-05-02 09:01:44 --> Security Class Initialized
DEBUG - 2025-05-02 09:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 09:01:44 --> Input Class Initialized
INFO - 2025-05-02 09:01:44 --> Language Class Initialized
INFO - 2025-05-02 09:01:44 --> Loader Class Initialized
INFO - 2025-05-02 09:01:44 --> Helper loaded: form_helper
INFO - 2025-05-02 09:01:44 --> Helper loaded: url_helper
INFO - 2025-05-02 09:01:44 --> Database Driver Class Initialized
INFO - 2025-05-02 09:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 09:01:44 --> Form Validation Class Initialized
INFO - 2025-05-02 09:01:44 --> Controller Class Initialized
INFO - 2025-05-02 09:01:44 --> Final output sent to browser
DEBUG - 2025-05-02 09:01:44 --> Total execution time: 0.0343
INFO - 2025-05-02 09:04:24 --> Config Class Initialized
INFO - 2025-05-02 09:04:24 --> Hooks Class Initialized
DEBUG - 2025-05-02 09:04:24 --> UTF-8 Support Enabled
INFO - 2025-05-02 09:04:24 --> Utf8 Class Initialized
INFO - 2025-05-02 09:04:24 --> URI Class Initialized
DEBUG - 2025-05-02 09:04:24 --> No URI present. Default controller set.
INFO - 2025-05-02 09:04:24 --> Router Class Initialized
INFO - 2025-05-02 09:04:24 --> Output Class Initialized
INFO - 2025-05-02 09:04:24 --> Security Class Initialized
DEBUG - 2025-05-02 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 09:04:24 --> Input Class Initialized
INFO - 2025-05-02 09:04:24 --> Language Class Initialized
INFO - 2025-05-02 09:04:24 --> Loader Class Initialized
INFO - 2025-05-02 09:04:24 --> Helper loaded: form_helper
INFO - 2025-05-02 09:04:24 --> Helper loaded: url_helper
INFO - 2025-05-02 09:04:24 --> Database Driver Class Initialized
INFO - 2025-05-02 09:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 09:04:24 --> Form Validation Class Initialized
INFO - 2025-05-02 09:04:24 --> Controller Class Initialized
INFO - 2025-05-02 09:04:24 --> Final output sent to browser
DEBUG - 2025-05-02 09:04:24 --> Total execution time: 0.0350
INFO - 2025-05-02 09:04:27 --> Config Class Initialized
INFO - 2025-05-02 09:04:27 --> Hooks Class Initialized
DEBUG - 2025-05-02 09:04:27 --> UTF-8 Support Enabled
INFO - 2025-05-02 09:04:27 --> Utf8 Class Initialized
INFO - 2025-05-02 09:04:27 --> URI Class Initialized
INFO - 2025-05-02 09:04:27 --> Router Class Initialized
INFO - 2025-05-02 09:04:27 --> Output Class Initialized
INFO - 2025-05-02 09:04:27 --> Security Class Initialized
DEBUG - 2025-05-02 09:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 09:04:27 --> Input Class Initialized
INFO - 2025-05-02 09:04:27 --> Language Class Initialized
INFO - 2025-05-02 09:04:27 --> Loader Class Initialized
INFO - 2025-05-02 09:04:27 --> Helper loaded: form_helper
INFO - 2025-05-02 09:04:27 --> Helper loaded: url_helper
INFO - 2025-05-02 09:04:27 --> Database Driver Class Initialized
INFO - 2025-05-02 09:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 09:04:27 --> Form Validation Class Initialized
INFO - 2025-05-02 09:04:27 --> Controller Class Initialized
DEBUG - 2025-05-02 09:04:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 09:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 09:04:27 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 09:04:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 09:04:27 --> Final output sent to browser
DEBUG - 2025-05-02 09:04:27 --> Total execution time: 0.0368
INFO - 2025-05-02 09:59:45 --> Config Class Initialized
INFO - 2025-05-02 09:59:45 --> Hooks Class Initialized
DEBUG - 2025-05-02 09:59:45 --> UTF-8 Support Enabled
INFO - 2025-05-02 09:59:45 --> Utf8 Class Initialized
INFO - 2025-05-02 09:59:45 --> URI Class Initialized
DEBUG - 2025-05-02 09:59:45 --> No URI present. Default controller set.
INFO - 2025-05-02 09:59:45 --> Router Class Initialized
INFO - 2025-05-02 09:59:45 --> Output Class Initialized
INFO - 2025-05-02 09:59:45 --> Security Class Initialized
DEBUG - 2025-05-02 09:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 09:59:45 --> Input Class Initialized
INFO - 2025-05-02 09:59:45 --> Language Class Initialized
INFO - 2025-05-02 09:59:45 --> Loader Class Initialized
INFO - 2025-05-02 09:59:45 --> Helper loaded: form_helper
INFO - 2025-05-02 09:59:45 --> Helper loaded: url_helper
INFO - 2025-05-02 09:59:45 --> Database Driver Class Initialized
INFO - 2025-05-02 09:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 09:59:45 --> Form Validation Class Initialized
INFO - 2025-05-02 09:59:45 --> Controller Class Initialized
INFO - 2025-05-02 09:59:45 --> Final output sent to browser
DEBUG - 2025-05-02 09:59:45 --> Total execution time: 0.0340
INFO - 2025-05-02 09:59:48 --> Config Class Initialized
INFO - 2025-05-02 09:59:48 --> Hooks Class Initialized
DEBUG - 2025-05-02 09:59:48 --> UTF-8 Support Enabled
INFO - 2025-05-02 09:59:48 --> Utf8 Class Initialized
INFO - 2025-05-02 09:59:48 --> URI Class Initialized
INFO - 2025-05-02 09:59:48 --> Router Class Initialized
INFO - 2025-05-02 09:59:48 --> Output Class Initialized
INFO - 2025-05-02 09:59:48 --> Security Class Initialized
DEBUG - 2025-05-02 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 09:59:48 --> Input Class Initialized
INFO - 2025-05-02 09:59:48 --> Language Class Initialized
INFO - 2025-05-02 09:59:48 --> Loader Class Initialized
INFO - 2025-05-02 09:59:48 --> Helper loaded: form_helper
INFO - 2025-05-02 09:59:48 --> Helper loaded: url_helper
INFO - 2025-05-02 09:59:48 --> Database Driver Class Initialized
INFO - 2025-05-02 09:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 09:59:48 --> Form Validation Class Initialized
INFO - 2025-05-02 09:59:48 --> Controller Class Initialized
DEBUG - 2025-05-02 09:59:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 09:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 09:59:48 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 09:59:48 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 09:59:48 --> Final output sent to browser
DEBUG - 2025-05-02 09:59:48 --> Total execution time: 0.0337
INFO - 2025-05-02 09:59:48 --> Config Class Initialized
INFO - 2025-05-02 09:59:48 --> Hooks Class Initialized
DEBUG - 2025-05-02 09:59:48 --> UTF-8 Support Enabled
INFO - 2025-05-02 09:59:48 --> Utf8 Class Initialized
INFO - 2025-05-02 09:59:48 --> URI Class Initialized
INFO - 2025-05-02 09:59:48 --> Router Class Initialized
INFO - 2025-05-02 09:59:48 --> Output Class Initialized
INFO - 2025-05-02 09:59:48 --> Security Class Initialized
DEBUG - 2025-05-02 09:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 09:59:49 --> Input Class Initialized
INFO - 2025-05-02 09:59:49 --> Language Class Initialized
ERROR - 2025-05-02 09:59:49 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 10:00:03 --> Config Class Initialized
INFO - 2025-05-02 10:00:03 --> Hooks Class Initialized
DEBUG - 2025-05-02 10:00:03 --> UTF-8 Support Enabled
INFO - 2025-05-02 10:00:03 --> Utf8 Class Initialized
INFO - 2025-05-02 10:00:03 --> URI Class Initialized
INFO - 2025-05-02 10:00:03 --> Router Class Initialized
INFO - 2025-05-02 10:00:03 --> Output Class Initialized
INFO - 2025-05-02 10:00:03 --> Security Class Initialized
DEBUG - 2025-05-02 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 10:00:03 --> Input Class Initialized
INFO - 2025-05-02 10:00:03 --> Language Class Initialized
INFO - 2025-05-02 10:00:03 --> Loader Class Initialized
INFO - 2025-05-02 10:00:03 --> Helper loaded: form_helper
INFO - 2025-05-02 10:00:03 --> Helper loaded: url_helper
INFO - 2025-05-02 10:00:03 --> Database Driver Class Initialized
INFO - 2025-05-02 10:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 10:00:03 --> Form Validation Class Initialized
INFO - 2025-05-02 10:00:03 --> Controller Class Initialized
DEBUG - 2025-05-02 10:00:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 10:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 10:00:03 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 10:00:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 10:00:03 --> Final output sent to browser
DEBUG - 2025-05-02 10:00:03 --> Total execution time: 0.0459
INFO - 2025-05-02 10:04:29 --> Config Class Initialized
INFO - 2025-05-02 10:04:29 --> Hooks Class Initialized
DEBUG - 2025-05-02 10:04:29 --> UTF-8 Support Enabled
INFO - 2025-05-02 10:04:29 --> Utf8 Class Initialized
INFO - 2025-05-02 10:04:29 --> URI Class Initialized
DEBUG - 2025-05-02 10:04:29 --> No URI present. Default controller set.
INFO - 2025-05-02 10:04:29 --> Router Class Initialized
INFO - 2025-05-02 10:04:29 --> Output Class Initialized
INFO - 2025-05-02 10:04:29 --> Security Class Initialized
DEBUG - 2025-05-02 10:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 10:04:29 --> Input Class Initialized
INFO - 2025-05-02 10:04:29 --> Language Class Initialized
INFO - 2025-05-02 10:04:29 --> Loader Class Initialized
INFO - 2025-05-02 10:04:29 --> Helper loaded: form_helper
INFO - 2025-05-02 10:04:29 --> Helper loaded: url_helper
INFO - 2025-05-02 10:04:29 --> Database Driver Class Initialized
INFO - 2025-05-02 10:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 10:04:29 --> Form Validation Class Initialized
INFO - 2025-05-02 10:04:29 --> Controller Class Initialized
INFO - 2025-05-02 10:04:29 --> Final output sent to browser
DEBUG - 2025-05-02 10:04:29 --> Total execution time: 0.0355
INFO - 2025-05-02 10:04:40 --> Config Class Initialized
INFO - 2025-05-02 10:04:40 --> Hooks Class Initialized
DEBUG - 2025-05-02 10:04:40 --> UTF-8 Support Enabled
INFO - 2025-05-02 10:04:40 --> Utf8 Class Initialized
INFO - 2025-05-02 10:04:40 --> URI Class Initialized
INFO - 2025-05-02 10:04:40 --> Router Class Initialized
INFO - 2025-05-02 10:04:40 --> Output Class Initialized
INFO - 2025-05-02 10:04:40 --> Security Class Initialized
DEBUG - 2025-05-02 10:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 10:04:40 --> Input Class Initialized
INFO - 2025-05-02 10:04:40 --> Language Class Initialized
INFO - 2025-05-02 10:04:40 --> Loader Class Initialized
INFO - 2025-05-02 10:04:40 --> Helper loaded: form_helper
INFO - 2025-05-02 10:04:40 --> Helper loaded: url_helper
INFO - 2025-05-02 10:04:40 --> Database Driver Class Initialized
INFO - 2025-05-02 10:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 10:04:40 --> Form Validation Class Initialized
INFO - 2025-05-02 10:04:40 --> Controller Class Initialized
DEBUG - 2025-05-02 10:04:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 10:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 10:04:40 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 10:04:40 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 10:04:40 --> Final output sent to browser
DEBUG - 2025-05-02 10:04:40 --> Total execution time: 0.0401
INFO - 2025-05-02 10:04:41 --> Config Class Initialized
INFO - 2025-05-02 10:04:41 --> Hooks Class Initialized
DEBUG - 2025-05-02 10:04:41 --> UTF-8 Support Enabled
INFO - 2025-05-02 10:04:41 --> Utf8 Class Initialized
INFO - 2025-05-02 10:04:41 --> URI Class Initialized
INFO - 2025-05-02 10:04:41 --> Router Class Initialized
INFO - 2025-05-02 10:04:41 --> Output Class Initialized
INFO - 2025-05-02 10:04:41 --> Security Class Initialized
DEBUG - 2025-05-02 10:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 10:04:41 --> Input Class Initialized
INFO - 2025-05-02 10:04:41 --> Language Class Initialized
ERROR - 2025-05-02 10:04:41 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 10:30:45 --> Config Class Initialized
INFO - 2025-05-02 10:30:45 --> Hooks Class Initialized
DEBUG - 2025-05-02 10:30:45 --> UTF-8 Support Enabled
INFO - 2025-05-02 10:30:45 --> Utf8 Class Initialized
INFO - 2025-05-02 10:30:45 --> URI Class Initialized
INFO - 2025-05-02 10:30:45 --> Router Class Initialized
INFO - 2025-05-02 10:30:45 --> Output Class Initialized
INFO - 2025-05-02 10:30:45 --> Security Class Initialized
DEBUG - 2025-05-02 10:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 10:30:45 --> Input Class Initialized
INFO - 2025-05-02 10:30:45 --> Language Class Initialized
INFO - 2025-05-02 10:30:45 --> Loader Class Initialized
INFO - 2025-05-02 10:30:45 --> Helper loaded: form_helper
INFO - 2025-05-02 10:30:45 --> Helper loaded: url_helper
INFO - 2025-05-02 10:30:45 --> Database Driver Class Initialized
INFO - 2025-05-02 10:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 10:30:45 --> Form Validation Class Initialized
INFO - 2025-05-02 10:30:45 --> Controller Class Initialized
DEBUG - 2025-05-02 10:30:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 10:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 10:30:45 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 10:30:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 10:30:45 --> Final output sent to browser
DEBUG - 2025-05-02 10:30:45 --> Total execution time: 0.0418
INFO - 2025-05-02 10:33:16 --> Config Class Initialized
INFO - 2025-05-02 10:33:16 --> Hooks Class Initialized
DEBUG - 2025-05-02 10:33:16 --> UTF-8 Support Enabled
INFO - 2025-05-02 10:33:16 --> Utf8 Class Initialized
INFO - 2025-05-02 10:33:16 --> URI Class Initialized
INFO - 2025-05-02 10:33:16 --> Router Class Initialized
INFO - 2025-05-02 10:33:16 --> Output Class Initialized
INFO - 2025-05-02 10:33:16 --> Security Class Initialized
DEBUG - 2025-05-02 10:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 10:33:16 --> Input Class Initialized
INFO - 2025-05-02 10:33:16 --> Language Class Initialized
INFO - 2025-05-02 10:33:16 --> Loader Class Initialized
INFO - 2025-05-02 10:33:16 --> Helper loaded: form_helper
INFO - 2025-05-02 10:33:16 --> Helper loaded: url_helper
INFO - 2025-05-02 10:33:16 --> Database Driver Class Initialized
INFO - 2025-05-02 10:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 10:33:16 --> Form Validation Class Initialized
INFO - 2025-05-02 10:33:16 --> Controller Class Initialized
DEBUG - 2025-05-02 10:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 10:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 10:33:16 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 10:33:16 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 10:33:16 --> Final output sent to browser
DEBUG - 2025-05-02 10:33:16 --> Total execution time: 0.0739
INFO - 2025-05-02 10:44:55 --> Config Class Initialized
INFO - 2025-05-02 10:44:55 --> Hooks Class Initialized
DEBUG - 2025-05-02 10:44:55 --> UTF-8 Support Enabled
INFO - 2025-05-02 10:44:55 --> Utf8 Class Initialized
INFO - 2025-05-02 10:44:55 --> URI Class Initialized
INFO - 2025-05-02 10:44:55 --> Router Class Initialized
INFO - 2025-05-02 10:44:55 --> Output Class Initialized
INFO - 2025-05-02 10:44:55 --> Security Class Initialized
DEBUG - 2025-05-02 10:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 10:44:55 --> Input Class Initialized
INFO - 2025-05-02 10:44:55 --> Language Class Initialized
INFO - 2025-05-02 10:44:55 --> Loader Class Initialized
INFO - 2025-05-02 10:44:55 --> Helper loaded: form_helper
INFO - 2025-05-02 10:44:55 --> Helper loaded: url_helper
INFO - 2025-05-02 10:44:55 --> Database Driver Class Initialized
INFO - 2025-05-02 10:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 10:44:55 --> Form Validation Class Initialized
INFO - 2025-05-02 10:44:55 --> Controller Class Initialized
DEBUG - 2025-05-02 10:44:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 10:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 10:44:55 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 10:44:55 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 10:44:55 --> Final output sent to browser
DEBUG - 2025-05-02 10:44:55 --> Total execution time: 0.0367
INFO - 2025-05-02 11:16:32 --> Config Class Initialized
INFO - 2025-05-02 11:16:32 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:16:32 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:16:32 --> Utf8 Class Initialized
INFO - 2025-05-02 11:16:32 --> URI Class Initialized
DEBUG - 2025-05-02 11:16:32 --> No URI present. Default controller set.
INFO - 2025-05-02 11:16:32 --> Router Class Initialized
INFO - 2025-05-02 11:16:32 --> Output Class Initialized
INFO - 2025-05-02 11:16:32 --> Security Class Initialized
DEBUG - 2025-05-02 11:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:16:32 --> Input Class Initialized
INFO - 2025-05-02 11:16:32 --> Language Class Initialized
INFO - 2025-05-02 11:16:32 --> Loader Class Initialized
INFO - 2025-05-02 11:16:32 --> Helper loaded: form_helper
INFO - 2025-05-02 11:16:32 --> Helper loaded: url_helper
INFO - 2025-05-02 11:16:32 --> Database Driver Class Initialized
INFO - 2025-05-02 11:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:16:32 --> Form Validation Class Initialized
INFO - 2025-05-02 11:16:32 --> Controller Class Initialized
INFO - 2025-05-02 11:16:32 --> Final output sent to browser
DEBUG - 2025-05-02 11:16:32 --> Total execution time: 0.0365
INFO - 2025-05-02 11:16:35 --> Config Class Initialized
INFO - 2025-05-02 11:16:35 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:16:35 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:16:35 --> Utf8 Class Initialized
INFO - 2025-05-02 11:16:35 --> URI Class Initialized
INFO - 2025-05-02 11:16:35 --> Router Class Initialized
INFO - 2025-05-02 11:16:35 --> Output Class Initialized
INFO - 2025-05-02 11:16:35 --> Security Class Initialized
DEBUG - 2025-05-02 11:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:16:35 --> Input Class Initialized
INFO - 2025-05-02 11:16:35 --> Language Class Initialized
INFO - 2025-05-02 11:16:35 --> Loader Class Initialized
INFO - 2025-05-02 11:16:35 --> Helper loaded: form_helper
INFO - 2025-05-02 11:16:35 --> Helper loaded: url_helper
INFO - 2025-05-02 11:16:35 --> Database Driver Class Initialized
INFO - 2025-05-02 11:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:16:35 --> Form Validation Class Initialized
INFO - 2025-05-02 11:16:35 --> Controller Class Initialized
DEBUG - 2025-05-02 11:16:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 11:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 11:16:35 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 11:16:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 11:16:35 --> Final output sent to browser
DEBUG - 2025-05-02 11:16:35 --> Total execution time: 0.0751
INFO - 2025-05-02 11:16:35 --> Config Class Initialized
INFO - 2025-05-02 11:16:35 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:16:35 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:16:35 --> Utf8 Class Initialized
INFO - 2025-05-02 11:16:35 --> URI Class Initialized
INFO - 2025-05-02 11:16:35 --> Router Class Initialized
INFO - 2025-05-02 11:16:35 --> Output Class Initialized
INFO - 2025-05-02 11:16:35 --> Security Class Initialized
DEBUG - 2025-05-02 11:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:16:35 --> Input Class Initialized
INFO - 2025-05-02 11:16:35 --> Language Class Initialized
ERROR - 2025-05-02 11:16:35 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 11:17:30 --> Config Class Initialized
INFO - 2025-05-02 11:17:30 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:17:30 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:17:30 --> Utf8 Class Initialized
INFO - 2025-05-02 11:17:30 --> URI Class Initialized
INFO - 2025-05-02 11:17:30 --> Router Class Initialized
INFO - 2025-05-02 11:17:30 --> Output Class Initialized
INFO - 2025-05-02 11:17:30 --> Security Class Initialized
DEBUG - 2025-05-02 11:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:17:30 --> Input Class Initialized
INFO - 2025-05-02 11:17:30 --> Language Class Initialized
INFO - 2025-05-02 11:17:30 --> Loader Class Initialized
INFO - 2025-05-02 11:17:30 --> Helper loaded: form_helper
INFO - 2025-05-02 11:17:30 --> Helper loaded: url_helper
INFO - 2025-05-02 11:17:30 --> Database Driver Class Initialized
INFO - 2025-05-02 11:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:17:30 --> Form Validation Class Initialized
INFO - 2025-05-02 11:17:30 --> Controller Class Initialized
DEBUG - 2025-05-02 11:17:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 11:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 11:17:30 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 11:17:30 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 11:17:30 --> Final output sent to browser
DEBUG - 2025-05-02 11:17:30 --> Total execution time: 0.0343
INFO - 2025-05-02 11:17:49 --> Config Class Initialized
INFO - 2025-05-02 11:17:49 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:17:49 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:17:49 --> Utf8 Class Initialized
INFO - 2025-05-02 11:17:49 --> URI Class Initialized
DEBUG - 2025-05-02 11:17:49 --> No URI present. Default controller set.
INFO - 2025-05-02 11:17:49 --> Router Class Initialized
INFO - 2025-05-02 11:17:49 --> Output Class Initialized
INFO - 2025-05-02 11:17:49 --> Security Class Initialized
DEBUG - 2025-05-02 11:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:17:49 --> Input Class Initialized
INFO - 2025-05-02 11:17:49 --> Language Class Initialized
INFO - 2025-05-02 11:17:49 --> Loader Class Initialized
INFO - 2025-05-02 11:17:49 --> Helper loaded: form_helper
INFO - 2025-05-02 11:17:49 --> Helper loaded: url_helper
INFO - 2025-05-02 11:17:49 --> Database Driver Class Initialized
INFO - 2025-05-02 11:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:17:49 --> Form Validation Class Initialized
INFO - 2025-05-02 11:17:49 --> Controller Class Initialized
INFO - 2025-05-02 11:17:49 --> Final output sent to browser
DEBUG - 2025-05-02 11:17:49 --> Total execution time: 0.0373
INFO - 2025-05-02 11:17:51 --> Config Class Initialized
INFO - 2025-05-02 11:17:51 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:17:51 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:17:51 --> Utf8 Class Initialized
INFO - 2025-05-02 11:17:51 --> URI Class Initialized
INFO - 2025-05-02 11:17:51 --> Router Class Initialized
INFO - 2025-05-02 11:17:51 --> Output Class Initialized
INFO - 2025-05-02 11:17:51 --> Security Class Initialized
DEBUG - 2025-05-02 11:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:17:51 --> Input Class Initialized
INFO - 2025-05-02 11:17:51 --> Language Class Initialized
INFO - 2025-05-02 11:17:51 --> Loader Class Initialized
INFO - 2025-05-02 11:17:51 --> Helper loaded: form_helper
INFO - 2025-05-02 11:17:51 --> Helper loaded: url_helper
INFO - 2025-05-02 11:17:51 --> Database Driver Class Initialized
INFO - 2025-05-02 11:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:17:51 --> Form Validation Class Initialized
INFO - 2025-05-02 11:17:51 --> Controller Class Initialized
DEBUG - 2025-05-02 11:17:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 11:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 11:17:51 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 11:17:51 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 11:17:51 --> Final output sent to browser
DEBUG - 2025-05-02 11:17:51 --> Total execution time: 0.0395
INFO - 2025-05-02 11:18:31 --> Config Class Initialized
INFO - 2025-05-02 11:18:31 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:18:31 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:18:31 --> Utf8 Class Initialized
INFO - 2025-05-02 11:18:31 --> URI Class Initialized
INFO - 2025-05-02 11:18:31 --> Router Class Initialized
INFO - 2025-05-02 11:18:31 --> Output Class Initialized
INFO - 2025-05-02 11:18:31 --> Security Class Initialized
DEBUG - 2025-05-02 11:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:18:31 --> Input Class Initialized
INFO - 2025-05-02 11:18:31 --> Language Class Initialized
ERROR - 2025-05-02 11:18:31 --> 404 Page Not Found: Ppdb/admin
INFO - 2025-05-02 11:18:36 --> Config Class Initialized
INFO - 2025-05-02 11:18:36 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:18:36 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:18:36 --> Utf8 Class Initialized
INFO - 2025-05-02 11:18:36 --> URI Class Initialized
INFO - 2025-05-02 11:18:36 --> Router Class Initialized
INFO - 2025-05-02 11:18:36 --> Output Class Initialized
INFO - 2025-05-02 11:18:36 --> Security Class Initialized
DEBUG - 2025-05-02 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:18:36 --> Input Class Initialized
INFO - 2025-05-02 11:18:36 --> Language Class Initialized
ERROR - 2025-05-02 11:18:36 --> 404 Page Not Found: Ppdb/admin
INFO - 2025-05-02 11:18:40 --> Config Class Initialized
INFO - 2025-05-02 11:18:40 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:18:40 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:18:40 --> Utf8 Class Initialized
INFO - 2025-05-02 11:18:40 --> URI Class Initialized
INFO - 2025-05-02 11:18:40 --> Router Class Initialized
INFO - 2025-05-02 11:18:40 --> Output Class Initialized
INFO - 2025-05-02 11:18:40 --> Security Class Initialized
DEBUG - 2025-05-02 11:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:18:40 --> Input Class Initialized
INFO - 2025-05-02 11:18:40 --> Language Class Initialized
INFO - 2025-05-02 11:18:40 --> Loader Class Initialized
INFO - 2025-05-02 11:18:40 --> Helper loaded: form_helper
INFO - 2025-05-02 11:18:40 --> Helper loaded: url_helper
INFO - 2025-05-02 11:18:40 --> Database Driver Class Initialized
INFO - 2025-05-02 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:18:40 --> Form Validation Class Initialized
INFO - 2025-05-02 11:18:40 --> Controller Class Initialized
INFO - 2025-05-02 11:18:40 --> Config Class Initialized
INFO - 2025-05-02 11:18:40 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:18:40 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:18:40 --> Utf8 Class Initialized
INFO - 2025-05-02 11:18:40 --> URI Class Initialized
INFO - 2025-05-02 11:18:40 --> Router Class Initialized
INFO - 2025-05-02 11:18:40 --> Output Class Initialized
INFO - 2025-05-02 11:18:40 --> Security Class Initialized
DEBUG - 2025-05-02 11:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:18:40 --> Input Class Initialized
INFO - 2025-05-02 11:18:40 --> Language Class Initialized
INFO - 2025-05-02 11:18:40 --> Loader Class Initialized
INFO - 2025-05-02 11:18:40 --> Helper loaded: form_helper
INFO - 2025-05-02 11:18:40 --> Helper loaded: url_helper
INFO - 2025-05-02 11:18:40 --> Database Driver Class Initialized
INFO - 2025-05-02 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:18:40 --> Form Validation Class Initialized
INFO - 2025-05-02 11:18:40 --> Controller Class Initialized
INFO - 2025-05-02 11:18:40 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-02 11:18:40 --> Final output sent to browser
DEBUG - 2025-05-02 11:18:40 --> Total execution time: 0.0316
INFO - 2025-05-02 11:18:45 --> Config Class Initialized
INFO - 2025-05-02 11:18:45 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:18:45 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:18:45 --> Utf8 Class Initialized
INFO - 2025-05-02 11:18:45 --> URI Class Initialized
INFO - 2025-05-02 11:18:45 --> Router Class Initialized
INFO - 2025-05-02 11:18:45 --> Output Class Initialized
INFO - 2025-05-02 11:18:45 --> Security Class Initialized
DEBUG - 2025-05-02 11:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:18:45 --> Input Class Initialized
INFO - 2025-05-02 11:18:45 --> Language Class Initialized
INFO - 2025-05-02 11:18:45 --> Loader Class Initialized
INFO - 2025-05-02 11:18:45 --> Helper loaded: form_helper
INFO - 2025-05-02 11:18:45 --> Helper loaded: url_helper
INFO - 2025-05-02 11:18:45 --> Database Driver Class Initialized
INFO - 2025-05-02 11:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:18:45 --> Form Validation Class Initialized
INFO - 2025-05-02 11:18:45 --> Controller Class Initialized
INFO - 2025-05-02 11:18:45 --> Config Class Initialized
INFO - 2025-05-02 11:18:45 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:18:45 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:18:45 --> Utf8 Class Initialized
INFO - 2025-05-02 11:18:45 --> URI Class Initialized
INFO - 2025-05-02 11:18:45 --> Router Class Initialized
INFO - 2025-05-02 11:18:45 --> Output Class Initialized
INFO - 2025-05-02 11:18:45 --> Security Class Initialized
DEBUG - 2025-05-02 11:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:18:45 --> Input Class Initialized
INFO - 2025-05-02 11:18:45 --> Language Class Initialized
INFO - 2025-05-02 11:18:45 --> Loader Class Initialized
INFO - 2025-05-02 11:18:45 --> Helper loaded: form_helper
INFO - 2025-05-02 11:18:45 --> Helper loaded: url_helper
INFO - 2025-05-02 11:18:45 --> Database Driver Class Initialized
INFO - 2025-05-02 11:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:18:45 --> Form Validation Class Initialized
INFO - 2025-05-02 11:18:45 --> Controller Class Initialized
INFO - 2025-05-02 11:18:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-02 11:18:45 --> Final output sent to browser
DEBUG - 2025-05-02 11:18:45 --> Total execution time: 0.0329
INFO - 2025-05-02 11:18:48 --> Config Class Initialized
INFO - 2025-05-02 11:18:48 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:18:48 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:18:48 --> Utf8 Class Initialized
INFO - 2025-05-02 11:18:48 --> URI Class Initialized
INFO - 2025-05-02 11:18:48 --> Router Class Initialized
INFO - 2025-05-02 11:18:48 --> Output Class Initialized
INFO - 2025-05-02 11:18:48 --> Security Class Initialized
DEBUG - 2025-05-02 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:18:48 --> Input Class Initialized
INFO - 2025-05-02 11:18:48 --> Language Class Initialized
INFO - 2025-05-02 11:18:48 --> Loader Class Initialized
INFO - 2025-05-02 11:18:48 --> Helper loaded: form_helper
INFO - 2025-05-02 11:18:48 --> Helper loaded: url_helper
INFO - 2025-05-02 11:18:48 --> Database Driver Class Initialized
INFO - 2025-05-02 11:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:18:48 --> Form Validation Class Initialized
INFO - 2025-05-02 11:18:48 --> Controller Class Initialized
INFO - 2025-05-02 11:18:48 --> Config Class Initialized
INFO - 2025-05-02 11:18:48 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:18:48 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:18:48 --> Utf8 Class Initialized
INFO - 2025-05-02 11:18:48 --> URI Class Initialized
INFO - 2025-05-02 11:18:48 --> Router Class Initialized
INFO - 2025-05-02 11:18:48 --> Output Class Initialized
INFO - 2025-05-02 11:18:48 --> Security Class Initialized
DEBUG - 2025-05-02 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:18:48 --> Input Class Initialized
INFO - 2025-05-02 11:18:48 --> Language Class Initialized
INFO - 2025-05-02 11:18:48 --> Loader Class Initialized
INFO - 2025-05-02 11:18:48 --> Helper loaded: form_helper
INFO - 2025-05-02 11:18:48 --> Helper loaded: url_helper
INFO - 2025-05-02 11:18:48 --> Database Driver Class Initialized
INFO - 2025-05-02 11:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:18:48 --> Form Validation Class Initialized
INFO - 2025-05-02 11:18:48 --> Controller Class Initialized
INFO - 2025-05-02 11:18:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:18:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:18:48 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:18:48 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-02 11:18:48 --> Final output sent to browser
DEBUG - 2025-05-02 11:18:48 --> Total execution time: 0.0480
INFO - 2025-05-02 11:18:52 --> Config Class Initialized
INFO - 2025-05-02 11:18:52 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:18:52 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:18:52 --> Utf8 Class Initialized
INFO - 2025-05-02 11:18:52 --> URI Class Initialized
INFO - 2025-05-02 11:18:52 --> Router Class Initialized
INFO - 2025-05-02 11:18:52 --> Output Class Initialized
INFO - 2025-05-02 11:18:52 --> Security Class Initialized
DEBUG - 2025-05-02 11:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:18:52 --> Input Class Initialized
INFO - 2025-05-02 11:18:52 --> Language Class Initialized
INFO - 2025-05-02 11:18:52 --> Loader Class Initialized
INFO - 2025-05-02 11:18:52 --> Helper loaded: form_helper
INFO - 2025-05-02 11:18:52 --> Helper loaded: url_helper
INFO - 2025-05-02 11:18:52 --> Database Driver Class Initialized
INFO - 2025-05-02 11:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:18:52 --> Form Validation Class Initialized
INFO - 2025-05-02 11:18:52 --> Controller Class Initialized
INFO - 2025-05-02 11:18:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:18:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:18:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:18:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-02 11:18:52 --> Final output sent to browser
DEBUG - 2025-05-02 11:18:52 --> Total execution time: 0.0503
INFO - 2025-05-02 11:19:00 --> Config Class Initialized
INFO - 2025-05-02 11:19:00 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:19:00 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:19:00 --> Utf8 Class Initialized
INFO - 2025-05-02 11:19:00 --> URI Class Initialized
INFO - 2025-05-02 11:19:00 --> Router Class Initialized
INFO - 2025-05-02 11:19:00 --> Output Class Initialized
INFO - 2025-05-02 11:19:00 --> Security Class Initialized
DEBUG - 2025-05-02 11:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:19:00 --> Input Class Initialized
INFO - 2025-05-02 11:19:00 --> Language Class Initialized
INFO - 2025-05-02 11:19:00 --> Loader Class Initialized
INFO - 2025-05-02 11:19:00 --> Helper loaded: form_helper
INFO - 2025-05-02 11:19:00 --> Helper loaded: url_helper
INFO - 2025-05-02 11:19:00 --> Database Driver Class Initialized
INFO - 2025-05-02 11:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:19:00 --> Form Validation Class Initialized
INFO - 2025-05-02 11:19:00 --> Controller Class Initialized
INFO - 2025-05-02 11:19:00 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:19:00 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:19:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:19:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 11:19:00 --> Final output sent to browser
DEBUG - 2025-05-02 11:19:00 --> Total execution time: 0.0408
INFO - 2025-05-02 11:19:02 --> Config Class Initialized
INFO - 2025-05-02 11:19:02 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:19:02 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:19:02 --> Utf8 Class Initialized
INFO - 2025-05-02 11:19:02 --> URI Class Initialized
INFO - 2025-05-02 11:19:02 --> Router Class Initialized
INFO - 2025-05-02 11:19:02 --> Output Class Initialized
INFO - 2025-05-02 11:19:02 --> Security Class Initialized
DEBUG - 2025-05-02 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:19:02 --> Input Class Initialized
INFO - 2025-05-02 11:19:02 --> Language Class Initialized
INFO - 2025-05-02 11:19:02 --> Loader Class Initialized
INFO - 2025-05-02 11:19:02 --> Helper loaded: form_helper
INFO - 2025-05-02 11:19:02 --> Helper loaded: url_helper
INFO - 2025-05-02 11:19:02 --> Database Driver Class Initialized
INFO - 2025-05-02 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:19:02 --> Form Validation Class Initialized
INFO - 2025-05-02 11:19:02 --> Controller Class Initialized
INFO - 2025-05-02 11:19:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:19:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:19:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:19:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-02 11:19:02 --> Final output sent to browser
DEBUG - 2025-05-02 11:19:02 --> Total execution time: 0.0421
INFO - 2025-05-02 11:19:10 --> Config Class Initialized
INFO - 2025-05-02 11:19:10 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:19:10 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:19:10 --> Utf8 Class Initialized
INFO - 2025-05-02 11:19:10 --> URI Class Initialized
INFO - 2025-05-02 11:19:10 --> Router Class Initialized
INFO - 2025-05-02 11:19:10 --> Output Class Initialized
INFO - 2025-05-02 11:19:10 --> Security Class Initialized
DEBUG - 2025-05-02 11:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:19:10 --> Input Class Initialized
INFO - 2025-05-02 11:19:10 --> Language Class Initialized
INFO - 2025-05-02 11:19:10 --> Loader Class Initialized
INFO - 2025-05-02 11:19:10 --> Helper loaded: form_helper
INFO - 2025-05-02 11:19:10 --> Helper loaded: url_helper
INFO - 2025-05-02 11:19:10 --> Database Driver Class Initialized
INFO - 2025-05-02 11:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:19:10 --> Form Validation Class Initialized
INFO - 2025-05-02 11:19:10 --> Controller Class Initialized
INFO - 2025-05-02 11:19:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:19:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:19:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:19:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-02 11:19:10 --> Final output sent to browser
DEBUG - 2025-05-02 11:19:10 --> Total execution time: 0.0428
INFO - 2025-05-02 11:19:27 --> Config Class Initialized
INFO - 2025-05-02 11:19:27 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:19:27 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:19:27 --> Utf8 Class Initialized
INFO - 2025-05-02 11:19:27 --> URI Class Initialized
INFO - 2025-05-02 11:19:27 --> Router Class Initialized
INFO - 2025-05-02 11:19:27 --> Output Class Initialized
INFO - 2025-05-02 11:19:27 --> Security Class Initialized
DEBUG - 2025-05-02 11:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:19:27 --> Input Class Initialized
INFO - 2025-05-02 11:19:27 --> Language Class Initialized
INFO - 2025-05-02 11:19:27 --> Loader Class Initialized
INFO - 2025-05-02 11:19:27 --> Helper loaded: form_helper
INFO - 2025-05-02 11:19:27 --> Helper loaded: url_helper
INFO - 2025-05-02 11:19:27 --> Database Driver Class Initialized
INFO - 2025-05-02 11:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:19:27 --> Form Validation Class Initialized
INFO - 2025-05-02 11:19:27 --> Controller Class Initialized
INFO - 2025-05-02 11:19:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:19:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:19:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:19:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 11:19:27 --> Final output sent to browser
DEBUG - 2025-05-02 11:19:27 --> Total execution time: 0.0395
INFO - 2025-05-02 11:19:29 --> Config Class Initialized
INFO - 2025-05-02 11:19:29 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:19:29 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:19:29 --> Utf8 Class Initialized
INFO - 2025-05-02 11:19:29 --> URI Class Initialized
INFO - 2025-05-02 11:19:29 --> Router Class Initialized
INFO - 2025-05-02 11:19:29 --> Output Class Initialized
INFO - 2025-05-02 11:19:29 --> Security Class Initialized
DEBUG - 2025-05-02 11:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:19:29 --> Input Class Initialized
INFO - 2025-05-02 11:19:29 --> Language Class Initialized
INFO - 2025-05-02 11:19:29 --> Loader Class Initialized
INFO - 2025-05-02 11:19:29 --> Helper loaded: form_helper
INFO - 2025-05-02 11:19:29 --> Helper loaded: url_helper
INFO - 2025-05-02 11:19:29 --> Database Driver Class Initialized
INFO - 2025-05-02 11:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:19:29 --> Form Validation Class Initialized
INFO - 2025-05-02 11:19:29 --> Controller Class Initialized
INFO - 2025-05-02 11:19:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:19:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:19:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:19:29 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-02 11:19:29 --> Final output sent to browser
DEBUG - 2025-05-02 11:19:29 --> Total execution time: 0.0379
INFO - 2025-05-02 11:19:52 --> Config Class Initialized
INFO - 2025-05-02 11:19:52 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:19:52 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:19:52 --> Utf8 Class Initialized
INFO - 2025-05-02 11:19:52 --> URI Class Initialized
INFO - 2025-05-02 11:19:52 --> Router Class Initialized
INFO - 2025-05-02 11:19:52 --> Output Class Initialized
INFO - 2025-05-02 11:19:52 --> Security Class Initialized
DEBUG - 2025-05-02 11:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:19:52 --> Input Class Initialized
INFO - 2025-05-02 11:19:52 --> Language Class Initialized
INFO - 2025-05-02 11:19:52 --> Loader Class Initialized
INFO - 2025-05-02 11:19:52 --> Helper loaded: form_helper
INFO - 2025-05-02 11:19:52 --> Helper loaded: url_helper
INFO - 2025-05-02 11:19:52 --> Database Driver Class Initialized
INFO - 2025-05-02 11:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:19:52 --> Form Validation Class Initialized
INFO - 2025-05-02 11:19:52 --> Controller Class Initialized
INFO - 2025-05-02 11:19:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:19:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:19:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:19:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 11:19:52 --> Final output sent to browser
DEBUG - 2025-05-02 11:19:52 --> Total execution time: 0.0388
INFO - 2025-05-02 11:19:53 --> Config Class Initialized
INFO - 2025-05-02 11:19:53 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:19:53 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:19:53 --> Utf8 Class Initialized
INFO - 2025-05-02 11:19:53 --> URI Class Initialized
INFO - 2025-05-02 11:19:53 --> Router Class Initialized
INFO - 2025-05-02 11:19:53 --> Output Class Initialized
INFO - 2025-05-02 11:19:53 --> Security Class Initialized
DEBUG - 2025-05-02 11:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:19:53 --> Input Class Initialized
INFO - 2025-05-02 11:19:53 --> Language Class Initialized
INFO - 2025-05-02 11:19:53 --> Loader Class Initialized
INFO - 2025-05-02 11:19:53 --> Helper loaded: form_helper
INFO - 2025-05-02 11:19:53 --> Helper loaded: url_helper
INFO - 2025-05-02 11:19:53 --> Database Driver Class Initialized
INFO - 2025-05-02 11:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:19:53 --> Form Validation Class Initialized
INFO - 2025-05-02 11:19:53 --> Controller Class Initialized
INFO - 2025-05-02 11:19:53 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:19:53 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:19:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:19:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-02 11:19:53 --> Final output sent to browser
DEBUG - 2025-05-02 11:19:53 --> Total execution time: 0.0445
INFO - 2025-05-02 11:20:02 --> Config Class Initialized
INFO - 2025-05-02 11:20:02 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:20:02 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:20:02 --> Utf8 Class Initialized
INFO - 2025-05-02 11:20:02 --> URI Class Initialized
INFO - 2025-05-02 11:20:02 --> Router Class Initialized
INFO - 2025-05-02 11:20:02 --> Output Class Initialized
INFO - 2025-05-02 11:20:02 --> Security Class Initialized
DEBUG - 2025-05-02 11:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:20:02 --> Input Class Initialized
INFO - 2025-05-02 11:20:02 --> Language Class Initialized
INFO - 2025-05-02 11:20:02 --> Loader Class Initialized
INFO - 2025-05-02 11:20:02 --> Helper loaded: form_helper
INFO - 2025-05-02 11:20:02 --> Helper loaded: url_helper
INFO - 2025-05-02 11:20:02 --> Database Driver Class Initialized
INFO - 2025-05-02 11:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:20:02 --> Form Validation Class Initialized
INFO - 2025-05-02 11:20:02 --> Controller Class Initialized
INFO - 2025-05-02 11:20:02 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:20:02 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:20:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:20:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-02 11:20:02 --> Final output sent to browser
DEBUG - 2025-05-02 11:20:02 --> Total execution time: 0.0564
INFO - 2025-05-02 11:20:05 --> Config Class Initialized
INFO - 2025-05-02 11:20:05 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:20:05 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:20:05 --> Utf8 Class Initialized
INFO - 2025-05-02 11:20:05 --> URI Class Initialized
INFO - 2025-05-02 11:20:05 --> Router Class Initialized
INFO - 2025-05-02 11:20:05 --> Output Class Initialized
INFO - 2025-05-02 11:20:05 --> Security Class Initialized
DEBUG - 2025-05-02 11:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:20:05 --> Input Class Initialized
INFO - 2025-05-02 11:20:05 --> Language Class Initialized
INFO - 2025-05-02 11:20:05 --> Loader Class Initialized
INFO - 2025-05-02 11:20:05 --> Helper loaded: form_helper
INFO - 2025-05-02 11:20:05 --> Helper loaded: url_helper
INFO - 2025-05-02 11:20:05 --> Database Driver Class Initialized
INFO - 2025-05-02 11:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:20:05 --> Form Validation Class Initialized
INFO - 2025-05-02 11:20:05 --> Controller Class Initialized
INFO - 2025-05-02 11:20:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:20:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:20:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:20:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 11:20:05 --> Final output sent to browser
DEBUG - 2025-05-02 11:20:05 --> Total execution time: 0.0411
INFO - 2025-05-02 11:20:11 --> Config Class Initialized
INFO - 2025-05-02 11:20:11 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:20:11 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:20:11 --> Utf8 Class Initialized
INFO - 2025-05-02 11:20:11 --> URI Class Initialized
INFO - 2025-05-02 11:20:11 --> Router Class Initialized
INFO - 2025-05-02 11:20:11 --> Output Class Initialized
INFO - 2025-05-02 11:20:11 --> Security Class Initialized
DEBUG - 2025-05-02 11:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:20:11 --> Input Class Initialized
INFO - 2025-05-02 11:20:11 --> Language Class Initialized
INFO - 2025-05-02 11:20:11 --> Loader Class Initialized
INFO - 2025-05-02 11:20:11 --> Helper loaded: form_helper
INFO - 2025-05-02 11:20:11 --> Helper loaded: url_helper
INFO - 2025-05-02 11:20:11 --> Database Driver Class Initialized
INFO - 2025-05-02 11:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:20:11 --> Form Validation Class Initialized
INFO - 2025-05-02 11:20:11 --> Controller Class Initialized
INFO - 2025-05-02 11:20:11 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:20:11 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:20:11 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-02 11:20:11 --> Final output sent to browser
DEBUG - 2025-05-02 11:20:11 --> Total execution time: 0.0396
INFO - 2025-05-02 11:20:19 --> Config Class Initialized
INFO - 2025-05-02 11:20:19 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:20:19 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:20:19 --> Utf8 Class Initialized
INFO - 2025-05-02 11:20:19 --> URI Class Initialized
INFO - 2025-05-02 11:20:19 --> Router Class Initialized
INFO - 2025-05-02 11:20:19 --> Output Class Initialized
INFO - 2025-05-02 11:20:19 --> Security Class Initialized
DEBUG - 2025-05-02 11:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:20:19 --> Input Class Initialized
INFO - 2025-05-02 11:20:19 --> Language Class Initialized
INFO - 2025-05-02 11:20:19 --> Loader Class Initialized
INFO - 2025-05-02 11:20:19 --> Helper loaded: form_helper
INFO - 2025-05-02 11:20:19 --> Helper loaded: url_helper
INFO - 2025-05-02 11:20:19 --> Database Driver Class Initialized
INFO - 2025-05-02 11:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:20:19 --> Form Validation Class Initialized
INFO - 2025-05-02 11:20:19 --> Controller Class Initialized
INFO - 2025-05-02 11:20:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:20:19 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:20:19 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-02 11:20:19 --> Final output sent to browser
DEBUG - 2025-05-02 11:20:19 --> Total execution time: 0.0380
INFO - 2025-05-02 11:21:16 --> Config Class Initialized
INFO - 2025-05-02 11:21:16 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:21:16 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:21:16 --> Utf8 Class Initialized
INFO - 2025-05-02 11:21:16 --> URI Class Initialized
INFO - 2025-05-02 11:21:16 --> Router Class Initialized
INFO - 2025-05-02 11:21:16 --> Output Class Initialized
INFO - 2025-05-02 11:21:16 --> Security Class Initialized
DEBUG - 2025-05-02 11:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:21:16 --> Input Class Initialized
INFO - 2025-05-02 11:21:16 --> Language Class Initialized
INFO - 2025-05-02 11:21:16 --> Loader Class Initialized
INFO - 2025-05-02 11:21:16 --> Helper loaded: form_helper
INFO - 2025-05-02 11:21:16 --> Helper loaded: url_helper
INFO - 2025-05-02 11:21:16 --> Database Driver Class Initialized
INFO - 2025-05-02 11:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:21:16 --> Form Validation Class Initialized
INFO - 2025-05-02 11:21:16 --> Controller Class Initialized
INFO - 2025-05-02 11:21:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:21:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:21:16 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:21:16 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-02 11:21:16 --> Final output sent to browser
DEBUG - 2025-05-02 11:21:16 --> Total execution time: 0.0426
INFO - 2025-05-02 11:21:18 --> Config Class Initialized
INFO - 2025-05-02 11:21:18 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:21:18 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:21:18 --> Utf8 Class Initialized
INFO - 2025-05-02 11:21:18 --> URI Class Initialized
INFO - 2025-05-02 11:21:18 --> Router Class Initialized
INFO - 2025-05-02 11:21:18 --> Output Class Initialized
INFO - 2025-05-02 11:21:18 --> Security Class Initialized
DEBUG - 2025-05-02 11:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:21:18 --> Input Class Initialized
INFO - 2025-05-02 11:21:18 --> Language Class Initialized
INFO - 2025-05-02 11:21:18 --> Loader Class Initialized
INFO - 2025-05-02 11:21:18 --> Helper loaded: form_helper
INFO - 2025-05-02 11:21:18 --> Helper loaded: url_helper
INFO - 2025-05-02 11:21:18 --> Database Driver Class Initialized
INFO - 2025-05-02 11:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:21:18 --> Form Validation Class Initialized
INFO - 2025-05-02 11:21:18 --> Controller Class Initialized
INFO - 2025-05-02 11:21:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:21:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:21:18 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-02 11:21:18 --> Final output sent to browser
DEBUG - 2025-05-02 11:21:18 --> Total execution time: 0.0394
INFO - 2025-05-02 11:22:56 --> Config Class Initialized
INFO - 2025-05-02 11:22:56 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:22:56 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:22:56 --> Utf8 Class Initialized
INFO - 2025-05-02 11:22:56 --> URI Class Initialized
INFO - 2025-05-02 11:22:56 --> Router Class Initialized
INFO - 2025-05-02 11:22:56 --> Output Class Initialized
INFO - 2025-05-02 11:22:56 --> Security Class Initialized
DEBUG - 2025-05-02 11:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:22:56 --> Input Class Initialized
INFO - 2025-05-02 11:22:56 --> Language Class Initialized
INFO - 2025-05-02 11:22:56 --> Loader Class Initialized
INFO - 2025-05-02 11:22:56 --> Helper loaded: form_helper
INFO - 2025-05-02 11:22:56 --> Helper loaded: url_helper
INFO - 2025-05-02 11:22:56 --> Database Driver Class Initialized
INFO - 2025-05-02 11:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:22:56 --> Form Validation Class Initialized
INFO - 2025-05-02 11:22:56 --> Controller Class Initialized
INFO - 2025-05-02 11:22:56 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:22:56 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:22:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:22:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-02 11:22:56 --> Final output sent to browser
DEBUG - 2025-05-02 11:22:56 --> Total execution time: 0.0415
INFO - 2025-05-02 11:22:59 --> Config Class Initialized
INFO - 2025-05-02 11:22:59 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:22:59 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:22:59 --> Utf8 Class Initialized
INFO - 2025-05-02 11:22:59 --> URI Class Initialized
INFO - 2025-05-02 11:22:59 --> Router Class Initialized
INFO - 2025-05-02 11:22:59 --> Output Class Initialized
INFO - 2025-05-02 11:22:59 --> Security Class Initialized
DEBUG - 2025-05-02 11:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:22:59 --> Input Class Initialized
INFO - 2025-05-02 11:22:59 --> Language Class Initialized
INFO - 2025-05-02 11:22:59 --> Loader Class Initialized
INFO - 2025-05-02 11:22:59 --> Helper loaded: form_helper
INFO - 2025-05-02 11:22:59 --> Helper loaded: url_helper
INFO - 2025-05-02 11:22:59 --> Database Driver Class Initialized
INFO - 2025-05-02 11:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:22:59 --> Form Validation Class Initialized
INFO - 2025-05-02 11:22:59 --> Controller Class Initialized
INFO - 2025-05-02 11:22:59 --> Config Class Initialized
INFO - 2025-05-02 11:22:59 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:22:59 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:22:59 --> Utf8 Class Initialized
INFO - 2025-05-02 11:22:59 --> URI Class Initialized
INFO - 2025-05-02 11:22:59 --> Router Class Initialized
INFO - 2025-05-02 11:22:59 --> Output Class Initialized
INFO - 2025-05-02 11:22:59 --> Security Class Initialized
DEBUG - 2025-05-02 11:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:22:59 --> Input Class Initialized
INFO - 2025-05-02 11:22:59 --> Language Class Initialized
INFO - 2025-05-02 11:22:59 --> Loader Class Initialized
INFO - 2025-05-02 11:22:59 --> Helper loaded: form_helper
INFO - 2025-05-02 11:22:59 --> Helper loaded: url_helper
INFO - 2025-05-02 11:22:59 --> Database Driver Class Initialized
INFO - 2025-05-02 11:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:22:59 --> Form Validation Class Initialized
INFO - 2025-05-02 11:22:59 --> Controller Class Initialized
INFO - 2025-05-02 11:22:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-02 11:22:59 --> Final output sent to browser
DEBUG - 2025-05-02 11:22:59 --> Total execution time: 0.0325
INFO - 2025-05-02 11:23:01 --> Config Class Initialized
INFO - 2025-05-02 11:23:01 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:01 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:01 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:01 --> URI Class Initialized
INFO - 2025-05-02 11:23:01 --> Router Class Initialized
INFO - 2025-05-02 11:23:01 --> Output Class Initialized
INFO - 2025-05-02 11:23:01 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:01 --> Input Class Initialized
INFO - 2025-05-02 11:23:01 --> Language Class Initialized
INFO - 2025-05-02 11:23:01 --> Loader Class Initialized
INFO - 2025-05-02 11:23:01 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:01 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:01 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:01 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:01 --> Controller Class Initialized
INFO - 2025-05-02 11:23:01 --> Config Class Initialized
INFO - 2025-05-02 11:23:01 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:01 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:01 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:01 --> URI Class Initialized
INFO - 2025-05-02 11:23:01 --> Router Class Initialized
INFO - 2025-05-02 11:23:01 --> Output Class Initialized
INFO - 2025-05-02 11:23:01 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:01 --> Input Class Initialized
INFO - 2025-05-02 11:23:01 --> Language Class Initialized
INFO - 2025-05-02 11:23:01 --> Loader Class Initialized
INFO - 2025-05-02 11:23:01 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:01 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:01 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:01 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:01 --> Controller Class Initialized
INFO - 2025-05-02 11:23:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:01 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:23:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-02 11:23:01 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:01 --> Total execution time: 0.0368
INFO - 2025-05-02 11:23:03 --> Config Class Initialized
INFO - 2025-05-02 11:23:03 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:03 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:03 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:03 --> URI Class Initialized
INFO - 2025-05-02 11:23:03 --> Router Class Initialized
INFO - 2025-05-02 11:23:03 --> Output Class Initialized
INFO - 2025-05-02 11:23:03 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:03 --> Input Class Initialized
INFO - 2025-05-02 11:23:03 --> Language Class Initialized
INFO - 2025-05-02 11:23:03 --> Loader Class Initialized
INFO - 2025-05-02 11:23:03 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:03 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:03 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:03 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:03 --> Controller Class Initialized
INFO - 2025-05-02 11:23:03 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:03 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:23:03 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-02 11:23:03 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:03 --> Total execution time: 0.0360
INFO - 2025-05-02 11:23:04 --> Config Class Initialized
INFO - 2025-05-02 11:23:04 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:04 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:04 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:04 --> URI Class Initialized
INFO - 2025-05-02 11:23:04 --> Router Class Initialized
INFO - 2025-05-02 11:23:04 --> Output Class Initialized
INFO - 2025-05-02 11:23:04 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:04 --> Input Class Initialized
INFO - 2025-05-02 11:23:04 --> Language Class Initialized
INFO - 2025-05-02 11:23:04 --> Loader Class Initialized
INFO - 2025-05-02 11:23:04 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:04 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:04 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:04 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:04 --> Controller Class Initialized
INFO - 2025-05-02 11:23:05 --> Config Class Initialized
INFO - 2025-05-02 11:23:05 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:05 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:05 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:05 --> URI Class Initialized
INFO - 2025-05-02 11:23:05 --> Router Class Initialized
INFO - 2025-05-02 11:23:05 --> Output Class Initialized
INFO - 2025-05-02 11:23:05 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:05 --> Input Class Initialized
INFO - 2025-05-02 11:23:05 --> Language Class Initialized
INFO - 2025-05-02 11:23:05 --> Loader Class Initialized
INFO - 2025-05-02 11:23:05 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:05 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:05 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:05 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:05 --> Controller Class Initialized
INFO - 2025-05-02 11:23:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-02 11:23:05 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:05 --> Total execution time: 0.0333
INFO - 2025-05-02 11:23:09 --> Config Class Initialized
INFO - 2025-05-02 11:23:09 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:09 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:09 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:09 --> URI Class Initialized
INFO - 2025-05-02 11:23:09 --> Router Class Initialized
INFO - 2025-05-02 11:23:09 --> Output Class Initialized
INFO - 2025-05-02 11:23:09 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:09 --> Input Class Initialized
INFO - 2025-05-02 11:23:09 --> Language Class Initialized
INFO - 2025-05-02 11:23:09 --> Loader Class Initialized
INFO - 2025-05-02 11:23:09 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:09 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:09 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:09 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:09 --> Controller Class Initialized
INFO - 2025-05-02 11:23:10 --> Config Class Initialized
INFO - 2025-05-02 11:23:10 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:10 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:10 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:10 --> URI Class Initialized
INFO - 2025-05-02 11:23:10 --> Router Class Initialized
INFO - 2025-05-02 11:23:10 --> Output Class Initialized
INFO - 2025-05-02 11:23:10 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:10 --> Input Class Initialized
INFO - 2025-05-02 11:23:10 --> Language Class Initialized
INFO - 2025-05-02 11:23:10 --> Loader Class Initialized
INFO - 2025-05-02 11:23:10 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:10 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:10 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:10 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:10 --> Controller Class Initialized
INFO - 2025-05-02 11:23:10 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:10 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:23:10 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-02 11:23:10 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:10 --> Total execution time: 0.0329
INFO - 2025-05-02 11:23:13 --> Config Class Initialized
INFO - 2025-05-02 11:23:13 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:13 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:13 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:13 --> URI Class Initialized
INFO - 2025-05-02 11:23:13 --> Router Class Initialized
INFO - 2025-05-02 11:23:13 --> Output Class Initialized
INFO - 2025-05-02 11:23:13 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:13 --> Input Class Initialized
INFO - 2025-05-02 11:23:13 --> Language Class Initialized
INFO - 2025-05-02 11:23:13 --> Loader Class Initialized
INFO - 2025-05-02 11:23:13 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:13 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:13 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:13 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:13 --> Controller Class Initialized
INFO - 2025-05-02 11:23:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:23:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 11:23:13 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:13 --> Total execution time: 0.0367
INFO - 2025-05-02 11:23:14 --> Config Class Initialized
INFO - 2025-05-02 11:23:14 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:14 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:14 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:14 --> URI Class Initialized
INFO - 2025-05-02 11:23:14 --> Router Class Initialized
INFO - 2025-05-02 11:23:14 --> Output Class Initialized
INFO - 2025-05-02 11:23:14 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:14 --> Input Class Initialized
INFO - 2025-05-02 11:23:14 --> Language Class Initialized
INFO - 2025-05-02 11:23:14 --> Loader Class Initialized
INFO - 2025-05-02 11:23:14 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:14 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:15 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:15 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:15 --> Controller Class Initialized
INFO - 2025-05-02 11:23:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:15 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-02 11:23:15 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:15 --> Total execution time: 0.0346
INFO - 2025-05-02 11:23:24 --> Config Class Initialized
INFO - 2025-05-02 11:23:24 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:24 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:24 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:24 --> URI Class Initialized
INFO - 2025-05-02 11:23:24 --> Router Class Initialized
INFO - 2025-05-02 11:23:24 --> Output Class Initialized
INFO - 2025-05-02 11:23:24 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:24 --> Input Class Initialized
INFO - 2025-05-02 11:23:24 --> Language Class Initialized
INFO - 2025-05-02 11:23:24 --> Loader Class Initialized
INFO - 2025-05-02 11:23:24 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:24 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:24 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:24 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:24 --> Controller Class Initialized
INFO - 2025-05-02 11:23:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:23:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-02 11:23:24 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:24 --> Total execution time: 0.0337
INFO - 2025-05-02 11:23:25 --> Config Class Initialized
INFO - 2025-05-02 11:23:25 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:25 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:25 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:25 --> URI Class Initialized
INFO - 2025-05-02 11:23:25 --> Router Class Initialized
INFO - 2025-05-02 11:23:25 --> Output Class Initialized
INFO - 2025-05-02 11:23:25 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:25 --> Input Class Initialized
INFO - 2025-05-02 11:23:25 --> Language Class Initialized
INFO - 2025-05-02 11:23:25 --> Loader Class Initialized
INFO - 2025-05-02 11:23:25 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:25 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:25 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:25 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:25 --> Controller Class Initialized
INFO - 2025-05-02 11:23:25 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:25 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:25 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-02 11:23:25 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:25 --> Total execution time: 0.0400
INFO - 2025-05-02 11:23:44 --> Config Class Initialized
INFO - 2025-05-02 11:23:44 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:44 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:44 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:44 --> URI Class Initialized
INFO - 2025-05-02 11:23:44 --> Router Class Initialized
INFO - 2025-05-02 11:23:44 --> Output Class Initialized
INFO - 2025-05-02 11:23:44 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:44 --> Input Class Initialized
INFO - 2025-05-02 11:23:44 --> Language Class Initialized
INFO - 2025-05-02 11:23:44 --> Loader Class Initialized
INFO - 2025-05-02 11:23:44 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:44 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:44 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:44 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:44 --> Controller Class Initialized
INFO - 2025-05-02 11:23:44 --> Config Class Initialized
INFO - 2025-05-02 11:23:44 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:44 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:44 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:44 --> URI Class Initialized
INFO - 2025-05-02 11:23:44 --> Router Class Initialized
INFO - 2025-05-02 11:23:44 --> Output Class Initialized
INFO - 2025-05-02 11:23:44 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:44 --> Input Class Initialized
INFO - 2025-05-02 11:23:44 --> Language Class Initialized
INFO - 2025-05-02 11:23:44 --> Loader Class Initialized
INFO - 2025-05-02 11:23:44 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:44 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:44 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:44 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:44 --> Controller Class Initialized
INFO - 2025-05-02 11:23:44 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-02 11:23:44 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:44 --> Total execution time: 0.0303
INFO - 2025-05-02 11:23:46 --> Config Class Initialized
INFO - 2025-05-02 11:23:46 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:46 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:46 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:46 --> URI Class Initialized
INFO - 2025-05-02 11:23:46 --> Router Class Initialized
INFO - 2025-05-02 11:23:46 --> Output Class Initialized
INFO - 2025-05-02 11:23:46 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:46 --> Input Class Initialized
INFO - 2025-05-02 11:23:46 --> Language Class Initialized
INFO - 2025-05-02 11:23:46 --> Loader Class Initialized
INFO - 2025-05-02 11:23:46 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:46 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:46 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:46 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:46 --> Controller Class Initialized
INFO - 2025-05-02 11:23:46 --> Config Class Initialized
INFO - 2025-05-02 11:23:46 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:46 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:46 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:46 --> URI Class Initialized
INFO - 2025-05-02 11:23:46 --> Router Class Initialized
INFO - 2025-05-02 11:23:46 --> Output Class Initialized
INFO - 2025-05-02 11:23:46 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:46 --> Input Class Initialized
INFO - 2025-05-02 11:23:46 --> Language Class Initialized
INFO - 2025-05-02 11:23:46 --> Loader Class Initialized
INFO - 2025-05-02 11:23:46 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:46 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:46 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:46 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:46 --> Controller Class Initialized
INFO - 2025-05-02 11:23:46 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:46 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:23:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-02 11:23:46 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:46 --> Total execution time: 0.0358
INFO - 2025-05-02 11:23:50 --> Config Class Initialized
INFO - 2025-05-02 11:23:50 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:50 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:50 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:50 --> URI Class Initialized
INFO - 2025-05-02 11:23:50 --> Router Class Initialized
INFO - 2025-05-02 11:23:50 --> Output Class Initialized
INFO - 2025-05-02 11:23:50 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:50 --> Input Class Initialized
INFO - 2025-05-02 11:23:50 --> Language Class Initialized
INFO - 2025-05-02 11:23:50 --> Loader Class Initialized
INFO - 2025-05-02 11:23:50 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:50 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:50 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:50 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:50 --> Controller Class Initialized
INFO - 2025-05-02 11:23:50 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:50 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:50 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/tambah_petugas.php
INFO - 2025-05-02 11:23:50 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:50 --> Total execution time: 0.0321
INFO - 2025-05-02 11:23:58 --> Config Class Initialized
INFO - 2025-05-02 11:23:58 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:23:58 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:23:58 --> Utf8 Class Initialized
INFO - 2025-05-02 11:23:58 --> URI Class Initialized
INFO - 2025-05-02 11:23:58 --> Router Class Initialized
INFO - 2025-05-02 11:23:58 --> Output Class Initialized
INFO - 2025-05-02 11:23:58 --> Security Class Initialized
DEBUG - 2025-05-02 11:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:23:58 --> Input Class Initialized
INFO - 2025-05-02 11:23:58 --> Language Class Initialized
INFO - 2025-05-02 11:23:58 --> Loader Class Initialized
INFO - 2025-05-02 11:23:58 --> Helper loaded: form_helper
INFO - 2025-05-02 11:23:58 --> Helper loaded: url_helper
INFO - 2025-05-02 11:23:58 --> Database Driver Class Initialized
INFO - 2025-05-02 11:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:23:58 --> Form Validation Class Initialized
INFO - 2025-05-02 11:23:58 --> Controller Class Initialized
INFO - 2025-05-02 11:23:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:23:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:23:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:23:58 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-02 11:23:58 --> Final output sent to browser
DEBUG - 2025-05-02 11:23:58 --> Total execution time: 0.0382
INFO - 2025-05-02 11:24:01 --> Config Class Initialized
INFO - 2025-05-02 11:24:01 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:24:01 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:24:01 --> Utf8 Class Initialized
INFO - 2025-05-02 11:24:01 --> URI Class Initialized
INFO - 2025-05-02 11:24:01 --> Router Class Initialized
INFO - 2025-05-02 11:24:01 --> Output Class Initialized
INFO - 2025-05-02 11:24:01 --> Security Class Initialized
DEBUG - 2025-05-02 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:24:01 --> Input Class Initialized
INFO - 2025-05-02 11:24:01 --> Language Class Initialized
INFO - 2025-05-02 11:24:01 --> Loader Class Initialized
INFO - 2025-05-02 11:24:01 --> Helper loaded: form_helper
INFO - 2025-05-02 11:24:01 --> Helper loaded: url_helper
INFO - 2025-05-02 11:24:01 --> Database Driver Class Initialized
INFO - 2025-05-02 11:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:24:01 --> Form Validation Class Initialized
INFO - 2025-05-02 11:24:01 --> Controller Class Initialized
INFO - 2025-05-02 11:24:01 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:24:01 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:24:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:24:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 11:24:01 --> Final output sent to browser
DEBUG - 2025-05-02 11:24:01 --> Total execution time: 0.0413
INFO - 2025-05-02 11:24:11 --> Config Class Initialized
INFO - 2025-05-02 11:24:11 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:24:11 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:24:11 --> Utf8 Class Initialized
INFO - 2025-05-02 11:24:11 --> URI Class Initialized
INFO - 2025-05-02 11:24:11 --> Router Class Initialized
INFO - 2025-05-02 11:24:11 --> Output Class Initialized
INFO - 2025-05-02 11:24:11 --> Security Class Initialized
DEBUG - 2025-05-02 11:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:24:11 --> Input Class Initialized
INFO - 2025-05-02 11:24:11 --> Language Class Initialized
INFO - 2025-05-02 11:24:11 --> Loader Class Initialized
INFO - 2025-05-02 11:24:11 --> Helper loaded: form_helper
INFO - 2025-05-02 11:24:11 --> Helper loaded: url_helper
INFO - 2025-05-02 11:24:11 --> Database Driver Class Initialized
INFO - 2025-05-02 11:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:24:11 --> Form Validation Class Initialized
INFO - 2025-05-02 11:24:11 --> Controller Class Initialized
INFO - 2025-05-02 11:24:11 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:24:11 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:24:11 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:24:11 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-02 11:24:11 --> Final output sent to browser
DEBUG - 2025-05-02 11:24:11 --> Total execution time: 0.0327
INFO - 2025-05-02 11:24:13 --> Config Class Initialized
INFO - 2025-05-02 11:24:13 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:24:13 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:24:13 --> Utf8 Class Initialized
INFO - 2025-05-02 11:24:13 --> URI Class Initialized
INFO - 2025-05-02 11:24:13 --> Router Class Initialized
INFO - 2025-05-02 11:24:13 --> Output Class Initialized
INFO - 2025-05-02 11:24:13 --> Security Class Initialized
DEBUG - 2025-05-02 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:24:13 --> Input Class Initialized
INFO - 2025-05-02 11:24:13 --> Language Class Initialized
INFO - 2025-05-02 11:24:13 --> Loader Class Initialized
INFO - 2025-05-02 11:24:13 --> Helper loaded: form_helper
INFO - 2025-05-02 11:24:13 --> Helper loaded: url_helper
INFO - 2025-05-02 11:24:13 --> Database Driver Class Initialized
INFO - 2025-05-02 11:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:24:13 --> Form Validation Class Initialized
INFO - 2025-05-02 11:24:13 --> Controller Class Initialized
INFO - 2025-05-02 11:24:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:24:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:24:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:24:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-02 11:24:13 --> Final output sent to browser
DEBUG - 2025-05-02 11:24:13 --> Total execution time: 0.0438
INFO - 2025-05-02 11:24:22 --> Config Class Initialized
INFO - 2025-05-02 11:24:22 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:24:22 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:24:22 --> Utf8 Class Initialized
INFO - 2025-05-02 11:24:22 --> URI Class Initialized
INFO - 2025-05-02 11:24:22 --> Router Class Initialized
INFO - 2025-05-02 11:24:22 --> Output Class Initialized
INFO - 2025-05-02 11:24:22 --> Security Class Initialized
DEBUG - 2025-05-02 11:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:24:22 --> Input Class Initialized
INFO - 2025-05-02 11:24:22 --> Language Class Initialized
INFO - 2025-05-02 11:24:22 --> Loader Class Initialized
INFO - 2025-05-02 11:24:22 --> Helper loaded: form_helper
INFO - 2025-05-02 11:24:22 --> Helper loaded: url_helper
INFO - 2025-05-02 11:24:22 --> Database Driver Class Initialized
INFO - 2025-05-02 11:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:24:22 --> Form Validation Class Initialized
INFO - 2025-05-02 11:24:22 --> Controller Class Initialized
INFO - 2025-05-02 11:24:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:24:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:24:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:24:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-02 11:24:22 --> Final output sent to browser
DEBUG - 2025-05-02 11:24:22 --> Total execution time: 0.0450
INFO - 2025-05-02 11:24:47 --> Config Class Initialized
INFO - 2025-05-02 11:24:47 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:24:47 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:24:47 --> Utf8 Class Initialized
INFO - 2025-05-02 11:24:47 --> URI Class Initialized
INFO - 2025-05-02 11:24:47 --> Router Class Initialized
INFO - 2025-05-02 11:24:47 --> Output Class Initialized
INFO - 2025-05-02 11:24:47 --> Security Class Initialized
DEBUG - 2025-05-02 11:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:24:47 --> Input Class Initialized
INFO - 2025-05-02 11:24:47 --> Language Class Initialized
INFO - 2025-05-02 11:24:47 --> Loader Class Initialized
INFO - 2025-05-02 11:24:47 --> Helper loaded: form_helper
INFO - 2025-05-02 11:24:47 --> Helper loaded: url_helper
INFO - 2025-05-02 11:24:47 --> Database Driver Class Initialized
INFO - 2025-05-02 11:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:24:47 --> Form Validation Class Initialized
INFO - 2025-05-02 11:24:47 --> Controller Class Initialized
INFO - 2025-05-02 11:24:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 11:24:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 11:24:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 11:24:47 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_rekomendasi.php
INFO - 2025-05-02 11:24:47 --> Final output sent to browser
DEBUG - 2025-05-02 11:24:47 --> Total execution time: 0.0378
INFO - 2025-05-02 11:54:03 --> Config Class Initialized
INFO - 2025-05-02 11:54:03 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:03 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:03 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:03 --> URI Class Initialized
DEBUG - 2025-05-02 11:54:03 --> No URI present. Default controller set.
INFO - 2025-05-02 11:54:03 --> Router Class Initialized
INFO - 2025-05-02 11:54:03 --> Output Class Initialized
INFO - 2025-05-02 11:54:03 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:03 --> Input Class Initialized
INFO - 2025-05-02 11:54:03 --> Language Class Initialized
INFO - 2025-05-02 11:54:03 --> Loader Class Initialized
INFO - 2025-05-02 11:54:03 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:03 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:03 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:03 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:03 --> Controller Class Initialized
INFO - 2025-05-02 11:54:03 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:03 --> Total execution time: 0.0294
INFO - 2025-05-02 11:54:08 --> Config Class Initialized
INFO - 2025-05-02 11:54:08 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:08 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:08 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:08 --> URI Class Initialized
DEBUG - 2025-05-02 11:54:08 --> No URI present. Default controller set.
INFO - 2025-05-02 11:54:08 --> Router Class Initialized
INFO - 2025-05-02 11:54:08 --> Output Class Initialized
INFO - 2025-05-02 11:54:08 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:08 --> Input Class Initialized
INFO - 2025-05-02 11:54:08 --> Language Class Initialized
INFO - 2025-05-02 11:54:08 --> Loader Class Initialized
INFO - 2025-05-02 11:54:08 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:08 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:08 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:08 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:08 --> Controller Class Initialized
INFO - 2025-05-02 11:54:08 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:08 --> Total execution time: 0.0296
INFO - 2025-05-02 11:54:14 --> Config Class Initialized
INFO - 2025-05-02 11:54:14 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:14 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:14 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:14 --> URI Class Initialized
DEBUG - 2025-05-02 11:54:14 --> No URI present. Default controller set.
INFO - 2025-05-02 11:54:14 --> Router Class Initialized
INFO - 2025-05-02 11:54:14 --> Output Class Initialized
INFO - 2025-05-02 11:54:14 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:14 --> Input Class Initialized
INFO - 2025-05-02 11:54:14 --> Language Class Initialized
INFO - 2025-05-02 11:54:14 --> Loader Class Initialized
INFO - 2025-05-02 11:54:14 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:14 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:14 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:14 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:14 --> Controller Class Initialized
INFO - 2025-05-02 11:54:14 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:14 --> Total execution time: 0.0309
INFO - 2025-05-02 11:54:21 --> Config Class Initialized
INFO - 2025-05-02 11:54:21 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:21 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:21 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:21 --> URI Class Initialized
DEBUG - 2025-05-02 11:54:21 --> No URI present. Default controller set.
INFO - 2025-05-02 11:54:21 --> Router Class Initialized
INFO - 2025-05-02 11:54:21 --> Output Class Initialized
INFO - 2025-05-02 11:54:21 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:21 --> Input Class Initialized
INFO - 2025-05-02 11:54:21 --> Language Class Initialized
INFO - 2025-05-02 11:54:21 --> Loader Class Initialized
INFO - 2025-05-02 11:54:21 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:21 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:21 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:21 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:21 --> Controller Class Initialized
INFO - 2025-05-02 11:54:21 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:21 --> Total execution time: 0.0294
INFO - 2025-05-02 11:54:24 --> Config Class Initialized
INFO - 2025-05-02 11:54:24 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:24 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:24 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:24 --> URI Class Initialized
INFO - 2025-05-02 11:54:24 --> Router Class Initialized
INFO - 2025-05-02 11:54:24 --> Output Class Initialized
INFO - 2025-05-02 11:54:24 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:24 --> Input Class Initialized
INFO - 2025-05-02 11:54:24 --> Language Class Initialized
INFO - 2025-05-02 11:54:24 --> Loader Class Initialized
INFO - 2025-05-02 11:54:24 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:24 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:24 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:24 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:24 --> Controller Class Initialized
INFO - 2025-05-02 11:54:24 --> Config Class Initialized
INFO - 2025-05-02 11:54:24 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:24 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:24 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:24 --> URI Class Initialized
INFO - 2025-05-02 11:54:24 --> Router Class Initialized
INFO - 2025-05-02 11:54:24 --> Output Class Initialized
INFO - 2025-05-02 11:54:24 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:24 --> Input Class Initialized
INFO - 2025-05-02 11:54:24 --> Language Class Initialized
INFO - 2025-05-02 11:54:24 --> Loader Class Initialized
INFO - 2025-05-02 11:54:24 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:24 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:24 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:24 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:24 --> Controller Class Initialized
INFO - 2025-05-02 11:54:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-02 11:54:24 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:24 --> Total execution time: 0.0355
INFO - 2025-05-02 11:54:25 --> Config Class Initialized
INFO - 2025-05-02 11:54:25 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:25 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:25 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:25 --> URI Class Initialized
INFO - 2025-05-02 11:54:25 --> Router Class Initialized
INFO - 2025-05-02 11:54:25 --> Output Class Initialized
INFO - 2025-05-02 11:54:25 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:25 --> Input Class Initialized
INFO - 2025-05-02 11:54:25 --> Language Class Initialized
ERROR - 2025-05-02 11:54:25 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 11:54:28 --> Config Class Initialized
INFO - 2025-05-02 11:54:28 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:28 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:28 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:28 --> URI Class Initialized
DEBUG - 2025-05-02 11:54:28 --> No URI present. Default controller set.
INFO - 2025-05-02 11:54:28 --> Router Class Initialized
INFO - 2025-05-02 11:54:28 --> Output Class Initialized
INFO - 2025-05-02 11:54:28 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:28 --> Input Class Initialized
INFO - 2025-05-02 11:54:28 --> Language Class Initialized
INFO - 2025-05-02 11:54:28 --> Loader Class Initialized
INFO - 2025-05-02 11:54:28 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:28 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:28 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:28 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:28 --> Controller Class Initialized
INFO - 2025-05-02 11:54:28 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:28 --> Total execution time: 0.0277
INFO - 2025-05-02 11:54:38 --> Config Class Initialized
INFO - 2025-05-02 11:54:38 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:38 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:38 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:38 --> URI Class Initialized
DEBUG - 2025-05-02 11:54:38 --> No URI present. Default controller set.
INFO - 2025-05-02 11:54:38 --> Router Class Initialized
INFO - 2025-05-02 11:54:38 --> Output Class Initialized
INFO - 2025-05-02 11:54:38 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:38 --> Input Class Initialized
INFO - 2025-05-02 11:54:38 --> Language Class Initialized
INFO - 2025-05-02 11:54:38 --> Loader Class Initialized
INFO - 2025-05-02 11:54:38 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:38 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:38 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:38 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:38 --> Controller Class Initialized
INFO - 2025-05-02 11:54:38 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:38 --> Total execution time: 0.0353
INFO - 2025-05-02 11:54:45 --> Config Class Initialized
INFO - 2025-05-02 11:54:45 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:45 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:45 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:45 --> URI Class Initialized
INFO - 2025-05-02 11:54:45 --> Router Class Initialized
INFO - 2025-05-02 11:54:45 --> Output Class Initialized
INFO - 2025-05-02 11:54:45 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:45 --> Input Class Initialized
INFO - 2025-05-02 11:54:45 --> Language Class Initialized
INFO - 2025-05-02 11:54:45 --> Loader Class Initialized
INFO - 2025-05-02 11:54:45 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:45 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:45 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:45 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:45 --> Controller Class Initialized
DEBUG - 2025-05-02 11:54:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 11:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 11:54:45 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 11:54:45 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 11:54:45 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:45 --> Total execution time: 0.0350
INFO - 2025-05-02 11:54:45 --> Config Class Initialized
INFO - 2025-05-02 11:54:45 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:46 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:46 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:46 --> URI Class Initialized
INFO - 2025-05-02 11:54:46 --> Router Class Initialized
INFO - 2025-05-02 11:54:46 --> Output Class Initialized
INFO - 2025-05-02 11:54:46 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:46 --> Input Class Initialized
INFO - 2025-05-02 11:54:46 --> Language Class Initialized
INFO - 2025-05-02 11:54:46 --> Loader Class Initialized
INFO - 2025-05-02 11:54:46 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:46 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:46 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:46 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:46 --> Controller Class Initialized
DEBUG - 2025-05-02 11:54:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 11:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 11:54:46 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 11:54:46 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 11:54:46 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:46 --> Total execution time: 0.0310
INFO - 2025-05-02 11:54:50 --> Config Class Initialized
INFO - 2025-05-02 11:54:50 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:54:50 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:54:50 --> Utf8 Class Initialized
INFO - 2025-05-02 11:54:50 --> URI Class Initialized
INFO - 2025-05-02 11:54:50 --> Router Class Initialized
INFO - 2025-05-02 11:54:50 --> Output Class Initialized
INFO - 2025-05-02 11:54:50 --> Security Class Initialized
DEBUG - 2025-05-02 11:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:54:50 --> Input Class Initialized
INFO - 2025-05-02 11:54:50 --> Language Class Initialized
INFO - 2025-05-02 11:54:50 --> Loader Class Initialized
INFO - 2025-05-02 11:54:50 --> Helper loaded: form_helper
INFO - 2025-05-02 11:54:50 --> Helper loaded: url_helper
INFO - 2025-05-02 11:54:50 --> Database Driver Class Initialized
INFO - 2025-05-02 11:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:54:50 --> Form Validation Class Initialized
INFO - 2025-05-02 11:54:50 --> Controller Class Initialized
DEBUG - 2025-05-02 11:54:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 11:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 11:54:50 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 11:54:50 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 11:54:50 --> Final output sent to browser
DEBUG - 2025-05-02 11:54:50 --> Total execution time: 0.0322
INFO - 2025-05-02 11:55:10 --> Config Class Initialized
INFO - 2025-05-02 11:55:10 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:55:11 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:55:11 --> Utf8 Class Initialized
INFO - 2025-05-02 11:55:11 --> URI Class Initialized
INFO - 2025-05-02 11:55:11 --> Router Class Initialized
INFO - 2025-05-02 11:55:11 --> Output Class Initialized
INFO - 2025-05-02 11:55:11 --> Security Class Initialized
DEBUG - 2025-05-02 11:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:55:11 --> Input Class Initialized
INFO - 2025-05-02 11:55:11 --> Language Class Initialized
ERROR - 2025-05-02 11:55:11 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 11:55:59 --> Config Class Initialized
INFO - 2025-05-02 11:55:59 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:55:59 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:55:59 --> Utf8 Class Initialized
INFO - 2025-05-02 11:55:59 --> URI Class Initialized
INFO - 2025-05-02 11:55:59 --> Router Class Initialized
INFO - 2025-05-02 11:55:59 --> Output Class Initialized
INFO - 2025-05-02 11:55:59 --> Security Class Initialized
DEBUG - 2025-05-02 11:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:55:59 --> Input Class Initialized
INFO - 2025-05-02 11:55:59 --> Language Class Initialized
INFO - 2025-05-02 11:55:59 --> Loader Class Initialized
INFO - 2025-05-02 11:55:59 --> Helper loaded: form_helper
INFO - 2025-05-02 11:55:59 --> Helper loaded: url_helper
INFO - 2025-05-02 11:55:59 --> Database Driver Class Initialized
INFO - 2025-05-02 11:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 11:55:59 --> Form Validation Class Initialized
INFO - 2025-05-02 11:55:59 --> Controller Class Initialized
DEBUG - 2025-05-02 11:55:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 11:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 11:55:59 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 11:55:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 11:55:59 --> Final output sent to browser
DEBUG - 2025-05-02 11:55:59 --> Total execution time: 0.0359
INFO - 2025-05-02 11:56:10 --> Config Class Initialized
INFO - 2025-05-02 11:56:10 --> Hooks Class Initialized
DEBUG - 2025-05-02 11:56:10 --> UTF-8 Support Enabled
INFO - 2025-05-02 11:56:10 --> Utf8 Class Initialized
INFO - 2025-05-02 11:56:10 --> URI Class Initialized
INFO - 2025-05-02 11:56:10 --> Router Class Initialized
INFO - 2025-05-02 11:56:10 --> Output Class Initialized
INFO - 2025-05-02 11:56:10 --> Security Class Initialized
DEBUG - 2025-05-02 11:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 11:56:10 --> Input Class Initialized
INFO - 2025-05-02 11:56:10 --> Language Class Initialized
ERROR - 2025-05-02 11:56:10 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 12:12:13 --> Config Class Initialized
INFO - 2025-05-02 12:12:13 --> Hooks Class Initialized
DEBUG - 2025-05-02 12:12:13 --> UTF-8 Support Enabled
INFO - 2025-05-02 12:12:13 --> Utf8 Class Initialized
INFO - 2025-05-02 12:12:13 --> URI Class Initialized
INFO - 2025-05-02 12:12:13 --> Router Class Initialized
INFO - 2025-05-02 12:12:13 --> Output Class Initialized
INFO - 2025-05-02 12:12:13 --> Security Class Initialized
DEBUG - 2025-05-02 12:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 12:12:13 --> Input Class Initialized
INFO - 2025-05-02 12:12:13 --> Language Class Initialized
INFO - 2025-05-02 12:12:13 --> Loader Class Initialized
INFO - 2025-05-02 12:12:13 --> Helper loaded: form_helper
INFO - 2025-05-02 12:12:13 --> Helper loaded: url_helper
INFO - 2025-05-02 12:12:13 --> Database Driver Class Initialized
INFO - 2025-05-02 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 12:12:13 --> Form Validation Class Initialized
INFO - 2025-05-02 12:12:13 --> Controller Class Initialized
INFO - 2025-05-02 12:12:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 12:12:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 12:12:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 12:12:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_rekomendasi.php
INFO - 2025-05-02 12:12:13 --> Final output sent to browser
DEBUG - 2025-05-02 12:12:13 --> Total execution time: 0.0322
INFO - 2025-05-02 12:12:14 --> Config Class Initialized
INFO - 2025-05-02 12:12:14 --> Hooks Class Initialized
DEBUG - 2025-05-02 12:12:14 --> UTF-8 Support Enabled
INFO - 2025-05-02 12:12:14 --> Utf8 Class Initialized
INFO - 2025-05-02 12:12:14 --> URI Class Initialized
INFO - 2025-05-02 12:12:14 --> Router Class Initialized
INFO - 2025-05-02 12:12:14 --> Output Class Initialized
INFO - 2025-05-02 12:12:14 --> Security Class Initialized
DEBUG - 2025-05-02 12:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 12:12:14 --> Input Class Initialized
INFO - 2025-05-02 12:12:14 --> Language Class Initialized
ERROR - 2025-05-02 12:12:14 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 12:24:38 --> Config Class Initialized
INFO - 2025-05-02 12:24:38 --> Hooks Class Initialized
DEBUG - 2025-05-02 12:24:38 --> UTF-8 Support Enabled
INFO - 2025-05-02 12:24:38 --> Utf8 Class Initialized
INFO - 2025-05-02 12:24:38 --> URI Class Initialized
INFO - 2025-05-02 12:24:38 --> Router Class Initialized
INFO - 2025-05-02 12:24:38 --> Output Class Initialized
INFO - 2025-05-02 12:24:38 --> Security Class Initialized
DEBUG - 2025-05-02 12:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 12:24:38 --> Input Class Initialized
INFO - 2025-05-02 12:24:38 --> Language Class Initialized
INFO - 2025-05-02 12:24:38 --> Loader Class Initialized
INFO - 2025-05-02 12:24:38 --> Helper loaded: form_helper
INFO - 2025-05-02 12:24:39 --> Helper loaded: url_helper
INFO - 2025-05-02 12:24:39 --> Database Driver Class Initialized
INFO - 2025-05-02 12:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 12:24:39 --> Form Validation Class Initialized
INFO - 2025-05-02 12:24:39 --> Controller Class Initialized
INFO - 2025-05-02 12:24:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 12:24:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 12:24:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 12:24:39 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_rekomendasi.php
INFO - 2025-05-02 12:24:39 --> Final output sent to browser
DEBUG - 2025-05-02 12:24:39 --> Total execution time: 0.0365
INFO - 2025-05-02 14:06:36 --> Config Class Initialized
INFO - 2025-05-02 14:06:36 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:06:36 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:06:36 --> Utf8 Class Initialized
INFO - 2025-05-02 14:06:36 --> URI Class Initialized
DEBUG - 2025-05-02 14:06:36 --> No URI present. Default controller set.
INFO - 2025-05-02 14:06:36 --> Router Class Initialized
INFO - 2025-05-02 14:06:36 --> Output Class Initialized
INFO - 2025-05-02 14:06:36 --> Security Class Initialized
DEBUG - 2025-05-02 14:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:06:36 --> Input Class Initialized
INFO - 2025-05-02 14:06:36 --> Language Class Initialized
INFO - 2025-05-02 14:06:36 --> Loader Class Initialized
INFO - 2025-05-02 14:06:36 --> Helper loaded: form_helper
INFO - 2025-05-02 14:06:36 --> Helper loaded: url_helper
INFO - 2025-05-02 14:06:36 --> Database Driver Class Initialized
INFO - 2025-05-02 14:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:06:36 --> Form Validation Class Initialized
INFO - 2025-05-02 14:06:36 --> Controller Class Initialized
INFO - 2025-05-02 14:06:36 --> Final output sent to browser
DEBUG - 2025-05-02 14:06:36 --> Total execution time: 0.0395
INFO - 2025-05-02 14:24:01 --> Config Class Initialized
INFO - 2025-05-02 14:24:01 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:24:01 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:24:01 --> Utf8 Class Initialized
INFO - 2025-05-02 14:24:01 --> URI Class Initialized
INFO - 2025-05-02 14:24:01 --> Router Class Initialized
INFO - 2025-05-02 14:24:01 --> Output Class Initialized
INFO - 2025-05-02 14:24:01 --> Security Class Initialized
DEBUG - 2025-05-02 14:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:24:01 --> Input Class Initialized
INFO - 2025-05-02 14:24:01 --> Language Class Initialized
INFO - 2025-05-02 14:24:01 --> Loader Class Initialized
INFO - 2025-05-02 14:24:01 --> Helper loaded: form_helper
INFO - 2025-05-02 14:24:01 --> Helper loaded: url_helper
INFO - 2025-05-02 14:24:01 --> Database Driver Class Initialized
INFO - 2025-05-02 14:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:24:01 --> Form Validation Class Initialized
INFO - 2025-05-02 14:24:01 --> Controller Class Initialized
DEBUG - 2025-05-02 14:24:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 14:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 14:24:01 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 14:24:01 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 14:24:01 --> Final output sent to browser
DEBUG - 2025-05-02 14:24:01 --> Total execution time: 0.0390
INFO - 2025-05-02 14:24:02 --> Config Class Initialized
INFO - 2025-05-02 14:24:02 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:24:02 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:24:02 --> Utf8 Class Initialized
INFO - 2025-05-02 14:24:02 --> URI Class Initialized
INFO - 2025-05-02 14:24:02 --> Router Class Initialized
INFO - 2025-05-02 14:24:02 --> Output Class Initialized
INFO - 2025-05-02 14:24:02 --> Security Class Initialized
DEBUG - 2025-05-02 14:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:24:02 --> Input Class Initialized
INFO - 2025-05-02 14:24:02 --> Language Class Initialized
INFO - 2025-05-02 14:24:02 --> Loader Class Initialized
INFO - 2025-05-02 14:24:02 --> Helper loaded: form_helper
INFO - 2025-05-02 14:24:02 --> Helper loaded: url_helper
INFO - 2025-05-02 14:24:02 --> Database Driver Class Initialized
INFO - 2025-05-02 14:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:24:02 --> Form Validation Class Initialized
INFO - 2025-05-02 14:24:02 --> Controller Class Initialized
DEBUG - 2025-05-02 14:24:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 14:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 14:24:02 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 14:24:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 14:24:02 --> Final output sent to browser
DEBUG - 2025-05-02 14:24:02 --> Total execution time: 0.0333
INFO - 2025-05-02 14:24:04 --> Config Class Initialized
INFO - 2025-05-02 14:24:04 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:24:04 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:24:04 --> Utf8 Class Initialized
INFO - 2025-05-02 14:24:04 --> URI Class Initialized
INFO - 2025-05-02 14:24:04 --> Router Class Initialized
INFO - 2025-05-02 14:24:04 --> Output Class Initialized
INFO - 2025-05-02 14:24:04 --> Security Class Initialized
DEBUG - 2025-05-02 14:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:24:04 --> Input Class Initialized
INFO - 2025-05-02 14:24:04 --> Language Class Initialized
ERROR - 2025-05-02 14:24:04 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 14:33:02 --> Config Class Initialized
INFO - 2025-05-02 14:33:02 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:33:02 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:33:02 --> Utf8 Class Initialized
INFO - 2025-05-02 14:33:02 --> URI Class Initialized
INFO - 2025-05-02 14:33:02 --> Router Class Initialized
INFO - 2025-05-02 14:33:02 --> Output Class Initialized
INFO - 2025-05-02 14:33:02 --> Security Class Initialized
DEBUG - 2025-05-02 14:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:33:02 --> Input Class Initialized
INFO - 2025-05-02 14:33:02 --> Language Class Initialized
INFO - 2025-05-02 14:33:02 --> Loader Class Initialized
INFO - 2025-05-02 14:33:02 --> Helper loaded: form_helper
INFO - 2025-05-02 14:33:02 --> Helper loaded: url_helper
INFO - 2025-05-02 14:33:02 --> Database Driver Class Initialized
INFO - 2025-05-02 14:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:33:02 --> Form Validation Class Initialized
INFO - 2025-05-02 14:33:02 --> Controller Class Initialized
DEBUG - 2025-05-02 14:33:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 14:33:02 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 14:33:02 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-02 14:33:02 --> POST data: Array
(
    [nama_siswa] => maulida rahma aulia
    [jenis_kelamin] => P
    [tempat_lahir] => batang
    [tanggal_lahir] => 2010-03-13
    [tempat_tanggal_lahir] => batang, 13 Maret 2010
    [rekomendasi] => bapak mashfufi/refa
    [pilihan_program] => IPS
    [no_hp_siswa] => 085640516376
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => sentul
    [rt] => 05
    [rw] => 03
    [desa] => sentul
    [kecamatan] => gringsing
    [kabupaten] => batang
    [provinsi] => jawa tengah
    [alamat_lengkap] => sentul, RT 05/RW 03, sentul, gringsing, batang, jawa tengah
    [nama_ayah] => muh sarip
    [nama_ibu] => siti nadhomah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => buruh
    [pekerjaan_ibu] => ibu rumah tangga
    [no_hp_ayah] => 085640516376
    [no_hp_ibu] => 085640516376
    [alamat_ortu] => sentul gringsing batang
    [saudara_sekolah] => Tidak
    [nama_wali] => muh sarip
    [hubungan_wali] => anak kandung
    [pendidikan_wali] => SD/MI Sederajat
    [pekerjaan_wali] => buruh
    [no_hp_wali] => 085640516376
    [alamat_wali] => sentul gringsing batang
    [nama_sekolah] => mts nu 01 gringsing 
    [nisn] => 
    [alamat_sekolah] => gringsing jalan raya lama
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => ingin melanjutkan jenjang sma
    [tanggal_lahir_db] => 2010-03-13
)

INFO - 2025-05-02 14:33:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-02 14:33:02 --> Generated registration number: A-2526/0157
DEBUG - 2025-05-02 14:33:02 --> Form data to save: Array
(
    [nama_siswa] => maulida rahma aulia
    [jenis_kelamin] => P
    [tempat_lahir] => batang
    [tanggal_lahir] => 2010-03-13
    [no_hp_siswa] => 085640516376
    [rekomendasi] => bapak mashfufi/refa
    [pilihan_program] => IPS
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => sentul
    [rt] => 05
    [rw] => 03
    [desa] => sentul
    [kecamatan] => gringsing
    [kabupaten] => batang
    [provinsi] => jawa tengah
    [nama_ayah] => muh sarip
    [nama_ibu] => siti nadhomah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => buruh
    [pekerjaan_ibu] => ibu rumah tangga
    [no_hp_ayah] => 085640516376
    [no_hp_ibu] => 085640516376
    [alamat_ortu] => sentul gringsing batang
    [saudara_sekolah] => Tidak
    [nama_wali] => muh sarip
    [hubungan_wali] => anak kandung
    [pendidikan_wali] => SD/MI Sederajat
    [pekerjaan_wali] => buruh
    [no_hp_wali] => 085640516376
    [alamat_wali] => sentul gringsing batang
    [nama_sekolah] => mts nu 01 gringsing 
    [nisn] => 
    [alamat_sekolah] => gringsing jalan raya lama
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => ingin melanjutkan jenjang sma
    [tanggal_daftar] => 2025-05-02 14:33:02
    [status] => Baru
    [no_pendaftaran] => A-2526/0157
)

DEBUG - 2025-05-02 14:33:02 --> Attempting to save data to pendaftaran table
DEBUG - 2025-05-02 14:33:02 --> Data: Array
(
    [nama_siswa] => maulida rahma aulia
    [jenis_kelamin] => P
    [tempat_lahir] => batang
    [tanggal_lahir] => 2010-03-13
    [no_hp_siswa] => 085640516376
    [rekomendasi] => bapak mashfufi/refa
    [pilihan_program] => IPS
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => sentul
    [rt] => 05
    [rw] => 03
    [desa] => sentul
    [kecamatan] => gringsing
    [kabupaten] => batang
    [provinsi] => jawa tengah
    [nama_ayah] => muh sarip
    [nama_ibu] => siti nadhomah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => buruh
    [pekerjaan_ibu] => ibu rumah tangga
    [no_hp_ayah] => 085640516376
    [no_hp_ibu] => 085640516376
    [alamat_ortu] => sentul gringsing batang
    [saudara_sekolah] => Tidak
    [nama_wali] => muh sarip
    [hubungan_wali] => anak kandung
    [pendidikan_wali] => SD/MI Sederajat
    [pekerjaan_wali] => buruh
    [no_hp_wali] => 085640516376
    [alamat_wali] => sentul gringsing batang
    [nama_sekolah] => mts nu 01 gringsing 
    [nisn] => 
    [alamat_sekolah] => gringsing jalan raya lama
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => ingin melanjutkan jenjang sma
    [tanggal_daftar] => 2025-05-02 14:33:02
    [status] => Baru
    [no_pendaftaran] => A-2526/0157
)

DEBUG - 2025-05-02 14:33:02 --> Data inserted successfully with ID: 166
INFO - 2025-05-02 14:33:12 --> Config Class Initialized
INFO - 2025-05-02 14:33:12 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:33:12 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:33:12 --> Utf8 Class Initialized
INFO - 2025-05-02 14:33:12 --> URI Class Initialized
INFO - 2025-05-02 14:33:12 --> Router Class Initialized
INFO - 2025-05-02 14:33:12 --> Output Class Initialized
INFO - 2025-05-02 14:33:12 --> Security Class Initialized
DEBUG - 2025-05-02 14:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:33:12 --> Input Class Initialized
INFO - 2025-05-02 14:33:12 --> Language Class Initialized
INFO - 2025-05-02 14:33:12 --> Loader Class Initialized
INFO - 2025-05-02 14:33:12 --> Helper loaded: form_helper
INFO - 2025-05-02 14:33:12 --> Helper loaded: url_helper
INFO - 2025-05-02 14:33:12 --> Database Driver Class Initialized
INFO - 2025-05-02 14:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:33:12 --> Form Validation Class Initialized
INFO - 2025-05-02 14:33:12 --> Controller Class Initialized
DEBUG - 2025-05-02 14:33:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 14:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 14:33:12 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 14:33:13 --> Config Class Initialized
INFO - 2025-05-02 14:33:13 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:33:13 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:33:13 --> Utf8 Class Initialized
INFO - 2025-05-02 14:33:13 --> URI Class Initialized
INFO - 2025-05-02 14:33:13 --> Router Class Initialized
INFO - 2025-05-02 14:33:13 --> Output Class Initialized
INFO - 2025-05-02 14:33:13 --> Security Class Initialized
DEBUG - 2025-05-02 14:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:33:13 --> Input Class Initialized
INFO - 2025-05-02 14:33:13 --> Language Class Initialized
INFO - 2025-05-02 14:33:13 --> Loader Class Initialized
INFO - 2025-05-02 14:33:13 --> Helper loaded: form_helper
INFO - 2025-05-02 14:33:13 --> Helper loaded: url_helper
INFO - 2025-05-02 14:33:13 --> Database Driver Class Initialized
INFO - 2025-05-02 14:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:33:13 --> Form Validation Class Initialized
INFO - 2025-05-02 14:33:13 --> Controller Class Initialized
DEBUG - 2025-05-02 14:33:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 14:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 14:33:13 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 14:33:13 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 14:33:13 --> Final output sent to browser
DEBUG - 2025-05-02 14:33:13 --> Total execution time: 0.0354
INFO - 2025-05-02 14:33:14 --> Config Class Initialized
INFO - 2025-05-02 14:33:14 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:33:14 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:33:14 --> Utf8 Class Initialized
INFO - 2025-05-02 14:33:14 --> URI Class Initialized
INFO - 2025-05-02 14:33:14 --> Router Class Initialized
INFO - 2025-05-02 14:33:14 --> Output Class Initialized
INFO - 2025-05-02 14:33:14 --> Security Class Initialized
DEBUG - 2025-05-02 14:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:33:14 --> Input Class Initialized
INFO - 2025-05-02 14:33:14 --> Language Class Initialized
ERROR - 2025-05-02 14:33:14 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 14:33:42 --> Config Class Initialized
INFO - 2025-05-02 14:33:42 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:33:42 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:33:42 --> Utf8 Class Initialized
INFO - 2025-05-02 14:33:42 --> URI Class Initialized
INFO - 2025-05-02 14:33:42 --> Router Class Initialized
INFO - 2025-05-02 14:33:42 --> Output Class Initialized
INFO - 2025-05-02 14:33:42 --> Security Class Initialized
DEBUG - 2025-05-02 14:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:33:42 --> Input Class Initialized
INFO - 2025-05-02 14:33:42 --> Language Class Initialized
INFO - 2025-05-02 14:33:42 --> Loader Class Initialized
INFO - 2025-05-02 14:33:42 --> Helper loaded: form_helper
INFO - 2025-05-02 14:33:42 --> Helper loaded: url_helper
INFO - 2025-05-02 14:33:42 --> Database Driver Class Initialized
INFO - 2025-05-02 14:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:33:42 --> Form Validation Class Initialized
INFO - 2025-05-02 14:33:42 --> Controller Class Initialized
INFO - 2025-05-02 14:33:42 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/login.php
INFO - 2025-05-02 14:33:42 --> Final output sent to browser
DEBUG - 2025-05-02 14:33:42 --> Total execution time: 0.0382
INFO - 2025-05-02 14:33:42 --> Config Class Initialized
INFO - 2025-05-02 14:33:42 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:33:42 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:33:42 --> Utf8 Class Initialized
INFO - 2025-05-02 14:33:42 --> URI Class Initialized
INFO - 2025-05-02 14:33:42 --> Router Class Initialized
INFO - 2025-05-02 14:33:42 --> Output Class Initialized
INFO - 2025-05-02 14:33:42 --> Security Class Initialized
DEBUG - 2025-05-02 14:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:33:42 --> Input Class Initialized
INFO - 2025-05-02 14:33:42 --> Language Class Initialized
ERROR - 2025-05-02 14:33:42 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 14:33:52 --> Config Class Initialized
INFO - 2025-05-02 14:33:52 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:33:52 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:33:52 --> Utf8 Class Initialized
INFO - 2025-05-02 14:33:52 --> URI Class Initialized
INFO - 2025-05-02 14:33:52 --> Router Class Initialized
INFO - 2025-05-02 14:33:52 --> Output Class Initialized
INFO - 2025-05-02 14:33:52 --> Security Class Initialized
DEBUG - 2025-05-02 14:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:33:52 --> Input Class Initialized
INFO - 2025-05-02 14:33:52 --> Language Class Initialized
INFO - 2025-05-02 14:33:52 --> Loader Class Initialized
INFO - 2025-05-02 14:33:52 --> Helper loaded: form_helper
INFO - 2025-05-02 14:33:52 --> Helper loaded: url_helper
INFO - 2025-05-02 14:33:52 --> Database Driver Class Initialized
INFO - 2025-05-02 14:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:33:52 --> Form Validation Class Initialized
INFO - 2025-05-02 14:33:52 --> Controller Class Initialized
INFO - 2025-05-02 14:33:53 --> Config Class Initialized
INFO - 2025-05-02 14:33:53 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:33:53 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:33:53 --> Utf8 Class Initialized
INFO - 2025-05-02 14:33:53 --> URI Class Initialized
INFO - 2025-05-02 14:33:53 --> Router Class Initialized
INFO - 2025-05-02 14:33:53 --> Output Class Initialized
INFO - 2025-05-02 14:33:53 --> Security Class Initialized
DEBUG - 2025-05-02 14:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:33:53 --> Input Class Initialized
INFO - 2025-05-02 14:33:53 --> Language Class Initialized
INFO - 2025-05-02 14:33:53 --> Loader Class Initialized
INFO - 2025-05-02 14:33:53 --> Helper loaded: form_helper
INFO - 2025-05-02 14:33:53 --> Helper loaded: url_helper
INFO - 2025-05-02 14:33:53 --> Database Driver Class Initialized
INFO - 2025-05-02 14:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:33:53 --> Form Validation Class Initialized
INFO - 2025-05-02 14:33:53 --> Controller Class Initialized
INFO - 2025-05-02 14:33:53 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:33:53 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:33:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:33:53 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-02 14:33:53 --> Final output sent to browser
DEBUG - 2025-05-02 14:33:53 --> Total execution time: 0.0347
INFO - 2025-05-02 14:34:00 --> Config Class Initialized
INFO - 2025-05-02 14:34:00 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:34:00 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:34:00 --> Utf8 Class Initialized
INFO - 2025-05-02 14:34:00 --> URI Class Initialized
INFO - 2025-05-02 14:34:00 --> Router Class Initialized
INFO - 2025-05-02 14:34:00 --> Output Class Initialized
INFO - 2025-05-02 14:34:00 --> Security Class Initialized
DEBUG - 2025-05-02 14:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:34:00 --> Input Class Initialized
INFO - 2025-05-02 14:34:00 --> Language Class Initialized
INFO - 2025-05-02 14:34:00 --> Loader Class Initialized
INFO - 2025-05-02 14:34:00 --> Helper loaded: form_helper
INFO - 2025-05-02 14:34:00 --> Helper loaded: url_helper
INFO - 2025-05-02 14:34:00 --> Database Driver Class Initialized
INFO - 2025-05-02 14:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:34:00 --> Form Validation Class Initialized
INFO - 2025-05-02 14:34:00 --> Controller Class Initialized
INFO - 2025-05-02 14:34:00 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:34:00 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:34:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:34:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 14:34:00 --> Final output sent to browser
DEBUG - 2025-05-02 14:34:00 --> Total execution time: 0.0458
INFO - 2025-05-02 14:34:22 --> Config Class Initialized
INFO - 2025-05-02 14:34:22 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:34:22 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:34:22 --> Utf8 Class Initialized
INFO - 2025-05-02 14:34:22 --> URI Class Initialized
INFO - 2025-05-02 14:34:22 --> Router Class Initialized
INFO - 2025-05-02 14:34:22 --> Output Class Initialized
INFO - 2025-05-02 14:34:22 --> Security Class Initialized
DEBUG - 2025-05-02 14:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:34:22 --> Input Class Initialized
INFO - 2025-05-02 14:34:22 --> Language Class Initialized
INFO - 2025-05-02 14:34:22 --> Loader Class Initialized
INFO - 2025-05-02 14:34:22 --> Helper loaded: form_helper
INFO - 2025-05-02 14:34:22 --> Helper loaded: url_helper
INFO - 2025-05-02 14:34:22 --> Database Driver Class Initialized
INFO - 2025-05-02 14:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:34:22 --> Form Validation Class Initialized
INFO - 2025-05-02 14:34:22 --> Controller Class Initialized
INFO - 2025-05-02 14:34:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:34:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:34:22 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_formulir.php
INFO - 2025-05-02 14:34:22 --> Final output sent to browser
DEBUG - 2025-05-02 14:34:22 --> Total execution time: 0.0431
INFO - 2025-05-02 14:35:56 --> Config Class Initialized
INFO - 2025-05-02 14:35:56 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:35:56 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:35:56 --> Utf8 Class Initialized
INFO - 2025-05-02 14:35:56 --> URI Class Initialized
INFO - 2025-05-02 14:35:56 --> Router Class Initialized
INFO - 2025-05-02 14:35:56 --> Output Class Initialized
INFO - 2025-05-02 14:35:56 --> Security Class Initialized
DEBUG - 2025-05-02 14:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:35:56 --> Input Class Initialized
INFO - 2025-05-02 14:35:56 --> Language Class Initialized
INFO - 2025-05-02 14:35:56 --> Loader Class Initialized
INFO - 2025-05-02 14:35:56 --> Helper loaded: form_helper
INFO - 2025-05-02 14:35:56 --> Helper loaded: url_helper
INFO - 2025-05-02 14:35:56 --> Database Driver Class Initialized
INFO - 2025-05-02 14:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:35:56 --> Form Validation Class Initialized
INFO - 2025-05-02 14:35:56 --> Controller Class Initialized
INFO - 2025-05-02 14:35:56 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:35:56 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:35:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:35:56 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-02 14:35:56 --> Final output sent to browser
DEBUG - 2025-05-02 14:35:56 --> Total execution time: 0.0380
INFO - 2025-05-02 14:36:04 --> Config Class Initialized
INFO - 2025-05-02 14:36:04 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:36:04 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:36:04 --> Utf8 Class Initialized
INFO - 2025-05-02 14:36:04 --> URI Class Initialized
INFO - 2025-05-02 14:36:04 --> Router Class Initialized
INFO - 2025-05-02 14:36:04 --> Output Class Initialized
INFO - 2025-05-02 14:36:04 --> Security Class Initialized
DEBUG - 2025-05-02 14:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:36:04 --> Input Class Initialized
INFO - 2025-05-02 14:36:04 --> Language Class Initialized
INFO - 2025-05-02 14:36:04 --> Loader Class Initialized
INFO - 2025-05-02 14:36:04 --> Helper loaded: form_helper
INFO - 2025-05-02 14:36:04 --> Helper loaded: url_helper
INFO - 2025-05-02 14:36:04 --> Database Driver Class Initialized
INFO - 2025-05-02 14:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:36:04 --> Form Validation Class Initialized
INFO - 2025-05-02 14:36:04 --> Controller Class Initialized
INFO - 2025-05-02 14:36:04 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:36:04 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:36:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:36:04 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 14:36:04 --> Final output sent to browser
DEBUG - 2025-05-02 14:36:04 --> Total execution time: 0.0498
INFO - 2025-05-02 14:36:05 --> Config Class Initialized
INFO - 2025-05-02 14:36:05 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:36:05 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:36:05 --> Utf8 Class Initialized
INFO - 2025-05-02 14:36:05 --> URI Class Initialized
INFO - 2025-05-02 14:36:05 --> Router Class Initialized
INFO - 2025-05-02 14:36:05 --> Output Class Initialized
INFO - 2025-05-02 14:36:05 --> Security Class Initialized
DEBUG - 2025-05-02 14:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:36:05 --> Input Class Initialized
INFO - 2025-05-02 14:36:05 --> Language Class Initialized
INFO - 2025-05-02 14:36:05 --> Loader Class Initialized
INFO - 2025-05-02 14:36:05 --> Helper loaded: form_helper
INFO - 2025-05-02 14:36:05 --> Helper loaded: url_helper
INFO - 2025-05-02 14:36:05 --> Database Driver Class Initialized
INFO - 2025-05-02 14:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:36:05 --> Form Validation Class Initialized
INFO - 2025-05-02 14:36:05 --> Controller Class Initialized
INFO - 2025-05-02 14:36:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:36:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:36:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:36:05 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-02 14:36:05 --> Final output sent to browser
DEBUG - 2025-05-02 14:36:05 --> Total execution time: 0.0402
INFO - 2025-05-02 14:41:35 --> Config Class Initialized
INFO - 2025-05-02 14:41:35 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:41:35 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:41:35 --> Utf8 Class Initialized
INFO - 2025-05-02 14:41:35 --> URI Class Initialized
INFO - 2025-05-02 14:41:35 --> Router Class Initialized
INFO - 2025-05-02 14:41:35 --> Output Class Initialized
INFO - 2025-05-02 14:41:35 --> Security Class Initialized
DEBUG - 2025-05-02 14:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:41:35 --> Input Class Initialized
INFO - 2025-05-02 14:41:35 --> Language Class Initialized
INFO - 2025-05-02 14:41:35 --> Loader Class Initialized
INFO - 2025-05-02 14:41:35 --> Helper loaded: form_helper
INFO - 2025-05-02 14:41:35 --> Helper loaded: url_helper
INFO - 2025-05-02 14:41:35 --> Database Driver Class Initialized
INFO - 2025-05-02 14:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:41:35 --> Form Validation Class Initialized
INFO - 2025-05-02 14:41:35 --> Controller Class Initialized
INFO - 2025-05-02 14:41:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:41:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:41:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-02 14:41:35 --> Config Class Initialized
INFO - 2025-05-02 14:41:35 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:41:35 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:41:35 --> Utf8 Class Initialized
INFO - 2025-05-02 14:41:35 --> URI Class Initialized
INFO - 2025-05-02 14:41:35 --> Router Class Initialized
INFO - 2025-05-02 14:41:35 --> Output Class Initialized
INFO - 2025-05-02 14:41:35 --> Security Class Initialized
DEBUG - 2025-05-02 14:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:41:35 --> Input Class Initialized
INFO - 2025-05-02 14:41:35 --> Language Class Initialized
INFO - 2025-05-02 14:41:35 --> Loader Class Initialized
INFO - 2025-05-02 14:41:35 --> Helper loaded: form_helper
INFO - 2025-05-02 14:41:35 --> Helper loaded: url_helper
INFO - 2025-05-02 14:41:35 --> Database Driver Class Initialized
INFO - 2025-05-02 14:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:41:35 --> Form Validation Class Initialized
INFO - 2025-05-02 14:41:35 --> Controller Class Initialized
INFO - 2025-05-02 14:41:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:41:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:41:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:41:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/input_daftar_ulang.php
INFO - 2025-05-02 14:41:35 --> Final output sent to browser
DEBUG - 2025-05-02 14:41:35 --> Total execution time: 0.0412
INFO - 2025-05-02 14:41:59 --> Config Class Initialized
INFO - 2025-05-02 14:41:59 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:41:59 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:41:59 --> Utf8 Class Initialized
INFO - 2025-05-02 14:41:59 --> URI Class Initialized
INFO - 2025-05-02 14:41:59 --> Router Class Initialized
INFO - 2025-05-02 14:41:59 --> Output Class Initialized
INFO - 2025-05-02 14:41:59 --> Security Class Initialized
DEBUG - 2025-05-02 14:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:41:59 --> Input Class Initialized
INFO - 2025-05-02 14:41:59 --> Language Class Initialized
INFO - 2025-05-02 14:41:59 --> Loader Class Initialized
INFO - 2025-05-02 14:41:59 --> Helper loaded: form_helper
INFO - 2025-05-02 14:41:59 --> Helper loaded: url_helper
INFO - 2025-05-02 14:41:59 --> Database Driver Class Initialized
INFO - 2025-05-02 14:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:41:59 --> Form Validation Class Initialized
INFO - 2025-05-02 14:41:59 --> Controller Class Initialized
INFO - 2025-05-02 14:41:59 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:41:59 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:41:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:41:59 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 14:41:59 --> Final output sent to browser
DEBUG - 2025-05-02 14:41:59 --> Total execution time: 0.0419
INFO - 2025-05-02 14:42:09 --> Config Class Initialized
INFO - 2025-05-02 14:42:09 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:42:09 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:42:09 --> Utf8 Class Initialized
INFO - 2025-05-02 14:42:09 --> URI Class Initialized
INFO - 2025-05-02 14:42:09 --> Router Class Initialized
INFO - 2025-05-02 14:42:09 --> Output Class Initialized
INFO - 2025-05-02 14:42:09 --> Security Class Initialized
DEBUG - 2025-05-02 14:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:42:09 --> Input Class Initialized
INFO - 2025-05-02 14:42:09 --> Language Class Initialized
INFO - 2025-05-02 14:42:09 --> Loader Class Initialized
INFO - 2025-05-02 14:42:09 --> Helper loaded: form_helper
INFO - 2025-05-02 14:42:09 --> Helper loaded: url_helper
INFO - 2025-05-02 14:42:09 --> Database Driver Class Initialized
INFO - 2025-05-02 14:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:42:09 --> Form Validation Class Initialized
INFO - 2025-05-02 14:42:09 --> Controller Class Initialized
INFO - 2025-05-02 14:42:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:42:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:42:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:42:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-02 14:42:09 --> Final output sent to browser
DEBUG - 2025-05-02 14:42:09 --> Total execution time: 0.0393
INFO - 2025-05-02 14:42:19 --> Config Class Initialized
INFO - 2025-05-02 14:42:19 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:42:19 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:42:19 --> Utf8 Class Initialized
INFO - 2025-05-02 14:42:19 --> URI Class Initialized
INFO - 2025-05-02 14:42:19 --> Router Class Initialized
INFO - 2025-05-02 14:42:19 --> Output Class Initialized
INFO - 2025-05-02 14:42:19 --> Security Class Initialized
DEBUG - 2025-05-02 14:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:42:19 --> Input Class Initialized
INFO - 2025-05-02 14:42:19 --> Language Class Initialized
INFO - 2025-05-02 14:42:19 --> Loader Class Initialized
INFO - 2025-05-02 14:42:19 --> Helper loaded: form_helper
INFO - 2025-05-02 14:42:19 --> Helper loaded: url_helper
INFO - 2025-05-02 14:42:19 --> Database Driver Class Initialized
INFO - 2025-05-02 14:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:42:19 --> Form Validation Class Initialized
INFO - 2025-05-02 14:42:19 --> Controller Class Initialized
INFO - 2025-05-02 14:42:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:42:19 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:42:19 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-02 14:42:19 --> Final output sent to browser
DEBUG - 2025-05-02 14:42:19 --> Total execution time: 0.0399
INFO - 2025-05-02 14:46:52 --> Config Class Initialized
INFO - 2025-05-02 14:46:52 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:46:52 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:46:52 --> Utf8 Class Initialized
INFO - 2025-05-02 14:46:52 --> URI Class Initialized
INFO - 2025-05-02 14:46:52 --> Router Class Initialized
INFO - 2025-05-02 14:46:52 --> Output Class Initialized
INFO - 2025-05-02 14:46:52 --> Security Class Initialized
DEBUG - 2025-05-02 14:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:46:52 --> Input Class Initialized
INFO - 2025-05-02 14:46:52 --> Language Class Initialized
INFO - 2025-05-02 14:46:52 --> Loader Class Initialized
INFO - 2025-05-02 14:46:52 --> Helper loaded: form_helper
INFO - 2025-05-02 14:46:52 --> Helper loaded: url_helper
INFO - 2025-05-02 14:46:52 --> Database Driver Class Initialized
INFO - 2025-05-02 14:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:46:52 --> Form Validation Class Initialized
INFO - 2025-05-02 14:46:52 --> Controller Class Initialized
INFO - 2025-05-02 14:46:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:46:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:46:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:46:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:46:52 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-02 14:46:52 --> Final output sent to browser
DEBUG - 2025-05-02 14:46:52 --> Total execution time: 0.0490
INFO - 2025-05-02 14:46:57 --> Config Class Initialized
INFO - 2025-05-02 14:46:57 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:46:57 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:46:57 --> Utf8 Class Initialized
INFO - 2025-05-02 14:46:57 --> URI Class Initialized
INFO - 2025-05-02 14:46:57 --> Router Class Initialized
INFO - 2025-05-02 14:46:57 --> Output Class Initialized
INFO - 2025-05-02 14:46:57 --> Security Class Initialized
DEBUG - 2025-05-02 14:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:46:57 --> Input Class Initialized
INFO - 2025-05-02 14:46:57 --> Language Class Initialized
INFO - 2025-05-02 14:46:57 --> Loader Class Initialized
INFO - 2025-05-02 14:46:57 --> Helper loaded: form_helper
INFO - 2025-05-02 14:46:57 --> Helper loaded: url_helper
INFO - 2025-05-02 14:46:57 --> Database Driver Class Initialized
INFO - 2025-05-02 14:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:46:57 --> Form Validation Class Initialized
INFO - 2025-05-02 14:46:57 --> Controller Class Initialized
INFO - 2025-05-02 14:46:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:46:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:46:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:46:57 --> Config Class Initialized
INFO - 2025-05-02 14:46:57 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:46:57 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:46:57 --> Utf8 Class Initialized
INFO - 2025-05-02 14:46:57 --> URI Class Initialized
INFO - 2025-05-02 14:46:57 --> Router Class Initialized
INFO - 2025-05-02 14:46:57 --> Output Class Initialized
INFO - 2025-05-02 14:46:57 --> Security Class Initialized
DEBUG - 2025-05-02 14:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:46:57 --> Input Class Initialized
INFO - 2025-05-02 14:46:57 --> Language Class Initialized
INFO - 2025-05-02 14:46:57 --> Loader Class Initialized
INFO - 2025-05-02 14:46:57 --> Helper loaded: form_helper
INFO - 2025-05-02 14:46:57 --> Helper loaded: url_helper
INFO - 2025-05-02 14:46:57 --> Database Driver Class Initialized
INFO - 2025-05-02 14:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:46:57 --> Form Validation Class Initialized
INFO - 2025-05-02 14:46:57 --> Controller Class Initialized
INFO - 2025-05-02 14:46:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:46:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:46:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:46:57 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-02 14:46:57 --> Final output sent to browser
DEBUG - 2025-05-02 14:46:57 --> Total execution time: 0.0359
INFO - 2025-05-02 14:47:00 --> Config Class Initialized
INFO - 2025-05-02 14:47:00 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:47:00 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:47:00 --> Utf8 Class Initialized
INFO - 2025-05-02 14:47:00 --> URI Class Initialized
INFO - 2025-05-02 14:47:00 --> Router Class Initialized
INFO - 2025-05-02 14:47:00 --> Output Class Initialized
INFO - 2025-05-02 14:47:00 --> Security Class Initialized
DEBUG - 2025-05-02 14:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:47:00 --> Input Class Initialized
INFO - 2025-05-02 14:47:00 --> Language Class Initialized
INFO - 2025-05-02 14:47:00 --> Loader Class Initialized
INFO - 2025-05-02 14:47:00 --> Helper loaded: form_helper
INFO - 2025-05-02 14:47:00 --> Helper loaded: url_helper
INFO - 2025-05-02 14:47:00 --> Database Driver Class Initialized
INFO - 2025-05-02 14:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:47:00 --> Form Validation Class Initialized
INFO - 2025-05-02 14:47:00 --> Controller Class Initialized
INFO - 2025-05-02 14:47:00 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:47:00 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:47:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:47:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 14:47:00 --> Final output sent to browser
DEBUG - 2025-05-02 14:47:00 --> Total execution time: 0.0436
INFO - 2025-05-02 14:50:08 --> Config Class Initialized
INFO - 2025-05-02 14:50:08 --> Hooks Class Initialized
DEBUG - 2025-05-02 14:50:08 --> UTF-8 Support Enabled
INFO - 2025-05-02 14:50:08 --> Utf8 Class Initialized
INFO - 2025-05-02 14:50:08 --> URI Class Initialized
INFO - 2025-05-02 14:50:08 --> Router Class Initialized
INFO - 2025-05-02 14:50:08 --> Output Class Initialized
INFO - 2025-05-02 14:50:08 --> Security Class Initialized
DEBUG - 2025-05-02 14:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 14:50:08 --> Input Class Initialized
INFO - 2025-05-02 14:50:08 --> Language Class Initialized
INFO - 2025-05-02 14:50:08 --> Loader Class Initialized
INFO - 2025-05-02 14:50:08 --> Helper loaded: form_helper
INFO - 2025-05-02 14:50:08 --> Helper loaded: url_helper
INFO - 2025-05-02 14:50:08 --> Database Driver Class Initialized
INFO - 2025-05-02 14:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 14:50:08 --> Form Validation Class Initialized
INFO - 2025-05-02 14:50:08 --> Controller Class Initialized
INFO - 2025-05-02 14:50:08 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 14:50:08 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 14:50:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 14:50:08 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-02 14:50:08 --> Final output sent to browser
DEBUG - 2025-05-02 14:50:08 --> Total execution time: 0.0381
INFO - 2025-05-02 15:27:24 --> Config Class Initialized
INFO - 2025-05-02 15:27:24 --> Hooks Class Initialized
DEBUG - 2025-05-02 15:27:24 --> UTF-8 Support Enabled
INFO - 2025-05-02 15:27:24 --> Utf8 Class Initialized
INFO - 2025-05-02 15:27:24 --> URI Class Initialized
INFO - 2025-05-02 15:27:24 --> Router Class Initialized
INFO - 2025-05-02 15:27:24 --> Output Class Initialized
INFO - 2025-05-02 15:27:24 --> Security Class Initialized
DEBUG - 2025-05-02 15:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 15:27:24 --> Input Class Initialized
INFO - 2025-05-02 15:27:24 --> Language Class Initialized
INFO - 2025-05-02 15:27:24 --> Loader Class Initialized
INFO - 2025-05-02 15:27:24 --> Helper loaded: form_helper
INFO - 2025-05-02 15:27:24 --> Helper loaded: url_helper
INFO - 2025-05-02 15:27:24 --> Database Driver Class Initialized
INFO - 2025-05-02 15:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 15:27:24 --> Form Validation Class Initialized
INFO - 2025-05-02 15:27:24 --> Controller Class Initialized
INFO - 2025-05-02 15:27:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 15:27:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 15:27:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 15:27:24 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/dashboard.php
INFO - 2025-05-02 15:27:24 --> Final output sent to browser
DEBUG - 2025-05-02 15:27:24 --> Total execution time: 0.0348
INFO - 2025-05-02 15:27:27 --> Config Class Initialized
INFO - 2025-05-02 15:27:27 --> Hooks Class Initialized
DEBUG - 2025-05-02 15:27:27 --> UTF-8 Support Enabled
INFO - 2025-05-02 15:27:27 --> Utf8 Class Initialized
INFO - 2025-05-02 15:27:27 --> URI Class Initialized
INFO - 2025-05-02 15:27:27 --> Router Class Initialized
INFO - 2025-05-02 15:27:27 --> Output Class Initialized
INFO - 2025-05-02 15:27:27 --> Security Class Initialized
DEBUG - 2025-05-02 15:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 15:27:27 --> Input Class Initialized
INFO - 2025-05-02 15:27:27 --> Language Class Initialized
INFO - 2025-05-02 15:27:27 --> Loader Class Initialized
INFO - 2025-05-02 15:27:27 --> Helper loaded: form_helper
INFO - 2025-05-02 15:27:27 --> Helper loaded: url_helper
INFO - 2025-05-02 15:27:27 --> Database Driver Class Initialized
INFO - 2025-05-02 15:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 15:27:27 --> Form Validation Class Initialized
INFO - 2025-05-02 15:27:27 --> Controller Class Initialized
INFO - 2025-05-02 15:27:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 15:27:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 15:27:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 15:27:27 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/rekapitulasi.php
INFO - 2025-05-02 15:27:27 --> Final output sent to browser
DEBUG - 2025-05-02 15:27:27 --> Total execution time: 0.0460
INFO - 2025-05-02 15:27:35 --> Config Class Initialized
INFO - 2025-05-02 15:27:35 --> Hooks Class Initialized
DEBUG - 2025-05-02 15:27:35 --> UTF-8 Support Enabled
INFO - 2025-05-02 15:27:35 --> Utf8 Class Initialized
INFO - 2025-05-02 15:27:35 --> URI Class Initialized
INFO - 2025-05-02 15:27:35 --> Router Class Initialized
INFO - 2025-05-02 15:27:35 --> Output Class Initialized
INFO - 2025-05-02 15:27:35 --> Security Class Initialized
DEBUG - 2025-05-02 15:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 15:27:35 --> Input Class Initialized
INFO - 2025-05-02 15:27:35 --> Language Class Initialized
INFO - 2025-05-02 15:27:35 --> Loader Class Initialized
INFO - 2025-05-02 15:27:35 --> Helper loaded: form_helper
INFO - 2025-05-02 15:27:35 --> Helper loaded: url_helper
INFO - 2025-05-02 15:27:35 --> Database Driver Class Initialized
INFO - 2025-05-02 15:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 15:27:35 --> Form Validation Class Initialized
INFO - 2025-05-02 15:27:35 --> Controller Class Initialized
INFO - 2025-05-02 15:27:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 15:27:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 15:27:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 15:27:35 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar.php
INFO - 2025-05-02 15:27:35 --> Final output sent to browser
DEBUG - 2025-05-02 15:27:35 --> Total execution time: 0.0370
INFO - 2025-05-02 15:27:48 --> Config Class Initialized
INFO - 2025-05-02 15:27:48 --> Hooks Class Initialized
DEBUG - 2025-05-02 15:27:48 --> UTF-8 Support Enabled
INFO - 2025-05-02 15:27:48 --> Utf8 Class Initialized
INFO - 2025-05-02 15:27:48 --> URI Class Initialized
INFO - 2025-05-02 15:27:48 --> Router Class Initialized
INFO - 2025-05-02 15:27:48 --> Output Class Initialized
INFO - 2025-05-02 15:27:48 --> Security Class Initialized
DEBUG - 2025-05-02 15:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 15:27:48 --> Input Class Initialized
INFO - 2025-05-02 15:27:48 --> Language Class Initialized
INFO - 2025-05-02 15:27:48 --> Loader Class Initialized
INFO - 2025-05-02 15:27:48 --> Helper loaded: form_helper
INFO - 2025-05-02 15:27:48 --> Helper loaded: url_helper
INFO - 2025-05-02 15:27:48 --> Database Driver Class Initialized
INFO - 2025-05-02 15:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 15:27:48 --> Form Validation Class Initialized
INFO - 2025-05-02 15:27:48 --> Controller Class Initialized
INFO - 2025-05-02 15:27:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 15:27:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 15:27:48 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 15:27:48 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/peserta_daftar_ulang.php
INFO - 2025-05-02 15:27:48 --> Final output sent to browser
DEBUG - 2025-05-02 15:27:48 --> Total execution time: 0.0381
INFO - 2025-05-02 15:27:55 --> Config Class Initialized
INFO - 2025-05-02 15:27:55 --> Hooks Class Initialized
DEBUG - 2025-05-02 15:27:55 --> UTF-8 Support Enabled
INFO - 2025-05-02 15:27:55 --> Utf8 Class Initialized
INFO - 2025-05-02 15:27:55 --> URI Class Initialized
INFO - 2025-05-02 15:27:55 --> Router Class Initialized
INFO - 2025-05-02 15:27:55 --> Output Class Initialized
INFO - 2025-05-02 15:27:55 --> Security Class Initialized
DEBUG - 2025-05-02 15:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 15:27:55 --> Input Class Initialized
INFO - 2025-05-02 15:27:55 --> Language Class Initialized
INFO - 2025-05-02 15:27:55 --> Loader Class Initialized
INFO - 2025-05-02 15:27:55 --> Helper loaded: form_helper
INFO - 2025-05-02 15:27:55 --> Helper loaded: url_helper
INFO - 2025-05-02 15:27:55 --> Database Driver Class Initialized
INFO - 2025-05-02 15:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 15:27:55 --> Form Validation Class Initialized
INFO - 2025-05-02 15:27:55 --> Controller Class Initialized
INFO - 2025-05-02 15:27:55 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 15:27:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 15:27:55 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 15:27:55 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/data_pendaftar_lengkap.php
INFO - 2025-05-02 15:27:55 --> Final output sent to browser
DEBUG - 2025-05-02 15:27:55 --> Total execution time: 0.0387
INFO - 2025-05-02 15:28:00 --> Config Class Initialized
INFO - 2025-05-02 15:28:00 --> Hooks Class Initialized
DEBUG - 2025-05-02 15:28:00 --> UTF-8 Support Enabled
INFO - 2025-05-02 15:28:00 --> Utf8 Class Initialized
INFO - 2025-05-02 15:28:00 --> URI Class Initialized
INFO - 2025-05-02 15:28:00 --> Router Class Initialized
INFO - 2025-05-02 15:28:00 --> Output Class Initialized
INFO - 2025-05-02 15:28:00 --> Security Class Initialized
DEBUG - 2025-05-02 15:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 15:28:00 --> Input Class Initialized
INFO - 2025-05-02 15:28:00 --> Language Class Initialized
INFO - 2025-05-02 15:28:00 --> Loader Class Initialized
INFO - 2025-05-02 15:28:00 --> Helper loaded: form_helper
INFO - 2025-05-02 15:28:00 --> Helper loaded: url_helper
INFO - 2025-05-02 15:28:00 --> Database Driver Class Initialized
INFO - 2025-05-02 15:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 15:28:00 --> Form Validation Class Initialized
INFO - 2025-05-02 15:28:00 --> Controller Class Initialized
INFO - 2025-05-02 15:28:00 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 15:28:00 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 15:28:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 15:28:00 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_seragam.php
INFO - 2025-05-02 15:28:00 --> Final output sent to browser
DEBUG - 2025-05-02 15:28:00 --> Total execution time: 0.0487
INFO - 2025-05-02 15:28:09 --> Config Class Initialized
INFO - 2025-05-02 15:28:09 --> Hooks Class Initialized
DEBUG - 2025-05-02 15:28:09 --> UTF-8 Support Enabled
INFO - 2025-05-02 15:28:09 --> Utf8 Class Initialized
INFO - 2025-05-02 15:28:09 --> URI Class Initialized
INFO - 2025-05-02 15:28:09 --> Router Class Initialized
INFO - 2025-05-02 15:28:09 --> Output Class Initialized
INFO - 2025-05-02 15:28:09 --> Security Class Initialized
DEBUG - 2025-05-02 15:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 15:28:09 --> Input Class Initialized
INFO - 2025-05-02 15:28:09 --> Language Class Initialized
INFO - 2025-05-02 15:28:09 --> Loader Class Initialized
INFO - 2025-05-02 15:28:09 --> Helper loaded: form_helper
INFO - 2025-05-02 15:28:09 --> Helper loaded: url_helper
INFO - 2025-05-02 15:28:09 --> Database Driver Class Initialized
INFO - 2025-05-02 15:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 15:28:09 --> Form Validation Class Initialized
INFO - 2025-05-02 15:28:09 --> Controller Class Initialized
INFO - 2025-05-02 15:28:09 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-02 15:28:09 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-02 15:28:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/_sidebar.php
INFO - 2025-05-02 15:28:09 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/admin/laporan_rekomendasi.php
INFO - 2025-05-02 15:28:09 --> Final output sent to browser
DEBUG - 2025-05-02 15:28:09 --> Total execution time: 0.0438
INFO - 2025-05-02 18:16:11 --> Config Class Initialized
INFO - 2025-05-02 18:16:11 --> Hooks Class Initialized
DEBUG - 2025-05-02 18:16:11 --> UTF-8 Support Enabled
INFO - 2025-05-02 18:16:11 --> Utf8 Class Initialized
INFO - 2025-05-02 18:16:11 --> URI Class Initialized
INFO - 2025-05-02 18:16:11 --> Router Class Initialized
INFO - 2025-05-02 18:16:11 --> Output Class Initialized
INFO - 2025-05-02 18:16:11 --> Security Class Initialized
DEBUG - 2025-05-02 18:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 18:16:11 --> Input Class Initialized
INFO - 2025-05-02 18:16:11 --> Language Class Initialized
ERROR - 2025-05-02 18:16:11 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-02 18:32:56 --> Config Class Initialized
INFO - 2025-05-02 18:32:56 --> Hooks Class Initialized
DEBUG - 2025-05-02 18:32:56 --> UTF-8 Support Enabled
INFO - 2025-05-02 18:32:56 --> Utf8 Class Initialized
INFO - 2025-05-02 18:32:56 --> URI Class Initialized
DEBUG - 2025-05-02 18:32:56 --> No URI present. Default controller set.
INFO - 2025-05-02 18:32:56 --> Router Class Initialized
INFO - 2025-05-02 18:32:56 --> Output Class Initialized
INFO - 2025-05-02 18:32:56 --> Security Class Initialized
DEBUG - 2025-05-02 18:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 18:32:56 --> Input Class Initialized
INFO - 2025-05-02 18:32:56 --> Language Class Initialized
INFO - 2025-05-02 18:32:56 --> Loader Class Initialized
INFO - 2025-05-02 18:32:56 --> Helper loaded: form_helper
INFO - 2025-05-02 18:32:56 --> Helper loaded: url_helper
INFO - 2025-05-02 18:32:56 --> Database Driver Class Initialized
INFO - 2025-05-02 18:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 18:32:56 --> Form Validation Class Initialized
INFO - 2025-05-02 18:32:56 --> Controller Class Initialized
INFO - 2025-05-02 18:32:56 --> Final output sent to browser
DEBUG - 2025-05-02 18:32:56 --> Total execution time: 0.0553
INFO - 2025-05-02 18:33:02 --> Config Class Initialized
INFO - 2025-05-02 18:33:02 --> Hooks Class Initialized
DEBUG - 2025-05-02 18:33:02 --> UTF-8 Support Enabled
INFO - 2025-05-02 18:33:02 --> Utf8 Class Initialized
INFO - 2025-05-02 18:33:02 --> URI Class Initialized
INFO - 2025-05-02 18:33:02 --> Router Class Initialized
INFO - 2025-05-02 18:33:02 --> Output Class Initialized
INFO - 2025-05-02 18:33:02 --> Security Class Initialized
DEBUG - 2025-05-02 18:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 18:33:02 --> Input Class Initialized
INFO - 2025-05-02 18:33:02 --> Language Class Initialized
INFO - 2025-05-02 18:33:02 --> Loader Class Initialized
INFO - 2025-05-02 18:33:02 --> Helper loaded: form_helper
INFO - 2025-05-02 18:33:02 --> Helper loaded: url_helper
INFO - 2025-05-02 18:33:02 --> Database Driver Class Initialized
INFO - 2025-05-02 18:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 18:33:02 --> Form Validation Class Initialized
INFO - 2025-05-02 18:33:02 --> Controller Class Initialized
DEBUG - 2025-05-02 18:33:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 18:33:02 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 18:33:02 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 18:33:02 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 18:33:02 --> Final output sent to browser
DEBUG - 2025-05-02 18:33:02 --> Total execution time: 0.0410
INFO - 2025-05-02 18:33:03 --> Config Class Initialized
INFO - 2025-05-02 18:33:03 --> Hooks Class Initialized
DEBUG - 2025-05-02 18:33:03 --> UTF-8 Support Enabled
INFO - 2025-05-02 18:33:03 --> Utf8 Class Initialized
INFO - 2025-05-02 18:33:03 --> URI Class Initialized
INFO - 2025-05-02 18:33:03 --> Router Class Initialized
INFO - 2025-05-02 18:33:03 --> Output Class Initialized
INFO - 2025-05-02 18:33:03 --> Security Class Initialized
DEBUG - 2025-05-02 18:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 18:33:03 --> Input Class Initialized
INFO - 2025-05-02 18:33:03 --> Language Class Initialized
ERROR - 2025-05-02 18:33:03 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 18:55:13 --> Config Class Initialized
INFO - 2025-05-02 18:55:13 --> Hooks Class Initialized
DEBUG - 2025-05-02 18:55:13 --> UTF-8 Support Enabled
INFO - 2025-05-02 18:55:13 --> Utf8 Class Initialized
INFO - 2025-05-02 18:55:13 --> URI Class Initialized
DEBUG - 2025-05-02 18:55:13 --> No URI present. Default controller set.
INFO - 2025-05-02 18:55:13 --> Router Class Initialized
INFO - 2025-05-02 18:55:13 --> Output Class Initialized
INFO - 2025-05-02 18:55:13 --> Security Class Initialized
DEBUG - 2025-05-02 18:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 18:55:13 --> Input Class Initialized
INFO - 2025-05-02 18:55:13 --> Language Class Initialized
INFO - 2025-05-02 18:55:13 --> Loader Class Initialized
INFO - 2025-05-02 18:55:13 --> Helper loaded: form_helper
INFO - 2025-05-02 18:55:13 --> Helper loaded: url_helper
INFO - 2025-05-02 18:55:13 --> Database Driver Class Initialized
INFO - 2025-05-02 18:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 18:55:13 --> Form Validation Class Initialized
INFO - 2025-05-02 18:55:13 --> Controller Class Initialized
INFO - 2025-05-02 18:55:13 --> Final output sent to browser
DEBUG - 2025-05-02 18:55:13 --> Total execution time: 0.0305
INFO - 2025-05-02 20:31:56 --> Config Class Initialized
INFO - 2025-05-02 20:31:56 --> Hooks Class Initialized
DEBUG - 2025-05-02 20:31:56 --> UTF-8 Support Enabled
INFO - 2025-05-02 20:31:56 --> Utf8 Class Initialized
INFO - 2025-05-02 20:31:56 --> URI Class Initialized
INFO - 2025-05-02 20:31:56 --> Router Class Initialized
INFO - 2025-05-02 20:31:56 --> Output Class Initialized
INFO - 2025-05-02 20:31:56 --> Security Class Initialized
DEBUG - 2025-05-02 20:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 20:31:56 --> Input Class Initialized
INFO - 2025-05-02 20:31:56 --> Language Class Initialized
ERROR - 2025-05-02 20:31:56 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-05-02 21:28:08 --> Config Class Initialized
INFO - 2025-05-02 21:28:08 --> Hooks Class Initialized
DEBUG - 2025-05-02 21:28:08 --> UTF-8 Support Enabled
INFO - 2025-05-02 21:28:08 --> Utf8 Class Initialized
INFO - 2025-05-02 21:28:08 --> URI Class Initialized
DEBUG - 2025-05-02 21:28:08 --> No URI present. Default controller set.
INFO - 2025-05-02 21:28:08 --> Router Class Initialized
INFO - 2025-05-02 21:28:08 --> Output Class Initialized
INFO - 2025-05-02 21:28:08 --> Security Class Initialized
DEBUG - 2025-05-02 21:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 21:28:08 --> Input Class Initialized
INFO - 2025-05-02 21:28:08 --> Language Class Initialized
INFO - 2025-05-02 21:28:08 --> Loader Class Initialized
INFO - 2025-05-02 21:28:08 --> Helper loaded: form_helper
INFO - 2025-05-02 21:28:08 --> Helper loaded: url_helper
INFO - 2025-05-02 21:28:08 --> Database Driver Class Initialized
INFO - 2025-05-02 21:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 21:28:08 --> Form Validation Class Initialized
INFO - 2025-05-02 21:28:08 --> Controller Class Initialized
INFO - 2025-05-02 21:28:08 --> Final output sent to browser
DEBUG - 2025-05-02 21:28:08 --> Total execution time: 0.0307
INFO - 2025-05-02 21:28:16 --> Config Class Initialized
INFO - 2025-05-02 21:28:16 --> Hooks Class Initialized
DEBUG - 2025-05-02 21:28:16 --> UTF-8 Support Enabled
INFO - 2025-05-02 21:28:16 --> Utf8 Class Initialized
INFO - 2025-05-02 21:28:16 --> URI Class Initialized
INFO - 2025-05-02 21:28:16 --> Router Class Initialized
INFO - 2025-05-02 21:28:16 --> Output Class Initialized
INFO - 2025-05-02 21:28:16 --> Security Class Initialized
DEBUG - 2025-05-02 21:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 21:28:16 --> Input Class Initialized
INFO - 2025-05-02 21:28:16 --> Language Class Initialized
INFO - 2025-05-02 21:28:16 --> Loader Class Initialized
INFO - 2025-05-02 21:28:16 --> Helper loaded: form_helper
INFO - 2025-05-02 21:28:16 --> Helper loaded: url_helper
INFO - 2025-05-02 21:28:16 --> Database Driver Class Initialized
INFO - 2025-05-02 21:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 21:28:16 --> Form Validation Class Initialized
INFO - 2025-05-02 21:28:16 --> Controller Class Initialized
DEBUG - 2025-05-02 21:28:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 21:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 21:28:16 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 21:28:16 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 21:28:16 --> Final output sent to browser
DEBUG - 2025-05-02 21:28:16 --> Total execution time: 0.0319
INFO - 2025-05-02 21:28:17 --> Config Class Initialized
INFO - 2025-05-02 21:28:17 --> Hooks Class Initialized
DEBUG - 2025-05-02 21:28:17 --> UTF-8 Support Enabled
INFO - 2025-05-02 21:28:17 --> Utf8 Class Initialized
INFO - 2025-05-02 21:28:17 --> URI Class Initialized
INFO - 2025-05-02 21:28:17 --> Router Class Initialized
INFO - 2025-05-02 21:28:17 --> Output Class Initialized
INFO - 2025-05-02 21:28:17 --> Security Class Initialized
DEBUG - 2025-05-02 21:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 21:28:17 --> Input Class Initialized
INFO - 2025-05-02 21:28:17 --> Language Class Initialized
ERROR - 2025-05-02 21:28:17 --> 404 Page Not Found: Faviconico/index
INFO - 2025-05-02 21:29:13 --> Config Class Initialized
INFO - 2025-05-02 21:29:13 --> Hooks Class Initialized
DEBUG - 2025-05-02 21:29:13 --> UTF-8 Support Enabled
INFO - 2025-05-02 21:29:13 --> Utf8 Class Initialized
INFO - 2025-05-02 21:29:13 --> URI Class Initialized
DEBUG - 2025-05-02 21:29:13 --> No URI present. Default controller set.
INFO - 2025-05-02 21:29:13 --> Router Class Initialized
INFO - 2025-05-02 21:29:13 --> Output Class Initialized
INFO - 2025-05-02 21:29:13 --> Security Class Initialized
DEBUG - 2025-05-02 21:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 21:29:13 --> Input Class Initialized
INFO - 2025-05-02 21:29:13 --> Language Class Initialized
INFO - 2025-05-02 21:29:13 --> Loader Class Initialized
INFO - 2025-05-02 21:29:13 --> Helper loaded: form_helper
INFO - 2025-05-02 21:29:13 --> Helper loaded: url_helper
INFO - 2025-05-02 21:29:13 --> Database Driver Class Initialized
INFO - 2025-05-02 21:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 21:29:13 --> Form Validation Class Initialized
INFO - 2025-05-02 21:29:13 --> Controller Class Initialized
INFO - 2025-05-02 21:29:13 --> Final output sent to browser
DEBUG - 2025-05-02 21:29:13 --> Total execution time: 0.0326
INFO - 2025-05-02 21:29:20 --> Config Class Initialized
INFO - 2025-05-02 21:29:20 --> Hooks Class Initialized
DEBUG - 2025-05-02 21:29:20 --> UTF-8 Support Enabled
INFO - 2025-05-02 21:29:20 --> Utf8 Class Initialized
INFO - 2025-05-02 21:29:20 --> URI Class Initialized
INFO - 2025-05-02 21:29:20 --> Router Class Initialized
INFO - 2025-05-02 21:29:20 --> Output Class Initialized
INFO - 2025-05-02 21:29:20 --> Security Class Initialized
DEBUG - 2025-05-02 21:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 21:29:20 --> Input Class Initialized
INFO - 2025-05-02 21:29:20 --> Language Class Initialized
INFO - 2025-05-02 21:29:20 --> Loader Class Initialized
INFO - 2025-05-02 21:29:20 --> Helper loaded: form_helper
INFO - 2025-05-02 21:29:20 --> Helper loaded: url_helper
INFO - 2025-05-02 21:29:20 --> Database Driver Class Initialized
INFO - 2025-05-02 21:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 21:29:20 --> Form Validation Class Initialized
INFO - 2025-05-02 21:29:20 --> Controller Class Initialized
DEBUG - 2025-05-02 21:29:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-02 21:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-02 21:29:20 --> Model "Ppdb_model" initialized
INFO - 2025-05-02 21:29:20 --> File loaded: /www/wwwroot/ppdb.manubanyuputih.id/application/views/ppdb/form_pendaftaran.php
INFO - 2025-05-02 21:29:20 --> Final output sent to browser
DEBUG - 2025-05-02 21:29:20 --> Total execution time: 0.0353
INFO - 2025-05-02 21:29:22 --> Config Class Initialized
INFO - 2025-05-02 21:29:22 --> Hooks Class Initialized
DEBUG - 2025-05-02 21:29:22 --> UTF-8 Support Enabled
INFO - 2025-05-02 21:29:22 --> Utf8 Class Initialized
INFO - 2025-05-02 21:29:22 --> URI Class Initialized
DEBUG - 2025-05-02 21:29:22 --> No URI present. Default controller set.
INFO - 2025-05-02 21:29:22 --> Router Class Initialized
INFO - 2025-05-02 21:29:22 --> Output Class Initialized
INFO - 2025-05-02 21:29:22 --> Security Class Initialized
DEBUG - 2025-05-02 21:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 21:29:22 --> Input Class Initialized
INFO - 2025-05-02 21:29:22 --> Language Class Initialized
INFO - 2025-05-02 21:29:22 --> Loader Class Initialized
INFO - 2025-05-02 21:29:22 --> Helper loaded: form_helper
INFO - 2025-05-02 21:29:22 --> Helper loaded: url_helper
INFO - 2025-05-02 21:29:22 --> Database Driver Class Initialized
INFO - 2025-05-02 21:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 21:29:22 --> Form Validation Class Initialized
INFO - 2025-05-02 21:29:22 --> Controller Class Initialized
INFO - 2025-05-02 21:29:22 --> Final output sent to browser
DEBUG - 2025-05-02 21:29:22 --> Total execution time: 0.0347
INFO - 2025-05-02 21:29:26 --> Config Class Initialized
INFO - 2025-05-02 21:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-02 21:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-02 21:29:26 --> Utf8 Class Initialized
INFO - 2025-05-02 21:29:26 --> URI Class Initialized
DEBUG - 2025-05-02 21:29:26 --> No URI present. Default controller set.
INFO - 2025-05-02 21:29:26 --> Router Class Initialized
INFO - 2025-05-02 21:29:26 --> Output Class Initialized
INFO - 2025-05-02 21:29:26 --> Security Class Initialized
DEBUG - 2025-05-02 21:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 21:29:26 --> Input Class Initialized
INFO - 2025-05-02 21:29:26 --> Language Class Initialized
INFO - 2025-05-02 21:29:26 --> Loader Class Initialized
INFO - 2025-05-02 21:29:26 --> Helper loaded: form_helper
INFO - 2025-05-02 21:29:26 --> Helper loaded: url_helper
INFO - 2025-05-02 21:29:26 --> Database Driver Class Initialized
INFO - 2025-05-02 21:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 21:29:26 --> Form Validation Class Initialized
INFO - 2025-05-02 21:29:26 --> Controller Class Initialized
INFO - 2025-05-02 21:29:26 --> Final output sent to browser
DEBUG - 2025-05-02 21:29:26 --> Total execution time: 0.0354
INFO - 2025-05-02 21:30:10 --> Config Class Initialized
INFO - 2025-05-02 21:30:10 --> Hooks Class Initialized
DEBUG - 2025-05-02 21:30:10 --> UTF-8 Support Enabled
INFO - 2025-05-02 21:30:10 --> Utf8 Class Initialized
INFO - 2025-05-02 21:30:10 --> URI Class Initialized
DEBUG - 2025-05-02 21:30:10 --> No URI present. Default controller set.
INFO - 2025-05-02 21:30:10 --> Router Class Initialized
INFO - 2025-05-02 21:30:10 --> Output Class Initialized
INFO - 2025-05-02 21:30:10 --> Security Class Initialized
DEBUG - 2025-05-02 21:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-02 21:30:10 --> Input Class Initialized
INFO - 2025-05-02 21:30:10 --> Language Class Initialized
INFO - 2025-05-02 21:30:10 --> Loader Class Initialized
INFO - 2025-05-02 21:30:10 --> Helper loaded: form_helper
INFO - 2025-05-02 21:30:10 --> Helper loaded: url_helper
INFO - 2025-05-02 21:30:10 --> Database Driver Class Initialized
INFO - 2025-05-02 21:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-02 21:30:10 --> Form Validation Class Initialized
INFO - 2025-05-02 21:30:10 --> Controller Class Initialized
INFO - 2025-05-02 21:30:10 --> Final output sent to browser
DEBUG - 2025-05-02 21:30:10 --> Total execution time: 0.0336
