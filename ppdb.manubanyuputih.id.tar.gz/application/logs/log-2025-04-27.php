<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-27 05:19:45 --> Config Class Initialized
INFO - 2025-04-27 05:19:45 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:19:45 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:19:45 --> Utf8 Class Initialized
INFO - 2025-04-27 05:19:45 --> URI Class Initialized
INFO - 2025-04-27 05:19:45 --> Router Class Initialized
INFO - 2025-04-27 05:19:45 --> Output Class Initialized
INFO - 2025-04-27 05:19:45 --> Security Class Initialized
DEBUG - 2025-04-27 05:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:19:45 --> Input Class Initialized
INFO - 2025-04-27 05:19:45 --> Language Class Initialized
INFO - 2025-04-27 05:19:45 --> Loader Class Initialized
INFO - 2025-04-27 05:19:45 --> Helper loaded: form_helper
INFO - 2025-04-27 05:19:45 --> Helper loaded: url_helper
INFO - 2025-04-27 05:19:45 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:19:45 --> Form Validation Class Initialized
INFO - 2025-04-27 05:19:45 --> Controller Class Initialized
INFO - 2025-04-27 05:19:45 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:19:45 --> Helper loaded: language_helper
INFO - 2025-04-27 05:19:45 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:19:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-04-27 05:19:45 --> Unable to find validation rule: valid_date
ERROR - 2025-04-27 05:19:45 --> Could not find the language line "form_validation_valid_date"
INFO - 2025-04-27 05:19:45 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:19:45 --> Final output sent to browser
DEBUG - 2025-04-27 05:19:45 --> Total execution time: 0.0374
INFO - 2025-04-27 05:21:47 --> Config Class Initialized
INFO - 2025-04-27 05:21:47 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:21:47 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:21:47 --> Utf8 Class Initialized
INFO - 2025-04-27 05:21:47 --> URI Class Initialized
INFO - 2025-04-27 05:21:47 --> Router Class Initialized
INFO - 2025-04-27 05:21:47 --> Output Class Initialized
INFO - 2025-04-27 05:21:47 --> Security Class Initialized
DEBUG - 2025-04-27 05:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:21:47 --> Input Class Initialized
INFO - 2025-04-27 05:21:47 --> Language Class Initialized
INFO - 2025-04-27 05:21:47 --> Loader Class Initialized
INFO - 2025-04-27 05:21:47 --> Helper loaded: form_helper
INFO - 2025-04-27 05:21:47 --> Helper loaded: url_helper
INFO - 2025-04-27 05:21:47 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:21:47 --> Form Validation Class Initialized
INFO - 2025-04-27 05:21:47 --> Controller Class Initialized
INFO - 2025-04-27 05:21:47 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:21:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:21:47 --> Helper loaded: language_helper
INFO - 2025-04-27 05:21:47 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:21:47 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:21:47 --> Final output sent to browser
DEBUG - 2025-04-27 05:21:47 --> Total execution time: 0.0436
INFO - 2025-04-27 05:22:12 --> Config Class Initialized
INFO - 2025-04-27 05:22:12 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:22:12 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:22:12 --> Utf8 Class Initialized
INFO - 2025-04-27 05:22:12 --> URI Class Initialized
INFO - 2025-04-27 05:22:12 --> Router Class Initialized
INFO - 2025-04-27 05:22:12 --> Output Class Initialized
INFO - 2025-04-27 05:22:12 --> Security Class Initialized
DEBUG - 2025-04-27 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:22:12 --> Input Class Initialized
INFO - 2025-04-27 05:22:12 --> Language Class Initialized
INFO - 2025-04-27 05:22:12 --> Loader Class Initialized
INFO - 2025-04-27 05:22:12 --> Helper loaded: form_helper
INFO - 2025-04-27 05:22:12 --> Helper loaded: url_helper
INFO - 2025-04-27 05:22:12 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:22:12 --> Form Validation Class Initialized
INFO - 2025-04-27 05:22:12 --> Controller Class Initialized
INFO - 2025-04-27 05:22:12 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:22:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:22:12 --> Helper loaded: language_helper
INFO - 2025-04-27 05:22:12 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:22:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-04-27 05:22:12 --> Controller: Data POST dari form: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2001-04-30","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"Batang, 30 April 2001"}
DEBUG - 2025-04-27 05:22:12 --> Controller: Data yang akan dikirim ke model: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2001-04-30","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"Batang, 30 April 2001"}
DEBUG - 2025-04-27 05:22:12 --> Model: Data yang akan disimpan: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2001-04-30","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"Batang, 30 April 2001"}
ERROR - 2025-04-27 05:22:12 --> Query error: Table 'ppdb_manu_db.nama_tabel_pendaftaran' doesn't exist - Invalid query: INSERT INTO `nama_tabel_pendaftaran` (`rekomendasi`, `jalur_pendaftaran`, `pilihan_program`, `nama_siswa`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `no_hp_siswa`, `tempat_tanggal_lahir`) VALUES ('teman', 'reguler_umum', 'ips', 'Akhmad Lutfi', 'laki-laki', 'Batang', '2001-04-30', '085747110787', 'Batang, 30 April 2001')
INFO - 2025-04-27 05:22:12 --> Language file loaded: language/english/db_lang.php
INFO - 2025-04-27 05:26:11 --> Config Class Initialized
INFO - 2025-04-27 05:26:11 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:26:11 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:26:11 --> Utf8 Class Initialized
INFO - 2025-04-27 05:26:11 --> URI Class Initialized
INFO - 2025-04-27 05:26:11 --> Router Class Initialized
INFO - 2025-04-27 05:26:11 --> Output Class Initialized
INFO - 2025-04-27 05:26:11 --> Security Class Initialized
DEBUG - 2025-04-27 05:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:26:11 --> Input Class Initialized
INFO - 2025-04-27 05:26:11 --> Language Class Initialized
INFO - 2025-04-27 05:26:11 --> Loader Class Initialized
INFO - 2025-04-27 05:26:11 --> Helper loaded: form_helper
INFO - 2025-04-27 05:26:11 --> Helper loaded: url_helper
INFO - 2025-04-27 05:26:11 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:26:11 --> Form Validation Class Initialized
INFO - 2025-04-27 05:26:11 --> Controller Class Initialized
ERROR - 2025-04-27 05:26:11 --> Severity: Compile Error --> Cannot declare class Pendaftaran, because the name is already in use C:\xampp\htdocs\ppdb_manu\application\models\Pendaftaran_model.php 3
INFO - 2025-04-27 05:29:40 --> Config Class Initialized
INFO - 2025-04-27 05:29:40 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:29:40 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:29:40 --> Utf8 Class Initialized
INFO - 2025-04-27 05:29:40 --> URI Class Initialized
INFO - 2025-04-27 05:29:40 --> Router Class Initialized
INFO - 2025-04-27 05:29:40 --> Output Class Initialized
INFO - 2025-04-27 05:29:40 --> Security Class Initialized
DEBUG - 2025-04-27 05:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:29:40 --> Input Class Initialized
INFO - 2025-04-27 05:29:40 --> Language Class Initialized
INFO - 2025-04-27 05:29:40 --> Loader Class Initialized
INFO - 2025-04-27 05:29:40 --> Helper loaded: form_helper
INFO - 2025-04-27 05:29:40 --> Helper loaded: url_helper
INFO - 2025-04-27 05:29:40 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:29:40 --> Form Validation Class Initialized
INFO - 2025-04-27 05:29:40 --> Controller Class Initialized
INFO - 2025-04-27 05:29:40 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:29:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:29:40 --> Helper loaded: language_helper
INFO - 2025-04-27 05:29:40 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:29:40 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:29:40 --> Final output sent to browser
DEBUG - 2025-04-27 05:29:40 --> Total execution time: 0.0295
INFO - 2025-04-27 05:29:41 --> Config Class Initialized
INFO - 2025-04-27 05:29:41 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:29:41 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:29:41 --> Utf8 Class Initialized
INFO - 2025-04-27 05:29:41 --> URI Class Initialized
INFO - 2025-04-27 05:29:41 --> Router Class Initialized
INFO - 2025-04-27 05:29:41 --> Output Class Initialized
INFO - 2025-04-27 05:29:41 --> Security Class Initialized
DEBUG - 2025-04-27 05:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:29:41 --> Input Class Initialized
INFO - 2025-04-27 05:29:41 --> Language Class Initialized
INFO - 2025-04-27 05:29:41 --> Loader Class Initialized
INFO - 2025-04-27 05:29:41 --> Helper loaded: form_helper
INFO - 2025-04-27 05:29:41 --> Helper loaded: url_helper
INFO - 2025-04-27 05:29:41 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:29:41 --> Form Validation Class Initialized
INFO - 2025-04-27 05:29:41 --> Controller Class Initialized
INFO - 2025-04-27 05:29:41 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:29:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:29:41 --> Helper loaded: language_helper
INFO - 2025-04-27 05:29:41 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:29:41 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:29:41 --> Final output sent to browser
DEBUG - 2025-04-27 05:29:41 --> Total execution time: 0.0464
INFO - 2025-04-27 05:30:00 --> Config Class Initialized
INFO - 2025-04-27 05:30:00 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:30:00 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:30:00 --> Utf8 Class Initialized
INFO - 2025-04-27 05:30:00 --> URI Class Initialized
INFO - 2025-04-27 05:30:00 --> Router Class Initialized
INFO - 2025-04-27 05:30:00 --> Output Class Initialized
INFO - 2025-04-27 05:30:00 --> Security Class Initialized
DEBUG - 2025-04-27 05:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:30:00 --> Input Class Initialized
INFO - 2025-04-27 05:30:00 --> Language Class Initialized
INFO - 2025-04-27 05:30:00 --> Loader Class Initialized
INFO - 2025-04-27 05:30:00 --> Helper loaded: form_helper
INFO - 2025-04-27 05:30:00 --> Helper loaded: url_helper
INFO - 2025-04-27 05:30:00 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:30:00 --> Form Validation Class Initialized
INFO - 2025-04-27 05:30:00 --> Controller Class Initialized
INFO - 2025-04-27 05:30:00 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:30:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:30:00 --> Helper loaded: language_helper
INFO - 2025-04-27 05:30:00 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:30:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-04-27 05:30:00 --> Controller: Data POST dari form: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"mipa","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2001-01-01","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"Batang, 01 Januari 2001"}
DEBUG - 2025-04-27 05:30:00 --> Controller: Data yang akan dikirim ke model: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"mipa","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2001-01-01","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"Batang, 01 Januari 2001"}
DEBUG - 2025-04-27 05:30:00 --> Model: Data yang akan disimpan: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"mipa","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2001-01-01","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"Batang, 01 Januari 2001"}
DEBUG - 2025-04-27 05:30:00 --> Model: Hasil insert: 1
INFO - 2025-04-27 05:30:00 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_berhasil.php
INFO - 2025-04-27 05:30:00 --> Final output sent to browser
DEBUG - 2025-04-27 05:30:00 --> Total execution time: 0.0360
INFO - 2025-04-27 05:31:30 --> Config Class Initialized
INFO - 2025-04-27 05:31:30 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:31:30 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:31:30 --> Utf8 Class Initialized
INFO - 2025-04-27 05:31:30 --> URI Class Initialized
INFO - 2025-04-27 05:31:30 --> Router Class Initialized
INFO - 2025-04-27 05:31:30 --> Output Class Initialized
INFO - 2025-04-27 05:31:30 --> Security Class Initialized
DEBUG - 2025-04-27 05:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:31:30 --> Input Class Initialized
INFO - 2025-04-27 05:31:30 --> Language Class Initialized
INFO - 2025-04-27 05:31:30 --> Loader Class Initialized
INFO - 2025-04-27 05:31:30 --> Helper loaded: form_helper
INFO - 2025-04-27 05:31:30 --> Helper loaded: url_helper
INFO - 2025-04-27 05:31:30 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:31:30 --> Form Validation Class Initialized
INFO - 2025-04-27 05:31:30 --> Controller Class Initialized
INFO - 2025-04-27 05:31:30 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:31:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:31:30 --> Helper loaded: language_helper
INFO - 2025-04-27 05:31:30 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:31:30 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:31:30 --> Final output sent to browser
DEBUG - 2025-04-27 05:31:30 --> Total execution time: 0.0304
INFO - 2025-04-27 05:34:11 --> Config Class Initialized
INFO - 2025-04-27 05:34:11 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:34:11 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:34:11 --> Utf8 Class Initialized
INFO - 2025-04-27 05:34:11 --> URI Class Initialized
INFO - 2025-04-27 05:34:11 --> Router Class Initialized
INFO - 2025-04-27 05:34:11 --> Output Class Initialized
INFO - 2025-04-27 05:34:11 --> Security Class Initialized
DEBUG - 2025-04-27 05:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:34:11 --> Input Class Initialized
INFO - 2025-04-27 05:34:11 --> Language Class Initialized
INFO - 2025-04-27 05:34:11 --> Loader Class Initialized
INFO - 2025-04-27 05:34:11 --> Helper loaded: form_helper
INFO - 2025-04-27 05:34:12 --> Helper loaded: url_helper
INFO - 2025-04-27 05:34:12 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:34:12 --> Form Validation Class Initialized
INFO - 2025-04-27 05:34:12 --> Controller Class Initialized
INFO - 2025-04-27 05:34:12 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:34:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:34:12 --> Helper loaded: language_helper
INFO - 2025-04-27 05:34:12 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:34:12 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:34:12 --> Final output sent to browser
DEBUG - 2025-04-27 05:34:12 --> Total execution time: 0.0467
INFO - 2025-04-27 05:35:53 --> Config Class Initialized
INFO - 2025-04-27 05:35:53 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:35:53 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:35:53 --> Utf8 Class Initialized
INFO - 2025-04-27 05:35:53 --> URI Class Initialized
INFO - 2025-04-27 05:35:53 --> Router Class Initialized
INFO - 2025-04-27 05:35:53 --> Output Class Initialized
INFO - 2025-04-27 05:35:53 --> Security Class Initialized
DEBUG - 2025-04-27 05:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:35:53 --> Input Class Initialized
INFO - 2025-04-27 05:35:53 --> Language Class Initialized
INFO - 2025-04-27 05:35:53 --> Loader Class Initialized
INFO - 2025-04-27 05:35:53 --> Helper loaded: form_helper
INFO - 2025-04-27 05:35:53 --> Helper loaded: url_helper
INFO - 2025-04-27 05:35:53 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:35:53 --> Form Validation Class Initialized
INFO - 2025-04-27 05:35:53 --> Controller Class Initialized
INFO - 2025-04-27 05:35:53 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:35:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:35:53 --> Helper loaded: language_helper
INFO - 2025-04-27 05:35:53 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:35:53 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:35:53 --> Final output sent to browser
DEBUG - 2025-04-27 05:35:53 --> Total execution time: 0.0453
INFO - 2025-04-27 05:38:16 --> Config Class Initialized
INFO - 2025-04-27 05:38:16 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:38:16 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:38:16 --> Utf8 Class Initialized
INFO - 2025-04-27 05:38:16 --> URI Class Initialized
INFO - 2025-04-27 05:38:16 --> Router Class Initialized
INFO - 2025-04-27 05:38:16 --> Output Class Initialized
INFO - 2025-04-27 05:38:16 --> Security Class Initialized
DEBUG - 2025-04-27 05:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:38:16 --> Input Class Initialized
INFO - 2025-04-27 05:38:16 --> Language Class Initialized
INFO - 2025-04-27 05:38:16 --> Loader Class Initialized
INFO - 2025-04-27 05:38:16 --> Helper loaded: form_helper
INFO - 2025-04-27 05:38:16 --> Helper loaded: url_helper
INFO - 2025-04-27 05:38:16 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:38:16 --> Form Validation Class Initialized
INFO - 2025-04-27 05:38:16 --> Controller Class Initialized
INFO - 2025-04-27 05:38:16 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:38:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:38:16 --> Helper loaded: language_helper
INFO - 2025-04-27 05:38:16 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:38:16 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:38:16 --> Final output sent to browser
DEBUG - 2025-04-27 05:38:16 --> Total execution time: 0.0359
INFO - 2025-04-27 05:38:55 --> Config Class Initialized
INFO - 2025-04-27 05:38:55 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:38:55 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:38:55 --> Utf8 Class Initialized
INFO - 2025-04-27 05:38:55 --> URI Class Initialized
INFO - 2025-04-27 05:38:55 --> Router Class Initialized
INFO - 2025-04-27 05:38:55 --> Output Class Initialized
INFO - 2025-04-27 05:38:55 --> Security Class Initialized
DEBUG - 2025-04-27 05:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:38:55 --> Input Class Initialized
INFO - 2025-04-27 05:38:55 --> Language Class Initialized
ERROR - 2025-04-27 05:38:55 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\ppdb_manu\application\controllers\Pendaftaran.php 30
INFO - 2025-04-27 05:39:54 --> Config Class Initialized
INFO - 2025-04-27 05:39:54 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:39:54 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:39:54 --> Utf8 Class Initialized
INFO - 2025-04-27 05:39:54 --> URI Class Initialized
INFO - 2025-04-27 05:39:54 --> Router Class Initialized
INFO - 2025-04-27 05:39:54 --> Output Class Initialized
INFO - 2025-04-27 05:39:54 --> Security Class Initialized
DEBUG - 2025-04-27 05:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:39:54 --> Input Class Initialized
INFO - 2025-04-27 05:39:54 --> Language Class Initialized
ERROR - 2025-04-27 05:39:54 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\ppdb_manu\application\controllers\Pendaftaran.php 30
INFO - 2025-04-27 05:39:55 --> Config Class Initialized
INFO - 2025-04-27 05:39:55 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:39:55 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:39:55 --> Utf8 Class Initialized
INFO - 2025-04-27 05:39:55 --> URI Class Initialized
INFO - 2025-04-27 05:39:55 --> Router Class Initialized
INFO - 2025-04-27 05:39:55 --> Output Class Initialized
INFO - 2025-04-27 05:39:55 --> Security Class Initialized
DEBUG - 2025-04-27 05:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:39:55 --> Input Class Initialized
INFO - 2025-04-27 05:39:55 --> Language Class Initialized
ERROR - 2025-04-27 05:39:55 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\ppdb_manu\application\controllers\Pendaftaran.php 30
INFO - 2025-04-27 05:44:19 --> Config Class Initialized
INFO - 2025-04-27 05:44:19 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:44:19 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:44:19 --> Utf8 Class Initialized
INFO - 2025-04-27 05:44:19 --> URI Class Initialized
INFO - 2025-04-27 05:44:19 --> Router Class Initialized
INFO - 2025-04-27 05:44:19 --> Output Class Initialized
INFO - 2025-04-27 05:44:19 --> Security Class Initialized
DEBUG - 2025-04-27 05:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:44:19 --> Input Class Initialized
INFO - 2025-04-27 05:44:19 --> Language Class Initialized
ERROR - 2025-04-27 05:44:19 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\ppdb_manu\application\controllers\Pendaftaran.php 30
INFO - 2025-04-27 05:45:27 --> Config Class Initialized
INFO - 2025-04-27 05:45:27 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:45:27 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:45:27 --> Utf8 Class Initialized
INFO - 2025-04-27 05:45:27 --> URI Class Initialized
INFO - 2025-04-27 05:45:27 --> Router Class Initialized
INFO - 2025-04-27 05:45:27 --> Output Class Initialized
INFO - 2025-04-27 05:45:27 --> Security Class Initialized
DEBUG - 2025-04-27 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:45:27 --> Input Class Initialized
INFO - 2025-04-27 05:45:27 --> Language Class Initialized
ERROR - 2025-04-27 05:45:27 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\ppdb_manu\application\controllers\Pendaftaran.php 30
INFO - 2025-04-27 05:46:32 --> Config Class Initialized
INFO - 2025-04-27 05:46:32 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:46:32 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:46:32 --> Utf8 Class Initialized
INFO - 2025-04-27 05:46:32 --> URI Class Initialized
INFO - 2025-04-27 05:46:32 --> Router Class Initialized
INFO - 2025-04-27 05:46:32 --> Output Class Initialized
INFO - 2025-04-27 05:46:32 --> Security Class Initialized
DEBUG - 2025-04-27 05:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:46:32 --> Input Class Initialized
INFO - 2025-04-27 05:46:32 --> Language Class Initialized
INFO - 2025-04-27 05:46:32 --> Loader Class Initialized
INFO - 2025-04-27 05:46:32 --> Helper loaded: form_helper
INFO - 2025-04-27 05:46:32 --> Helper loaded: url_helper
INFO - 2025-04-27 05:46:32 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:46:32 --> Form Validation Class Initialized
INFO - 2025-04-27 05:46:32 --> Controller Class Initialized
INFO - 2025-04-27 05:46:32 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:46:32 --> Helper loaded: language_helper
INFO - 2025-04-27 05:46:32 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:46:32 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:46:32 --> Final output sent to browser
DEBUG - 2025-04-27 05:46:32 --> Total execution time: 0.0475
INFO - 2025-04-27 05:46:51 --> Config Class Initialized
INFO - 2025-04-27 05:46:51 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:46:51 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:46:51 --> Utf8 Class Initialized
INFO - 2025-04-27 05:46:51 --> URI Class Initialized
INFO - 2025-04-27 05:46:51 --> Router Class Initialized
INFO - 2025-04-27 05:46:51 --> Output Class Initialized
INFO - 2025-04-27 05:46:52 --> Security Class Initialized
DEBUG - 2025-04-27 05:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:46:52 --> Input Class Initialized
INFO - 2025-04-27 05:46:52 --> Language Class Initialized
INFO - 2025-04-27 05:46:52 --> Loader Class Initialized
INFO - 2025-04-27 05:46:52 --> Helper loaded: form_helper
INFO - 2025-04-27 05:46:52 --> Helper loaded: url_helper
INFO - 2025-04-27 05:46:52 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:46:52 --> Form Validation Class Initialized
INFO - 2025-04-27 05:46:52 --> Controller Class Initialized
INFO - 2025-04-27 05:46:52 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:46:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:46:52 --> Helper loaded: language_helper
INFO - 2025-04-27 05:46:52 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:46:52 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:46:52 --> Final output sent to browser
DEBUG - 2025-04-27 05:46:52 --> Total execution time: 0.0446
INFO - 2025-04-27 05:48:14 --> Config Class Initialized
INFO - 2025-04-27 05:48:14 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:48:14 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:48:14 --> Utf8 Class Initialized
INFO - 2025-04-27 05:48:14 --> URI Class Initialized
INFO - 2025-04-27 05:48:14 --> Router Class Initialized
INFO - 2025-04-27 05:48:14 --> Output Class Initialized
INFO - 2025-04-27 05:48:14 --> Security Class Initialized
DEBUG - 2025-04-27 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:48:14 --> Input Class Initialized
INFO - 2025-04-27 05:48:14 --> Language Class Initialized
INFO - 2025-04-27 05:48:14 --> Loader Class Initialized
INFO - 2025-04-27 05:48:14 --> Helper loaded: form_helper
INFO - 2025-04-27 05:48:14 --> Helper loaded: url_helper
INFO - 2025-04-27 05:48:14 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:48:14 --> Form Validation Class Initialized
INFO - 2025-04-27 05:48:14 --> Controller Class Initialized
INFO - 2025-04-27 05:48:14 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:48:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:48:14 --> Helper loaded: language_helper
INFO - 2025-04-27 05:48:14 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:48:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-04-27 05:48:14 --> Controller: Data POST dari form: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2002-01-01","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"Batang, 01 Jan 2002","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"adilko","desa":"rowosari","rt":"003","rw":"004","kecamatan":"limpung","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"adilko, Desa rowosari, RT 003\/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah","nama_ayah":"ayahku","nama_ibu":"ibuku","pendidikan_ayah":"s2","pekerjaan_ayah":"BUTRUH","no_hp_ayah":"085747110787","pendidikan_ibu":"d1","pekerjaan_ibu":"ewewewe","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"punya","nama_wali":"FAHRUTORI","hubungan_wali":"AYAH","pendidikan_wali":"smp","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"MTS NH","alamat_sekolah":"Banyuputih","nisn":"","piagam":"tidak_punya","motivasi":"piongin "}
DEBUG - 2025-04-27 05:48:14 --> Controller: Data yang akan dikirim ke model: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2002-01-01","tempat_tanggal_lahir":"Batang, 01 Jan 2002","no_hp_siswa":"085747110787","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"adilko","desa":"rowosari","rt":"003","rw":"004","kecamatan":"limpung","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"adilko, Desa rowosari, RT 003\/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah","nama_ayah":"ayahku","pendidikan_ayah":"s2","pekerjaan_ayah":"BUTRUH","no_hp_ayah":"085747110787","nama_ibu":"ibuku","pendidikan_ibu":"d1","pekerjaan_ibu":"ewewewe","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"punya","nama_wali":"FAHRUTORI","hubungan_wali":"AYAH","pendidikan_wali":"smp","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"MTS NH","alamat_sekolah":"Banyuputih","nisn":"","piagam":"tidak_punya","motivasi":"piongin ","tanggal_daftar":"2025-04-27 05:48:14","status":"baru"}
DEBUG - 2025-04-27 05:48:14 --> Model: Data yang akan disimpan: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2002-01-01","tempat_tanggal_lahir":"Batang, 01 Jan 2002","no_hp_siswa":"085747110787","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"adilko","desa":"rowosari","rt":"003","rw":"004","kecamatan":"limpung","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"adilko, Desa rowosari, RT 003\/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah","nama_ayah":"ayahku","pendidikan_ayah":"s2","pekerjaan_ayah":"BUTRUH","no_hp_ayah":"085747110787","nama_ibu":"ibuku","pendidikan_ibu":"d1","pekerjaan_ibu":"ewewewe","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"punya","nama_wali":"FAHRUTORI","hubungan_wali":"AYAH","pendidikan_wali":"smp","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"MTS NH","alamat_sekolah":"Banyuputih","nisn":"","piagam":"tidak_punya","motivasi":"piongin ","tanggal_daftar":"2025-04-27 05:48:14","status":"baru"}
ERROR - 2025-04-27 05:48:14 --> Query error: Unknown column 'tanggal_daftar' in 'field list' - Invalid query: INSERT INTO `pendaftaran` (`rekomendasi`, `jalur_pendaftaran`, `pilihan_program`, `nama_siswa`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `tempat_tanggal_lahir`, `no_hp_siswa`, `tinggal`, `tinggal_lainnya`, `dukuh`, `desa`, `rt`, `rw`, `kecamatan`, `kabupaten`, `provinsi`, `alamat_lengkap`, `nama_ayah`, `pendidikan_ayah`, `pekerjaan_ayah`, `no_hp_ayah`, `nama_ibu`, `pendidikan_ibu`, `pekerjaan_ibu`, `no_hp_ibu`, `alamat_ortu`, `saudara_sekolah`, `nama_wali`, `hubungan_wali`, `pendidikan_wali`, `pekerjaan_wali`, `no_hp_wali`, `alamat_wali`, `nama_sekolah`, `alamat_sekolah`, `nisn`, `piagam`, `motivasi`, `tanggal_daftar`, `status`) VALUES ('teman', 'reguler_umum', 'ips', 'Akhmad Lutfi', 'laki-laki', 'Batang', '2002-01-01', 'Batang, 01 Jan 2002', '085747110787', 'bersama_ortu', '', 'adilko', 'rowosari', '003', '004', 'limpung', 'Batang', 'Jawa Tengah', 'adilko, Desa rowosari, RT 003/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah', 'ayahku', 's2', 'BUTRUH', '085747110787', 'ibuku', 'd1', 'ewewewe', '085747110787', 'Dukuh Adiloko Desa Rowosari', 'punya', 'FAHRUTORI', 'AYAH', 'smp', 'BURUH', '085747110787', 'Dukuh Adiloko Desa Rowosari', 'MTS NH', 'Banyuputih', '', 'tidak_punya', 'piongin ', '2025-04-27 05:48:14', 'baru')
INFO - 2025-04-27 05:48:14 --> Language file loaded: language/english/db_lang.php
INFO - 2025-04-27 05:52:18 --> Config Class Initialized
INFO - 2025-04-27 05:52:18 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:52:18 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:52:18 --> Utf8 Class Initialized
INFO - 2025-04-27 05:52:18 --> URI Class Initialized
INFO - 2025-04-27 05:52:18 --> Router Class Initialized
INFO - 2025-04-27 05:52:18 --> Output Class Initialized
INFO - 2025-04-27 05:52:18 --> Security Class Initialized
DEBUG - 2025-04-27 05:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:52:18 --> Input Class Initialized
INFO - 2025-04-27 05:52:18 --> Language Class Initialized
INFO - 2025-04-27 05:52:18 --> Loader Class Initialized
INFO - 2025-04-27 05:52:18 --> Helper loaded: form_helper
INFO - 2025-04-27 05:52:18 --> Helper loaded: url_helper
INFO - 2025-04-27 05:52:18 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:52:18 --> Form Validation Class Initialized
INFO - 2025-04-27 05:52:18 --> Controller Class Initialized
INFO - 2025-04-27 05:52:18 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:52:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:52:18 --> Helper loaded: language_helper
INFO - 2025-04-27 05:52:18 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:52:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-04-27 05:52:18 --> Controller: Data POST dari form: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2002-01-01","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"Batang, 01 Jan 2002","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"adilko","desa":"rowosari","rt":"003","rw":"004","kecamatan":"limpung","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"adilko, Desa rowosari, RT 003\/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah","nama_ayah":"ayahku","nama_ibu":"ibuku","pendidikan_ayah":"s2","pekerjaan_ayah":"BUTRUH","no_hp_ayah":"085747110787","pendidikan_ibu":"d1","pekerjaan_ibu":"ewewewe","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"punya","nama_wali":"FAHRUTORI","hubungan_wali":"AYAH","pendidikan_wali":"smp","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"MTS NH","alamat_sekolah":"Banyuputih","nisn":"","piagam":"tidak_punya","motivasi":"piongin "}
DEBUG - 2025-04-27 05:52:18 --> Controller: Data yang akan dikirim ke model: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2002-01-01","tempat_tanggal_lahir":"Batang, 01 Jan 2002","no_hp_siswa":"085747110787","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"adilko","desa":"rowosari","rt":"003","rw":"004","kecamatan":"limpung","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"adilko, Desa rowosari, RT 003\/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah","nama_ayah":"ayahku","pendidikan_ayah":"s2","pekerjaan_ayah":"BUTRUH","no_hp_ayah":"085747110787","nama_ibu":"ibuku","pendidikan_ibu":"d1","pekerjaan_ibu":"ewewewe","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"punya","nama_wali":"FAHRUTORI","hubungan_wali":"AYAH","pendidikan_wali":"smp","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"MTS NH","alamat_sekolah":"Banyuputih","nisn":"","piagam":"tidak_punya","motivasi":"piongin "}
DEBUG - 2025-04-27 05:52:18 --> Model: Data yang akan disimpan: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"Akhmad Lutfi","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2002-01-01","tempat_tanggal_lahir":"Batang, 01 Jan 2002","no_hp_siswa":"085747110787","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"adilko","desa":"rowosari","rt":"003","rw":"004","kecamatan":"limpung","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"adilko, Desa rowosari, RT 003\/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah","nama_ayah":"ayahku","pendidikan_ayah":"s2","pekerjaan_ayah":"BUTRUH","no_hp_ayah":"085747110787","nama_ibu":"ibuku","pendidikan_ibu":"d1","pekerjaan_ibu":"ewewewe","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"punya","nama_wali":"FAHRUTORI","hubungan_wali":"AYAH","pendidikan_wali":"smp","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"MTS NH","alamat_sekolah":"Banyuputih","nisn":"","piagam":"tidak_punya","motivasi":"piongin "}
DEBUG - 2025-04-27 05:52:18 --> Model: Hasil insert: 1
INFO - 2025-04-27 05:52:18 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_berhasil.php
INFO - 2025-04-27 05:52:18 --> Final output sent to browser
DEBUG - 2025-04-27 05:52:18 --> Total execution time: 0.0722
INFO - 2025-04-27 05:52:20 --> Config Class Initialized
INFO - 2025-04-27 05:52:20 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:52:20 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:52:20 --> Utf8 Class Initialized
INFO - 2025-04-27 05:52:20 --> URI Class Initialized
INFO - 2025-04-27 05:52:20 --> Router Class Initialized
INFO - 2025-04-27 05:52:20 --> Output Class Initialized
INFO - 2025-04-27 05:52:20 --> Security Class Initialized
DEBUG - 2025-04-27 05:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:52:20 --> Input Class Initialized
INFO - 2025-04-27 05:52:20 --> Language Class Initialized
INFO - 2025-04-27 05:52:20 --> Loader Class Initialized
INFO - 2025-04-27 05:52:20 --> Helper loaded: form_helper
INFO - 2025-04-27 05:52:20 --> Helper loaded: url_helper
INFO - 2025-04-27 05:52:20 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:52:20 --> Form Validation Class Initialized
INFO - 2025-04-27 05:52:20 --> Controller Class Initialized
INFO - 2025-04-27 05:52:20 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:52:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:52:20 --> Helper loaded: language_helper
INFO - 2025-04-27 05:52:20 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:52:20 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:52:20 --> Final output sent to browser
DEBUG - 2025-04-27 05:52:20 --> Total execution time: 0.0297
INFO - 2025-04-27 05:53:10 --> Config Class Initialized
INFO - 2025-04-27 05:53:10 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:53:10 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:53:10 --> Utf8 Class Initialized
INFO - 2025-04-27 05:53:10 --> URI Class Initialized
INFO - 2025-04-27 05:53:10 --> Router Class Initialized
INFO - 2025-04-27 05:53:10 --> Output Class Initialized
INFO - 2025-04-27 05:53:10 --> Security Class Initialized
DEBUG - 2025-04-27 05:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:53:10 --> Input Class Initialized
INFO - 2025-04-27 05:53:10 --> Language Class Initialized
INFO - 2025-04-27 05:53:10 --> Loader Class Initialized
INFO - 2025-04-27 05:53:10 --> Helper loaded: form_helper
INFO - 2025-04-27 05:53:10 --> Helper loaded: url_helper
INFO - 2025-04-27 05:53:10 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:53:10 --> Form Validation Class Initialized
INFO - 2025-04-27 05:53:10 --> Controller Class Initialized
INFO - 2025-04-27 05:53:10 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:53:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:53:10 --> Helper loaded: language_helper
INFO - 2025-04-27 05:53:10 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:53:10 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:53:10 --> Final output sent to browser
DEBUG - 2025-04-27 05:53:10 --> Total execution time: 0.0485
INFO - 2025-04-27 05:53:57 --> Config Class Initialized
INFO - 2025-04-27 05:53:57 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:53:57 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:53:57 --> Utf8 Class Initialized
INFO - 2025-04-27 05:53:57 --> URI Class Initialized
INFO - 2025-04-27 05:53:57 --> Router Class Initialized
INFO - 2025-04-27 05:53:57 --> Output Class Initialized
INFO - 2025-04-27 05:53:57 --> Security Class Initialized
DEBUG - 2025-04-27 05:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:53:57 --> Input Class Initialized
INFO - 2025-04-27 05:53:57 --> Language Class Initialized
INFO - 2025-04-27 05:53:57 --> Loader Class Initialized
INFO - 2025-04-27 05:53:57 --> Helper loaded: form_helper
INFO - 2025-04-27 05:53:57 --> Helper loaded: url_helper
INFO - 2025-04-27 05:53:57 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:53:57 --> Form Validation Class Initialized
INFO - 2025-04-27 05:53:57 --> Controller Class Initialized
INFO - 2025-04-27 05:53:57 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:53:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:53:57 --> Helper loaded: language_helper
INFO - 2025-04-27 05:53:57 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:53:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-27 05:53:57 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:53:57 --> Final output sent to browser
DEBUG - 2025-04-27 05:53:57 --> Total execution time: 0.0325
INFO - 2025-04-27 05:57:05 --> Config Class Initialized
INFO - 2025-04-27 05:57:05 --> Hooks Class Initialized
DEBUG - 2025-04-27 05:57:05 --> UTF-8 Support Enabled
INFO - 2025-04-27 05:57:05 --> Utf8 Class Initialized
INFO - 2025-04-27 05:57:05 --> URI Class Initialized
INFO - 2025-04-27 05:57:05 --> Router Class Initialized
INFO - 2025-04-27 05:57:05 --> Output Class Initialized
INFO - 2025-04-27 05:57:05 --> Security Class Initialized
DEBUG - 2025-04-27 05:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 05:57:05 --> Input Class Initialized
INFO - 2025-04-27 05:57:05 --> Language Class Initialized
INFO - 2025-04-27 05:57:05 --> Loader Class Initialized
INFO - 2025-04-27 05:57:05 --> Helper loaded: form_helper
INFO - 2025-04-27 05:57:05 --> Helper loaded: url_helper
INFO - 2025-04-27 05:57:05 --> Database Driver Class Initialized
DEBUG - 2025-04-27 05:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 05:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 05:57:05 --> Form Validation Class Initialized
INFO - 2025-04-27 05:57:05 --> Controller Class Initialized
INFO - 2025-04-27 05:57:05 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 05:57:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 05:57:05 --> Helper loaded: language_helper
INFO - 2025-04-27 05:57:05 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 05:57:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-27 05:57:05 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 05:57:05 --> Final output sent to browser
DEBUG - 2025-04-27 05:57:05 --> Total execution time: 0.0307
INFO - 2025-04-27 06:09:18 --> Config Class Initialized
INFO - 2025-04-27 06:09:18 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:09:18 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:09:18 --> Utf8 Class Initialized
INFO - 2025-04-27 06:09:18 --> URI Class Initialized
INFO - 2025-04-27 06:09:18 --> Router Class Initialized
INFO - 2025-04-27 06:09:18 --> Output Class Initialized
INFO - 2025-04-27 06:09:18 --> Security Class Initialized
DEBUG - 2025-04-27 06:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:09:18 --> Input Class Initialized
INFO - 2025-04-27 06:09:18 --> Language Class Initialized
INFO - 2025-04-27 06:09:18 --> Loader Class Initialized
INFO - 2025-04-27 06:09:18 --> Helper loaded: form_helper
INFO - 2025-04-27 06:09:18 --> Helper loaded: url_helper
INFO - 2025-04-27 06:09:18 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:09:18 --> Form Validation Class Initialized
INFO - 2025-04-27 06:09:18 --> Controller Class Initialized
INFO - 2025-04-27 06:09:18 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:09:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:09:18 --> Helper loaded: language_helper
INFO - 2025-04-27 06:09:18 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:09:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-27 06:09:18 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:09:18 --> Final output sent to browser
DEBUG - 2025-04-27 06:09:18 --> Total execution time: 0.0576
INFO - 2025-04-27 06:09:21 --> Config Class Initialized
INFO - 2025-04-27 06:09:21 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:09:21 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:09:21 --> Utf8 Class Initialized
INFO - 2025-04-27 06:09:21 --> URI Class Initialized
INFO - 2025-04-27 06:09:21 --> Router Class Initialized
INFO - 2025-04-27 06:09:21 --> Output Class Initialized
INFO - 2025-04-27 06:09:21 --> Security Class Initialized
DEBUG - 2025-04-27 06:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:09:21 --> Input Class Initialized
INFO - 2025-04-27 06:09:21 --> Language Class Initialized
INFO - 2025-04-27 06:09:21 --> Loader Class Initialized
INFO - 2025-04-27 06:09:21 --> Helper loaded: form_helper
INFO - 2025-04-27 06:09:21 --> Helper loaded: url_helper
INFO - 2025-04-27 06:09:21 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:09:21 --> Form Validation Class Initialized
INFO - 2025-04-27 06:09:21 --> Controller Class Initialized
INFO - 2025-04-27 06:09:21 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:09:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:09:21 --> Helper loaded: language_helper
INFO - 2025-04-27 06:09:21 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:09:21 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:09:21 --> Final output sent to browser
DEBUG - 2025-04-27 06:09:21 --> Total execution time: 0.0581
INFO - 2025-04-27 06:10:28 --> Config Class Initialized
INFO - 2025-04-27 06:10:28 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:10:28 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:10:28 --> Utf8 Class Initialized
INFO - 2025-04-27 06:10:28 --> URI Class Initialized
INFO - 2025-04-27 06:10:28 --> Router Class Initialized
INFO - 2025-04-27 06:10:28 --> Output Class Initialized
INFO - 2025-04-27 06:10:28 --> Security Class Initialized
DEBUG - 2025-04-27 06:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:10:28 --> Input Class Initialized
INFO - 2025-04-27 06:10:28 --> Language Class Initialized
INFO - 2025-04-27 06:10:28 --> Loader Class Initialized
INFO - 2025-04-27 06:10:28 --> Helper loaded: form_helper
INFO - 2025-04-27 06:10:28 --> Helper loaded: url_helper
INFO - 2025-04-27 06:10:28 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:10:28 --> Form Validation Class Initialized
INFO - 2025-04-27 06:10:28 --> Controller Class Initialized
INFO - 2025-04-27 06:10:28 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:10:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:10:28 --> Helper loaded: language_helper
INFO - 2025-04-27 06:10:28 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:10:28 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:10:28 --> Final output sent to browser
DEBUG - 2025-04-27 06:10:28 --> Total execution time: 0.0464
INFO - 2025-04-27 06:10:36 --> Config Class Initialized
INFO - 2025-04-27 06:10:36 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:10:36 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:10:36 --> Utf8 Class Initialized
INFO - 2025-04-27 06:10:36 --> URI Class Initialized
INFO - 2025-04-27 06:10:36 --> Router Class Initialized
INFO - 2025-04-27 06:10:36 --> Output Class Initialized
INFO - 2025-04-27 06:10:36 --> Security Class Initialized
DEBUG - 2025-04-27 06:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:10:36 --> Input Class Initialized
INFO - 2025-04-27 06:10:36 --> Language Class Initialized
INFO - 2025-04-27 06:10:36 --> Loader Class Initialized
INFO - 2025-04-27 06:10:36 --> Helper loaded: form_helper
INFO - 2025-04-27 06:10:36 --> Helper loaded: url_helper
INFO - 2025-04-27 06:10:36 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:10:36 --> Form Validation Class Initialized
INFO - 2025-04-27 06:10:36 --> Controller Class Initialized
INFO - 2025-04-27 06:10:36 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:10:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:10:36 --> Helper loaded: language_helper
INFO - 2025-04-27 06:10:36 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:10:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-27 06:10:36 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:10:36 --> Final output sent to browser
DEBUG - 2025-04-27 06:10:36 --> Total execution time: 0.0370
INFO - 2025-04-27 06:10:59 --> Config Class Initialized
INFO - 2025-04-27 06:10:59 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:10:59 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:10:59 --> Utf8 Class Initialized
INFO - 2025-04-27 06:10:59 --> URI Class Initialized
INFO - 2025-04-27 06:10:59 --> Router Class Initialized
INFO - 2025-04-27 06:10:59 --> Output Class Initialized
INFO - 2025-04-27 06:10:59 --> Security Class Initialized
DEBUG - 2025-04-27 06:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:10:59 --> Input Class Initialized
INFO - 2025-04-27 06:10:59 --> Language Class Initialized
INFO - 2025-04-27 06:10:59 --> Loader Class Initialized
INFO - 2025-04-27 06:10:59 --> Helper loaded: form_helper
INFO - 2025-04-27 06:10:59 --> Helper loaded: url_helper
INFO - 2025-04-27 06:10:59 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:10:59 --> Form Validation Class Initialized
INFO - 2025-04-27 06:10:59 --> Controller Class Initialized
INFO - 2025-04-27 06:10:59 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:10:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:10:59 --> Helper loaded: language_helper
INFO - 2025-04-27 06:10:59 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:10:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-27 06:10:59 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:10:59 --> Final output sent to browser
DEBUG - 2025-04-27 06:10:59 --> Total execution time: 0.0324
INFO - 2025-04-27 06:12:00 --> Config Class Initialized
INFO - 2025-04-27 06:12:00 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:12:00 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:12:00 --> Utf8 Class Initialized
INFO - 2025-04-27 06:12:00 --> URI Class Initialized
INFO - 2025-04-27 06:12:00 --> Router Class Initialized
INFO - 2025-04-27 06:12:00 --> Output Class Initialized
INFO - 2025-04-27 06:12:00 --> Security Class Initialized
DEBUG - 2025-04-27 06:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:12:00 --> Input Class Initialized
INFO - 2025-04-27 06:12:00 --> Language Class Initialized
INFO - 2025-04-27 06:12:00 --> Loader Class Initialized
INFO - 2025-04-27 06:12:00 --> Helper loaded: form_helper
INFO - 2025-04-27 06:12:00 --> Helper loaded: url_helper
INFO - 2025-04-27 06:12:00 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:12:00 --> Form Validation Class Initialized
INFO - 2025-04-27 06:12:00 --> Controller Class Initialized
INFO - 2025-04-27 06:12:00 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:12:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:12:00 --> Helper loaded: language_helper
INFO - 2025-04-27 06:12:00 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:12:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-27 06:12:00 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:12:00 --> Final output sent to browser
DEBUG - 2025-04-27 06:12:00 --> Total execution time: 0.0544
INFO - 2025-04-27 06:15:28 --> Config Class Initialized
INFO - 2025-04-27 06:15:28 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:15:28 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:15:28 --> Utf8 Class Initialized
INFO - 2025-04-27 06:15:28 --> URI Class Initialized
INFO - 2025-04-27 06:15:28 --> Router Class Initialized
INFO - 2025-04-27 06:15:28 --> Output Class Initialized
INFO - 2025-04-27 06:15:28 --> Security Class Initialized
DEBUG - 2025-04-27 06:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:15:28 --> Input Class Initialized
INFO - 2025-04-27 06:15:28 --> Language Class Initialized
INFO - 2025-04-27 06:15:28 --> Loader Class Initialized
INFO - 2025-04-27 06:15:28 --> Helper loaded: form_helper
INFO - 2025-04-27 06:15:28 --> Helper loaded: url_helper
INFO - 2025-04-27 06:15:28 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:15:28 --> Form Validation Class Initialized
INFO - 2025-04-27 06:15:28 --> Controller Class Initialized
INFO - 2025-04-27 06:15:28 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:15:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:15:28 --> Helper loaded: language_helper
INFO - 2025-04-27 06:15:28 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:15:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-27 06:15:28 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:15:28 --> Final output sent to browser
DEBUG - 2025-04-27 06:15:28 --> Total execution time: 0.0435
INFO - 2025-04-27 06:15:43 --> Config Class Initialized
INFO - 2025-04-27 06:15:43 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:15:43 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:15:43 --> Utf8 Class Initialized
INFO - 2025-04-27 06:15:43 --> URI Class Initialized
INFO - 2025-04-27 06:15:43 --> Router Class Initialized
INFO - 2025-04-27 06:15:43 --> Output Class Initialized
INFO - 2025-04-27 06:15:43 --> Security Class Initialized
DEBUG - 2025-04-27 06:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:15:43 --> Input Class Initialized
INFO - 2025-04-27 06:15:43 --> Language Class Initialized
INFO - 2025-04-27 06:15:43 --> Loader Class Initialized
INFO - 2025-04-27 06:15:43 --> Helper loaded: form_helper
INFO - 2025-04-27 06:15:43 --> Helper loaded: url_helper
INFO - 2025-04-27 06:15:43 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:15:43 --> Form Validation Class Initialized
INFO - 2025-04-27 06:15:43 --> Controller Class Initialized
INFO - 2025-04-27 06:15:43 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:15:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:15:43 --> Helper loaded: language_helper
INFO - 2025-04-27 06:15:43 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:15:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-27 06:15:43 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:15:43 --> Final output sent to browser
DEBUG - 2025-04-27 06:15:43 --> Total execution time: 0.0347
INFO - 2025-04-27 06:15:54 --> Config Class Initialized
INFO - 2025-04-27 06:15:54 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:15:54 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:15:54 --> Utf8 Class Initialized
INFO - 2025-04-27 06:15:54 --> URI Class Initialized
INFO - 2025-04-27 06:15:54 --> Router Class Initialized
INFO - 2025-04-27 06:15:54 --> Output Class Initialized
INFO - 2025-04-27 06:15:54 --> Security Class Initialized
DEBUG - 2025-04-27 06:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:15:54 --> Input Class Initialized
INFO - 2025-04-27 06:15:54 --> Language Class Initialized
INFO - 2025-04-27 06:15:54 --> Loader Class Initialized
INFO - 2025-04-27 06:15:54 --> Helper loaded: form_helper
INFO - 2025-04-27 06:15:54 --> Helper loaded: url_helper
INFO - 2025-04-27 06:15:54 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:15:54 --> Form Validation Class Initialized
INFO - 2025-04-27 06:15:54 --> Controller Class Initialized
INFO - 2025-04-27 06:15:54 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:15:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:15:54 --> Helper loaded: language_helper
INFO - 2025-04-27 06:15:54 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:15:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-04-27 06:15:54 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:15:54 --> Final output sent to browser
DEBUG - 2025-04-27 06:15:54 --> Total execution time: 0.0360
INFO - 2025-04-27 06:16:00 --> Config Class Initialized
INFO - 2025-04-27 06:16:00 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:16:00 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:16:00 --> Utf8 Class Initialized
INFO - 2025-04-27 06:16:00 --> URI Class Initialized
INFO - 2025-04-27 06:16:00 --> Router Class Initialized
INFO - 2025-04-27 06:16:00 --> Output Class Initialized
INFO - 2025-04-27 06:16:00 --> Security Class Initialized
DEBUG - 2025-04-27 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:16:00 --> Input Class Initialized
INFO - 2025-04-27 06:16:00 --> Language Class Initialized
INFO - 2025-04-27 06:16:00 --> Loader Class Initialized
INFO - 2025-04-27 06:16:00 --> Helper loaded: form_helper
INFO - 2025-04-27 06:16:00 --> Helper loaded: url_helper
INFO - 2025-04-27 06:16:00 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:16:00 --> Form Validation Class Initialized
INFO - 2025-04-27 06:16:00 --> Controller Class Initialized
INFO - 2025-04-27 06:16:00 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:16:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:16:00 --> Helper loaded: language_helper
INFO - 2025-04-27 06:16:00 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:16:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-04-27 06:16:00 --> Controller: Data POST dari form: {"rekomendasi":"zakia Rahmawati 10.8","jalur_pendaftaran":"reguler_sosial","pilihan_program":"ips","nama_siswa":"DEWI KARTIKA SARI","jenis_kelamin":"perempuan","tempat_lahir":"Batang","tanggal_lahir":"2010-11-03","no_hp_siswa":"082326877593","tempat_tanggal_lahir":"Batang, 03 Nov 2010","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"Jatirejo ","desa":"Luwung ","rt":"02","rw":"03","kecamatan":"Banyuputih ","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"Jatirejo , Desa Luwung , RT 02\/RW 03, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","nama_ibu":"saripah","pendidikan_ayah":"sd","pekerjaan_ayah":"buruh","no_hp_ayah":"085747110787","pendidikan_ibu":"smp","pekerjaan_ibu":"IRT","no_hp_ibu":"085326822456","alamat_ortu":"jatirejo,luwung, Banyuputih,batang","saudara_sekolah":"tidak_punya","nama_wali":"-","hubungan_wali":"-","pendidikan_wali":"sd","pekerjaan_wali":"-","no_hp_wali":"-","alamat_wali":"-","nama_sekolah":"SMP N 02 LIMPUNG","alamat_sekolah":"Mojo","nisn":"","piagam":"tidak_punya","motivasi":"men pinter"}
DEBUG - 2025-04-27 06:16:00 --> Controller: Data yang akan dikirim ke model: {"rekomendasi":"zakia Rahmawati 10.8","jalur_pendaftaran":"reguler_sosial","pilihan_program":"ips","nama_siswa":"DEWI KARTIKA SARI","jenis_kelamin":"perempuan","tempat_lahir":"Batang","tanggal_lahir":"2010-11-03","tempat_tanggal_lahir":"Batang, 03 Nov 2010","no_hp_siswa":"082326877593","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"Jatirejo ","desa":"Luwung ","rt":"02","rw":"03","kecamatan":"Banyuputih ","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"Jatirejo , Desa Luwung , RT 02\/RW 03, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","pendidikan_ayah":"sd","pekerjaan_ayah":"buruh","no_hp_ayah":"085747110787","nama_ibu":"saripah","pendidikan_ibu":"smp","pekerjaan_ibu":"IRT","no_hp_ibu":"085326822456","alamat_ortu":"jatirejo,luwung, Banyuputih,batang","saudara_sekolah":"tidak_punya","nama_wali":"-","hubungan_wali":"-","pendidikan_wali":"sd","pekerjaan_wali":"-","no_hp_wali":"-","alamat_wali":"-","nama_sekolah":"SMP N 02 LIMPUNG","alamat_sekolah":"Mojo","nisn":"","piagam":"tidak_punya","motivasi":"men pinter","tanggal_daftar":"2025-04-27 06:16:00","status":"baru"}
DEBUG - 2025-04-27 06:16:00 --> Model: Data yang akan disimpan: {"rekomendasi":"zakia Rahmawati 10.8","jalur_pendaftaran":"reguler_sosial","pilihan_program":"ips","nama_siswa":"DEWI KARTIKA SARI","jenis_kelamin":"perempuan","tempat_lahir":"Batang","tanggal_lahir":"2010-11-03","tempat_tanggal_lahir":"Batang, 03 Nov 2010","no_hp_siswa":"082326877593","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"Jatirejo ","desa":"Luwung ","rt":"02","rw":"03","kecamatan":"Banyuputih ","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"Jatirejo , Desa Luwung , RT 02\/RW 03, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","pendidikan_ayah":"sd","pekerjaan_ayah":"buruh","no_hp_ayah":"085747110787","nama_ibu":"saripah","pendidikan_ibu":"smp","pekerjaan_ibu":"IRT","no_hp_ibu":"085326822456","alamat_ortu":"jatirejo,luwung, Banyuputih,batang","saudara_sekolah":"tidak_punya","nama_wali":"-","hubungan_wali":"-","pendidikan_wali":"sd","pekerjaan_wali":"-","no_hp_wali":"-","alamat_wali":"-","nama_sekolah":"SMP N 02 LIMPUNG","alamat_sekolah":"Mojo","nisn":"","piagam":"tidak_punya","motivasi":"men pinter","tanggal_daftar":"2025-04-27 06:16:00","status":"baru"}
ERROR - 2025-04-27 06:16:00 --> Query error: Unknown column 'status' in 'field list' - Invalid query: INSERT INTO `pendaftaran` (`rekomendasi`, `jalur_pendaftaran`, `pilihan_program`, `nama_siswa`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `tempat_tanggal_lahir`, `no_hp_siswa`, `tinggal`, `tinggal_lainnya`, `dukuh`, `desa`, `rt`, `rw`, `kecamatan`, `kabupaten`, `provinsi`, `alamat_lengkap`, `nama_ayah`, `pendidikan_ayah`, `pekerjaan_ayah`, `no_hp_ayah`, `nama_ibu`, `pendidikan_ibu`, `pekerjaan_ibu`, `no_hp_ibu`, `alamat_ortu`, `saudara_sekolah`, `nama_wali`, `hubungan_wali`, `pendidikan_wali`, `pekerjaan_wali`, `no_hp_wali`, `alamat_wali`, `nama_sekolah`, `alamat_sekolah`, `nisn`, `piagam`, `motivasi`, `tanggal_daftar`, `status`) VALUES ('zakia Rahmawati 10.8', 'reguler_sosial', 'ips', 'DEWI KARTIKA SARI', 'perempuan', 'Batang', '2010-11-03', 'Batang, 03 Nov 2010', '082326877593', 'bersama_ortu', '', 'Jatirejo ', 'Luwung ', '02', '03', 'Banyuputih ', 'Batang', 'Jawa Tengah', 'Jatirejo , Desa Luwung , RT 02/RW 03, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah', 'Nasrudin ', 'sd', 'buruh', '085747110787', 'saripah', 'smp', 'IRT', '085326822456', 'jatirejo,luwung, Banyuputih,batang', 'tidak_punya', '-', '-', 'sd', '-', '-', '-', 'SMP N 02 LIMPUNG', 'Mojo', '', 'tidak_punya', 'men pinter', '2025-04-27 06:16:00', 'baru')
DEBUG - 2025-04-27 06:16:00 --> DB Transaction Failure
INFO - 2025-04-27 06:16:00 --> Language file loaded: language/english/db_lang.php
INFO - 2025-04-27 06:20:22 --> Config Class Initialized
INFO - 2025-04-27 06:20:22 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:20:22 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:20:22 --> Utf8 Class Initialized
INFO - 2025-04-27 06:20:22 --> URI Class Initialized
INFO - 2025-04-27 06:20:22 --> Router Class Initialized
INFO - 2025-04-27 06:20:22 --> Output Class Initialized
INFO - 2025-04-27 06:20:22 --> Security Class Initialized
DEBUG - 2025-04-27 06:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:20:22 --> Input Class Initialized
INFO - 2025-04-27 06:20:22 --> Language Class Initialized
INFO - 2025-04-27 06:20:22 --> Loader Class Initialized
INFO - 2025-04-27 06:20:22 --> Helper loaded: form_helper
INFO - 2025-04-27 06:20:22 --> Helper loaded: url_helper
INFO - 2025-04-27 06:20:22 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:20:22 --> Form Validation Class Initialized
INFO - 2025-04-27 06:20:22 --> Controller Class Initialized
INFO - 2025-04-27 06:20:22 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:20:22 --> Helper loaded: language_helper
INFO - 2025-04-27 06:20:22 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:20:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-04-27 06:20:22 --> Controller: Data POST dari form: {"rekomendasi":"zakia Rahmawati 10.8","jalur_pendaftaran":"reguler_sosial","pilihan_program":"ips","nama_siswa":"DEWI KARTIKA SARI","jenis_kelamin":"perempuan","tempat_lahir":"Batang","tanggal_lahir":"2010-11-03","no_hp_siswa":"082326877593","tempat_tanggal_lahir":"Batang, 03 Nov 2010","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"Jatirejo ","desa":"Luwung ","rt":"02","rw":"03","kecamatan":"Banyuputih ","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"Jatirejo , Desa Luwung , RT 02\/RW 03, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","nama_ibu":"saripah","pendidikan_ayah":"sd","pekerjaan_ayah":"buruh","no_hp_ayah":"085747110787","pendidikan_ibu":"smp","pekerjaan_ibu":"IRT","no_hp_ibu":"085326822456","alamat_ortu":"jatirejo,luwung, Banyuputih,batang","saudara_sekolah":"tidak_punya","nama_wali":"-","hubungan_wali":"-","pendidikan_wali":"sd","pekerjaan_wali":"-","no_hp_wali":"-","alamat_wali":"-","nama_sekolah":"SMP N 02 LIMPUNG","alamat_sekolah":"Mojo","nisn":"","piagam":"tidak_punya","motivasi":"men pinter"}
DEBUG - 2025-04-27 06:20:22 --> Controller: Data yang akan dikirim ke model: {"rekomendasi":"zakia Rahmawati 10.8","jalur_pendaftaran":"reguler_sosial","pilihan_program":"ips","nama_siswa":"DEWI KARTIKA SARI","jenis_kelamin":"perempuan","tempat_lahir":"Batang","tanggal_lahir":"2010-11-03","tempat_tanggal_lahir":"Batang, 03 Nov 2010","no_hp_siswa":"082326877593","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"Jatirejo ","desa":"Luwung ","rt":"02","rw":"03","kecamatan":"Banyuputih ","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"Jatirejo , Desa Luwung , RT 02\/RW 03, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","pendidikan_ayah":"sd","pekerjaan_ayah":"buruh","no_hp_ayah":"085747110787","nama_ibu":"saripah","pendidikan_ibu":"smp","pekerjaan_ibu":"IRT","no_hp_ibu":"085326822456","alamat_ortu":"jatirejo,luwung, Banyuputih,batang","saudara_sekolah":"tidak_punya","nama_wali":"-","hubungan_wali":"-","pendidikan_wali":"sd","pekerjaan_wali":"-","no_hp_wali":"-","alamat_wali":"-","nama_sekolah":"SMP N 02 LIMPUNG","alamat_sekolah":"Mojo","nisn":"","piagam":"tidak_punya","motivasi":"men pinter","tanggal_daftar":"2025-04-27 06:20:22","status":"baru"}
DEBUG - 2025-04-27 06:20:22 --> Model: Data yang akan disimpan: {"rekomendasi":"zakia Rahmawati 10.8","jalur_pendaftaran":"reguler_sosial","pilihan_program":"ips","nama_siswa":"DEWI KARTIKA SARI","jenis_kelamin":"perempuan","tempat_lahir":"Batang","tanggal_lahir":"2010-11-03","tempat_tanggal_lahir":"Batang, 03 Nov 2010","no_hp_siswa":"082326877593","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"Jatirejo ","desa":"Luwung ","rt":"02","rw":"03","kecamatan":"Banyuputih ","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"Jatirejo , Desa Luwung , RT 02\/RW 03, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","pendidikan_ayah":"sd","pekerjaan_ayah":"buruh","no_hp_ayah":"085747110787","nama_ibu":"saripah","pendidikan_ibu":"smp","pekerjaan_ibu":"IRT","no_hp_ibu":"085326822456","alamat_ortu":"jatirejo,luwung, Banyuputih,batang","saudara_sekolah":"tidak_punya","nama_wali":"-","hubungan_wali":"-","pendidikan_wali":"sd","pekerjaan_wali":"-","no_hp_wali":"-","alamat_wali":"-","nama_sekolah":"SMP N 02 LIMPUNG","alamat_sekolah":"Mojo","nisn":"","piagam":"tidak_punya","motivasi":"men pinter","tanggal_daftar":"2025-04-27 06:20:22","status":"baru"}
DEBUG - 2025-04-27 06:20:22 --> Model: Data berhasil disimpan dengan ID: 3
INFO - 2025-04-27 06:20:22 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_berhasil.php
INFO - 2025-04-27 06:20:22 --> Final output sent to browser
DEBUG - 2025-04-27 06:20:22 --> Total execution time: 0.0774
INFO - 2025-04-27 06:22:44 --> Config Class Initialized
INFO - 2025-04-27 06:22:44 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:22:44 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:22:44 --> Utf8 Class Initialized
INFO - 2025-04-27 06:22:44 --> URI Class Initialized
INFO - 2025-04-27 06:22:44 --> Router Class Initialized
INFO - 2025-04-27 06:22:44 --> Output Class Initialized
INFO - 2025-04-27 06:22:44 --> Security Class Initialized
DEBUG - 2025-04-27 06:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:22:44 --> Input Class Initialized
INFO - 2025-04-27 06:22:44 --> Language Class Initialized
INFO - 2025-04-27 06:22:44 --> Loader Class Initialized
INFO - 2025-04-27 06:22:44 --> Helper loaded: form_helper
INFO - 2025-04-27 06:22:44 --> Helper loaded: url_helper
INFO - 2025-04-27 06:22:44 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:22:44 --> Form Validation Class Initialized
INFO - 2025-04-27 06:22:44 --> Controller Class Initialized
INFO - 2025-04-27 06:22:44 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:22:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:22:44 --> Helper loaded: language_helper
INFO - 2025-04-27 06:22:44 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:22:44 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:22:44 --> Final output sent to browser
DEBUG - 2025-04-27 06:22:44 --> Total execution time: 0.0344
INFO - 2025-04-27 06:23:22 --> Config Class Initialized
INFO - 2025-04-27 06:23:22 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:23:22 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:23:22 --> Utf8 Class Initialized
INFO - 2025-04-27 06:23:22 --> URI Class Initialized
INFO - 2025-04-27 06:23:22 --> Router Class Initialized
INFO - 2025-04-27 06:23:22 --> Output Class Initialized
INFO - 2025-04-27 06:23:22 --> Security Class Initialized
DEBUG - 2025-04-27 06:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:23:22 --> Input Class Initialized
INFO - 2025-04-27 06:23:22 --> Language Class Initialized
INFO - 2025-04-27 06:23:22 --> Loader Class Initialized
INFO - 2025-04-27 06:23:22 --> Helper loaded: form_helper
INFO - 2025-04-27 06:23:22 --> Helper loaded: url_helper
INFO - 2025-04-27 06:23:22 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:23:22 --> Form Validation Class Initialized
INFO - 2025-04-27 06:23:22 --> Controller Class Initialized
INFO - 2025-04-27 06:23:22 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:23:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:23:22 --> Helper loaded: language_helper
INFO - 2025-04-27 06:23:22 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:23:22 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:23:22 --> Final output sent to browser
DEBUG - 2025-04-27 06:23:22 --> Total execution time: 0.0311
INFO - 2025-04-27 06:24:35 --> Config Class Initialized
INFO - 2025-04-27 06:24:35 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:24:35 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:24:35 --> Utf8 Class Initialized
INFO - 2025-04-27 06:24:35 --> URI Class Initialized
INFO - 2025-04-27 06:24:35 --> Router Class Initialized
INFO - 2025-04-27 06:24:35 --> Output Class Initialized
INFO - 2025-04-27 06:24:35 --> Security Class Initialized
DEBUG - 2025-04-27 06:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:24:35 --> Input Class Initialized
INFO - 2025-04-27 06:24:35 --> Language Class Initialized
INFO - 2025-04-27 06:24:35 --> Loader Class Initialized
INFO - 2025-04-27 06:24:35 --> Helper loaded: form_helper
INFO - 2025-04-27 06:24:35 --> Helper loaded: url_helper
INFO - 2025-04-27 06:24:35 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:24:35 --> Form Validation Class Initialized
INFO - 2025-04-27 06:24:35 --> Controller Class Initialized
INFO - 2025-04-27 06:24:35 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:24:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:24:35 --> Helper loaded: language_helper
INFO - 2025-04-27 06:24:35 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:24:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-04-27 06:24:35 --> Controller: Data POST dari form: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"muhamad fariz khamdan","jenis_kelamin":"laki-laki","tempat_lahir":"BATANG","tanggal_lahir":"2005-01-04","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"BATANG, 04 Jan 2005","tinggal":"bersama_wali","tinggal_lainnya":"","dukuh":"adilko","desa":"rowosari","rt":"003","rw":"004","kecamatan":"limpung","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"adilko, Desa rowosari, RT 003\/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","nama_ibu":"ibuku","pendidikan_ayah":"s2","pekerjaan_ayah":"BUTRUH","no_hp_ayah":"085747110787","pendidikan_ibu":"s3","pekerjaan_ibu":"ewewewe","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"punya","nama_wali":"FAHRUTORI","hubungan_wali":"AYAH","pendidikan_wali":"s2","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"MTS NH","alamat_sekolah":"Banyuputih","nisn":"","piagam":"tidak_punya","motivasi":"apa ayaaaa"}
DEBUG - 2025-04-27 06:24:35 --> Controller: Data yang akan dikirim ke model: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"muhamad fariz khamdan","jenis_kelamin":"laki-laki","tempat_lahir":"BATANG","tanggal_lahir":"2005-01-04","tempat_tanggal_lahir":"BATANG, 04 Jan 2005","no_hp_siswa":"085747110787","tinggal":"bersama_wali","tinggal_lainnya":"","dukuh":"adilko","desa":"rowosari","rt":"003","rw":"004","kecamatan":"limpung","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"adilko, Desa rowosari, RT 003\/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","pendidikan_ayah":"s2","pekerjaan_ayah":"BUTRUH","no_hp_ayah":"085747110787","nama_ibu":"ibuku","pendidikan_ibu":"s3","pekerjaan_ibu":"ewewewe","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"punya","nama_wali":"FAHRUTORI","hubungan_wali":"AYAH","pendidikan_wali":"s2","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"MTS NH","alamat_sekolah":"Banyuputih","nisn":"","piagam":"tidak_punya","motivasi":"apa ayaaaa","tanggal_daftar":"2025-04-27 06:24:35","status":"baru"}
DEBUG - 2025-04-27 06:24:35 --> Model: Data yang akan disimpan: {"rekomendasi":"teman","jalur_pendaftaran":"reguler_umum","pilihan_program":"ips","nama_siswa":"muhamad fariz khamdan","jenis_kelamin":"laki-laki","tempat_lahir":"BATANG","tanggal_lahir":"2005-01-04","tempat_tanggal_lahir":"BATANG, 04 Jan 2005","no_hp_siswa":"085747110787","tinggal":"bersama_wali","tinggal_lainnya":"","dukuh":"adilko","desa":"rowosari","rt":"003","rw":"004","kecamatan":"limpung","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"adilko, Desa rowosari, RT 003\/RW 004, Kec. limpung, Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","pendidikan_ayah":"s2","pekerjaan_ayah":"BUTRUH","no_hp_ayah":"085747110787","nama_ibu":"ibuku","pendidikan_ibu":"s3","pekerjaan_ibu":"ewewewe","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"punya","nama_wali":"FAHRUTORI","hubungan_wali":"AYAH","pendidikan_wali":"s2","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"MTS NH","alamat_sekolah":"Banyuputih","nisn":"","piagam":"tidak_punya","motivasi":"apa ayaaaa","tanggal_daftar":"2025-04-27 06:24:35","status":"baru"}
DEBUG - 2025-04-27 06:24:35 --> Model: Data berhasil disimpan dengan ID: 4
INFO - 2025-04-27 06:24:35 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_berhasil.php
INFO - 2025-04-27 06:24:35 --> Final output sent to browser
DEBUG - 2025-04-27 06:24:35 --> Total execution time: 0.0466
INFO - 2025-04-27 06:24:53 --> Config Class Initialized
INFO - 2025-04-27 06:24:53 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:24:53 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:24:53 --> Utf8 Class Initialized
INFO - 2025-04-27 06:24:53 --> URI Class Initialized
INFO - 2025-04-27 06:24:53 --> Router Class Initialized
INFO - 2025-04-27 06:24:53 --> Output Class Initialized
INFO - 2025-04-27 06:24:53 --> Security Class Initialized
DEBUG - 2025-04-27 06:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:24:53 --> Input Class Initialized
INFO - 2025-04-27 06:24:53 --> Language Class Initialized
INFO - 2025-04-27 06:24:53 --> Loader Class Initialized
INFO - 2025-04-27 06:24:53 --> Helper loaded: form_helper
INFO - 2025-04-27 06:24:53 --> Helper loaded: url_helper
INFO - 2025-04-27 06:24:53 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:24:53 --> Form Validation Class Initialized
INFO - 2025-04-27 06:24:53 --> Controller Class Initialized
INFO - 2025-04-27 06:24:53 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:24:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:24:53 --> Helper loaded: language_helper
INFO - 2025-04-27 06:24:53 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:24:53 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:24:53 --> Final output sent to browser
DEBUG - 2025-04-27 06:24:53 --> Total execution time: 0.0324
INFO - 2025-04-27 06:32:34 --> Config Class Initialized
INFO - 2025-04-27 06:32:34 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:32:34 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:32:34 --> Utf8 Class Initialized
INFO - 2025-04-27 06:32:34 --> URI Class Initialized
INFO - 2025-04-27 06:32:34 --> Router Class Initialized
INFO - 2025-04-27 06:32:34 --> Output Class Initialized
INFO - 2025-04-27 06:32:34 --> Security Class Initialized
DEBUG - 2025-04-27 06:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:32:34 --> Input Class Initialized
INFO - 2025-04-27 06:32:34 --> Language Class Initialized
INFO - 2025-04-27 06:32:34 --> Loader Class Initialized
INFO - 2025-04-27 06:32:34 --> Helper loaded: form_helper
INFO - 2025-04-27 06:32:34 --> Helper loaded: url_helper
INFO - 2025-04-27 06:32:34 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:32:34 --> Form Validation Class Initialized
INFO - 2025-04-27 06:32:34 --> Controller Class Initialized
INFO - 2025-04-27 06:32:34 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:32:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:32:34 --> Helper loaded: language_helper
INFO - 2025-04-27 06:32:34 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:32:34 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:32:34 --> Final output sent to browser
DEBUG - 2025-04-27 06:32:34 --> Total execution time: 0.0418
INFO - 2025-04-27 06:38:37 --> Config Class Initialized
INFO - 2025-04-27 06:38:37 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:38:37 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:38:37 --> Utf8 Class Initialized
INFO - 2025-04-27 06:38:37 --> URI Class Initialized
INFO - 2025-04-27 06:38:37 --> Router Class Initialized
INFO - 2025-04-27 06:38:37 --> Output Class Initialized
INFO - 2025-04-27 06:38:37 --> Security Class Initialized
DEBUG - 2025-04-27 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:38:37 --> Input Class Initialized
INFO - 2025-04-27 06:38:37 --> Language Class Initialized
INFO - 2025-04-27 06:38:37 --> Loader Class Initialized
INFO - 2025-04-27 06:38:37 --> Helper loaded: form_helper
INFO - 2025-04-27 06:38:37 --> Helper loaded: url_helper
INFO - 2025-04-27 06:38:37 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:38:37 --> Form Validation Class Initialized
INFO - 2025-04-27 06:38:37 --> Controller Class Initialized
INFO - 2025-04-27 06:38:37 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:38:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:38:37 --> Helper loaded: language_helper
INFO - 2025-04-27 06:38:37 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:38:37 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:38:37 --> Final output sent to browser
DEBUG - 2025-04-27 06:38:37 --> Total execution time: 0.0349
INFO - 2025-04-27 06:40:20 --> Config Class Initialized
INFO - 2025-04-27 06:40:20 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:40:20 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:40:20 --> Utf8 Class Initialized
INFO - 2025-04-27 06:40:20 --> URI Class Initialized
INFO - 2025-04-27 06:40:20 --> Router Class Initialized
INFO - 2025-04-27 06:40:20 --> Output Class Initialized
INFO - 2025-04-27 06:40:20 --> Security Class Initialized
DEBUG - 2025-04-27 06:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:40:20 --> Input Class Initialized
INFO - 2025-04-27 06:40:20 --> Language Class Initialized
INFO - 2025-04-27 06:40:20 --> Loader Class Initialized
INFO - 2025-04-27 06:40:20 --> Helper loaded: form_helper
INFO - 2025-04-27 06:40:20 --> Helper loaded: url_helper
INFO - 2025-04-27 06:40:20 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:40:20 --> Form Validation Class Initialized
INFO - 2025-04-27 06:40:20 --> Controller Class Initialized
INFO - 2025-04-27 06:40:20 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:40:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:40:20 --> Helper loaded: language_helper
INFO - 2025-04-27 06:40:20 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:40:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-04-27 06:40:20 --> Controller: Data POST dari form: {"rekomendasi":"zakia Rahmawati 10.8","jalur_pendaftaran":"reguler_prestasi","pilihan_program":"agm","nama_siswa":"EKA DEWI LESTARI","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2003-03-04","no_hp_siswa":"085747110787","tempat_tanggal_lahir":"Batang, 04 Mar 2003","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"Jatirejo ","desa":"Luwung ","rt":"003","rw":"004","kecamatan":"Banyuputih ","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"Jatirejo , Desa Luwung , RT 003\/RW 004, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","nama_ibu":"ibuku","pendidikan_ayah":"s3","pekerjaan_ayah":"buruh","no_hp_ayah":"085747110787","pendidikan_ibu":"s1","pekerjaan_ibu":"IRT","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"tidak_punya","nama_wali":"FAHRUTORI","hubungan_wali":"sdsdsd","pendidikan_wali":"","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"SMP N 02 LIMPUNG","alamat_sekolah":"Limoung","nisn":"","piagam":"tidak_punya","motivasi":"Ingin belajar ilmu pengetahuan sosial dan ekonomi untuk melanjutkan ke jenjang lebih tinggi "}
DEBUG - 2025-04-27 06:40:20 --> Controller: Data yang akan dikirim ke model: {"rekomendasi":"zakia Rahmawati 10.8","jalur_pendaftaran":"reguler_prestasi","pilihan_program":"agm","nama_siswa":"EKA DEWI LESTARI","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2003-03-04","tempat_tanggal_lahir":"Batang, 04 Mar 2003","no_hp_siswa":"085747110787","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"Jatirejo ","desa":"Luwung ","rt":"003","rw":"004","kecamatan":"Banyuputih ","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"Jatirejo , Desa Luwung , RT 003\/RW 004, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","pendidikan_ayah":"s3","pekerjaan_ayah":"buruh","no_hp_ayah":"085747110787","nama_ibu":"ibuku","pendidikan_ibu":"s1","pekerjaan_ibu":"IRT","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"tidak_punya","nama_wali":"FAHRUTORI","hubungan_wali":"sdsdsd","pendidikan_wali":"","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"SMP N 02 LIMPUNG","alamat_sekolah":"Limoung","nisn":"","piagam":"tidak_punya","motivasi":"Ingin belajar ilmu pengetahuan sosial dan ekonomi untuk melanjutkan ke jenjang lebih tinggi ","tanggal_daftar":"2025-04-27 06:40:20"}
DEBUG - 2025-04-27 06:40:20 --> Model: Data yang akan disimpan: {"rekomendasi":"zakia Rahmawati 10.8","jalur_pendaftaran":"reguler_prestasi","pilihan_program":"agm","nama_siswa":"EKA DEWI LESTARI","jenis_kelamin":"laki-laki","tempat_lahir":"Batang","tanggal_lahir":"2003-03-04","tempat_tanggal_lahir":"Batang, 04 Mar 2003","no_hp_siswa":"085747110787","tinggal":"bersama_ortu","tinggal_lainnya":"","dukuh":"Jatirejo ","desa":"Luwung ","rt":"003","rw":"004","kecamatan":"Banyuputih ","kabupaten":"Batang","provinsi":"Jawa Tengah","alamat_lengkap":"Jatirejo , Desa Luwung , RT 003\/RW 004, Kec. Banyuputih , Kab. Batang, Prov. Jawa Tengah","nama_ayah":"Nasrudin ","pendidikan_ayah":"s3","pekerjaan_ayah":"buruh","no_hp_ayah":"085747110787","nama_ibu":"ibuku","pendidikan_ibu":"s1","pekerjaan_ibu":"IRT","no_hp_ibu":"085747110787","alamat_ortu":"Dukuh Adiloko Desa Rowosari","saudara_sekolah":"tidak_punya","nama_wali":"FAHRUTORI","hubungan_wali":"sdsdsd","pendidikan_wali":"","pekerjaan_wali":"BURUH","no_hp_wali":"085747110787","alamat_wali":"Dukuh Adiloko Desa Rowosari","nama_sekolah":"SMP N 02 LIMPUNG","alamat_sekolah":"Limoung","nisn":"","piagam":"tidak_punya","motivasi":"Ingin belajar ilmu pengetahuan sosial dan ekonomi untuk melanjutkan ke jenjang lebih tinggi ","tanggal_daftar":"2025-04-27 06:40:20","no_pendaftaran":"A-2627\/001"}
DEBUG - 2025-04-27 06:40:20 --> Model: Data berhasil disimpan dengan ID: 5
INFO - 2025-04-27 06:40:20 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_berhasil.php
INFO - 2025-04-27 06:40:20 --> Final output sent to browser
DEBUG - 2025-04-27 06:40:20 --> Total execution time: 0.1137
INFO - 2025-04-27 06:40:33 --> Config Class Initialized
INFO - 2025-04-27 06:40:33 --> Hooks Class Initialized
DEBUG - 2025-04-27 06:40:33 --> UTF-8 Support Enabled
INFO - 2025-04-27 06:40:33 --> Utf8 Class Initialized
INFO - 2025-04-27 06:40:33 --> URI Class Initialized
INFO - 2025-04-27 06:40:33 --> Router Class Initialized
INFO - 2025-04-27 06:40:33 --> Output Class Initialized
INFO - 2025-04-27 06:40:33 --> Security Class Initialized
DEBUG - 2025-04-27 06:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-27 06:40:33 --> Input Class Initialized
INFO - 2025-04-27 06:40:33 --> Language Class Initialized
INFO - 2025-04-27 06:40:33 --> Loader Class Initialized
INFO - 2025-04-27 06:40:33 --> Helper loaded: form_helper
INFO - 2025-04-27 06:40:33 --> Helper loaded: url_helper
INFO - 2025-04-27 06:40:33 --> Database Driver Class Initialized
DEBUG - 2025-04-27 06:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-04-27 06:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-04-27 06:40:33 --> Form Validation Class Initialized
INFO - 2025-04-27 06:40:33 --> Controller Class Initialized
INFO - 2025-04-27 06:40:33 --> Model "Pendaftaran_model" initialized
DEBUG - 2025-04-27 06:40:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-04-27 06:40:33 --> Helper loaded: language_helper
INFO - 2025-04-27 06:40:33 --> Language file loaded: language/indonesian/form_validation_lang.php
INFO - 2025-04-27 06:40:33 --> File loaded: C:\xampp\htdocs\ppdb_manu\application\views\pendaftaran_form.php
INFO - 2025-04-27 06:40:33 --> Final output sent to browser
DEBUG - 2025-04-27 06:40:33 --> Total execution time: 0.0318
