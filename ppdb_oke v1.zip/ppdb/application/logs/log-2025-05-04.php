<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-04 05:34:00 --> Config Class Initialized
INFO - 2025-05-04 05:34:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:34:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:34:00 --> Utf8 Class Initialized
INFO - 2025-05-04 05:34:00 --> URI Class Initialized
DEBUG - 2025-05-04 05:34:00 --> No URI present. Default controller set.
INFO - 2025-05-04 05:34:00 --> Router Class Initialized
INFO - 2025-05-04 05:34:00 --> Output Class Initialized
INFO - 2025-05-04 05:34:00 --> Security Class Initialized
DEBUG - 2025-05-04 05:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:34:00 --> Input Class Initialized
INFO - 2025-05-04 05:34:00 --> Language Class Initialized
INFO - 2025-05-04 05:34:00 --> Loader Class Initialized
INFO - 2025-05-04 05:34:00 --> Helper loaded: form_helper
INFO - 2025-05-04 05:34:00 --> Helper loaded: url_helper
INFO - 2025-05-04 05:34:00 --> Database Driver Class Initialized
ERROR - 2025-05-04 05:34:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ppdb_manu_db' C:\xampp\htdocs\ppdb\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-05-04 05:34:01 --> Unable to connect to the database
INFO - 2025-05-04 05:34:01 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-04 05:45:15 --> Config Class Initialized
INFO - 2025-05-04 05:45:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:45:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:45:15 --> Utf8 Class Initialized
INFO - 2025-05-04 05:45:15 --> URI Class Initialized
DEBUG - 2025-05-04 05:45:15 --> No URI present. Default controller set.
INFO - 2025-05-04 05:45:15 --> Router Class Initialized
INFO - 2025-05-04 05:45:15 --> Output Class Initialized
INFO - 2025-05-04 05:45:15 --> Security Class Initialized
DEBUG - 2025-05-04 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:45:15 --> Input Class Initialized
INFO - 2025-05-04 05:45:15 --> Language Class Initialized
INFO - 2025-05-04 05:45:15 --> Loader Class Initialized
INFO - 2025-05-04 05:45:15 --> Helper loaded: form_helper
INFO - 2025-05-04 05:45:15 --> Helper loaded: url_helper
INFO - 2025-05-04 05:45:15 --> Database Driver Class Initialized
INFO - 2025-05-04 05:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:45:15 --> Form Validation Class Initialized
INFO - 2025-05-04 05:45:15 --> Controller Class Initialized
INFO - 2025-05-04 05:45:15 --> Final output sent to browser
DEBUG - 2025-05-04 05:45:15 --> Total execution time: 0.0786
INFO - 2025-05-04 05:45:18 --> Config Class Initialized
INFO - 2025-05-04 05:45:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:45:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:45:18 --> Utf8 Class Initialized
INFO - 2025-05-04 05:45:18 --> URI Class Initialized
INFO - 2025-05-04 05:45:18 --> Router Class Initialized
INFO - 2025-05-04 05:45:18 --> Output Class Initialized
INFO - 2025-05-04 05:45:18 --> Security Class Initialized
DEBUG - 2025-05-04 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:45:18 --> Input Class Initialized
INFO - 2025-05-04 05:45:18 --> Language Class Initialized
INFO - 2025-05-04 05:45:18 --> Loader Class Initialized
INFO - 2025-05-04 05:45:18 --> Helper loaded: form_helper
INFO - 2025-05-04 05:45:18 --> Helper loaded: url_helper
INFO - 2025-05-04 05:45:18 --> Database Driver Class Initialized
INFO - 2025-05-04 05:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:45:18 --> Form Validation Class Initialized
INFO - 2025-05-04 05:45:18 --> Controller Class Initialized
DEBUG - 2025-05-04 05:45:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:45:18 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:45:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:45:18 --> Final output sent to browser
DEBUG - 2025-05-04 05:45:18 --> Total execution time: 0.0318
INFO - 2025-05-04 05:53:25 --> Config Class Initialized
INFO - 2025-05-04 05:53:25 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:25 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:25 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:25 --> URI Class Initialized
INFO - 2025-05-04 05:53:25 --> Router Class Initialized
INFO - 2025-05-04 05:53:25 --> Output Class Initialized
INFO - 2025-05-04 05:53:25 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:25 --> Input Class Initialized
INFO - 2025-05-04 05:53:25 --> Language Class Initialized
INFO - 2025-05-04 05:53:25 --> Loader Class Initialized
INFO - 2025-05-04 05:53:25 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:25 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:25 --> Database Driver Class Initialized
INFO - 2025-05-04 05:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:25 --> Form Validation Class Initialized
INFO - 2025-05-04 05:53:25 --> Controller Class Initialized
DEBUG - 2025-05-04 05:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:53:25 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:53:25 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:53:25 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:25 --> Total execution time: 0.0431
INFO - 2025-05-04 05:53:28 --> Config Class Initialized
INFO - 2025-05-04 05:53:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:28 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:28 --> URI Class Initialized
INFO - 2025-05-04 05:53:28 --> Router Class Initialized
INFO - 2025-05-04 05:53:28 --> Output Class Initialized
INFO - 2025-05-04 05:53:28 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:28 --> Input Class Initialized
INFO - 2025-05-04 05:53:28 --> Language Class Initialized
INFO - 2025-05-04 05:53:28 --> Loader Class Initialized
INFO - 2025-05-04 05:53:28 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:28 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:28 --> Database Driver Class Initialized
INFO - 2025-05-04 05:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:28 --> Form Validation Class Initialized
INFO - 2025-05-04 05:53:28 --> Controller Class Initialized
DEBUG - 2025-05-04 05:53:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:53:28 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:53:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:53:28 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:28 --> Total execution time: 0.0523
INFO - 2025-05-04 05:53:35 --> Config Class Initialized
INFO - 2025-05-04 05:53:35 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:35 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:35 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:35 --> URI Class Initialized
INFO - 2025-05-04 05:53:35 --> Router Class Initialized
INFO - 2025-05-04 05:53:35 --> Output Class Initialized
INFO - 2025-05-04 05:53:35 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:35 --> Input Class Initialized
INFO - 2025-05-04 05:53:35 --> Language Class Initialized
INFO - 2025-05-04 05:53:35 --> Loader Class Initialized
INFO - 2025-05-04 05:53:35 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:35 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:35 --> Database Driver Class Initialized
INFO - 2025-05-04 05:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:35 --> Form Validation Class Initialized
INFO - 2025-05-04 05:53:35 --> Controller Class Initialized
DEBUG - 2025-05-04 05:53:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:53:35 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:53:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:53:35 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:35 --> Total execution time: 0.0906
INFO - 2025-05-04 05:53:37 --> Config Class Initialized
INFO - 2025-05-04 05:53:37 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:53:37 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:53:37 --> Utf8 Class Initialized
INFO - 2025-05-04 05:53:37 --> URI Class Initialized
INFO - 2025-05-04 05:53:37 --> Router Class Initialized
INFO - 2025-05-04 05:53:37 --> Output Class Initialized
INFO - 2025-05-04 05:53:37 --> Security Class Initialized
DEBUG - 2025-05-04 05:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:53:37 --> Input Class Initialized
INFO - 2025-05-04 05:53:37 --> Language Class Initialized
INFO - 2025-05-04 05:53:37 --> Loader Class Initialized
INFO - 2025-05-04 05:53:37 --> Helper loaded: form_helper
INFO - 2025-05-04 05:53:37 --> Helper loaded: url_helper
INFO - 2025-05-04 05:53:37 --> Database Driver Class Initialized
INFO - 2025-05-04 05:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:53:37 --> Form Validation Class Initialized
INFO - 2025-05-04 05:53:37 --> Controller Class Initialized
DEBUG - 2025-05-04 05:53:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:53:37 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:53:37 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:53:37 --> Final output sent to browser
DEBUG - 2025-05-04 05:53:37 --> Total execution time: 0.0386
INFO - 2025-05-04 05:54:43 --> Config Class Initialized
INFO - 2025-05-04 05:54:43 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:43 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:43 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:43 --> URI Class Initialized
INFO - 2025-05-04 05:54:43 --> Router Class Initialized
INFO - 2025-05-04 05:54:43 --> Output Class Initialized
INFO - 2025-05-04 05:54:43 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:43 --> Input Class Initialized
INFO - 2025-05-04 05:54:43 --> Language Class Initialized
INFO - 2025-05-04 05:54:43 --> Loader Class Initialized
INFO - 2025-05-04 05:54:43 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:43 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:43 --> Database Driver Class Initialized
INFO - 2025-05-04 05:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:43 --> Form Validation Class Initialized
INFO - 2025-05-04 05:54:43 --> Controller Class Initialized
DEBUG - 2025-05-04 05:54:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:54:43 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 05:54:43 --> POST data: Array
(
    [nama_siswa] => Akhmad Lutfi lagi nih
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2010-03-09
    [tempat_tanggal_lahir] => Batang, 9 Maret 2010
    [tempat_tanggal_lahir_db] => Batang, 9 Maret 2010
    [rekomendasi] => teman
    [pilihan_program] => MIPA
    [no_hp_siswa] => 085747110787
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Wali
    [dukuh] => Jatirejo
    [rt] => 002
    [rw] => 004
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Jatirejo, RT 002/RW 004, Banyuputih, limpugn, Batang, Jawa Tengah
    [alamat_lengkap_db] => Jatirejo, RT 002/RW 004, Banyuputih, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Subkhi alwi
    [nama_ibu] => Kholiyah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => Tidak Sekolah
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => Ibu rumah tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 123456
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => mantab adijaidjs
    [tanggal_lahir_db] => 2010-03-09
)

INFO - 2025-05-04 05:54:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 05:54:43 --> Generated registration number: A-2526/0160
DEBUG - 2025-05-04 05:54:43 --> Form data to save: Array
(
    [nama_siswa] => Akhmad Lutfi lagi nih
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2010-03-09
    [tempat_tanggal_lahir] => Batang, 9 Maret 2010
    [no_hp_siswa] => 085747110787
    [rekomendasi] => teman
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Wali
    [dukuh] => Jatirejo
    [rt] => 002
    [rw] => 004
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Jatirejo, RT 002/RW 004, Banyuputih, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Subkhi alwi
    [nama_ibu] => Kholiyah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => Tidak Sekolah
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => Ibu rumah tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 123456
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => mantab adijaidjs
    [tanggal_daftar] => 2025-05-04 05:54:43
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-04 05:54:43 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 05:54:43 --> Database config: 1
DEBUG - 2025-05-04 05:54:43 --> Database hostname: localhost
DEBUG - 2025-05-04 05:54:43 --> Database username: root
DEBUG - 2025-05-04 05:54:43 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 05:54:43 --> Data to save: Array
(
    [nama_siswa] => Akhmad Lutfi lagi nih
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2010-03-09
    [tempat_tanggal_lahir] => Batang, 9 Maret 2010
    [no_hp_siswa] => 085747110787
    [rekomendasi] => teman
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Wali
    [dukuh] => Jatirejo
    [rt] => 002
    [rw] => 004
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Jatirejo, RT 002/RW 004, Banyuputih, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Subkhi alwi
    [nama_ibu] => Kholiyah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => Tidak Sekolah
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => Ibu rumah tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 123456
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => mantab adijaidjs
    [tanggal_daftar] => 2025-05-04 05:54:43
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-04 05:54:43 --> Data inserted successfully with ID: 170
INFO - 2025-05-04 05:54:46 --> Config Class Initialized
INFO - 2025-05-04 05:54:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:46 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:46 --> URI Class Initialized
INFO - 2025-05-04 05:54:46 --> Router Class Initialized
INFO - 2025-05-04 05:54:46 --> Output Class Initialized
INFO - 2025-05-04 05:54:46 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:46 --> Input Class Initialized
INFO - 2025-05-04 05:54:46 --> Language Class Initialized
INFO - 2025-05-04 05:54:46 --> Loader Class Initialized
INFO - 2025-05-04 05:54:46 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:46 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:46 --> Database Driver Class Initialized
INFO - 2025-05-04 05:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:46 --> Form Validation Class Initialized
INFO - 2025-05-04 05:54:46 --> Controller Class Initialized
DEBUG - 2025-05-04 05:54:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:54:46 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:54:46 --> Config Class Initialized
INFO - 2025-05-04 05:54:46 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:54:46 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:54:46 --> Utf8 Class Initialized
INFO - 2025-05-04 05:54:46 --> URI Class Initialized
INFO - 2025-05-04 05:54:46 --> Router Class Initialized
INFO - 2025-05-04 05:54:46 --> Output Class Initialized
INFO - 2025-05-04 05:54:46 --> Security Class Initialized
DEBUG - 2025-05-04 05:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:54:46 --> Input Class Initialized
INFO - 2025-05-04 05:54:46 --> Language Class Initialized
INFO - 2025-05-04 05:54:46 --> Loader Class Initialized
INFO - 2025-05-04 05:54:46 --> Helper loaded: form_helper
INFO - 2025-05-04 05:54:46 --> Helper loaded: url_helper
INFO - 2025-05-04 05:54:46 --> Database Driver Class Initialized
INFO - 2025-05-04 05:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:54:46 --> Form Validation Class Initialized
INFO - 2025-05-04 05:54:46 --> Controller Class Initialized
DEBUG - 2025-05-04 05:54:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:54:46 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:54:46 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:54:46 --> Final output sent to browser
DEBUG - 2025-05-04 05:54:46 --> Total execution time: 0.0308
INFO - 2025-05-04 05:56:19 --> Config Class Initialized
INFO - 2025-05-04 05:56:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:56:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:56:19 --> Utf8 Class Initialized
INFO - 2025-05-04 05:56:19 --> URI Class Initialized
INFO - 2025-05-04 05:56:19 --> Router Class Initialized
INFO - 2025-05-04 05:56:19 --> Output Class Initialized
INFO - 2025-05-04 05:56:19 --> Security Class Initialized
DEBUG - 2025-05-04 05:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:56:19 --> Input Class Initialized
INFO - 2025-05-04 05:56:19 --> Language Class Initialized
INFO - 2025-05-04 05:56:19 --> Loader Class Initialized
INFO - 2025-05-04 05:56:19 --> Helper loaded: form_helper
INFO - 2025-05-04 05:56:19 --> Helper loaded: url_helper
INFO - 2025-05-04 05:56:19 --> Database Driver Class Initialized
INFO - 2025-05-04 05:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:56:19 --> Form Validation Class Initialized
INFO - 2025-05-04 05:56:19 --> Controller Class Initialized
DEBUG - 2025-05-04 05:56:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:56:19 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:56:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:56:19 --> Final output sent to browser
DEBUG - 2025-05-04 05:56:19 --> Total execution time: 0.0369
INFO - 2025-05-04 05:56:21 --> Config Class Initialized
INFO - 2025-05-04 05:56:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:56:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:56:21 --> Utf8 Class Initialized
INFO - 2025-05-04 05:56:21 --> URI Class Initialized
INFO - 2025-05-04 05:56:21 --> Router Class Initialized
INFO - 2025-05-04 05:56:21 --> Output Class Initialized
INFO - 2025-05-04 05:56:21 --> Security Class Initialized
DEBUG - 2025-05-04 05:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:56:21 --> Input Class Initialized
INFO - 2025-05-04 05:56:21 --> Language Class Initialized
INFO - 2025-05-04 05:56:21 --> Loader Class Initialized
INFO - 2025-05-04 05:56:21 --> Helper loaded: form_helper
INFO - 2025-05-04 05:56:21 --> Helper loaded: url_helper
INFO - 2025-05-04 05:56:21 --> Database Driver Class Initialized
INFO - 2025-05-04 05:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:56:21 --> Form Validation Class Initialized
INFO - 2025-05-04 05:56:21 --> Controller Class Initialized
DEBUG - 2025-05-04 05:56:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:56:21 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:56:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:56:21 --> Final output sent to browser
DEBUG - 2025-05-04 05:56:21 --> Total execution time: 0.0613
INFO - 2025-05-04 05:57:41 --> Config Class Initialized
INFO - 2025-05-04 05:57:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:57:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:57:41 --> Utf8 Class Initialized
INFO - 2025-05-04 05:57:41 --> URI Class Initialized
INFO - 2025-05-04 05:57:41 --> Router Class Initialized
INFO - 2025-05-04 05:57:41 --> Output Class Initialized
INFO - 2025-05-04 05:57:41 --> Security Class Initialized
DEBUG - 2025-05-04 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:57:41 --> Input Class Initialized
INFO - 2025-05-04 05:57:41 --> Language Class Initialized
INFO - 2025-05-04 05:57:41 --> Loader Class Initialized
INFO - 2025-05-04 05:57:41 --> Helper loaded: form_helper
INFO - 2025-05-04 05:57:41 --> Helper loaded: url_helper
INFO - 2025-05-04 05:57:41 --> Database Driver Class Initialized
INFO - 2025-05-04 05:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:57:41 --> Form Validation Class Initialized
INFO - 2025-05-04 05:57:41 --> Controller Class Initialized
DEBUG - 2025-05-04 05:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:57:41 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 05:57:41 --> POST data: Array
(
    [nama_siswa] => nama tester
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2014-02-04
    [tempat_tanggal_lahir] => Batang, 4 Februari 2014
    [tempat_tanggal_lahir_db] => Batang, 4 Februari 2014
    [rekomendasi] => Guru PAI MTs
    [pilihan_program] => MIPA
    [no_hp_siswa] => 085747110787
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Kemloko
    [rt] => 002
    [rw] => 03
    [desa] => sembung
    [kecamatan] => Banyuputih 
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Kemloko, RT 002/RW 03, sembung, Banyuputih , Batang, Jawa Tengah
    [alamat_lengkap_db] => Kemloko, RT 002/RW 03, sembung, Banyuputih , Batang, Jawa Tengah
    [nama_ayah] => ayahku
    [nama_ibu] => aaaaaa
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => Tidak Sekolah
    [pekerjaan_ayah] => BUTRUH
    [pekerjaan_ibu] => BURUH
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 Banyuputih
    [nisn] => 0064399082
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Ya
    [nama_event] => 
    [motivasi] => mantap lah
    [tanggal_lahir_db] => 2014-02-04
)

INFO - 2025-05-04 05:57:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 05:57:41 --> Generated registration number: A-2526/0161
DEBUG - 2025-05-04 05:57:41 --> Form data to save: Array
(
    [nama_siswa] => nama tester
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2014-02-04
    [tempat_tanggal_lahir] => Batang, 4 Februari 2014
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Guru PAI MTs
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Kemloko
    [rt] => 002
    [rw] => 03
    [desa] => sembung
    [kecamatan] => Banyuputih 
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Kemloko, RT 002/RW 03, sembung, Banyuputih , Batang, Jawa Tengah
    [nama_ayah] => ayahku
    [nama_ibu] => aaaaaa
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => Tidak Sekolah
    [pekerjaan_ayah] => BUTRUH
    [pekerjaan_ibu] => BURUH
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 Banyuputih
    [nisn] => 0064399082
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Ya
    [nama_event] => 
    [motivasi] => mantap lah
    [tanggal_daftar] => 2025-05-04 05:57:41
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-04 05:57:41 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 05:57:41 --> Database config: 1
DEBUG - 2025-05-04 05:57:41 --> Database hostname: localhost
DEBUG - 2025-05-04 05:57:41 --> Database username: root
DEBUG - 2025-05-04 05:57:41 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 05:57:41 --> Data to save: Array
(
    [nama_siswa] => nama tester
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2014-02-04
    [tempat_tanggal_lahir] => Batang, 4 Februari 2014
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Guru PAI MTs
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Kemloko
    [rt] => 002
    [rw] => 03
    [desa] => sembung
    [kecamatan] => Banyuputih 
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Kemloko, RT 002/RW 03, sembung, Banyuputih , Batang, Jawa Tengah
    [nama_ayah] => ayahku
    [nama_ibu] => aaaaaa
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => Tidak Sekolah
    [pekerjaan_ayah] => BUTRUH
    [pekerjaan_ibu] => BURUH
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 Banyuputih
    [nisn] => 0064399082
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Ya
    [nama_event] => 
    [motivasi] => mantap lah
    [tanggal_daftar] => 2025-05-04 05:57:41
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-04 05:57:41 --> Data inserted successfully with ID: 171
INFO - 2025-05-04 05:57:41 --> Config Class Initialized
INFO - 2025-05-04 05:57:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:57:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:57:41 --> Utf8 Class Initialized
INFO - 2025-05-04 05:57:41 --> URI Class Initialized
INFO - 2025-05-04 05:57:41 --> Router Class Initialized
INFO - 2025-05-04 05:57:41 --> Output Class Initialized
INFO - 2025-05-04 05:57:41 --> Security Class Initialized
DEBUG - 2025-05-04 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:57:41 --> Input Class Initialized
INFO - 2025-05-04 05:57:41 --> Language Class Initialized
INFO - 2025-05-04 05:57:41 --> Loader Class Initialized
INFO - 2025-05-04 05:57:41 --> Helper loaded: form_helper
INFO - 2025-05-04 05:57:41 --> Helper loaded: url_helper
INFO - 2025-05-04 05:57:41 --> Database Driver Class Initialized
INFO - 2025-05-04 05:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:57:41 --> Form Validation Class Initialized
INFO - 2025-05-04 05:57:41 --> Controller Class Initialized
DEBUG - 2025-05-04 05:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:57:41 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:57:41 --> Config Class Initialized
INFO - 2025-05-04 05:57:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:57:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:57:41 --> Utf8 Class Initialized
INFO - 2025-05-04 05:57:41 --> URI Class Initialized
INFO - 2025-05-04 05:57:41 --> Router Class Initialized
INFO - 2025-05-04 05:57:41 --> Output Class Initialized
INFO - 2025-05-04 05:57:41 --> Security Class Initialized
DEBUG - 2025-05-04 05:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:57:41 --> Input Class Initialized
INFO - 2025-05-04 05:57:41 --> Language Class Initialized
INFO - 2025-05-04 05:57:41 --> Loader Class Initialized
INFO - 2025-05-04 05:57:41 --> Helper loaded: form_helper
INFO - 2025-05-04 05:57:41 --> Helper loaded: url_helper
INFO - 2025-05-04 05:57:41 --> Database Driver Class Initialized
INFO - 2025-05-04 05:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:57:41 --> Form Validation Class Initialized
INFO - 2025-05-04 05:57:41 --> Controller Class Initialized
DEBUG - 2025-05-04 05:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:57:41 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:57:41 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:57:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:57:41 --> Final output sent to browser
DEBUG - 2025-05-04 05:57:41 --> Total execution time: 0.0299
INFO - 2025-05-04 05:59:18 --> Config Class Initialized
INFO - 2025-05-04 05:59:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:18 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:18 --> URI Class Initialized
INFO - 2025-05-04 05:59:18 --> Router Class Initialized
INFO - 2025-05-04 05:59:18 --> Output Class Initialized
INFO - 2025-05-04 05:59:18 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:18 --> Input Class Initialized
INFO - 2025-05-04 05:59:18 --> Language Class Initialized
INFO - 2025-05-04 05:59:18 --> Loader Class Initialized
INFO - 2025-05-04 05:59:18 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:18 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:18 --> Database Driver Class Initialized
INFO - 2025-05-04 05:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:18 --> Form Validation Class Initialized
INFO - 2025-05-04 05:59:18 --> Controller Class Initialized
DEBUG - 2025-05-04 05:59:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:59:18 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:59:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:59:18 --> Final output sent to browser
DEBUG - 2025-05-04 05:59:18 --> Total execution time: 0.0438
INFO - 2025-05-04 05:59:24 --> Config Class Initialized
INFO - 2025-05-04 05:59:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 05:59:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 05:59:24 --> Utf8 Class Initialized
INFO - 2025-05-04 05:59:24 --> URI Class Initialized
INFO - 2025-05-04 05:59:24 --> Router Class Initialized
INFO - 2025-05-04 05:59:24 --> Output Class Initialized
INFO - 2025-05-04 05:59:24 --> Security Class Initialized
DEBUG - 2025-05-04 05:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 05:59:24 --> Input Class Initialized
INFO - 2025-05-04 05:59:24 --> Language Class Initialized
INFO - 2025-05-04 05:59:24 --> Loader Class Initialized
INFO - 2025-05-04 05:59:24 --> Helper loaded: form_helper
INFO - 2025-05-04 05:59:24 --> Helper loaded: url_helper
INFO - 2025-05-04 05:59:24 --> Database Driver Class Initialized
INFO - 2025-05-04 05:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 05:59:24 --> Form Validation Class Initialized
INFO - 2025-05-04 05:59:24 --> Controller Class Initialized
DEBUG - 2025-05-04 05:59:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 05:59:24 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 05:59:24 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 05:59:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 05:59:24 --> Final output sent to browser
DEBUG - 2025-05-04 05:59:24 --> Total execution time: 0.0339
INFO - 2025-05-04 06:00:16 --> Config Class Initialized
INFO - 2025-05-04 06:00:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:16 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:16 --> URI Class Initialized
INFO - 2025-05-04 06:00:16 --> Router Class Initialized
INFO - 2025-05-04 06:00:16 --> Output Class Initialized
INFO - 2025-05-04 06:00:16 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:16 --> Input Class Initialized
INFO - 2025-05-04 06:00:16 --> Language Class Initialized
INFO - 2025-05-04 06:00:16 --> Loader Class Initialized
INFO - 2025-05-04 06:00:16 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:16 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:16 --> Database Driver Class Initialized
INFO - 2025-05-04 06:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:16 --> Form Validation Class Initialized
INFO - 2025-05-04 06:00:16 --> Controller Class Initialized
DEBUG - 2025-05-04 06:00:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:00:16 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 06:00:16 --> POST data: Array
(
    [nama_siswa] => ahmad etster
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2025-05-20
    [tempat_tanggal_lahir] => Batang, 20 Mei 2025
    [tempat_tanggal_lahir_db] => Batang, 20 Mei 2025
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [no_hp_siswa] => 085747110787
    [jalur_pendaftaran] => Tahfidz
    [tinggal] => Bersama Orang Tua
    [dukuh] => Jatirejo 
    [rt] => 02
    [rw] => 03
    [desa] => sembung
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Jatirejo , RT 02/RW 03, sembung, limpugn, Batang, Jawa Tengah
    [alamat_lengkap_db] => Jatirejo , RT 02/RW 03, sembung, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => Kholiyah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => aaaaa
    [pekerjaan_ibu] => Ibu rumah tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 Banyuputih
    [nisn] => 103332
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => eaaaaaaaaaaaaaaa
    [tanggal_lahir_db] => 2025-05-20
)

INFO - 2025-05-04 06:00:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 06:00:16 --> Generated registration number: A-2526/0162
DEBUG - 2025-05-04 06:00:16 --> Form data to save: Array
(
    [nama_siswa] => ahmad etster
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2025-05-20
    [tempat_tanggal_lahir] => Batang, 20 Mei 2025
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Tahfidz
    [tinggal] => Bersama Orang Tua
    [dukuh] => Jatirejo 
    [rt] => 02
    [rw] => 03
    [desa] => sembung
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Jatirejo , RT 02/RW 03, sembung, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => Kholiyah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => aaaaa
    [pekerjaan_ibu] => Ibu rumah tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 Banyuputih
    [nisn] => 103332
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => eaaaaaaaaaaaaaaa
    [tanggal_daftar] => 2025-05-04 06:00:16
    [status] => Baru
    [no_pendaftaran] => A-2526/0162
)

DEBUG - 2025-05-04 06:00:16 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 06:00:16 --> Database config: 1
DEBUG - 2025-05-04 06:00:16 --> Database hostname: localhost
DEBUG - 2025-05-04 06:00:16 --> Database username: root
DEBUG - 2025-05-04 06:00:16 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 06:00:16 --> Data to save: Array
(
    [nama_siswa] => ahmad etster
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2025-05-20
    [tempat_tanggal_lahir] => Batang, 20 Mei 2025
    [no_hp_siswa] => 085747110787
    [rekomendasi] => Pak mujab
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Tahfidz
    [tinggal] => Bersama Orang Tua
    [dukuh] => Jatirejo 
    [rt] => 02
    [rw] => 03
    [desa] => sembung
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Jatirejo , RT 02/RW 03, sembung, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => Kholiyah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => aaaaa
    [pekerjaan_ibu] => Ibu rumah tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 Banyuputih
    [nisn] => 103332
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => eaaaaaaaaaaaaaaa
    [tanggal_daftar] => 2025-05-04 06:00:16
    [status] => Baru
    [no_pendaftaran] => A-2526/0162
)

DEBUG - 2025-05-04 06:00:16 --> Data inserted successfully with ID: 172
INFO - 2025-05-04 06:00:16 --> Final output sent to browser
DEBUG - 2025-05-04 06:00:16 --> Total execution time: 0.0747
INFO - 2025-05-04 06:00:18 --> Config Class Initialized
INFO - 2025-05-04 06:00:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:18 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:18 --> URI Class Initialized
INFO - 2025-05-04 06:00:18 --> Router Class Initialized
INFO - 2025-05-04 06:00:18 --> Output Class Initialized
INFO - 2025-05-04 06:00:18 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:18 --> Input Class Initialized
INFO - 2025-05-04 06:00:18 --> Language Class Initialized
INFO - 2025-05-04 06:00:18 --> Loader Class Initialized
INFO - 2025-05-04 06:00:18 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:18 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:18 --> Database Driver Class Initialized
INFO - 2025-05-04 06:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:18 --> Form Validation Class Initialized
INFO - 2025-05-04 06:00:18 --> Controller Class Initialized
DEBUG - 2025-05-04 06:00:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:00:18 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:00:18 --> Config Class Initialized
INFO - 2025-05-04 06:00:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:00:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:00:18 --> Utf8 Class Initialized
INFO - 2025-05-04 06:00:18 --> URI Class Initialized
INFO - 2025-05-04 06:00:18 --> Router Class Initialized
INFO - 2025-05-04 06:00:18 --> Output Class Initialized
INFO - 2025-05-04 06:00:18 --> Security Class Initialized
DEBUG - 2025-05-04 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:00:18 --> Input Class Initialized
INFO - 2025-05-04 06:00:18 --> Language Class Initialized
INFO - 2025-05-04 06:00:18 --> Loader Class Initialized
INFO - 2025-05-04 06:00:18 --> Helper loaded: form_helper
INFO - 2025-05-04 06:00:18 --> Helper loaded: url_helper
INFO - 2025-05-04 06:00:18 --> Database Driver Class Initialized
INFO - 2025-05-04 06:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:00:18 --> Form Validation Class Initialized
INFO - 2025-05-04 06:00:18 --> Controller Class Initialized
DEBUG - 2025-05-04 06:00:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:00:18 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:00:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:00:18 --> Final output sent to browser
DEBUG - 2025-05-04 06:00:18 --> Total execution time: 0.0304
INFO - 2025-05-04 06:01:42 --> Config Class Initialized
INFO - 2025-05-04 06:01:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:01:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:01:42 --> Utf8 Class Initialized
INFO - 2025-05-04 06:01:42 --> URI Class Initialized
INFO - 2025-05-04 06:01:42 --> Router Class Initialized
INFO - 2025-05-04 06:01:42 --> Output Class Initialized
INFO - 2025-05-04 06:01:42 --> Security Class Initialized
DEBUG - 2025-05-04 06:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:01:42 --> Input Class Initialized
INFO - 2025-05-04 06:01:42 --> Language Class Initialized
INFO - 2025-05-04 06:01:42 --> Loader Class Initialized
INFO - 2025-05-04 06:01:42 --> Helper loaded: form_helper
INFO - 2025-05-04 06:01:42 --> Helper loaded: url_helper
INFO - 2025-05-04 06:01:42 --> Database Driver Class Initialized
INFO - 2025-05-04 06:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:01:42 --> Form Validation Class Initialized
INFO - 2025-05-04 06:01:42 --> Controller Class Initialized
DEBUG - 2025-05-04 06:01:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:01:42 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:01:42 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:01:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:01:42 --> Final output sent to browser
DEBUG - 2025-05-04 06:01:42 --> Total execution time: 0.0439
INFO - 2025-05-04 06:02:53 --> Config Class Initialized
INFO - 2025-05-04 06:02:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:02:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:02:53 --> Utf8 Class Initialized
INFO - 2025-05-04 06:02:53 --> URI Class Initialized
INFO - 2025-05-04 06:02:53 --> Router Class Initialized
INFO - 2025-05-04 06:02:53 --> Output Class Initialized
INFO - 2025-05-04 06:02:53 --> Security Class Initialized
DEBUG - 2025-05-04 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:02:53 --> Input Class Initialized
INFO - 2025-05-04 06:02:53 --> Language Class Initialized
INFO - 2025-05-04 06:02:53 --> Loader Class Initialized
INFO - 2025-05-04 06:02:53 --> Helper loaded: form_helper
INFO - 2025-05-04 06:02:53 --> Helper loaded: url_helper
INFO - 2025-05-04 06:02:53 --> Database Driver Class Initialized
INFO - 2025-05-04 06:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:02:54 --> Form Validation Class Initialized
INFO - 2025-05-04 06:02:54 --> Controller Class Initialized
DEBUG - 2025-05-04 06:02:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:02:54 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 06:02:54 --> POST data: Array
(
    [nama_siswa] => nama tester
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2010-02-16
    [tempat_tanggal_lahir] => Batang, 16 Februari 2010
    [tempat_tanggal_lahir_db] => Batang, 16 Februari 2010
    [rekomendasi] => zakia Rahmawati 10.8
    [pilihan_program] => IPS
    [no_hp_siswa] => 085747110787
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 002
    [rw] => 02
    [desa] => Banyuputih
    [kecamatan] => limpung
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Ngebong, RT 002/RW 02, Banyuputih, limpung, Batang, Jawa Tengah
    [alamat_lengkap_db] => Ngebong, RT 002/RW 02, Banyuputih, limpung, Batang, Jawa Tengah
    [nama_ayah] => ayahku
    [nama_ibu] => Kholiyah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => aaaaa
    [pekerjaan_ibu] => BURUH
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => Kholiyah
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 BANYUPUTIH
    [nisn] => 4584568554
    [alamat_sekolah] => yuyuyu
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => uyuyuyuyuy
    [tanggal_lahir_db] => 2010-02-16
)

INFO - 2025-05-04 06:02:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 06:02:54 --> Generated registration number: A-2526/0160
DEBUG - 2025-05-04 06:02:54 --> Form data to save: Array
(
    [nama_siswa] => nama tester
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2010-02-16
    [tempat_tanggal_lahir] => Batang, 16 Februari 2010
    [no_hp_siswa] => 085747110787
    [rekomendasi] => zakia Rahmawati 10.8
    [pilihan_program] => IPS
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 002
    [rw] => 02
    [desa] => Banyuputih
    [kecamatan] => limpung
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Ngebong, RT 002/RW 02, Banyuputih, limpung, Batang, Jawa Tengah
    [nama_ayah] => ayahku
    [nama_ibu] => Kholiyah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => aaaaa
    [pekerjaan_ibu] => BURUH
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => Kholiyah
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 BANYUPUTIH
    [nisn] => 4584568554
    [alamat_sekolah] => yuyuyu
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => uyuyuyuyuy
    [tanggal_daftar] => 2025-05-04 06:02:54
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-04 06:02:54 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 06:02:54 --> Database config: 1
DEBUG - 2025-05-04 06:02:54 --> Database hostname: localhost
DEBUG - 2025-05-04 06:02:54 --> Database username: root
DEBUG - 2025-05-04 06:02:54 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 06:02:54 --> Data to save: Array
(
    [nama_siswa] => nama tester
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2010-02-16
    [tempat_tanggal_lahir] => Batang, 16 Februari 2010
    [no_hp_siswa] => 085747110787
    [rekomendasi] => zakia Rahmawati 10.8
    [pilihan_program] => IPS
    [jalur_pendaftaran] => Sosial
    [tinggal] => Bersama Orang Tua
    [dukuh] => Ngebong
    [rt] => 002
    [rw] => 02
    [desa] => Banyuputih
    [kecamatan] => limpung
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Ngebong, RT 002/RW 02, Banyuputih, limpung, Batang, Jawa Tengah
    [nama_ayah] => ayahku
    [nama_ibu] => Kholiyah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => aaaaa
    [pekerjaan_ibu] => BURUH
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => Kholiyah
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MA NU 01 BANYUPUTIH
    [nisn] => 4584568554
    [alamat_sekolah] => yuyuyu
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => uyuyuyuyuy
    [tanggal_daftar] => 2025-05-04 06:02:54
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-04 06:02:54 --> Data inserted successfully with ID: 173
INFO - 2025-05-04 06:02:54 --> Final output sent to browser
DEBUG - 2025-05-04 06:02:54 --> Total execution time: 0.0413
INFO - 2025-05-04 06:02:55 --> Config Class Initialized
INFO - 2025-05-04 06:02:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:02:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:02:55 --> Utf8 Class Initialized
INFO - 2025-05-04 06:02:55 --> URI Class Initialized
INFO - 2025-05-04 06:02:55 --> Router Class Initialized
INFO - 2025-05-04 06:02:55 --> Output Class Initialized
INFO - 2025-05-04 06:02:55 --> Security Class Initialized
DEBUG - 2025-05-04 06:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:02:55 --> Input Class Initialized
INFO - 2025-05-04 06:02:55 --> Language Class Initialized
INFO - 2025-05-04 06:02:55 --> Loader Class Initialized
INFO - 2025-05-04 06:02:55 --> Helper loaded: form_helper
INFO - 2025-05-04 06:02:55 --> Helper loaded: url_helper
INFO - 2025-05-04 06:02:55 --> Database Driver Class Initialized
INFO - 2025-05-04 06:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:02:55 --> Form Validation Class Initialized
INFO - 2025-05-04 06:02:55 --> Controller Class Initialized
DEBUG - 2025-05-04 06:02:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:02:55 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:02:55 --> Config Class Initialized
INFO - 2025-05-04 06:02:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:02:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:02:55 --> Utf8 Class Initialized
INFO - 2025-05-04 06:02:55 --> URI Class Initialized
INFO - 2025-05-04 06:02:55 --> Router Class Initialized
INFO - 2025-05-04 06:02:55 --> Output Class Initialized
INFO - 2025-05-04 06:02:55 --> Security Class Initialized
DEBUG - 2025-05-04 06:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:02:55 --> Input Class Initialized
INFO - 2025-05-04 06:02:55 --> Language Class Initialized
INFO - 2025-05-04 06:02:55 --> Loader Class Initialized
INFO - 2025-05-04 06:02:55 --> Helper loaded: form_helper
INFO - 2025-05-04 06:02:55 --> Helper loaded: url_helper
INFO - 2025-05-04 06:02:55 --> Database Driver Class Initialized
INFO - 2025-05-04 06:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:02:55 --> Form Validation Class Initialized
INFO - 2025-05-04 06:02:55 --> Controller Class Initialized
DEBUG - 2025-05-04 06:02:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:02:55 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:02:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:02:55 --> Final output sent to browser
DEBUG - 2025-05-04 06:02:55 --> Total execution time: 0.0302
INFO - 2025-05-04 06:04:56 --> Config Class Initialized
INFO - 2025-05-04 06:04:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:04:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:04:56 --> Utf8 Class Initialized
INFO - 2025-05-04 06:04:56 --> URI Class Initialized
INFO - 2025-05-04 06:04:56 --> Router Class Initialized
INFO - 2025-05-04 06:04:56 --> Output Class Initialized
INFO - 2025-05-04 06:04:56 --> Security Class Initialized
DEBUG - 2025-05-04 06:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:04:56 --> Input Class Initialized
INFO - 2025-05-04 06:04:56 --> Language Class Initialized
INFO - 2025-05-04 06:04:56 --> Loader Class Initialized
INFO - 2025-05-04 06:04:56 --> Helper loaded: form_helper
INFO - 2025-05-04 06:04:56 --> Helper loaded: url_helper
INFO - 2025-05-04 06:04:56 --> Database Driver Class Initialized
INFO - 2025-05-04 06:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:04:56 --> Form Validation Class Initialized
INFO - 2025-05-04 06:04:56 --> Controller Class Initialized
DEBUG - 2025-05-04 06:04:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:04:56 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:04:56 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:04:56 --> Final output sent to browser
DEBUG - 2025-05-04 06:04:56 --> Total execution time: 0.0464
INFO - 2025-05-04 06:05:00 --> Config Class Initialized
INFO - 2025-05-04 06:05:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:05:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:05:00 --> Utf8 Class Initialized
INFO - 2025-05-04 06:05:00 --> URI Class Initialized
INFO - 2025-05-04 06:05:00 --> Router Class Initialized
INFO - 2025-05-04 06:05:00 --> Output Class Initialized
INFO - 2025-05-04 06:05:00 --> Security Class Initialized
DEBUG - 2025-05-04 06:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:05:00 --> Input Class Initialized
INFO - 2025-05-04 06:05:00 --> Language Class Initialized
INFO - 2025-05-04 06:05:00 --> Loader Class Initialized
INFO - 2025-05-04 06:05:00 --> Helper loaded: form_helper
INFO - 2025-05-04 06:05:00 --> Helper loaded: url_helper
INFO - 2025-05-04 06:05:00 --> Database Driver Class Initialized
INFO - 2025-05-04 06:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:05:00 --> Form Validation Class Initialized
INFO - 2025-05-04 06:05:00 --> Controller Class Initialized
DEBUG - 2025-05-04 06:05:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:05:00 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:05:00 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:05:00 --> Final output sent to browser
DEBUG - 2025-05-04 06:05:00 --> Total execution time: 0.0519
INFO - 2025-05-04 06:05:53 --> Config Class Initialized
INFO - 2025-05-04 06:05:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:05:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:05:53 --> Utf8 Class Initialized
INFO - 2025-05-04 06:05:53 --> URI Class Initialized
INFO - 2025-05-04 06:05:53 --> Router Class Initialized
INFO - 2025-05-04 06:05:53 --> Output Class Initialized
INFO - 2025-05-04 06:05:53 --> Security Class Initialized
DEBUG - 2025-05-04 06:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:05:53 --> Input Class Initialized
INFO - 2025-05-04 06:05:53 --> Language Class Initialized
INFO - 2025-05-04 06:05:53 --> Loader Class Initialized
INFO - 2025-05-04 06:05:53 --> Helper loaded: form_helper
INFO - 2025-05-04 06:05:53 --> Helper loaded: url_helper
INFO - 2025-05-04 06:05:53 --> Database Driver Class Initialized
INFO - 2025-05-04 06:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:05:53 --> Form Validation Class Initialized
INFO - 2025-05-04 06:05:53 --> Controller Class Initialized
DEBUG - 2025-05-04 06:05:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:05:53 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:05:53 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:05:53 --> Final output sent to browser
DEBUG - 2025-05-04 06:05:53 --> Total execution time: 0.0338
INFO - 2025-05-04 06:06:07 --> Config Class Initialized
INFO - 2025-05-04 06:06:07 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:06:07 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:06:07 --> Utf8 Class Initialized
INFO - 2025-05-04 06:06:07 --> URI Class Initialized
INFO - 2025-05-04 06:06:07 --> Router Class Initialized
INFO - 2025-05-04 06:06:07 --> Output Class Initialized
INFO - 2025-05-04 06:06:07 --> Security Class Initialized
DEBUG - 2025-05-04 06:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:06:07 --> Input Class Initialized
INFO - 2025-05-04 06:06:07 --> Language Class Initialized
INFO - 2025-05-04 06:06:07 --> Loader Class Initialized
INFO - 2025-05-04 06:06:07 --> Helper loaded: form_helper
INFO - 2025-05-04 06:06:07 --> Helper loaded: url_helper
INFO - 2025-05-04 06:06:07 --> Database Driver Class Initialized
INFO - 2025-05-04 06:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:06:07 --> Form Validation Class Initialized
INFO - 2025-05-04 06:06:07 --> Controller Class Initialized
DEBUG - 2025-05-04 06:06:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:06:07 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 06:06:07 --> POST data: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [tempat_tanggal_lahir_db] => Demak, 15 Agustus 2008
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [no_hp_siswa] => 081234567890
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [alamat_lengkap_db] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_lahir_db] => 2008-08-15
)

INFO - 2025-05-04 06:06:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 06:06:07 --> Generated registration number: A-2526/0161
DEBUG - 2025-05-04 06:06:07 --> Form data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 06:06:07
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-04 06:06:07 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 06:06:07 --> Database config: 1
DEBUG - 2025-05-04 06:06:07 --> Database hostname: localhost
DEBUG - 2025-05-04 06:06:07 --> Database username: root
DEBUG - 2025-05-04 06:06:07 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 06:06:07 --> Data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 06:06:07
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-04 06:06:07 --> Data inserted successfully with ID: 174
INFO - 2025-05-04 06:06:07 --> Final output sent to browser
DEBUG - 2025-05-04 06:06:07 --> Total execution time: 0.0403
INFO - 2025-05-04 06:06:08 --> Config Class Initialized
INFO - 2025-05-04 06:06:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:06:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:06:08 --> Utf8 Class Initialized
INFO - 2025-05-04 06:06:08 --> URI Class Initialized
INFO - 2025-05-04 06:06:08 --> Router Class Initialized
INFO - 2025-05-04 06:06:08 --> Output Class Initialized
INFO - 2025-05-04 06:06:08 --> Security Class Initialized
DEBUG - 2025-05-04 06:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:06:08 --> Input Class Initialized
INFO - 2025-05-04 06:06:08 --> Language Class Initialized
INFO - 2025-05-04 06:06:08 --> Loader Class Initialized
INFO - 2025-05-04 06:06:08 --> Helper loaded: form_helper
INFO - 2025-05-04 06:06:08 --> Helper loaded: url_helper
INFO - 2025-05-04 06:06:08 --> Database Driver Class Initialized
INFO - 2025-05-04 06:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:06:08 --> Form Validation Class Initialized
INFO - 2025-05-04 06:06:08 --> Controller Class Initialized
DEBUG - 2025-05-04 06:06:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:06:08 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:06:08 --> Config Class Initialized
INFO - 2025-05-04 06:06:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:06:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:06:08 --> Utf8 Class Initialized
INFO - 2025-05-04 06:06:08 --> URI Class Initialized
INFO - 2025-05-04 06:06:08 --> Router Class Initialized
INFO - 2025-05-04 06:06:08 --> Output Class Initialized
INFO - 2025-05-04 06:06:08 --> Security Class Initialized
DEBUG - 2025-05-04 06:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:06:08 --> Input Class Initialized
INFO - 2025-05-04 06:06:08 --> Language Class Initialized
INFO - 2025-05-04 06:06:08 --> Loader Class Initialized
INFO - 2025-05-04 06:06:08 --> Helper loaded: form_helper
INFO - 2025-05-04 06:06:08 --> Helper loaded: url_helper
INFO - 2025-05-04 06:06:08 --> Database Driver Class Initialized
INFO - 2025-05-04 06:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:06:08 --> Form Validation Class Initialized
INFO - 2025-05-04 06:06:08 --> Controller Class Initialized
DEBUG - 2025-05-04 06:06:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:06:08 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:06:08 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:06:08 --> Final output sent to browser
DEBUG - 2025-05-04 06:06:08 --> Total execution time: 0.0296
INFO - 2025-05-04 06:08:40 --> Config Class Initialized
INFO - 2025-05-04 06:08:40 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:08:40 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:08:40 --> Utf8 Class Initialized
INFO - 2025-05-04 06:08:40 --> URI Class Initialized
INFO - 2025-05-04 06:08:40 --> Router Class Initialized
INFO - 2025-05-04 06:08:40 --> Output Class Initialized
INFO - 2025-05-04 06:08:40 --> Security Class Initialized
DEBUG - 2025-05-04 06:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:08:40 --> Input Class Initialized
INFO - 2025-05-04 06:08:40 --> Language Class Initialized
INFO - 2025-05-04 06:08:40 --> Loader Class Initialized
INFO - 2025-05-04 06:08:40 --> Helper loaded: form_helper
INFO - 2025-05-04 06:08:40 --> Helper loaded: url_helper
INFO - 2025-05-04 06:08:40 --> Database Driver Class Initialized
INFO - 2025-05-04 06:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:08:40 --> Form Validation Class Initialized
INFO - 2025-05-04 06:08:40 --> Controller Class Initialized
DEBUG - 2025-05-04 06:08:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:08:40 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:08:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:08:40 --> Final output sent to browser
DEBUG - 2025-05-04 06:08:40 --> Total execution time: 0.0462
INFO - 2025-05-04 06:08:42 --> Config Class Initialized
INFO - 2025-05-04 06:08:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:08:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:08:42 --> Utf8 Class Initialized
INFO - 2025-05-04 06:08:42 --> URI Class Initialized
INFO - 2025-05-04 06:08:42 --> Router Class Initialized
INFO - 2025-05-04 06:08:42 --> Output Class Initialized
INFO - 2025-05-04 06:08:42 --> Security Class Initialized
DEBUG - 2025-05-04 06:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:08:42 --> Input Class Initialized
INFO - 2025-05-04 06:08:42 --> Language Class Initialized
INFO - 2025-05-04 06:08:42 --> Loader Class Initialized
INFO - 2025-05-04 06:08:42 --> Helper loaded: form_helper
INFO - 2025-05-04 06:08:42 --> Helper loaded: url_helper
INFO - 2025-05-04 06:08:42 --> Database Driver Class Initialized
INFO - 2025-05-04 06:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:08:42 --> Form Validation Class Initialized
INFO - 2025-05-04 06:08:42 --> Controller Class Initialized
DEBUG - 2025-05-04 06:08:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:08:42 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:08:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:08:42 --> Final output sent to browser
DEBUG - 2025-05-04 06:08:42 --> Total execution time: 0.0528
INFO - 2025-05-04 06:08:47 --> Config Class Initialized
INFO - 2025-05-04 06:08:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:08:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:08:47 --> Utf8 Class Initialized
INFO - 2025-05-04 06:08:47 --> URI Class Initialized
INFO - 2025-05-04 06:08:47 --> Router Class Initialized
INFO - 2025-05-04 06:08:47 --> Output Class Initialized
INFO - 2025-05-04 06:08:47 --> Security Class Initialized
DEBUG - 2025-05-04 06:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:08:47 --> Input Class Initialized
INFO - 2025-05-04 06:08:47 --> Language Class Initialized
INFO - 2025-05-04 06:08:47 --> Loader Class Initialized
INFO - 2025-05-04 06:08:47 --> Helper loaded: form_helper
INFO - 2025-05-04 06:08:47 --> Helper loaded: url_helper
INFO - 2025-05-04 06:08:47 --> Database Driver Class Initialized
INFO - 2025-05-04 06:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:08:47 --> Form Validation Class Initialized
INFO - 2025-05-04 06:08:47 --> Controller Class Initialized
DEBUG - 2025-05-04 06:08:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:08:47 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:08:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:08:47 --> Final output sent to browser
DEBUG - 2025-05-04 06:08:47 --> Total execution time: 0.0309
INFO - 2025-05-04 06:08:56 --> Config Class Initialized
INFO - 2025-05-04 06:08:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:08:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:08:56 --> Utf8 Class Initialized
INFO - 2025-05-04 06:08:56 --> URI Class Initialized
INFO - 2025-05-04 06:08:56 --> Router Class Initialized
INFO - 2025-05-04 06:08:56 --> Output Class Initialized
INFO - 2025-05-04 06:08:56 --> Security Class Initialized
DEBUG - 2025-05-04 06:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:08:56 --> Input Class Initialized
INFO - 2025-05-04 06:08:56 --> Language Class Initialized
INFO - 2025-05-04 06:08:56 --> Loader Class Initialized
INFO - 2025-05-04 06:08:56 --> Helper loaded: form_helper
INFO - 2025-05-04 06:08:56 --> Helper loaded: url_helper
INFO - 2025-05-04 06:08:56 --> Database Driver Class Initialized
INFO - 2025-05-04 06:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:08:56 --> Form Validation Class Initialized
INFO - 2025-05-04 06:08:56 --> Controller Class Initialized
DEBUG - 2025-05-04 06:08:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:08:56 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 06:08:56 --> POST data: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [tempat_tanggal_lahir_db] => Demak, 15 Agustus 2008
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [no_hp_siswa] => 081234567890
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [alamat_lengkap_db] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_lahir_db] => 2008-08-15
)

INFO - 2025-05-04 06:08:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 06:08:56 --> Generated registration number: A-2526/0160
DEBUG - 2025-05-04 06:08:56 --> Form data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 06:08:56
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-04 06:08:56 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 06:08:56 --> Database config: 1
DEBUG - 2025-05-04 06:08:56 --> Database hostname: localhost
DEBUG - 2025-05-04 06:08:56 --> Database username: root
DEBUG - 2025-05-04 06:08:56 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 06:08:56 --> Data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 06:08:56
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-04 06:08:56 --> Data inserted successfully with ID: 175
INFO - 2025-05-04 06:08:56 --> Final output sent to browser
DEBUG - 2025-05-04 06:08:56 --> Total execution time: 0.0385
INFO - 2025-05-04 06:09:49 --> Config Class Initialized
INFO - 2025-05-04 06:09:49 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:09:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:09:49 --> Utf8 Class Initialized
INFO - 2025-05-04 06:09:49 --> URI Class Initialized
INFO - 2025-05-04 06:09:49 --> Router Class Initialized
INFO - 2025-05-04 06:09:49 --> Output Class Initialized
INFO - 2025-05-04 06:09:49 --> Security Class Initialized
DEBUG - 2025-05-04 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:09:49 --> Input Class Initialized
INFO - 2025-05-04 06:09:49 --> Language Class Initialized
INFO - 2025-05-04 06:09:49 --> Loader Class Initialized
INFO - 2025-05-04 06:09:49 --> Helper loaded: form_helper
INFO - 2025-05-04 06:09:49 --> Helper loaded: url_helper
INFO - 2025-05-04 06:09:49 --> Database Driver Class Initialized
INFO - 2025-05-04 06:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:09:49 --> Form Validation Class Initialized
INFO - 2025-05-04 06:09:49 --> Controller Class Initialized
DEBUG - 2025-05-04 06:09:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:09:49 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:09:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:09:49 --> Final output sent to browser
DEBUG - 2025-05-04 06:09:49 --> Total execution time: 0.0353
INFO - 2025-05-04 06:10:00 --> Config Class Initialized
INFO - 2025-05-04 06:10:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:00 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:00 --> URI Class Initialized
INFO - 2025-05-04 06:10:00 --> Router Class Initialized
INFO - 2025-05-04 06:10:00 --> Output Class Initialized
INFO - 2025-05-04 06:10:00 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:00 --> Input Class Initialized
INFO - 2025-05-04 06:10:00 --> Language Class Initialized
INFO - 2025-05-04 06:10:00 --> Loader Class Initialized
INFO - 2025-05-04 06:10:00 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:00 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:00 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:00 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:00 --> Controller Class Initialized
DEBUG - 2025-05-04 06:10:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:10:00 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 06:10:00 --> POST data: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [tempat_tanggal_lahir_db] => Demak, 15 Agustus 2008
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [no_hp_siswa] => 081234567890
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [alamat_lengkap_db] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_lahir_db] => 2008-08-15
)

INFO - 2025-05-04 06:10:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 06:10:00 --> Generated registration number: A-2526/0160
DEBUG - 2025-05-04 06:10:00 --> Form data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 06:10:00
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-04 06:10:00 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 06:10:00 --> Database config: 1
DEBUG - 2025-05-04 06:10:00 --> Database hostname: localhost
DEBUG - 2025-05-04 06:10:00 --> Database username: root
DEBUG - 2025-05-04 06:10:00 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 06:10:00 --> Data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 06:10:00
    [status] => Baru
    [no_pendaftaran] => A-2526/0160
)

DEBUG - 2025-05-04 06:10:00 --> Data inserted successfully with ID: 176
INFO - 2025-05-04 06:10:00 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:00 --> Total execution time: 0.0393
INFO - 2025-05-04 06:10:02 --> Config Class Initialized
INFO - 2025-05-04 06:10:02 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:02 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:02 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:02 --> URI Class Initialized
DEBUG - 2025-05-04 06:10:02 --> No URI present. Default controller set.
INFO - 2025-05-04 06:10:02 --> Router Class Initialized
INFO - 2025-05-04 06:10:02 --> Output Class Initialized
INFO - 2025-05-04 06:10:02 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:02 --> Input Class Initialized
INFO - 2025-05-04 06:10:02 --> Language Class Initialized
INFO - 2025-05-04 06:10:02 --> Loader Class Initialized
INFO - 2025-05-04 06:10:02 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:02 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:02 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:02 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:02 --> Controller Class Initialized
INFO - 2025-05-04 06:10:02 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:02 --> Total execution time: 0.0338
INFO - 2025-05-04 06:10:26 --> Config Class Initialized
INFO - 2025-05-04 06:10:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:26 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:26 --> URI Class Initialized
INFO - 2025-05-04 06:10:26 --> Router Class Initialized
INFO - 2025-05-04 06:10:26 --> Output Class Initialized
INFO - 2025-05-04 06:10:26 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:26 --> Input Class Initialized
INFO - 2025-05-04 06:10:26 --> Language Class Initialized
INFO - 2025-05-04 06:10:26 --> Loader Class Initialized
INFO - 2025-05-04 06:10:26 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:26 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:26 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:26 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:26 --> Controller Class Initialized
INFO - 2025-05-04 06:10:26 --> Config Class Initialized
INFO - 2025-05-04 06:10:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:26 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:26 --> URI Class Initialized
INFO - 2025-05-04 06:10:26 --> Router Class Initialized
INFO - 2025-05-04 06:10:26 --> Output Class Initialized
INFO - 2025-05-04 06:10:26 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:26 --> Input Class Initialized
INFO - 2025-05-04 06:10:26 --> Language Class Initialized
INFO - 2025-05-04 06:10:26 --> Loader Class Initialized
INFO - 2025-05-04 06:10:26 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:26 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:26 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:26 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:26 --> Controller Class Initialized
INFO - 2025-05-04 06:10:26 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/login.php
INFO - 2025-05-04 06:10:26 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:26 --> Total execution time: 0.0295
INFO - 2025-05-04 06:10:28 --> Config Class Initialized
INFO - 2025-05-04 06:10:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:28 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:28 --> URI Class Initialized
INFO - 2025-05-04 06:10:28 --> Router Class Initialized
INFO - 2025-05-04 06:10:28 --> Output Class Initialized
INFO - 2025-05-04 06:10:28 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:28 --> Input Class Initialized
INFO - 2025-05-04 06:10:28 --> Language Class Initialized
INFO - 2025-05-04 06:10:28 --> Loader Class Initialized
INFO - 2025-05-04 06:10:28 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:28 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:28 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:28 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:28 --> Controller Class Initialized
INFO - 2025-05-04 06:10:28 --> Config Class Initialized
INFO - 2025-05-04 06:10:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:28 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:28 --> URI Class Initialized
INFO - 2025-05-04 06:10:28 --> Router Class Initialized
INFO - 2025-05-04 06:10:28 --> Output Class Initialized
INFO - 2025-05-04 06:10:28 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:28 --> Input Class Initialized
INFO - 2025-05-04 06:10:28 --> Language Class Initialized
INFO - 2025-05-04 06:10:28 --> Loader Class Initialized
INFO - 2025-05-04 06:10:28 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:28 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:28 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:28 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:28 --> Controller Class Initialized
INFO - 2025-05-04 06:10:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:10:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:10:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:10:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 06:10:28 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:28 --> Total execution time: 0.0314
INFO - 2025-05-04 06:10:29 --> Config Class Initialized
INFO - 2025-05-04 06:10:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:29 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:29 --> URI Class Initialized
INFO - 2025-05-04 06:10:29 --> Router Class Initialized
INFO - 2025-05-04 06:10:29 --> Output Class Initialized
INFO - 2025-05-04 06:10:29 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:29 --> Input Class Initialized
INFO - 2025-05-04 06:10:29 --> Language Class Initialized
INFO - 2025-05-04 06:10:29 --> Loader Class Initialized
INFO - 2025-05-04 06:10:29 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:29 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:29 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:29 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:29 --> Controller Class Initialized
INFO - 2025-05-04 06:10:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:10:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:10:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:10:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 06:10:29 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:29 --> Total execution time: 0.0330
INFO - 2025-05-04 06:10:31 --> Config Class Initialized
INFO - 2025-05-04 06:10:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:31 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:31 --> URI Class Initialized
INFO - 2025-05-04 06:10:31 --> Router Class Initialized
INFO - 2025-05-04 06:10:31 --> Output Class Initialized
INFO - 2025-05-04 06:10:31 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:31 --> Input Class Initialized
INFO - 2025-05-04 06:10:31 --> Language Class Initialized
INFO - 2025-05-04 06:10:31 --> Loader Class Initialized
INFO - 2025-05-04 06:10:31 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:31 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:31 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:31 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:31 --> Controller Class Initialized
INFO - 2025-05-04 06:10:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:10:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:10:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:10:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-04 06:10:31 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:31 --> Total execution time: 0.0358
INFO - 2025-05-04 06:10:34 --> Config Class Initialized
INFO - 2025-05-04 06:10:34 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:34 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:34 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:34 --> URI Class Initialized
INFO - 2025-05-04 06:10:34 --> Router Class Initialized
INFO - 2025-05-04 06:10:34 --> Output Class Initialized
INFO - 2025-05-04 06:10:34 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:34 --> Input Class Initialized
INFO - 2025-05-04 06:10:34 --> Language Class Initialized
INFO - 2025-05-04 06:10:34 --> Loader Class Initialized
INFO - 2025-05-04 06:10:34 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:34 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:34 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:34 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:34 --> Controller Class Initialized
INFO - 2025-05-04 06:10:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:10:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:10:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:10:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 06:10:34 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:34 --> Total execution time: 0.0347
INFO - 2025-05-04 06:10:43 --> Config Class Initialized
INFO - 2025-05-04 06:10:43 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:43 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:43 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:43 --> URI Class Initialized
INFO - 2025-05-04 06:10:43 --> Router Class Initialized
INFO - 2025-05-04 06:10:43 --> Output Class Initialized
INFO - 2025-05-04 06:10:43 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:43 --> Input Class Initialized
INFO - 2025-05-04 06:10:43 --> Language Class Initialized
INFO - 2025-05-04 06:10:43 --> Loader Class Initialized
INFO - 2025-05-04 06:10:43 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:43 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:43 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:43 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:43 --> Controller Class Initialized
INFO - 2025-05-04 06:10:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:10:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:10:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:10:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-04 06:10:43 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:43 --> Total execution time: 0.0374
INFO - 2025-05-04 06:10:51 --> Config Class Initialized
INFO - 2025-05-04 06:10:51 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:10:51 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:10:51 --> Utf8 Class Initialized
INFO - 2025-05-04 06:10:51 --> URI Class Initialized
INFO - 2025-05-04 06:10:51 --> Router Class Initialized
INFO - 2025-05-04 06:10:51 --> Output Class Initialized
INFO - 2025-05-04 06:10:51 --> Security Class Initialized
DEBUG - 2025-05-04 06:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:10:51 --> Input Class Initialized
INFO - 2025-05-04 06:10:51 --> Language Class Initialized
INFO - 2025-05-04 06:10:51 --> Loader Class Initialized
INFO - 2025-05-04 06:10:51 --> Helper loaded: form_helper
INFO - 2025-05-04 06:10:51 --> Helper loaded: url_helper
INFO - 2025-05-04 06:10:51 --> Database Driver Class Initialized
INFO - 2025-05-04 06:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:10:51 --> Form Validation Class Initialized
INFO - 2025-05-04 06:10:51 --> Controller Class Initialized
INFO - 2025-05-04 06:10:51 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:10:51 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:10:51 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_pendaftar.php
INFO - 2025-05-04 06:10:51 --> Final output sent to browser
DEBUG - 2025-05-04 06:10:51 --> Total execution time: 0.0344
INFO - 2025-05-04 06:11:03 --> Config Class Initialized
INFO - 2025-05-04 06:11:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:03 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:03 --> URI Class Initialized
INFO - 2025-05-04 06:11:03 --> Router Class Initialized
INFO - 2025-05-04 06:11:03 --> Output Class Initialized
INFO - 2025-05-04 06:11:03 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:03 --> Input Class Initialized
INFO - 2025-05-04 06:11:03 --> Language Class Initialized
INFO - 2025-05-04 06:11:03 --> Loader Class Initialized
INFO - 2025-05-04 06:11:03 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:03 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:03 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:03 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:03 --> Controller Class Initialized
INFO - 2025-05-04 06:11:03 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:03 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:03 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:03 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-04 06:11:03 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:03 --> Total execution time: 0.0336
INFO - 2025-05-04 06:11:05 --> Config Class Initialized
INFO - 2025-05-04 06:11:05 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:05 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:05 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:05 --> URI Class Initialized
INFO - 2025-05-04 06:11:05 --> Router Class Initialized
INFO - 2025-05-04 06:11:05 --> Output Class Initialized
INFO - 2025-05-04 06:11:05 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:05 --> Input Class Initialized
INFO - 2025-05-04 06:11:05 --> Language Class Initialized
INFO - 2025-05-04 06:11:05 --> Loader Class Initialized
INFO - 2025-05-04 06:11:05 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:05 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:05 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:05 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:05 --> Controller Class Initialized
INFO - 2025-05-04 06:11:05 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:05 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:05 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:05 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 06:11:05 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:05 --> Total execution time: 0.0338
INFO - 2025-05-04 06:11:24 --> Config Class Initialized
INFO - 2025-05-04 06:11:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:24 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:24 --> URI Class Initialized
INFO - 2025-05-04 06:11:24 --> Router Class Initialized
INFO - 2025-05-04 06:11:24 --> Output Class Initialized
INFO - 2025-05-04 06:11:24 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:24 --> Input Class Initialized
INFO - 2025-05-04 06:11:24 --> Language Class Initialized
INFO - 2025-05-04 06:11:24 --> Loader Class Initialized
INFO - 2025-05-04 06:11:24 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:24 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:24 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:24 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:24 --> Controller Class Initialized
INFO - 2025-05-04 06:11:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-04 06:11:24 --> Config Class Initialized
INFO - 2025-05-04 06:11:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:24 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:24 --> URI Class Initialized
INFO - 2025-05-04 06:11:24 --> Router Class Initialized
INFO - 2025-05-04 06:11:24 --> Output Class Initialized
INFO - 2025-05-04 06:11:24 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:24 --> Input Class Initialized
INFO - 2025-05-04 06:11:24 --> Language Class Initialized
INFO - 2025-05-04 06:11:24 --> Loader Class Initialized
INFO - 2025-05-04 06:11:24 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:24 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:24 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:24 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:24 --> Controller Class Initialized
INFO - 2025-05-04 06:11:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 06:11:24 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:24 --> Total execution time: 0.0328
INFO - 2025-05-04 06:11:26 --> Config Class Initialized
INFO - 2025-05-04 06:11:26 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:26 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:26 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:26 --> URI Class Initialized
INFO - 2025-05-04 06:11:26 --> Router Class Initialized
INFO - 2025-05-04 06:11:26 --> Output Class Initialized
INFO - 2025-05-04 06:11:26 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:26 --> Input Class Initialized
INFO - 2025-05-04 06:11:26 --> Language Class Initialized
INFO - 2025-05-04 06:11:26 --> Loader Class Initialized
INFO - 2025-05-04 06:11:26 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:26 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:26 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:26 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:26 --> Controller Class Initialized
INFO - 2025-05-04 06:11:26 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:26 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:26 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:26 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-04 06:11:26 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:26 --> Total execution time: 0.0361
INFO - 2025-05-04 06:11:28 --> Config Class Initialized
INFO - 2025-05-04 06:11:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:28 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:28 --> URI Class Initialized
INFO - 2025-05-04 06:11:28 --> Router Class Initialized
INFO - 2025-05-04 06:11:28 --> Output Class Initialized
INFO - 2025-05-04 06:11:28 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:28 --> Input Class Initialized
INFO - 2025-05-04 06:11:28 --> Language Class Initialized
INFO - 2025-05-04 06:11:28 --> Loader Class Initialized
INFO - 2025-05-04 06:11:28 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:28 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:28 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:28 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:28 --> Controller Class Initialized
INFO - 2025-05-04 06:11:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 06:11:28 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:28 --> Total execution time: 0.0339
INFO - 2025-05-04 06:11:30 --> Config Class Initialized
INFO - 2025-05-04 06:11:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:30 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:30 --> URI Class Initialized
INFO - 2025-05-04 06:11:30 --> Router Class Initialized
INFO - 2025-05-04 06:11:30 --> Output Class Initialized
INFO - 2025-05-04 06:11:30 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:30 --> Input Class Initialized
INFO - 2025-05-04 06:11:30 --> Language Class Initialized
INFO - 2025-05-04 06:11:30 --> Loader Class Initialized
INFO - 2025-05-04 06:11:30 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:30 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:30 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:30 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:30 --> Controller Class Initialized
INFO - 2025-05-04 06:11:30 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:30 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-04 06:11:30 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:30 --> Total execution time: 0.0362
INFO - 2025-05-04 06:11:35 --> Config Class Initialized
INFO - 2025-05-04 06:11:35 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:35 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:35 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:35 --> URI Class Initialized
INFO - 2025-05-04 06:11:35 --> Router Class Initialized
INFO - 2025-05-04 06:11:35 --> Output Class Initialized
INFO - 2025-05-04 06:11:35 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:35 --> Input Class Initialized
INFO - 2025-05-04 06:11:35 --> Language Class Initialized
INFO - 2025-05-04 06:11:35 --> Loader Class Initialized
INFO - 2025-05-04 06:11:35 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:35 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:35 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:35 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:35 --> Controller Class Initialized
INFO - 2025-05-04 06:11:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 06:11:35 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:35 --> Total execution time: 0.0342
INFO - 2025-05-04 06:11:39 --> Config Class Initialized
INFO - 2025-05-04 06:11:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:39 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:39 --> URI Class Initialized
INFO - 2025-05-04 06:11:39 --> Router Class Initialized
INFO - 2025-05-04 06:11:39 --> Output Class Initialized
INFO - 2025-05-04 06:11:39 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:39 --> Input Class Initialized
INFO - 2025-05-04 06:11:39 --> Language Class Initialized
INFO - 2025-05-04 06:11:39 --> Loader Class Initialized
INFO - 2025-05-04 06:11:39 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:39 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:39 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:39 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:39 --> Controller Class Initialized
INFO - 2025-05-04 06:11:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-04 06:11:39 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:39 --> Total execution time: 0.0331
INFO - 2025-05-04 06:11:41 --> Config Class Initialized
INFO - 2025-05-04 06:11:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:41 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:41 --> URI Class Initialized
INFO - 2025-05-04 06:11:41 --> Router Class Initialized
INFO - 2025-05-04 06:11:41 --> Output Class Initialized
INFO - 2025-05-04 06:11:41 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:41 --> Input Class Initialized
INFO - 2025-05-04 06:11:41 --> Language Class Initialized
INFO - 2025-05-04 06:11:41 --> Loader Class Initialized
INFO - 2025-05-04 06:11:41 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:41 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:41 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:41 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:41 --> Controller Class Initialized
INFO - 2025-05-04 06:11:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:41 --> Config Class Initialized
INFO - 2025-05-04 06:11:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:41 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:41 --> URI Class Initialized
INFO - 2025-05-04 06:11:41 --> Router Class Initialized
INFO - 2025-05-04 06:11:41 --> Output Class Initialized
INFO - 2025-05-04 06:11:41 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:41 --> Input Class Initialized
INFO - 2025-05-04 06:11:41 --> Language Class Initialized
INFO - 2025-05-04 06:11:41 --> Loader Class Initialized
INFO - 2025-05-04 06:11:41 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:41 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:41 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:41 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:41 --> Controller Class Initialized
INFO - 2025-05-04 06:11:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 06:11:41 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:41 --> Total execution time: 0.0341
INFO - 2025-05-04 06:11:55 --> Config Class Initialized
INFO - 2025-05-04 06:11:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:55 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:55 --> URI Class Initialized
INFO - 2025-05-04 06:11:55 --> Router Class Initialized
INFO - 2025-05-04 06:11:55 --> Output Class Initialized
INFO - 2025-05-04 06:11:55 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:55 --> Input Class Initialized
INFO - 2025-05-04 06:11:55 --> Language Class Initialized
INFO - 2025-05-04 06:11:55 --> Loader Class Initialized
INFO - 2025-05-04 06:11:55 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:55 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:55 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:55 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:55 --> Controller Class Initialized
INFO - 2025-05-04 06:11:55 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 06:11:55 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:55 --> Total execution time: 0.0355
INFO - 2025-05-04 06:11:58 --> Config Class Initialized
INFO - 2025-05-04 06:11:58 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:11:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:11:58 --> Utf8 Class Initialized
INFO - 2025-05-04 06:11:58 --> URI Class Initialized
INFO - 2025-05-04 06:11:58 --> Router Class Initialized
INFO - 2025-05-04 06:11:58 --> Output Class Initialized
INFO - 2025-05-04 06:11:58 --> Security Class Initialized
DEBUG - 2025-05-04 06:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:11:58 --> Input Class Initialized
INFO - 2025-05-04 06:11:58 --> Language Class Initialized
INFO - 2025-05-04 06:11:58 --> Loader Class Initialized
INFO - 2025-05-04 06:11:58 --> Helper loaded: form_helper
INFO - 2025-05-04 06:11:58 --> Helper loaded: url_helper
INFO - 2025-05-04 06:11:58 --> Database Driver Class Initialized
INFO - 2025-05-04 06:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:11:58 --> Form Validation Class Initialized
INFO - 2025-05-04 06:11:58 --> Controller Class Initialized
INFO - 2025-05-04 06:11:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:11:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:11:58 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:11:58 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-04 06:11:58 --> Final output sent to browser
DEBUG - 2025-05-04 06:11:58 --> Total execution time: 0.0367
INFO - 2025-05-04 06:12:49 --> Config Class Initialized
INFO - 2025-05-04 06:12:49 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:12:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:12:49 --> Utf8 Class Initialized
INFO - 2025-05-04 06:12:49 --> URI Class Initialized
INFO - 2025-05-04 06:12:49 --> Router Class Initialized
INFO - 2025-05-04 06:12:49 --> Output Class Initialized
INFO - 2025-05-04 06:12:49 --> Security Class Initialized
DEBUG - 2025-05-04 06:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:12:49 --> Input Class Initialized
INFO - 2025-05-04 06:12:49 --> Language Class Initialized
INFO - 2025-05-04 06:12:49 --> Loader Class Initialized
INFO - 2025-05-04 06:12:49 --> Helper loaded: form_helper
INFO - 2025-05-04 06:12:49 --> Helper loaded: url_helper
INFO - 2025-05-04 06:12:49 --> Database Driver Class Initialized
INFO - 2025-05-04 06:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:12:49 --> Form Validation Class Initialized
INFO - 2025-05-04 06:12:49 --> Controller Class Initialized
INFO - 2025-05-04 06:12:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:12:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:12:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:12:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-04 06:12:49 --> Final output sent to browser
DEBUG - 2025-05-04 06:12:49 --> Total execution time: 0.0437
INFO - 2025-05-04 06:13:16 --> Config Class Initialized
INFO - 2025-05-04 06:13:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:16 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:16 --> URI Class Initialized
DEBUG - 2025-05-04 06:13:16 --> No URI present. Default controller set.
INFO - 2025-05-04 06:13:16 --> Router Class Initialized
INFO - 2025-05-04 06:13:16 --> Output Class Initialized
INFO - 2025-05-04 06:13:16 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:16 --> Input Class Initialized
INFO - 2025-05-04 06:13:16 --> Language Class Initialized
INFO - 2025-05-04 06:13:16 --> Loader Class Initialized
INFO - 2025-05-04 06:13:16 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:16 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:16 --> Database Driver Class Initialized
INFO - 2025-05-04 06:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:16 --> Form Validation Class Initialized
INFO - 2025-05-04 06:13:16 --> Controller Class Initialized
INFO - 2025-05-04 06:13:16 --> Final output sent to browser
DEBUG - 2025-05-04 06:13:16 --> Total execution time: 0.0306
INFO - 2025-05-04 06:13:30 --> Config Class Initialized
INFO - 2025-05-04 06:13:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:30 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:30 --> URI Class Initialized
INFO - 2025-05-04 06:13:30 --> Router Class Initialized
INFO - 2025-05-04 06:13:30 --> Output Class Initialized
INFO - 2025-05-04 06:13:30 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:30 --> Input Class Initialized
INFO - 2025-05-04 06:13:30 --> Language Class Initialized
INFO - 2025-05-04 06:13:30 --> Loader Class Initialized
INFO - 2025-05-04 06:13:30 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:30 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:30 --> Database Driver Class Initialized
INFO - 2025-05-04 06:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:30 --> Form Validation Class Initialized
INFO - 2025-05-04 06:13:30 --> Controller Class Initialized
DEBUG - 2025-05-04 06:13:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:13:30 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:13:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:13:30 --> Final output sent to browser
DEBUG - 2025-05-04 06:13:30 --> Total execution time: 0.0316
INFO - 2025-05-04 06:13:40 --> Config Class Initialized
INFO - 2025-05-04 06:13:40 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:40 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:40 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:40 --> URI Class Initialized
INFO - 2025-05-04 06:13:40 --> Router Class Initialized
INFO - 2025-05-04 06:13:40 --> Output Class Initialized
INFO - 2025-05-04 06:13:40 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:40 --> Input Class Initialized
INFO - 2025-05-04 06:13:40 --> Language Class Initialized
INFO - 2025-05-04 06:13:40 --> Loader Class Initialized
INFO - 2025-05-04 06:13:40 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:40 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:40 --> Database Driver Class Initialized
INFO - 2025-05-04 06:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:40 --> Form Validation Class Initialized
INFO - 2025-05-04 06:13:40 --> Controller Class Initialized
INFO - 2025-05-04 06:13:40 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:13:40 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:13:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:13:40 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-04 06:13:40 --> Final output sent to browser
DEBUG - 2025-05-04 06:13:40 --> Total execution time: 0.0338
INFO - 2025-05-04 06:13:42 --> Config Class Initialized
INFO - 2025-05-04 06:13:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:42 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:42 --> URI Class Initialized
INFO - 2025-05-04 06:13:42 --> Router Class Initialized
INFO - 2025-05-04 06:13:42 --> Output Class Initialized
INFO - 2025-05-04 06:13:42 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:42 --> Input Class Initialized
INFO - 2025-05-04 06:13:42 --> Language Class Initialized
INFO - 2025-05-04 06:13:42 --> Loader Class Initialized
INFO - 2025-05-04 06:13:42 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:42 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:42 --> Database Driver Class Initialized
INFO - 2025-05-04 06:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:42 --> Form Validation Class Initialized
INFO - 2025-05-04 06:13:42 --> Controller Class Initialized
INFO - 2025-05-04 06:13:42 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:13:42 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:13:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:13:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 06:13:42 --> Final output sent to browser
DEBUG - 2025-05-04 06:13:42 --> Total execution time: 0.0312
INFO - 2025-05-04 06:13:43 --> Config Class Initialized
INFO - 2025-05-04 06:13:43 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:43 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:43 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:43 --> URI Class Initialized
INFO - 2025-05-04 06:13:43 --> Router Class Initialized
INFO - 2025-05-04 06:13:43 --> Output Class Initialized
INFO - 2025-05-04 06:13:43 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:43 --> Input Class Initialized
INFO - 2025-05-04 06:13:43 --> Language Class Initialized
INFO - 2025-05-04 06:13:43 --> Loader Class Initialized
INFO - 2025-05-04 06:13:43 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:43 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:43 --> Database Driver Class Initialized
INFO - 2025-05-04 06:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:43 --> Form Validation Class Initialized
INFO - 2025-05-04 06:13:43 --> Controller Class Initialized
INFO - 2025-05-04 06:13:43 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:13:43 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:13:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:13:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 06:13:43 --> Final output sent to browser
DEBUG - 2025-05-04 06:13:43 --> Total execution time: 0.0332
INFO - 2025-05-04 06:13:44 --> Config Class Initialized
INFO - 2025-05-04 06:13:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:44 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:44 --> URI Class Initialized
INFO - 2025-05-04 06:13:44 --> Router Class Initialized
INFO - 2025-05-04 06:13:44 --> Output Class Initialized
INFO - 2025-05-04 06:13:44 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:44 --> Input Class Initialized
INFO - 2025-05-04 06:13:44 --> Language Class Initialized
INFO - 2025-05-04 06:13:44 --> Loader Class Initialized
INFO - 2025-05-04 06:13:44 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:44 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:44 --> Database Driver Class Initialized
INFO - 2025-05-04 06:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:44 --> Form Validation Class Initialized
INFO - 2025-05-04 06:13:44 --> Controller Class Initialized
INFO - 2025-05-04 06:13:44 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:13:44 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:13:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:13:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 06:13:44 --> Final output sent to browser
DEBUG - 2025-05-04 06:13:44 --> Total execution time: 0.0305
INFO - 2025-05-04 06:13:53 --> Config Class Initialized
INFO - 2025-05-04 06:13:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:53 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:53 --> URI Class Initialized
INFO - 2025-05-04 06:13:53 --> Router Class Initialized
INFO - 2025-05-04 06:13:53 --> Output Class Initialized
INFO - 2025-05-04 06:13:53 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:53 --> Input Class Initialized
INFO - 2025-05-04 06:13:53 --> Language Class Initialized
INFO - 2025-05-04 06:13:53 --> Loader Class Initialized
INFO - 2025-05-04 06:13:53 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:53 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:53 --> Database Driver Class Initialized
INFO - 2025-05-04 06:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:53 --> Form Validation Class Initialized
INFO - 2025-05-04 06:13:53 --> Controller Class Initialized
INFO - 2025-05-04 06:13:53 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:13:53 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:13:53 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:13:53 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 06:13:53 --> Final output sent to browser
DEBUG - 2025-05-04 06:13:53 --> Total execution time: 0.0359
INFO - 2025-05-04 06:13:58 --> Config Class Initialized
INFO - 2025-05-04 06:13:58 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:13:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:13:58 --> Utf8 Class Initialized
INFO - 2025-05-04 06:13:58 --> URI Class Initialized
INFO - 2025-05-04 06:13:58 --> Router Class Initialized
INFO - 2025-05-04 06:13:58 --> Output Class Initialized
INFO - 2025-05-04 06:13:58 --> Security Class Initialized
DEBUG - 2025-05-04 06:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:13:58 --> Input Class Initialized
INFO - 2025-05-04 06:13:58 --> Language Class Initialized
INFO - 2025-05-04 06:13:58 --> Loader Class Initialized
INFO - 2025-05-04 06:13:58 --> Helper loaded: form_helper
INFO - 2025-05-04 06:13:58 --> Helper loaded: url_helper
INFO - 2025-05-04 06:13:58 --> Database Driver Class Initialized
INFO - 2025-05-04 06:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:13:58 --> Form Validation Class Initialized
INFO - 2025-05-04 06:13:58 --> Controller Class Initialized
INFO - 2025-05-04 06:13:58 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:13:58 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:13:58 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:13:58 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 06:13:58 --> Final output sent to browser
DEBUG - 2025-05-04 06:13:58 --> Total execution time: 0.0320
INFO - 2025-05-04 06:23:09 --> Config Class Initialized
INFO - 2025-05-04 06:23:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:09 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:09 --> URI Class Initialized
INFO - 2025-05-04 06:23:09 --> Router Class Initialized
INFO - 2025-05-04 06:23:09 --> Output Class Initialized
INFO - 2025-05-04 06:23:09 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:09 --> Input Class Initialized
INFO - 2025-05-04 06:23:09 --> Language Class Initialized
INFO - 2025-05-04 06:23:09 --> Loader Class Initialized
INFO - 2025-05-04 06:23:09 --> Helper loaded: form_helper
INFO - 2025-05-04 06:23:09 --> Helper loaded: url_helper
INFO - 2025-05-04 06:23:09 --> Database Driver Class Initialized
INFO - 2025-05-04 06:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:23:09 --> Form Validation Class Initialized
INFO - 2025-05-04 06:23:09 --> Controller Class Initialized
DEBUG - 2025-05-04 06:23:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:23:09 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:23:10 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:23:10 --> Final output sent to browser
DEBUG - 2025-05-04 06:23:10 --> Total execution time: 0.7453
INFO - 2025-05-04 06:23:12 --> Config Class Initialized
INFO - 2025-05-04 06:23:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:12 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:12 --> URI Class Initialized
INFO - 2025-05-04 06:23:12 --> Router Class Initialized
INFO - 2025-05-04 06:23:12 --> Output Class Initialized
INFO - 2025-05-04 06:23:12 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:12 --> Input Class Initialized
INFO - 2025-05-04 06:23:12 --> Language Class Initialized
ERROR - 2025-05-04 06:23:12 --> 404 Page Not Found: Ppdb/admin
INFO - 2025-05-04 06:23:16 --> Config Class Initialized
INFO - 2025-05-04 06:23:16 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:16 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:16 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:16 --> URI Class Initialized
INFO - 2025-05-04 06:23:16 --> Router Class Initialized
INFO - 2025-05-04 06:23:16 --> Output Class Initialized
INFO - 2025-05-04 06:23:16 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:16 --> Input Class Initialized
INFO - 2025-05-04 06:23:16 --> Language Class Initialized
INFO - 2025-05-04 06:23:16 --> Loader Class Initialized
INFO - 2025-05-04 06:23:16 --> Helper loaded: form_helper
INFO - 2025-05-04 06:23:16 --> Helper loaded: url_helper
INFO - 2025-05-04 06:23:16 --> Database Driver Class Initialized
INFO - 2025-05-04 06:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:23:16 --> Form Validation Class Initialized
INFO - 2025-05-04 06:23:16 --> Controller Class Initialized
INFO - 2025-05-04 06:23:16 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:23:16 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:23:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:23:16 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 06:23:16 --> Final output sent to browser
DEBUG - 2025-05-04 06:23:16 --> Total execution time: 0.1629
INFO - 2025-05-04 06:23:18 --> Config Class Initialized
INFO - 2025-05-04 06:23:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:18 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:18 --> URI Class Initialized
INFO - 2025-05-04 06:23:18 --> Router Class Initialized
INFO - 2025-05-04 06:23:18 --> Output Class Initialized
INFO - 2025-05-04 06:23:18 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:18 --> Input Class Initialized
INFO - 2025-05-04 06:23:18 --> Language Class Initialized
INFO - 2025-05-04 06:23:18 --> Loader Class Initialized
INFO - 2025-05-04 06:23:18 --> Helper loaded: form_helper
INFO - 2025-05-04 06:23:18 --> Helper loaded: url_helper
INFO - 2025-05-04 06:23:18 --> Database Driver Class Initialized
INFO - 2025-05-04 06:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:23:18 --> Form Validation Class Initialized
INFO - 2025-05-04 06:23:18 --> Controller Class Initialized
INFO - 2025-05-04 06:23:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:23:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:23:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:23:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 06:23:18 --> Final output sent to browser
DEBUG - 2025-05-04 06:23:18 --> Total execution time: 0.1186
INFO - 2025-05-04 06:23:22 --> Config Class Initialized
INFO - 2025-05-04 06:23:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:22 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:22 --> URI Class Initialized
INFO - 2025-05-04 06:23:22 --> Router Class Initialized
INFO - 2025-05-04 06:23:22 --> Output Class Initialized
INFO - 2025-05-04 06:23:22 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:22 --> Input Class Initialized
INFO - 2025-05-04 06:23:22 --> Language Class Initialized
INFO - 2025-05-04 06:23:22 --> Loader Class Initialized
INFO - 2025-05-04 06:23:22 --> Helper loaded: form_helper
INFO - 2025-05-04 06:23:22 --> Helper loaded: url_helper
INFO - 2025-05-04 06:23:22 --> Database Driver Class Initialized
INFO - 2025-05-04 06:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:23:22 --> Form Validation Class Initialized
INFO - 2025-05-04 06:23:22 --> Controller Class Initialized
INFO - 2025-05-04 06:23:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:23:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:23:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:23:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-04 06:23:22 --> Final output sent to browser
DEBUG - 2025-05-04 06:23:22 --> Total execution time: 0.1044
INFO - 2025-05-04 06:23:24 --> Config Class Initialized
INFO - 2025-05-04 06:23:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:24 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:24 --> URI Class Initialized
INFO - 2025-05-04 06:23:24 --> Router Class Initialized
INFO - 2025-05-04 06:23:24 --> Output Class Initialized
INFO - 2025-05-04 06:23:24 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:24 --> Input Class Initialized
INFO - 2025-05-04 06:23:24 --> Language Class Initialized
INFO - 2025-05-04 06:23:24 --> Loader Class Initialized
INFO - 2025-05-04 06:23:24 --> Helper loaded: form_helper
INFO - 2025-05-04 06:23:24 --> Helper loaded: url_helper
INFO - 2025-05-04 06:23:24 --> Database Driver Class Initialized
INFO - 2025-05-04 06:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:23:24 --> Form Validation Class Initialized
INFO - 2025-05-04 06:23:24 --> Controller Class Initialized
INFO - 2025-05-04 06:23:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:23:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:23:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-04 06:23:24 --> Final output sent to browser
DEBUG - 2025-05-04 06:23:24 --> Total execution time: 0.2541
INFO - 2025-05-04 06:23:28 --> Config Class Initialized
INFO - 2025-05-04 06:23:28 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:28 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:28 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:28 --> URI Class Initialized
INFO - 2025-05-04 06:23:28 --> Router Class Initialized
INFO - 2025-05-04 06:23:28 --> Output Class Initialized
INFO - 2025-05-04 06:23:28 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:28 --> Input Class Initialized
INFO - 2025-05-04 06:23:28 --> Language Class Initialized
INFO - 2025-05-04 06:23:28 --> Loader Class Initialized
INFO - 2025-05-04 06:23:28 --> Helper loaded: form_helper
INFO - 2025-05-04 06:23:28 --> Helper loaded: url_helper
INFO - 2025-05-04 06:23:28 --> Database Driver Class Initialized
INFO - 2025-05-04 06:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:23:28 --> Form Validation Class Initialized
INFO - 2025-05-04 06:23:28 --> Controller Class Initialized
INFO - 2025-05-04 06:23:28 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:23:28 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:23:28 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/pengaturan.php
INFO - 2025-05-04 06:23:28 --> Final output sent to browser
DEBUG - 2025-05-04 06:23:28 --> Total execution time: 0.0338
INFO - 2025-05-04 06:23:41 --> Config Class Initialized
INFO - 2025-05-04 06:23:41 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:23:41 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:23:41 --> Utf8 Class Initialized
INFO - 2025-05-04 06:23:41 --> URI Class Initialized
INFO - 2025-05-04 06:23:41 --> Router Class Initialized
INFO - 2025-05-04 06:23:41 --> Output Class Initialized
INFO - 2025-05-04 06:23:41 --> Security Class Initialized
DEBUG - 2025-05-04 06:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:23:41 --> Input Class Initialized
INFO - 2025-05-04 06:23:41 --> Language Class Initialized
INFO - 2025-05-04 06:23:41 --> Loader Class Initialized
INFO - 2025-05-04 06:23:41 --> Helper loaded: form_helper
INFO - 2025-05-04 06:23:41 --> Helper loaded: url_helper
INFO - 2025-05-04 06:23:41 --> Database Driver Class Initialized
INFO - 2025-05-04 06:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:23:41 --> Form Validation Class Initialized
INFO - 2025-05-04 06:23:41 --> Controller Class Initialized
INFO - 2025-05-04 06:23:41 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:23:41 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:23:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:23:41 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 06:23:41 --> Final output sent to browser
DEBUG - 2025-05-04 06:23:41 --> Total execution time: 0.0329
INFO - 2025-05-04 06:25:22 --> Config Class Initialized
INFO - 2025-05-04 06:25:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:25:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:25:22 --> Utf8 Class Initialized
INFO - 2025-05-04 06:25:22 --> URI Class Initialized
INFO - 2025-05-04 06:25:22 --> Router Class Initialized
INFO - 2025-05-04 06:25:22 --> Output Class Initialized
INFO - 2025-05-04 06:25:22 --> Security Class Initialized
DEBUG - 2025-05-04 06:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:25:22 --> Input Class Initialized
INFO - 2025-05-04 06:25:22 --> Language Class Initialized
INFO - 2025-05-04 06:25:22 --> Loader Class Initialized
INFO - 2025-05-04 06:25:22 --> Helper loaded: form_helper
INFO - 2025-05-04 06:25:22 --> Helper loaded: url_helper
INFO - 2025-05-04 06:25:22 --> Database Driver Class Initialized
INFO - 2025-05-04 06:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:25:22 --> Form Validation Class Initialized
INFO - 2025-05-04 06:25:22 --> Controller Class Initialized
INFO - 2025-05-04 06:25:22 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:25:22 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:25:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:25:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 06:25:22 --> Final output sent to browser
DEBUG - 2025-05-04 06:25:22 --> Total execution time: 0.0342
INFO - 2025-05-04 06:26:15 --> Config Class Initialized
INFO - 2025-05-04 06:26:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:26:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:26:15 --> Utf8 Class Initialized
INFO - 2025-05-04 06:26:15 --> URI Class Initialized
DEBUG - 2025-05-04 06:26:15 --> No URI present. Default controller set.
INFO - 2025-05-04 06:26:15 --> Router Class Initialized
INFO - 2025-05-04 06:26:15 --> Output Class Initialized
INFO - 2025-05-04 06:26:15 --> Security Class Initialized
DEBUG - 2025-05-04 06:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:26:15 --> Input Class Initialized
INFO - 2025-05-04 06:26:15 --> Language Class Initialized
INFO - 2025-05-04 06:26:15 --> Loader Class Initialized
INFO - 2025-05-04 06:26:15 --> Helper loaded: form_helper
INFO - 2025-05-04 06:26:15 --> Helper loaded: url_helper
INFO - 2025-05-04 06:26:15 --> Database Driver Class Initialized
INFO - 2025-05-04 06:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:26:15 --> Form Validation Class Initialized
INFO - 2025-05-04 06:26:15 --> Controller Class Initialized
INFO - 2025-05-04 06:26:15 --> Final output sent to browser
DEBUG - 2025-05-04 06:26:15 --> Total execution time: 0.0305
INFO - 2025-05-04 06:26:18 --> Config Class Initialized
INFO - 2025-05-04 06:26:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:26:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:26:18 --> Utf8 Class Initialized
INFO - 2025-05-04 06:26:18 --> URI Class Initialized
INFO - 2025-05-04 06:26:18 --> Router Class Initialized
INFO - 2025-05-04 06:26:18 --> Output Class Initialized
INFO - 2025-05-04 06:26:18 --> Security Class Initialized
DEBUG - 2025-05-04 06:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:26:18 --> Input Class Initialized
INFO - 2025-05-04 06:26:18 --> Language Class Initialized
INFO - 2025-05-04 06:26:18 --> Loader Class Initialized
INFO - 2025-05-04 06:26:18 --> Helper loaded: form_helper
INFO - 2025-05-04 06:26:18 --> Helper loaded: url_helper
INFO - 2025-05-04 06:26:18 --> Database Driver Class Initialized
INFO - 2025-05-04 06:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:26:18 --> Form Validation Class Initialized
INFO - 2025-05-04 06:26:18 --> Controller Class Initialized
INFO - 2025-05-04 06:26:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 06:26:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 06:26:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 06:26:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 06:26:18 --> Final output sent to browser
DEBUG - 2025-05-04 06:26:18 --> Total execution time: 0.0314
INFO - 2025-05-04 06:26:22 --> Config Class Initialized
INFO - 2025-05-04 06:26:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:26:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:26:22 --> Utf8 Class Initialized
INFO - 2025-05-04 06:26:22 --> URI Class Initialized
INFO - 2025-05-04 06:26:22 --> Router Class Initialized
INFO - 2025-05-04 06:26:22 --> Output Class Initialized
INFO - 2025-05-04 06:26:22 --> Security Class Initialized
DEBUG - 2025-05-04 06:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:26:22 --> Input Class Initialized
INFO - 2025-05-04 06:26:22 --> Language Class Initialized
INFO - 2025-05-04 06:26:22 --> Loader Class Initialized
INFO - 2025-05-04 06:26:22 --> Helper loaded: form_helper
INFO - 2025-05-04 06:26:22 --> Helper loaded: url_helper
INFO - 2025-05-04 06:26:22 --> Database Driver Class Initialized
INFO - 2025-05-04 06:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:26:22 --> Form Validation Class Initialized
INFO - 2025-05-04 06:26:22 --> Controller Class Initialized
DEBUG - 2025-05-04 06:26:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:26:22 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:26:22 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:26:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:26:22 --> Final output sent to browser
DEBUG - 2025-05-04 06:26:22 --> Total execution time: 0.0308
INFO - 2025-05-04 06:26:50 --> Config Class Initialized
INFO - 2025-05-04 06:26:50 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:26:50 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:26:50 --> Utf8 Class Initialized
INFO - 2025-05-04 06:26:50 --> URI Class Initialized
INFO - 2025-05-04 06:26:50 --> Router Class Initialized
INFO - 2025-05-04 06:26:50 --> Output Class Initialized
INFO - 2025-05-04 06:26:50 --> Security Class Initialized
DEBUG - 2025-05-04 06:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:26:50 --> Input Class Initialized
INFO - 2025-05-04 06:26:50 --> Language Class Initialized
INFO - 2025-05-04 06:26:50 --> Loader Class Initialized
INFO - 2025-05-04 06:26:50 --> Helper loaded: form_helper
INFO - 2025-05-04 06:26:50 --> Helper loaded: url_helper
INFO - 2025-05-04 06:26:51 --> Database Driver Class Initialized
INFO - 2025-05-04 06:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:26:51 --> Form Validation Class Initialized
INFO - 2025-05-04 06:26:51 --> Controller Class Initialized
DEBUG - 2025-05-04 06:26:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:26:51 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:26:51 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:26:51 --> Final output sent to browser
DEBUG - 2025-05-04 06:26:51 --> Total execution time: 0.0427
INFO - 2025-05-04 06:27:07 --> Config Class Initialized
INFO - 2025-05-04 06:27:07 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:27:07 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:27:07 --> Utf8 Class Initialized
INFO - 2025-05-04 06:27:07 --> URI Class Initialized
INFO - 2025-05-04 06:27:07 --> Router Class Initialized
INFO - 2025-05-04 06:27:07 --> Output Class Initialized
INFO - 2025-05-04 06:27:07 --> Security Class Initialized
DEBUG - 2025-05-04 06:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:27:07 --> Input Class Initialized
INFO - 2025-05-04 06:27:07 --> Language Class Initialized
INFO - 2025-05-04 06:27:07 --> Loader Class Initialized
INFO - 2025-05-04 06:27:07 --> Helper loaded: form_helper
INFO - 2025-05-04 06:27:07 --> Helper loaded: url_helper
INFO - 2025-05-04 06:27:07 --> Database Driver Class Initialized
INFO - 2025-05-04 06:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:27:07 --> Form Validation Class Initialized
INFO - 2025-05-04 06:27:07 --> Controller Class Initialized
DEBUG - 2025-05-04 06:27:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:27:07 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:27:07 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:27:07 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:27:07 --> Final output sent to browser
DEBUG - 2025-05-04 06:27:07 --> Total execution time: 0.0445
INFO - 2025-05-04 06:27:15 --> Config Class Initialized
INFO - 2025-05-04 06:27:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:27:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:27:15 --> Utf8 Class Initialized
INFO - 2025-05-04 06:27:15 --> URI Class Initialized
INFO - 2025-05-04 06:27:15 --> Router Class Initialized
INFO - 2025-05-04 06:27:15 --> Output Class Initialized
INFO - 2025-05-04 06:27:15 --> Security Class Initialized
DEBUG - 2025-05-04 06:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:27:15 --> Input Class Initialized
INFO - 2025-05-04 06:27:15 --> Language Class Initialized
INFO - 2025-05-04 06:27:15 --> Loader Class Initialized
INFO - 2025-05-04 06:27:15 --> Helper loaded: form_helper
INFO - 2025-05-04 06:27:15 --> Helper loaded: url_helper
INFO - 2025-05-04 06:27:15 --> Database Driver Class Initialized
INFO - 2025-05-04 06:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:27:15 --> Form Validation Class Initialized
INFO - 2025-05-04 06:27:15 --> Controller Class Initialized
DEBUG - 2025-05-04 06:27:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:27:15 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:27:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:27:15 --> Final output sent to browser
DEBUG - 2025-05-04 06:27:15 --> Total execution time: 0.0492
INFO - 2025-05-04 06:28:27 --> Config Class Initialized
INFO - 2025-05-04 06:28:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:28:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:28:27 --> Utf8 Class Initialized
INFO - 2025-05-04 06:28:27 --> URI Class Initialized
INFO - 2025-05-04 06:28:27 --> Router Class Initialized
INFO - 2025-05-04 06:28:27 --> Output Class Initialized
INFO - 2025-05-04 06:28:27 --> Security Class Initialized
DEBUG - 2025-05-04 06:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:28:27 --> Input Class Initialized
INFO - 2025-05-04 06:28:27 --> Language Class Initialized
INFO - 2025-05-04 06:28:27 --> Loader Class Initialized
INFO - 2025-05-04 06:28:27 --> Helper loaded: form_helper
INFO - 2025-05-04 06:28:27 --> Helper loaded: url_helper
INFO - 2025-05-04 06:28:27 --> Database Driver Class Initialized
INFO - 2025-05-04 06:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:28:27 --> Form Validation Class Initialized
INFO - 2025-05-04 06:28:27 --> Controller Class Initialized
DEBUG - 2025-05-04 06:28:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:28:27 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 06:28:27 --> POST data: Array
(
    [nama_siswa] => Akhmad Lutfi ewewew
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2015-06-25
    [tempat_tanggal_lahir] => Batang, 25 Juni 2015
    [tempat_tanggal_lahir_db] => Batang, 25 Juni 2015
    [rekomendasi] => 
    [pilihan_program] => MIPA
    [no_hp_siswa] => 085747110787
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Lokojoyo banyuputih
    [rt] => 03
    [rw] => 02
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Lokojoyo banyuputih, RT 03/RW 02, Banyuputih, limpugn, Batang, Jawa Tengah
    [alamat_lengkap_db] => Lokojoyo banyuputih, RT 03/RW 02, Banyuputih, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => Ibu rumah tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => sadddddddddddddddddddddwwwwwwwwwwwwwwwwww
    [tanggal_lahir_db] => 2015-06-25
)

INFO - 2025-05-04 06:28:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 06:28:27 --> Generated registration number: A-2526/0161
DEBUG - 2025-05-04 06:28:27 --> Form data to save: Array
(
    [nama_siswa] => Akhmad Lutfi ewewew
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2015-06-25
    [tempat_tanggal_lahir] => Batang, 25 Juni 2015
    [no_hp_siswa] => 085747110787
    [rekomendasi] => 
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Lokojoyo banyuputih
    [rt] => 03
    [rw] => 02
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Lokojoyo banyuputih, RT 03/RW 02, Banyuputih, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => Ibu rumah tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => sadddddddddddddddddddddwwwwwwwwwwwwwwwwww
    [tanggal_daftar] => 2025-05-04 06:28:27
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-04 06:28:27 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 06:28:27 --> Database config: 1
DEBUG - 2025-05-04 06:28:27 --> Database hostname: localhost
DEBUG - 2025-05-04 06:28:27 --> Database username: root
DEBUG - 2025-05-04 06:28:27 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 06:28:27 --> Data to save: Array
(
    [nama_siswa] => Akhmad Lutfi ewewew
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Batang
    [tanggal_lahir] => 2015-06-25
    [tempat_tanggal_lahir] => Batang, 25 Juni 2015
    [no_hp_siswa] => 085747110787
    [rekomendasi] => 
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Orang Tua
    [dukuh] => Lokojoyo banyuputih
    [rt] => 03
    [rw] => 02
    [desa] => Banyuputih
    [kecamatan] => limpugn
    [kabupaten] => Batang
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Lokojoyo banyuputih, RT 03/RW 02, Banyuputih, limpugn, Batang, Jawa Tengah
    [nama_ayah] => Juwanto
    [nama_ibu] => saripah
    [pendidikan_ayah] => SD/MI Sederajat
    [pendidikan_ibu] => SD/MI Sederajat
    [pekerjaan_ayah] => PNS
    [pekerjaan_ibu] => Ibu rumah tangga
    [no_hp_ayah] => 085747110787
    [no_hp_ibu] => 085747110787
    [alamat_ortu] => Dukuh Adiloko Desa Rowosari
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => MANU BANYUPUTIH
    [nisn] => 103332
    [alamat_sekolah] => Dukuh Adiloko Desa Rowosari
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => sadddddddddddddddddddddwwwwwwwwwwwwwwwwww
    [tanggal_daftar] => 2025-05-04 06:28:27
    [status] => Baru
    [no_pendaftaran] => A-2526/0161
)

DEBUG - 2025-05-04 06:28:27 --> Data inserted successfully with ID: 177
INFO - 2025-05-04 06:28:27 --> Final output sent to browser
DEBUG - 2025-05-04 06:28:27 --> Total execution time: 0.0526
INFO - 2025-05-04 06:28:29 --> Config Class Initialized
INFO - 2025-05-04 06:28:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:28:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:28:29 --> Utf8 Class Initialized
INFO - 2025-05-04 06:28:29 --> URI Class Initialized
DEBUG - 2025-05-04 06:28:29 --> No URI present. Default controller set.
INFO - 2025-05-04 06:28:29 --> Router Class Initialized
INFO - 2025-05-04 06:28:29 --> Output Class Initialized
INFO - 2025-05-04 06:28:29 --> Security Class Initialized
DEBUG - 2025-05-04 06:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:28:29 --> Input Class Initialized
INFO - 2025-05-04 06:28:29 --> Language Class Initialized
INFO - 2025-05-04 06:28:29 --> Loader Class Initialized
INFO - 2025-05-04 06:28:29 --> Helper loaded: form_helper
INFO - 2025-05-04 06:28:29 --> Helper loaded: url_helper
INFO - 2025-05-04 06:28:29 --> Database Driver Class Initialized
INFO - 2025-05-04 06:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:28:29 --> Form Validation Class Initialized
INFO - 2025-05-04 06:28:29 --> Controller Class Initialized
INFO - 2025-05-04 06:28:29 --> Final output sent to browser
DEBUG - 2025-05-04 06:28:29 --> Total execution time: 0.0317
INFO - 2025-05-04 06:29:02 --> Config Class Initialized
INFO - 2025-05-04 06:29:02 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:29:02 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:29:02 --> Utf8 Class Initialized
INFO - 2025-05-04 06:29:02 --> URI Class Initialized
INFO - 2025-05-04 06:29:02 --> Router Class Initialized
INFO - 2025-05-04 06:29:02 --> Output Class Initialized
INFO - 2025-05-04 06:29:02 --> Security Class Initialized
DEBUG - 2025-05-04 06:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:29:02 --> Input Class Initialized
INFO - 2025-05-04 06:29:02 --> Language Class Initialized
INFO - 2025-05-04 06:29:02 --> Loader Class Initialized
INFO - 2025-05-04 06:29:02 --> Helper loaded: form_helper
INFO - 2025-05-04 06:29:02 --> Helper loaded: url_helper
INFO - 2025-05-04 06:29:02 --> Database Driver Class Initialized
INFO - 2025-05-04 06:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:29:02 --> Form Validation Class Initialized
INFO - 2025-05-04 06:29:02 --> Controller Class Initialized
DEBUG - 2025-05-04 06:29:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:29:02 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:29:02 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:29:02 --> Final output sent to browser
DEBUG - 2025-05-04 06:29:02 --> Total execution time: 0.0313
INFO - 2025-05-04 06:29:11 --> Config Class Initialized
INFO - 2025-05-04 06:29:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:29:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:29:11 --> Utf8 Class Initialized
INFO - 2025-05-04 06:29:11 --> URI Class Initialized
INFO - 2025-05-04 06:29:11 --> Router Class Initialized
INFO - 2025-05-04 06:29:11 --> Output Class Initialized
INFO - 2025-05-04 06:29:11 --> Security Class Initialized
DEBUG - 2025-05-04 06:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:29:11 --> Input Class Initialized
INFO - 2025-05-04 06:29:11 --> Language Class Initialized
INFO - 2025-05-04 06:29:11 --> Loader Class Initialized
INFO - 2025-05-04 06:29:11 --> Helper loaded: form_helper
INFO - 2025-05-04 06:29:11 --> Helper loaded: url_helper
INFO - 2025-05-04 06:29:11 --> Database Driver Class Initialized
INFO - 2025-05-04 06:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:29:11 --> Form Validation Class Initialized
INFO - 2025-05-04 06:29:11 --> Controller Class Initialized
DEBUG - 2025-05-04 06:29:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:29:11 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:29:11 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:29:11 --> Final output sent to browser
DEBUG - 2025-05-04 06:29:11 --> Total execution time: 0.0542
INFO - 2025-05-04 06:30:59 --> Config Class Initialized
INFO - 2025-05-04 06:30:59 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:30:59 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:30:59 --> Utf8 Class Initialized
INFO - 2025-05-04 06:30:59 --> URI Class Initialized
INFO - 2025-05-04 06:30:59 --> Router Class Initialized
INFO - 2025-05-04 06:30:59 --> Output Class Initialized
INFO - 2025-05-04 06:30:59 --> Security Class Initialized
DEBUG - 2025-05-04 06:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:30:59 --> Input Class Initialized
INFO - 2025-05-04 06:30:59 --> Language Class Initialized
INFO - 2025-05-04 06:30:59 --> Loader Class Initialized
INFO - 2025-05-04 06:30:59 --> Helper loaded: form_helper
INFO - 2025-05-04 06:30:59 --> Helper loaded: url_helper
INFO - 2025-05-04 06:30:59 --> Database Driver Class Initialized
INFO - 2025-05-04 06:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:30:59 --> Form Validation Class Initialized
INFO - 2025-05-04 06:30:59 --> Controller Class Initialized
DEBUG - 2025-05-04 06:30:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:30:59 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:30:59 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:30:59 --> Final output sent to browser
DEBUG - 2025-05-04 06:30:59 --> Total execution time: 0.0367
INFO - 2025-05-04 06:33:55 --> Config Class Initialized
INFO - 2025-05-04 06:33:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:33:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:33:55 --> Utf8 Class Initialized
INFO - 2025-05-04 06:33:55 --> URI Class Initialized
INFO - 2025-05-04 06:33:55 --> Router Class Initialized
INFO - 2025-05-04 06:33:55 --> Output Class Initialized
INFO - 2025-05-04 06:33:55 --> Security Class Initialized
DEBUG - 2025-05-04 06:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:33:55 --> Input Class Initialized
INFO - 2025-05-04 06:33:55 --> Language Class Initialized
INFO - 2025-05-04 06:33:55 --> Loader Class Initialized
INFO - 2025-05-04 06:33:55 --> Helper loaded: form_helper
INFO - 2025-05-04 06:33:55 --> Helper loaded: url_helper
INFO - 2025-05-04 06:33:55 --> Database Driver Class Initialized
INFO - 2025-05-04 06:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:33:55 --> Form Validation Class Initialized
INFO - 2025-05-04 06:33:55 --> Controller Class Initialized
DEBUG - 2025-05-04 06:33:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:33:55 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:33:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:33:55 --> Final output sent to browser
DEBUG - 2025-05-04 06:33:55 --> Total execution time: 0.0420
INFO - 2025-05-04 06:34:53 --> Config Class Initialized
INFO - 2025-05-04 06:34:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:34:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:34:53 --> Utf8 Class Initialized
INFO - 2025-05-04 06:34:53 --> URI Class Initialized
INFO - 2025-05-04 06:34:53 --> Router Class Initialized
INFO - 2025-05-04 06:34:53 --> Output Class Initialized
INFO - 2025-05-04 06:34:53 --> Security Class Initialized
DEBUG - 2025-05-04 06:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:34:53 --> Input Class Initialized
INFO - 2025-05-04 06:34:53 --> Language Class Initialized
INFO - 2025-05-04 06:34:53 --> Loader Class Initialized
INFO - 2025-05-04 06:34:53 --> Helper loaded: form_helper
INFO - 2025-05-04 06:34:53 --> Helper loaded: url_helper
INFO - 2025-05-04 06:34:53 --> Database Driver Class Initialized
INFO - 2025-05-04 06:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:34:53 --> Form Validation Class Initialized
INFO - 2025-05-04 06:34:53 --> Controller Class Initialized
DEBUG - 2025-05-04 06:34:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:34:53 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:34:53 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:34:53 --> Final output sent to browser
DEBUG - 2025-05-04 06:34:53 --> Total execution time: 0.0326
INFO - 2025-05-04 06:36:00 --> Config Class Initialized
INFO - 2025-05-04 06:36:00 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:36:00 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:36:00 --> Utf8 Class Initialized
INFO - 2025-05-04 06:36:00 --> URI Class Initialized
INFO - 2025-05-04 06:36:00 --> Router Class Initialized
INFO - 2025-05-04 06:36:00 --> Output Class Initialized
INFO - 2025-05-04 06:36:00 --> Security Class Initialized
DEBUG - 2025-05-04 06:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:36:00 --> Input Class Initialized
INFO - 2025-05-04 06:36:00 --> Language Class Initialized
INFO - 2025-05-04 06:36:00 --> Loader Class Initialized
INFO - 2025-05-04 06:36:00 --> Helper loaded: form_helper
INFO - 2025-05-04 06:36:00 --> Helper loaded: url_helper
INFO - 2025-05-04 06:36:00 --> Database Driver Class Initialized
INFO - 2025-05-04 06:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:36:00 --> Form Validation Class Initialized
INFO - 2025-05-04 06:36:00 --> Controller Class Initialized
DEBUG - 2025-05-04 06:36:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:36:00 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:36:00 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:36:00 --> Final output sent to browser
DEBUG - 2025-05-04 06:36:00 --> Total execution time: 0.0419
INFO - 2025-05-04 06:36:37 --> Config Class Initialized
INFO - 2025-05-04 06:36:37 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:36:37 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:36:37 --> Utf8 Class Initialized
INFO - 2025-05-04 06:36:37 --> URI Class Initialized
INFO - 2025-05-04 06:36:37 --> Router Class Initialized
INFO - 2025-05-04 06:36:37 --> Output Class Initialized
INFO - 2025-05-04 06:36:37 --> Security Class Initialized
DEBUG - 2025-05-04 06:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:36:37 --> Input Class Initialized
INFO - 2025-05-04 06:36:37 --> Language Class Initialized
INFO - 2025-05-04 06:36:37 --> Loader Class Initialized
INFO - 2025-05-04 06:36:37 --> Helper loaded: form_helper
INFO - 2025-05-04 06:36:37 --> Helper loaded: url_helper
INFO - 2025-05-04 06:36:37 --> Database Driver Class Initialized
INFO - 2025-05-04 06:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:36:37 --> Form Validation Class Initialized
INFO - 2025-05-04 06:36:37 --> Controller Class Initialized
DEBUG - 2025-05-04 06:36:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:36:37 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:36:37 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:36:37 --> Final output sent to browser
DEBUG - 2025-05-04 06:36:37 --> Total execution time: 0.0626
INFO - 2025-05-04 06:37:29 --> Config Class Initialized
INFO - 2025-05-04 06:37:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:37:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:37:29 --> Utf8 Class Initialized
INFO - 2025-05-04 06:37:29 --> URI Class Initialized
INFO - 2025-05-04 06:37:29 --> Router Class Initialized
INFO - 2025-05-04 06:37:29 --> Output Class Initialized
INFO - 2025-05-04 06:37:29 --> Security Class Initialized
DEBUG - 2025-05-04 06:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:37:29 --> Input Class Initialized
INFO - 2025-05-04 06:37:29 --> Language Class Initialized
INFO - 2025-05-04 06:37:29 --> Loader Class Initialized
INFO - 2025-05-04 06:37:29 --> Helper loaded: form_helper
INFO - 2025-05-04 06:37:29 --> Helper loaded: url_helper
INFO - 2025-05-04 06:37:29 --> Database Driver Class Initialized
INFO - 2025-05-04 06:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:37:29 --> Form Validation Class Initialized
INFO - 2025-05-04 06:37:29 --> Controller Class Initialized
DEBUG - 2025-05-04 06:37:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:37:29 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:37:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:37:29 --> Final output sent to browser
DEBUG - 2025-05-04 06:37:29 --> Total execution time: 0.0385
INFO - 2025-05-04 06:38:24 --> Config Class Initialized
INFO - 2025-05-04 06:38:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:38:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:38:24 --> Utf8 Class Initialized
INFO - 2025-05-04 06:38:24 --> URI Class Initialized
INFO - 2025-05-04 06:38:24 --> Router Class Initialized
INFO - 2025-05-04 06:38:24 --> Output Class Initialized
INFO - 2025-05-04 06:38:24 --> Security Class Initialized
DEBUG - 2025-05-04 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:38:24 --> Input Class Initialized
INFO - 2025-05-04 06:38:24 --> Language Class Initialized
INFO - 2025-05-04 06:38:24 --> Loader Class Initialized
INFO - 2025-05-04 06:38:24 --> Helper loaded: form_helper
INFO - 2025-05-04 06:38:24 --> Helper loaded: url_helper
INFO - 2025-05-04 06:38:24 --> Database Driver Class Initialized
INFO - 2025-05-04 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:38:24 --> Form Validation Class Initialized
INFO - 2025-05-04 06:38:24 --> Controller Class Initialized
DEBUG - 2025-05-04 06:38:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:38:24 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:38:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:38:24 --> Final output sent to browser
DEBUG - 2025-05-04 06:38:24 --> Total execution time: 0.0338
INFO - 2025-05-04 06:39:08 --> Config Class Initialized
INFO - 2025-05-04 06:39:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:39:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:39:08 --> Utf8 Class Initialized
INFO - 2025-05-04 06:39:08 --> URI Class Initialized
INFO - 2025-05-04 06:39:08 --> Router Class Initialized
INFO - 2025-05-04 06:39:08 --> Output Class Initialized
INFO - 2025-05-04 06:39:08 --> Security Class Initialized
DEBUG - 2025-05-04 06:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:39:08 --> Input Class Initialized
INFO - 2025-05-04 06:39:08 --> Language Class Initialized
INFO - 2025-05-04 06:39:09 --> Loader Class Initialized
INFO - 2025-05-04 06:39:09 --> Helper loaded: form_helper
INFO - 2025-05-04 06:39:09 --> Helper loaded: url_helper
INFO - 2025-05-04 06:39:09 --> Database Driver Class Initialized
INFO - 2025-05-04 06:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:39:09 --> Form Validation Class Initialized
INFO - 2025-05-04 06:39:09 --> Controller Class Initialized
DEBUG - 2025-05-04 06:39:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:39:09 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:39:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:39:09 --> Final output sent to browser
DEBUG - 2025-05-04 06:39:09 --> Total execution time: 0.0866
INFO - 2025-05-04 06:40:29 --> Config Class Initialized
INFO - 2025-05-04 06:40:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:40:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:40:29 --> Utf8 Class Initialized
INFO - 2025-05-04 06:40:29 --> URI Class Initialized
INFO - 2025-05-04 06:40:29 --> Router Class Initialized
INFO - 2025-05-04 06:40:29 --> Output Class Initialized
INFO - 2025-05-04 06:40:29 --> Security Class Initialized
DEBUG - 2025-05-04 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:40:29 --> Input Class Initialized
INFO - 2025-05-04 06:40:29 --> Language Class Initialized
INFO - 2025-05-04 06:40:29 --> Loader Class Initialized
INFO - 2025-05-04 06:40:29 --> Helper loaded: form_helper
INFO - 2025-05-04 06:40:29 --> Helper loaded: url_helper
INFO - 2025-05-04 06:40:29 --> Database Driver Class Initialized
INFO - 2025-05-04 06:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:40:29 --> Form Validation Class Initialized
INFO - 2025-05-04 06:40:29 --> Controller Class Initialized
DEBUG - 2025-05-04 06:40:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:40:29 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:40:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:40:29 --> Final output sent to browser
DEBUG - 2025-05-04 06:40:29 --> Total execution time: 0.0358
INFO - 2025-05-04 06:40:58 --> Config Class Initialized
INFO - 2025-05-04 06:40:58 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:40:58 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:40:58 --> Utf8 Class Initialized
INFO - 2025-05-04 06:40:58 --> URI Class Initialized
INFO - 2025-05-04 06:40:58 --> Router Class Initialized
INFO - 2025-05-04 06:40:58 --> Output Class Initialized
INFO - 2025-05-04 06:40:58 --> Security Class Initialized
DEBUG - 2025-05-04 06:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:40:58 --> Input Class Initialized
INFO - 2025-05-04 06:40:58 --> Language Class Initialized
INFO - 2025-05-04 06:40:58 --> Loader Class Initialized
INFO - 2025-05-04 06:40:58 --> Helper loaded: form_helper
INFO - 2025-05-04 06:40:58 --> Helper loaded: url_helper
INFO - 2025-05-04 06:40:58 --> Database Driver Class Initialized
INFO - 2025-05-04 06:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:40:58 --> Form Validation Class Initialized
INFO - 2025-05-04 06:40:58 --> Controller Class Initialized
DEBUG - 2025-05-04 06:40:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:40:58 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:40:58 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:40:58 --> Final output sent to browser
DEBUG - 2025-05-04 06:40:58 --> Total execution time: 0.0451
INFO - 2025-05-04 06:42:22 --> Config Class Initialized
INFO - 2025-05-04 06:42:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:42:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:42:22 --> Utf8 Class Initialized
INFO - 2025-05-04 06:42:22 --> URI Class Initialized
INFO - 2025-05-04 06:42:22 --> Router Class Initialized
INFO - 2025-05-04 06:42:22 --> Output Class Initialized
INFO - 2025-05-04 06:42:22 --> Security Class Initialized
DEBUG - 2025-05-04 06:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:42:22 --> Input Class Initialized
INFO - 2025-05-04 06:42:22 --> Language Class Initialized
INFO - 2025-05-04 06:42:22 --> Loader Class Initialized
INFO - 2025-05-04 06:42:22 --> Helper loaded: form_helper
INFO - 2025-05-04 06:42:22 --> Helper loaded: url_helper
INFO - 2025-05-04 06:42:22 --> Database Driver Class Initialized
INFO - 2025-05-04 06:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:42:22 --> Form Validation Class Initialized
INFO - 2025-05-04 06:42:22 --> Controller Class Initialized
DEBUG - 2025-05-04 06:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:42:22 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:42:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:42:22 --> Final output sent to browser
DEBUG - 2025-05-04 06:42:22 --> Total execution time: 0.0336
INFO - 2025-05-04 06:43:21 --> Config Class Initialized
INFO - 2025-05-04 06:43:21 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:43:21 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:43:21 --> Utf8 Class Initialized
INFO - 2025-05-04 06:43:21 --> URI Class Initialized
INFO - 2025-05-04 06:43:21 --> Router Class Initialized
INFO - 2025-05-04 06:43:21 --> Output Class Initialized
INFO - 2025-05-04 06:43:21 --> Security Class Initialized
DEBUG - 2025-05-04 06:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:43:21 --> Input Class Initialized
INFO - 2025-05-04 06:43:21 --> Language Class Initialized
INFO - 2025-05-04 06:43:21 --> Loader Class Initialized
INFO - 2025-05-04 06:43:21 --> Helper loaded: form_helper
INFO - 2025-05-04 06:43:21 --> Helper loaded: url_helper
INFO - 2025-05-04 06:43:21 --> Database Driver Class Initialized
INFO - 2025-05-04 06:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:43:21 --> Form Validation Class Initialized
INFO - 2025-05-04 06:43:21 --> Controller Class Initialized
DEBUG - 2025-05-04 06:43:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:43:21 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:43:21 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:43:21 --> Final output sent to browser
DEBUG - 2025-05-04 06:43:21 --> Total execution time: 0.0367
INFO - 2025-05-04 06:44:44 --> Config Class Initialized
INFO - 2025-05-04 06:44:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:44:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:44:44 --> Utf8 Class Initialized
INFO - 2025-05-04 06:44:44 --> URI Class Initialized
INFO - 2025-05-04 06:44:44 --> Router Class Initialized
INFO - 2025-05-04 06:44:44 --> Output Class Initialized
INFO - 2025-05-04 06:44:44 --> Security Class Initialized
DEBUG - 2025-05-04 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:44:44 --> Input Class Initialized
INFO - 2025-05-04 06:44:44 --> Language Class Initialized
INFO - 2025-05-04 06:44:44 --> Loader Class Initialized
INFO - 2025-05-04 06:44:44 --> Helper loaded: form_helper
INFO - 2025-05-04 06:44:44 --> Helper loaded: url_helper
INFO - 2025-05-04 06:44:44 --> Database Driver Class Initialized
INFO - 2025-05-04 06:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:44:44 --> Form Validation Class Initialized
INFO - 2025-05-04 06:44:44 --> Controller Class Initialized
DEBUG - 2025-05-04 06:44:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:44:44 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:44:44 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:44:44 --> Final output sent to browser
DEBUG - 2025-05-04 06:44:44 --> Total execution time: 0.0306
INFO - 2025-05-04 06:45:53 --> Config Class Initialized
INFO - 2025-05-04 06:45:53 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:45:53 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:45:53 --> Utf8 Class Initialized
INFO - 2025-05-04 06:45:53 --> URI Class Initialized
INFO - 2025-05-04 06:45:53 --> Router Class Initialized
INFO - 2025-05-04 06:45:53 --> Output Class Initialized
INFO - 2025-05-04 06:45:53 --> Security Class Initialized
DEBUG - 2025-05-04 06:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:45:53 --> Input Class Initialized
INFO - 2025-05-04 06:45:53 --> Language Class Initialized
INFO - 2025-05-04 06:45:53 --> Loader Class Initialized
INFO - 2025-05-04 06:45:53 --> Helper loaded: form_helper
INFO - 2025-05-04 06:45:53 --> Helper loaded: url_helper
INFO - 2025-05-04 06:45:53 --> Database Driver Class Initialized
INFO - 2025-05-04 06:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:45:53 --> Form Validation Class Initialized
INFO - 2025-05-04 06:45:53 --> Controller Class Initialized
DEBUG - 2025-05-04 06:45:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:45:53 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:45:53 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:45:53 --> Final output sent to browser
DEBUG - 2025-05-04 06:45:53 --> Total execution time: 0.0375
INFO - 2025-05-04 06:47:52 --> Config Class Initialized
INFO - 2025-05-04 06:47:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:47:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:47:52 --> Utf8 Class Initialized
INFO - 2025-05-04 06:47:52 --> URI Class Initialized
INFO - 2025-05-04 06:47:52 --> Router Class Initialized
INFO - 2025-05-04 06:47:52 --> Output Class Initialized
INFO - 2025-05-04 06:47:52 --> Security Class Initialized
DEBUG - 2025-05-04 06:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:47:52 --> Input Class Initialized
INFO - 2025-05-04 06:47:52 --> Language Class Initialized
INFO - 2025-05-04 06:47:52 --> Loader Class Initialized
INFO - 2025-05-04 06:47:52 --> Helper loaded: form_helper
INFO - 2025-05-04 06:47:52 --> Helper loaded: url_helper
INFO - 2025-05-04 06:47:52 --> Database Driver Class Initialized
INFO - 2025-05-04 06:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:47:52 --> Form Validation Class Initialized
INFO - 2025-05-04 06:47:52 --> Controller Class Initialized
DEBUG - 2025-05-04 06:47:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:47:52 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:47:52 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:47:52 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:47:52 --> Final output sent to browser
DEBUG - 2025-05-04 06:47:52 --> Total execution time: 0.0352
INFO - 2025-05-04 06:48:03 --> Config Class Initialized
INFO - 2025-05-04 06:48:03 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:48:03 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:48:03 --> Utf8 Class Initialized
INFO - 2025-05-04 06:48:03 --> URI Class Initialized
INFO - 2025-05-04 06:48:03 --> Router Class Initialized
INFO - 2025-05-04 06:48:03 --> Output Class Initialized
INFO - 2025-05-04 06:48:03 --> Security Class Initialized
DEBUG - 2025-05-04 06:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:48:03 --> Input Class Initialized
INFO - 2025-05-04 06:48:03 --> Language Class Initialized
INFO - 2025-05-04 06:48:03 --> Loader Class Initialized
INFO - 2025-05-04 06:48:03 --> Helper loaded: form_helper
INFO - 2025-05-04 06:48:03 --> Helper loaded: url_helper
INFO - 2025-05-04 06:48:03 --> Database Driver Class Initialized
INFO - 2025-05-04 06:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:48:03 --> Form Validation Class Initialized
INFO - 2025-05-04 06:48:03 --> Controller Class Initialized
DEBUG - 2025-05-04 06:48:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:48:03 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:48:03 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:48:03 --> Final output sent to browser
DEBUG - 2025-05-04 06:48:03 --> Total execution time: 0.0447
INFO - 2025-05-04 06:49:08 --> Config Class Initialized
INFO - 2025-05-04 06:49:08 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:49:08 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:49:08 --> Utf8 Class Initialized
INFO - 2025-05-04 06:49:08 --> URI Class Initialized
INFO - 2025-05-04 06:49:08 --> Router Class Initialized
INFO - 2025-05-04 06:49:08 --> Output Class Initialized
INFO - 2025-05-04 06:49:08 --> Security Class Initialized
DEBUG - 2025-05-04 06:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:49:08 --> Input Class Initialized
INFO - 2025-05-04 06:49:08 --> Language Class Initialized
INFO - 2025-05-04 06:49:08 --> Loader Class Initialized
INFO - 2025-05-04 06:49:08 --> Helper loaded: form_helper
INFO - 2025-05-04 06:49:08 --> Helper loaded: url_helper
INFO - 2025-05-04 06:49:08 --> Database Driver Class Initialized
INFO - 2025-05-04 06:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:49:08 --> Form Validation Class Initialized
INFO - 2025-05-04 06:49:08 --> Controller Class Initialized
DEBUG - 2025-05-04 06:49:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:49:08 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:49:08 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:49:08 --> Final output sent to browser
DEBUG - 2025-05-04 06:49:08 --> Total execution time: 0.0392
INFO - 2025-05-04 06:51:42 --> Config Class Initialized
INFO - 2025-05-04 06:51:42 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:51:42 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:51:42 --> Utf8 Class Initialized
INFO - 2025-05-04 06:51:42 --> URI Class Initialized
INFO - 2025-05-04 06:51:42 --> Router Class Initialized
INFO - 2025-05-04 06:51:42 --> Output Class Initialized
INFO - 2025-05-04 06:51:42 --> Security Class Initialized
DEBUG - 2025-05-04 06:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:51:42 --> Input Class Initialized
INFO - 2025-05-04 06:51:42 --> Language Class Initialized
INFO - 2025-05-04 06:51:42 --> Loader Class Initialized
INFO - 2025-05-04 06:51:42 --> Helper loaded: form_helper
INFO - 2025-05-04 06:51:42 --> Helper loaded: url_helper
INFO - 2025-05-04 06:51:42 --> Database Driver Class Initialized
INFO - 2025-05-04 06:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:51:42 --> Form Validation Class Initialized
INFO - 2025-05-04 06:51:42 --> Controller Class Initialized
DEBUG - 2025-05-04 06:51:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:51:42 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:51:42 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:51:42 --> Final output sent to browser
DEBUG - 2025-05-04 06:51:42 --> Total execution time: 0.0631
INFO - 2025-05-04 06:51:43 --> Config Class Initialized
INFO - 2025-05-04 06:51:43 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:51:43 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:51:43 --> Utf8 Class Initialized
INFO - 2025-05-04 06:51:43 --> URI Class Initialized
INFO - 2025-05-04 06:51:43 --> Router Class Initialized
INFO - 2025-05-04 06:51:43 --> Output Class Initialized
INFO - 2025-05-04 06:51:43 --> Security Class Initialized
DEBUG - 2025-05-04 06:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:51:43 --> Input Class Initialized
INFO - 2025-05-04 06:51:43 --> Language Class Initialized
INFO - 2025-05-04 06:51:43 --> Loader Class Initialized
INFO - 2025-05-04 06:51:43 --> Helper loaded: form_helper
INFO - 2025-05-04 06:51:43 --> Helper loaded: url_helper
INFO - 2025-05-04 06:51:43 --> Database Driver Class Initialized
INFO - 2025-05-04 06:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:51:43 --> Form Validation Class Initialized
INFO - 2025-05-04 06:51:43 --> Controller Class Initialized
DEBUG - 2025-05-04 06:51:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:51:43 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:51:43 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:51:43 --> Final output sent to browser
DEBUG - 2025-05-04 06:51:43 --> Total execution time: 0.0628
INFO - 2025-05-04 06:52:32 --> Config Class Initialized
INFO - 2025-05-04 06:52:32 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:52:32 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:52:32 --> Utf8 Class Initialized
INFO - 2025-05-04 06:52:32 --> URI Class Initialized
INFO - 2025-05-04 06:52:32 --> Router Class Initialized
INFO - 2025-05-04 06:52:32 --> Output Class Initialized
INFO - 2025-05-04 06:52:32 --> Security Class Initialized
DEBUG - 2025-05-04 06:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:52:32 --> Input Class Initialized
INFO - 2025-05-04 06:52:32 --> Language Class Initialized
INFO - 2025-05-04 06:52:32 --> Loader Class Initialized
INFO - 2025-05-04 06:52:32 --> Helper loaded: form_helper
INFO - 2025-05-04 06:52:32 --> Helper loaded: url_helper
INFO - 2025-05-04 06:52:32 --> Database Driver Class Initialized
INFO - 2025-05-04 06:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:52:32 --> Form Validation Class Initialized
INFO - 2025-05-04 06:52:32 --> Controller Class Initialized
DEBUG - 2025-05-04 06:52:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:52:32 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:52:32 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:52:32 --> Final output sent to browser
DEBUG - 2025-05-04 06:52:32 --> Total execution time: 0.0942
INFO - 2025-05-04 06:55:45 --> Config Class Initialized
INFO - 2025-05-04 06:55:45 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:55:45 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:55:45 --> Utf8 Class Initialized
INFO - 2025-05-04 06:55:45 --> URI Class Initialized
INFO - 2025-05-04 06:55:45 --> Router Class Initialized
INFO - 2025-05-04 06:55:45 --> Output Class Initialized
INFO - 2025-05-04 06:55:45 --> Security Class Initialized
DEBUG - 2025-05-04 06:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:55:45 --> Input Class Initialized
INFO - 2025-05-04 06:55:45 --> Language Class Initialized
INFO - 2025-05-04 06:55:45 --> Loader Class Initialized
INFO - 2025-05-04 06:55:45 --> Helper loaded: form_helper
INFO - 2025-05-04 06:55:45 --> Helper loaded: url_helper
INFO - 2025-05-04 06:55:45 --> Database Driver Class Initialized
INFO - 2025-05-04 06:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:55:45 --> Form Validation Class Initialized
INFO - 2025-05-04 06:55:45 --> Controller Class Initialized
DEBUG - 2025-05-04 06:55:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:55:45 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:55:45 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:55:45 --> Final output sent to browser
DEBUG - 2025-05-04 06:55:45 --> Total execution time: 0.0451
INFO - 2025-05-04 06:56:04 --> Config Class Initialized
INFO - 2025-05-04 06:56:04 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:56:04 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:56:04 --> Utf8 Class Initialized
INFO - 2025-05-04 06:56:04 --> URI Class Initialized
INFO - 2025-05-04 06:56:04 --> Router Class Initialized
INFO - 2025-05-04 06:56:04 --> Output Class Initialized
INFO - 2025-05-04 06:56:04 --> Security Class Initialized
DEBUG - 2025-05-04 06:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:56:04 --> Input Class Initialized
INFO - 2025-05-04 06:56:04 --> Language Class Initialized
INFO - 2025-05-04 06:56:04 --> Loader Class Initialized
INFO - 2025-05-04 06:56:04 --> Helper loaded: form_helper
INFO - 2025-05-04 06:56:04 --> Helper loaded: url_helper
INFO - 2025-05-04 06:56:04 --> Database Driver Class Initialized
INFO - 2025-05-04 06:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:56:04 --> Form Validation Class Initialized
INFO - 2025-05-04 06:56:04 --> Controller Class Initialized
DEBUG - 2025-05-04 06:56:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:56:04 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 06:56:04 --> POST data: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [tempat_tanggal_lahir_db] => Demak, 15 Agustus 2008
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [no_hp_siswa] => 081234567890
    [jalur_pendaftaran] => Reguler
    [tinggal] => Lainnya
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [alamat_lengkap_db] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_lahir_db] => 2008-08-15
)

INFO - 2025-05-04 06:56:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 06:56:04 --> Generated registration number: A-2526/0162
DEBUG - 2025-05-04 06:56:04 --> Form data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Lainnya
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 06:56:04
    [status] => Baru
    [no_pendaftaran] => A-2526/0162
)

DEBUG - 2025-05-04 06:56:04 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 06:56:04 --> Database config: 1
DEBUG - 2025-05-04 06:56:04 --> Database hostname: localhost
DEBUG - 2025-05-04 06:56:04 --> Database username: root
DEBUG - 2025-05-04 06:56:04 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 06:56:04 --> Data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Lainnya
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 06:56:04
    [status] => Baru
    [no_pendaftaran] => A-2526/0162
)

DEBUG - 2025-05-04 06:56:04 --> Data inserted successfully with ID: 178
INFO - 2025-05-04 06:56:04 --> Final output sent to browser
DEBUG - 2025-05-04 06:56:04 --> Total execution time: 0.0403
INFO - 2025-05-04 06:56:05 --> Config Class Initialized
INFO - 2025-05-04 06:56:05 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:56:05 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:56:05 --> Utf8 Class Initialized
INFO - 2025-05-04 06:56:05 --> URI Class Initialized
DEBUG - 2025-05-04 06:56:05 --> No URI present. Default controller set.
INFO - 2025-05-04 06:56:05 --> Router Class Initialized
INFO - 2025-05-04 06:56:05 --> Output Class Initialized
INFO - 2025-05-04 06:56:05 --> Security Class Initialized
DEBUG - 2025-05-04 06:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:56:05 --> Input Class Initialized
INFO - 2025-05-04 06:56:05 --> Language Class Initialized
INFO - 2025-05-04 06:56:05 --> Loader Class Initialized
INFO - 2025-05-04 06:56:05 --> Helper loaded: form_helper
INFO - 2025-05-04 06:56:05 --> Helper loaded: url_helper
INFO - 2025-05-04 06:56:05 --> Database Driver Class Initialized
INFO - 2025-05-04 06:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:56:05 --> Form Validation Class Initialized
INFO - 2025-05-04 06:56:05 --> Controller Class Initialized
INFO - 2025-05-04 06:56:05 --> Final output sent to browser
DEBUG - 2025-05-04 06:56:05 --> Total execution time: 0.0332
INFO - 2025-05-04 06:56:09 --> Config Class Initialized
INFO - 2025-05-04 06:56:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:56:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:56:09 --> Utf8 Class Initialized
INFO - 2025-05-04 06:56:09 --> URI Class Initialized
INFO - 2025-05-04 06:56:09 --> Router Class Initialized
INFO - 2025-05-04 06:56:09 --> Output Class Initialized
INFO - 2025-05-04 06:56:09 --> Security Class Initialized
DEBUG - 2025-05-04 06:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:56:09 --> Input Class Initialized
INFO - 2025-05-04 06:56:09 --> Language Class Initialized
INFO - 2025-05-04 06:56:09 --> Loader Class Initialized
INFO - 2025-05-04 06:56:09 --> Helper loaded: form_helper
INFO - 2025-05-04 06:56:09 --> Helper loaded: url_helper
INFO - 2025-05-04 06:56:09 --> Database Driver Class Initialized
INFO - 2025-05-04 06:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:56:09 --> Form Validation Class Initialized
INFO - 2025-05-04 06:56:09 --> Controller Class Initialized
DEBUG - 2025-05-04 06:56:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:56:09 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:56:09 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:56:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:56:09 --> Final output sent to browser
DEBUG - 2025-05-04 06:56:09 --> Total execution time: 0.0299
INFO - 2025-05-04 06:57:11 --> Config Class Initialized
INFO - 2025-05-04 06:57:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:57:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:57:11 --> Utf8 Class Initialized
INFO - 2025-05-04 06:57:11 --> URI Class Initialized
INFO - 2025-05-04 06:57:11 --> Router Class Initialized
INFO - 2025-05-04 06:57:11 --> Output Class Initialized
INFO - 2025-05-04 06:57:11 --> Security Class Initialized
DEBUG - 2025-05-04 06:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:57:11 --> Input Class Initialized
INFO - 2025-05-04 06:57:11 --> Language Class Initialized
INFO - 2025-05-04 06:57:11 --> Loader Class Initialized
INFO - 2025-05-04 06:57:11 --> Helper loaded: form_helper
INFO - 2025-05-04 06:57:11 --> Helper loaded: url_helper
INFO - 2025-05-04 06:57:11 --> Database Driver Class Initialized
INFO - 2025-05-04 06:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:57:11 --> Form Validation Class Initialized
INFO - 2025-05-04 06:57:11 --> Controller Class Initialized
DEBUG - 2025-05-04 06:57:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:57:11 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:57:11 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:57:11 --> Final output sent to browser
DEBUG - 2025-05-04 06:57:11 --> Total execution time: 0.0720
INFO - 2025-05-04 06:57:12 --> Config Class Initialized
INFO - 2025-05-04 06:57:12 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:57:12 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:57:12 --> Utf8 Class Initialized
INFO - 2025-05-04 06:57:12 --> URI Class Initialized
INFO - 2025-05-04 06:57:12 --> Router Class Initialized
INFO - 2025-05-04 06:57:12 --> Output Class Initialized
INFO - 2025-05-04 06:57:12 --> Security Class Initialized
DEBUG - 2025-05-04 06:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:57:12 --> Input Class Initialized
INFO - 2025-05-04 06:57:12 --> Language Class Initialized
INFO - 2025-05-04 06:57:12 --> Loader Class Initialized
INFO - 2025-05-04 06:57:12 --> Helper loaded: form_helper
INFO - 2025-05-04 06:57:12 --> Helper loaded: url_helper
INFO - 2025-05-04 06:57:12 --> Database Driver Class Initialized
INFO - 2025-05-04 06:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:57:12 --> Form Validation Class Initialized
INFO - 2025-05-04 06:57:12 --> Controller Class Initialized
DEBUG - 2025-05-04 06:57:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:57:12 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:57:12 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:57:12 --> Final output sent to browser
DEBUG - 2025-05-04 06:57:12 --> Total execution time: 0.0730
INFO - 2025-05-04 06:58:24 --> Config Class Initialized
INFO - 2025-05-04 06:58:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:58:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:58:24 --> Utf8 Class Initialized
INFO - 2025-05-04 06:58:24 --> URI Class Initialized
INFO - 2025-05-04 06:58:24 --> Router Class Initialized
INFO - 2025-05-04 06:58:24 --> Output Class Initialized
INFO - 2025-05-04 06:58:24 --> Security Class Initialized
DEBUG - 2025-05-04 06:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:58:24 --> Input Class Initialized
INFO - 2025-05-04 06:58:24 --> Language Class Initialized
INFO - 2025-05-04 06:58:24 --> Loader Class Initialized
INFO - 2025-05-04 06:58:24 --> Helper loaded: form_helper
INFO - 2025-05-04 06:58:24 --> Helper loaded: url_helper
INFO - 2025-05-04 06:58:24 --> Database Driver Class Initialized
INFO - 2025-05-04 06:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:58:24 --> Form Validation Class Initialized
INFO - 2025-05-04 06:58:24 --> Controller Class Initialized
DEBUG - 2025-05-04 06:58:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:58:24 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:58:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:58:24 --> Final output sent to browser
DEBUG - 2025-05-04 06:58:24 --> Total execution time: 0.1223
INFO - 2025-05-04 06:58:56 --> Config Class Initialized
INFO - 2025-05-04 06:58:56 --> Hooks Class Initialized
DEBUG - 2025-05-04 06:58:56 --> UTF-8 Support Enabled
INFO - 2025-05-04 06:58:56 --> Utf8 Class Initialized
INFO - 2025-05-04 06:58:56 --> URI Class Initialized
INFO - 2025-05-04 06:58:56 --> Router Class Initialized
INFO - 2025-05-04 06:58:56 --> Output Class Initialized
INFO - 2025-05-04 06:58:56 --> Security Class Initialized
DEBUG - 2025-05-04 06:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 06:58:56 --> Input Class Initialized
INFO - 2025-05-04 06:58:56 --> Language Class Initialized
INFO - 2025-05-04 06:58:56 --> Loader Class Initialized
INFO - 2025-05-04 06:58:56 --> Helper loaded: form_helper
INFO - 2025-05-04 06:58:56 --> Helper loaded: url_helper
INFO - 2025-05-04 06:58:56 --> Database Driver Class Initialized
INFO - 2025-05-04 06:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 06:58:56 --> Form Validation Class Initialized
INFO - 2025-05-04 06:58:56 --> Controller Class Initialized
DEBUG - 2025-05-04 06:58:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 06:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 06:58:56 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 06:58:56 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 06:58:56 --> Final output sent to browser
DEBUG - 2025-05-04 06:58:56 --> Total execution time: 0.1595
INFO - 2025-05-04 07:03:14 --> Config Class Initialized
INFO - 2025-05-04 07:03:14 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:03:14 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:03:14 --> Utf8 Class Initialized
INFO - 2025-05-04 07:03:14 --> URI Class Initialized
INFO - 2025-05-04 07:03:14 --> Router Class Initialized
INFO - 2025-05-04 07:03:14 --> Output Class Initialized
INFO - 2025-05-04 07:03:14 --> Security Class Initialized
DEBUG - 2025-05-04 07:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:03:14 --> Input Class Initialized
INFO - 2025-05-04 07:03:14 --> Language Class Initialized
INFO - 2025-05-04 07:03:14 --> Loader Class Initialized
INFO - 2025-05-04 07:03:14 --> Helper loaded: form_helper
INFO - 2025-05-04 07:03:14 --> Helper loaded: url_helper
INFO - 2025-05-04 07:03:14 --> Database Driver Class Initialized
INFO - 2025-05-04 07:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:03:14 --> Form Validation Class Initialized
INFO - 2025-05-04 07:03:14 --> Controller Class Initialized
DEBUG - 2025-05-04 07:03:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 07:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 07:03:14 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 07:03:14 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 07:03:14 --> Final output sent to browser
DEBUG - 2025-05-04 07:03:14 --> Total execution time: 0.0681
INFO - 2025-05-04 07:05:09 --> Config Class Initialized
INFO - 2025-05-04 07:05:09 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:05:09 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:05:09 --> Utf8 Class Initialized
INFO - 2025-05-04 07:05:09 --> URI Class Initialized
INFO - 2025-05-04 07:05:09 --> Router Class Initialized
INFO - 2025-05-04 07:05:09 --> Output Class Initialized
INFO - 2025-05-04 07:05:09 --> Security Class Initialized
DEBUG - 2025-05-04 07:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:05:09 --> Input Class Initialized
INFO - 2025-05-04 07:05:09 --> Language Class Initialized
INFO - 2025-05-04 07:05:09 --> Loader Class Initialized
INFO - 2025-05-04 07:05:09 --> Helper loaded: form_helper
INFO - 2025-05-04 07:05:09 --> Helper loaded: url_helper
INFO - 2025-05-04 07:05:09 --> Database Driver Class Initialized
INFO - 2025-05-04 07:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:05:09 --> Form Validation Class Initialized
INFO - 2025-05-04 07:05:09 --> Controller Class Initialized
DEBUG - 2025-05-04 07:05:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 07:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 07:05:09 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 07:05:09 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 07:05:09 --> Final output sent to browser
DEBUG - 2025-05-04 07:05:09 --> Total execution time: 0.0654
INFO - 2025-05-04 07:07:22 --> Config Class Initialized
INFO - 2025-05-04 07:07:22 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:07:22 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:07:22 --> Utf8 Class Initialized
INFO - 2025-05-04 07:07:22 --> URI Class Initialized
INFO - 2025-05-04 07:07:22 --> Router Class Initialized
INFO - 2025-05-04 07:07:22 --> Output Class Initialized
INFO - 2025-05-04 07:07:22 --> Security Class Initialized
DEBUG - 2025-05-04 07:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:07:22 --> Input Class Initialized
INFO - 2025-05-04 07:07:22 --> Language Class Initialized
INFO - 2025-05-04 07:07:22 --> Loader Class Initialized
INFO - 2025-05-04 07:07:22 --> Helper loaded: form_helper
INFO - 2025-05-04 07:07:22 --> Helper loaded: url_helper
INFO - 2025-05-04 07:07:22 --> Database Driver Class Initialized
INFO - 2025-05-04 07:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:07:22 --> Form Validation Class Initialized
INFO - 2025-05-04 07:07:22 --> Controller Class Initialized
DEBUG - 2025-05-04 07:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 07:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 07:07:22 --> Model "Ppdb_model" initialized
INFO - 2025-05-04 07:07:22 --> File loaded: C:\xampp\htdocs\ppdb\application\views\ppdb/form_pendaftaran.php
INFO - 2025-05-04 07:07:22 --> Final output sent to browser
DEBUG - 2025-05-04 07:07:22 --> Total execution time: 0.0743
INFO - 2025-05-04 07:08:10 --> Config Class Initialized
INFO - 2025-05-04 07:08:10 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:10 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:10 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:10 --> URI Class Initialized
INFO - 2025-05-04 07:08:10 --> Router Class Initialized
INFO - 2025-05-04 07:08:10 --> Output Class Initialized
INFO - 2025-05-04 07:08:10 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:10 --> Input Class Initialized
INFO - 2025-05-04 07:08:10 --> Language Class Initialized
INFO - 2025-05-04 07:08:10 --> Loader Class Initialized
INFO - 2025-05-04 07:08:10 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:10 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:10 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:10 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:10 --> Controller Class Initialized
DEBUG - 2025-05-04 07:08:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2025-05-04 07:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2025-05-04 07:08:10 --> Model "Ppdb_model" initialized
DEBUG - 2025-05-04 07:08:10 --> POST data: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [tempat_tanggal_lahir_db] => Demak, 15 Agustus 2008
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [no_hp_siswa] => 081234567890
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Wali
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [alamat_lengkap_db] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_lahir_db] => 2008-08-15
)

INFO - 2025-05-04 07:08:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2025-05-04 07:08:10 --> Generated registration number: A-2526/0163
DEBUG - 2025-05-04 07:08:10 --> Form data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Wali
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 07:08:10
    [status] => Baru
    [no_pendaftaran] => A-2526/0163
)

DEBUG - 2025-05-04 07:08:10 --> === Starting save_pendaftaran ===
DEBUG - 2025-05-04 07:08:10 --> Database config: 1
DEBUG - 2025-05-04 07:08:10 --> Database hostname: localhost
DEBUG - 2025-05-04 07:08:10 --> Database username: root
DEBUG - 2025-05-04 07:08:10 --> Database database: ppdb_mansaba
DEBUG - 2025-05-04 07:08:10 --> Data to save: Array
(
    [nama_siswa] => Ahmad Fauzi
    [jenis_kelamin] => Laki-laki
    [tempat_lahir] => Demak
    [tanggal_lahir] => 2008-08-15
    [tempat_tanggal_lahir] => Demak, 15 Agustus 2008
    [no_hp_siswa] => 081234567890
    [rekomendasi] => Guru PAI
    [pilihan_program] => MIPA
    [jalur_pendaftaran] => Reguler
    [tinggal] => Bersama Wali
    [dukuh] => Dukuh Krajan
    [rt] => 01
    [rw] => 02
    [desa] => Mranggen
    [kecamatan] => Mranggen
    [kabupaten] => Demak
    [provinsi] => Jawa Tengah
    [alamat_lengkap] => Dukuh Krajan, RT 01/RW 02, Mranggen, Mranggen, Demak, Jawa Tengah
    [nama_ayah] => Budi Santoso
    [nama_ibu] => Siti Aminah
    [pendidikan_ayah] => Strata 1
    [pendidikan_ibu] => SLTA Sederajat
    [pekerjaan_ayah] => Wiraswasta
    [pekerjaan_ibu] => Ibu Rumah Tangga
    [no_hp_ayah] => 081234567891
    [no_hp_ibu] => 081234567892
    [alamat_ortu] => Jl. Merdeka No. 123
    [saudara_sekolah] => Tidak
    [nama_wali] => 
    [hubungan_wali] => 
    [pendidikan_wali] => 
    [pekerjaan_wali] => 
    [no_hp_wali] => 
    [alamat_wali] => 
    [nama_sekolah] => SMP Negeri 1 Mranggen
    [nisn] => 1234567890
    [alamat_sekolah] => Jl. Pendidikan No. 1, Mranggen
    [piagam] => Tidak
    [nama_event] => 
    [motivasi] => Ingin melanjutkan pendidikan di MA NU 01 Banyuputih karena memiliki program unggulan yang sesuai dengan minat saya.
    [tanggal_daftar] => 2025-05-04 07:08:10
    [status] => Baru
    [no_pendaftaran] => A-2526/0163
)

DEBUG - 2025-05-04 07:08:10 --> Data inserted successfully with ID: 179
INFO - 2025-05-04 07:08:10 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:10 --> Total execution time: 0.0393
INFO - 2025-05-04 07:08:11 --> Config Class Initialized
INFO - 2025-05-04 07:08:11 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:11 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:11 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:11 --> URI Class Initialized
DEBUG - 2025-05-04 07:08:11 --> No URI present. Default controller set.
INFO - 2025-05-04 07:08:11 --> Router Class Initialized
INFO - 2025-05-04 07:08:11 --> Output Class Initialized
INFO - 2025-05-04 07:08:11 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:11 --> Input Class Initialized
INFO - 2025-05-04 07:08:11 --> Language Class Initialized
INFO - 2025-05-04 07:08:11 --> Loader Class Initialized
INFO - 2025-05-04 07:08:11 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:11 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:11 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:11 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:11 --> Controller Class Initialized
INFO - 2025-05-04 07:08:11 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:11 --> Total execution time: 0.0294
INFO - 2025-05-04 07:08:13 --> Config Class Initialized
INFO - 2025-05-04 07:08:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:13 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:13 --> URI Class Initialized
INFO - 2025-05-04 07:08:13 --> Router Class Initialized
INFO - 2025-05-04 07:08:13 --> Output Class Initialized
INFO - 2025-05-04 07:08:13 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:13 --> Input Class Initialized
INFO - 2025-05-04 07:08:13 --> Language Class Initialized
INFO - 2025-05-04 07:08:13 --> Loader Class Initialized
INFO - 2025-05-04 07:08:13 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:13 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:13 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:13 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:13 --> Controller Class Initialized
INFO - 2025-05-04 07:08:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:08:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:08:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:08:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 07:08:13 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:13 --> Total execution time: 0.0313
INFO - 2025-05-04 07:08:15 --> Config Class Initialized
INFO - 2025-05-04 07:08:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:15 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:15 --> URI Class Initialized
INFO - 2025-05-04 07:08:15 --> Router Class Initialized
INFO - 2025-05-04 07:08:15 --> Output Class Initialized
INFO - 2025-05-04 07:08:15 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:15 --> Input Class Initialized
INFO - 2025-05-04 07:08:15 --> Language Class Initialized
INFO - 2025-05-04 07:08:15 --> Loader Class Initialized
INFO - 2025-05-04 07:08:15 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:15 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:15 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:15 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:15 --> Controller Class Initialized
INFO - 2025-05-04 07:08:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:08:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:08:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:08:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 07:08:15 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:15 --> Total execution time: 0.0338
INFO - 2025-05-04 07:08:17 --> Config Class Initialized
INFO - 2025-05-04 07:08:17 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:17 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:17 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:17 --> URI Class Initialized
INFO - 2025-05-04 07:08:17 --> Router Class Initialized
INFO - 2025-05-04 07:08:17 --> Output Class Initialized
INFO - 2025-05-04 07:08:17 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:17 --> Input Class Initialized
INFO - 2025-05-04 07:08:17 --> Language Class Initialized
INFO - 2025-05-04 07:08:17 --> Loader Class Initialized
INFO - 2025-05-04 07:08:17 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:17 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:17 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:17 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:17 --> Controller Class Initialized
INFO - 2025-05-04 07:08:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:08:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:08:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:08:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-04 07:08:17 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:17 --> Total execution time: 0.0359
INFO - 2025-05-04 07:08:18 --> Config Class Initialized
INFO - 2025-05-04 07:08:18 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:18 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:18 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:18 --> URI Class Initialized
INFO - 2025-05-04 07:08:18 --> Router Class Initialized
INFO - 2025-05-04 07:08:18 --> Output Class Initialized
INFO - 2025-05-04 07:08:18 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:18 --> Input Class Initialized
INFO - 2025-05-04 07:08:18 --> Language Class Initialized
INFO - 2025-05-04 07:08:18 --> Loader Class Initialized
INFO - 2025-05-04 07:08:18 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:18 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:18 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:18 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:18 --> Controller Class Initialized
INFO - 2025-05-04 07:08:18 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:08:18 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:08:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:08:18 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 07:08:18 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:18 --> Total execution time: 0.0344
INFO - 2025-05-04 07:08:20 --> Config Class Initialized
INFO - 2025-05-04 07:08:20 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:20 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:20 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:20 --> URI Class Initialized
INFO - 2025-05-04 07:08:20 --> Router Class Initialized
INFO - 2025-05-04 07:08:20 --> Output Class Initialized
INFO - 2025-05-04 07:08:20 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:20 --> Input Class Initialized
INFO - 2025-05-04 07:08:20 --> Language Class Initialized
INFO - 2025-05-04 07:08:20 --> Loader Class Initialized
INFO - 2025-05-04 07:08:20 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:20 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:20 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:20 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:20 --> Controller Class Initialized
INFO - 2025-05-04 07:08:20 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:08:20 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:08:20 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:08:20 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-04 07:08:20 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:20 --> Total execution time: 0.0361
INFO - 2025-05-04 07:08:44 --> Config Class Initialized
INFO - 2025-05-04 07:08:44 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:44 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:44 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:44 --> URI Class Initialized
INFO - 2025-05-04 07:08:44 --> Router Class Initialized
INFO - 2025-05-04 07:08:44 --> Output Class Initialized
INFO - 2025-05-04 07:08:44 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:44 --> Input Class Initialized
INFO - 2025-05-04 07:08:44 --> Language Class Initialized
INFO - 2025-05-04 07:08:45 --> Loader Class Initialized
INFO - 2025-05-04 07:08:45 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:45 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:45 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:45 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:45 --> Controller Class Initialized
INFO - 2025-05-04 07:08:45 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:08:45 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:08:45 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:08:45 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/belum_daftar_ulang.php
INFO - 2025-05-04 07:08:45 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:45 --> Total execution time: 0.0340
INFO - 2025-05-04 07:08:47 --> Config Class Initialized
INFO - 2025-05-04 07:08:47 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:47 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:47 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:47 --> URI Class Initialized
INFO - 2025-05-04 07:08:47 --> Router Class Initialized
INFO - 2025-05-04 07:08:47 --> Output Class Initialized
INFO - 2025-05-04 07:08:47 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:47 --> Input Class Initialized
INFO - 2025-05-04 07:08:47 --> Language Class Initialized
INFO - 2025-05-04 07:08:47 --> Loader Class Initialized
INFO - 2025-05-04 07:08:47 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:47 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:47 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:47 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:47 --> Controller Class Initialized
INFO - 2025-05-04 07:08:47 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:08:47 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:08:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:08:47 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 07:08:47 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:47 --> Total execution time: 0.0342
INFO - 2025-05-04 07:08:49 --> Config Class Initialized
INFO - 2025-05-04 07:08:49 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:08:49 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:08:49 --> Utf8 Class Initialized
INFO - 2025-05-04 07:08:49 --> URI Class Initialized
INFO - 2025-05-04 07:08:49 --> Router Class Initialized
INFO - 2025-05-04 07:08:49 --> Output Class Initialized
INFO - 2025-05-04 07:08:49 --> Security Class Initialized
DEBUG - 2025-05-04 07:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:08:49 --> Input Class Initialized
INFO - 2025-05-04 07:08:49 --> Language Class Initialized
INFO - 2025-05-04 07:08:49 --> Loader Class Initialized
INFO - 2025-05-04 07:08:49 --> Helper loaded: form_helper
INFO - 2025-05-04 07:08:49 --> Helper loaded: url_helper
INFO - 2025-05-04 07:08:49 --> Database Driver Class Initialized
INFO - 2025-05-04 07:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:08:49 --> Form Validation Class Initialized
INFO - 2025-05-04 07:08:49 --> Controller Class Initialized
INFO - 2025-05-04 07:08:49 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:08:49 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:08:49 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-04 07:08:49 --> Final output sent to browser
DEBUG - 2025-05-04 07:08:49 --> Total execution time: 0.0332
INFO - 2025-05-04 07:10:31 --> Config Class Initialized
INFO - 2025-05-04 07:10:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:10:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:10:31 --> Utf8 Class Initialized
INFO - 2025-05-04 07:10:31 --> URI Class Initialized
INFO - 2025-05-04 07:10:31 --> Router Class Initialized
INFO - 2025-05-04 07:10:31 --> Output Class Initialized
INFO - 2025-05-04 07:10:31 --> Security Class Initialized
DEBUG - 2025-05-04 07:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:10:31 --> Input Class Initialized
INFO - 2025-05-04 07:10:31 --> Language Class Initialized
INFO - 2025-05-04 07:10:31 --> Loader Class Initialized
INFO - 2025-05-04 07:10:31 --> Helper loaded: form_helper
INFO - 2025-05-04 07:10:31 --> Helper loaded: url_helper
INFO - 2025-05-04 07:10:31 --> Database Driver Class Initialized
INFO - 2025-05-04 07:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:10:31 --> Form Validation Class Initialized
INFO - 2025-05-04 07:10:31 --> Controller Class Initialized
INFO - 2025-05-04 07:10:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:10:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:10:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-04 07:10:31 --> Final output sent to browser
DEBUG - 2025-05-04 07:10:31 --> Total execution time: 0.0564
INFO - 2025-05-04 07:10:57 --> Config Class Initialized
INFO - 2025-05-04 07:10:57 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:10:57 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:10:57 --> Utf8 Class Initialized
INFO - 2025-05-04 07:10:57 --> URI Class Initialized
INFO - 2025-05-04 07:10:57 --> Router Class Initialized
INFO - 2025-05-04 07:10:57 --> Output Class Initialized
INFO - 2025-05-04 07:10:57 --> Security Class Initialized
DEBUG - 2025-05-04 07:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:10:57 --> Input Class Initialized
INFO - 2025-05-04 07:10:57 --> Language Class Initialized
INFO - 2025-05-04 07:10:57 --> Loader Class Initialized
INFO - 2025-05-04 07:10:57 --> Helper loaded: form_helper
INFO - 2025-05-04 07:10:57 --> Helper loaded: url_helper
INFO - 2025-05-04 07:10:57 --> Database Driver Class Initialized
INFO - 2025-05-04 07:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:10:57 --> Form Validation Class Initialized
INFO - 2025-05-04 07:10:57 --> Controller Class Initialized
INFO - 2025-05-04 07:10:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:10:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:10:57 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-04 07:10:57 --> Final output sent to browser
DEBUG - 2025-05-04 07:10:57 --> Total execution time: 0.1325
INFO - 2025-05-04 07:12:06 --> Config Class Initialized
INFO - 2025-05-04 07:12:06 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:12:06 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:12:06 --> Utf8 Class Initialized
INFO - 2025-05-04 07:12:06 --> URI Class Initialized
INFO - 2025-05-04 07:12:06 --> Router Class Initialized
INFO - 2025-05-04 07:12:06 --> Output Class Initialized
INFO - 2025-05-04 07:12:06 --> Security Class Initialized
DEBUG - 2025-05-04 07:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:12:06 --> Input Class Initialized
INFO - 2025-05-04 07:12:06 --> Language Class Initialized
INFO - 2025-05-04 07:12:06 --> Loader Class Initialized
INFO - 2025-05-04 07:12:06 --> Helper loaded: form_helper
INFO - 2025-05-04 07:12:06 --> Helper loaded: url_helper
INFO - 2025-05-04 07:12:06 --> Database Driver Class Initialized
INFO - 2025-05-04 07:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:12:06 --> Form Validation Class Initialized
INFO - 2025-05-04 07:12:06 --> Controller Class Initialized
INFO - 2025-05-04 07:12:06 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:12:06 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:12:06 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-04 07:12:06 --> Final output sent to browser
DEBUG - 2025-05-04 07:12:06 --> Total execution time: 0.0414
INFO - 2025-05-04 07:13:15 --> Config Class Initialized
INFO - 2025-05-04 07:13:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:13:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:13:15 --> Utf8 Class Initialized
INFO - 2025-05-04 07:13:15 --> URI Class Initialized
INFO - 2025-05-04 07:13:15 --> Router Class Initialized
INFO - 2025-05-04 07:13:15 --> Output Class Initialized
INFO - 2025-05-04 07:13:15 --> Security Class Initialized
DEBUG - 2025-05-04 07:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:13:15 --> Input Class Initialized
INFO - 2025-05-04 07:13:15 --> Language Class Initialized
INFO - 2025-05-04 07:13:15 --> Loader Class Initialized
INFO - 2025-05-04 07:13:15 --> Helper loaded: form_helper
INFO - 2025-05-04 07:13:15 --> Helper loaded: url_helper
INFO - 2025-05-04 07:13:15 --> Database Driver Class Initialized
INFO - 2025-05-04 07:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:13:15 --> Form Validation Class Initialized
INFO - 2025-05-04 07:13:15 --> Controller Class Initialized
INFO - 2025-05-04 07:13:15 --> Config Class Initialized
INFO - 2025-05-04 07:13:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:13:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:13:15 --> Utf8 Class Initialized
INFO - 2025-05-04 07:13:15 --> URI Class Initialized
INFO - 2025-05-04 07:13:15 --> Router Class Initialized
INFO - 2025-05-04 07:13:15 --> Output Class Initialized
INFO - 2025-05-04 07:13:15 --> Security Class Initialized
DEBUG - 2025-05-04 07:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:13:15 --> Input Class Initialized
INFO - 2025-05-04 07:13:15 --> Language Class Initialized
INFO - 2025-05-04 07:13:15 --> Loader Class Initialized
INFO - 2025-05-04 07:13:15 --> Helper loaded: form_helper
INFO - 2025-05-04 07:13:15 --> Helper loaded: url_helper
INFO - 2025-05-04 07:13:15 --> Database Driver Class Initialized
INFO - 2025-05-04 07:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:13:15 --> Form Validation Class Initialized
INFO - 2025-05-04 07:13:15 --> Controller Class Initialized
INFO - 2025-05-04 07:13:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/login.php
INFO - 2025-05-04 07:13:15 --> Final output sent to browser
DEBUG - 2025-05-04 07:13:15 --> Total execution time: 0.0669
INFO - 2025-05-04 07:13:19 --> Config Class Initialized
INFO - 2025-05-04 07:13:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:13:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:13:19 --> Utf8 Class Initialized
INFO - 2025-05-04 07:13:19 --> URI Class Initialized
INFO - 2025-05-04 07:13:19 --> Router Class Initialized
INFO - 2025-05-04 07:13:19 --> Output Class Initialized
INFO - 2025-05-04 07:13:19 --> Security Class Initialized
DEBUG - 2025-05-04 07:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:13:19 --> Input Class Initialized
INFO - 2025-05-04 07:13:19 --> Language Class Initialized
INFO - 2025-05-04 07:13:19 --> Loader Class Initialized
INFO - 2025-05-04 07:13:19 --> Helper loaded: form_helper
INFO - 2025-05-04 07:13:19 --> Helper loaded: url_helper
INFO - 2025-05-04 07:13:19 --> Database Driver Class Initialized
INFO - 2025-05-04 07:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:13:19 --> Form Validation Class Initialized
INFO - 2025-05-04 07:13:19 --> Controller Class Initialized
INFO - 2025-05-04 07:13:19 --> Config Class Initialized
INFO - 2025-05-04 07:13:19 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:13:19 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:13:19 --> Utf8 Class Initialized
INFO - 2025-05-04 07:13:19 --> URI Class Initialized
INFO - 2025-05-04 07:13:19 --> Router Class Initialized
INFO - 2025-05-04 07:13:19 --> Output Class Initialized
INFO - 2025-05-04 07:13:19 --> Security Class Initialized
DEBUG - 2025-05-04 07:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:13:19 --> Input Class Initialized
INFO - 2025-05-04 07:13:19 --> Language Class Initialized
INFO - 2025-05-04 07:13:19 --> Loader Class Initialized
INFO - 2025-05-04 07:13:19 --> Helper loaded: form_helper
INFO - 2025-05-04 07:13:19 --> Helper loaded: url_helper
INFO - 2025-05-04 07:13:19 --> Database Driver Class Initialized
INFO - 2025-05-04 07:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:13:19 --> Form Validation Class Initialized
INFO - 2025-05-04 07:13:19 --> Controller Class Initialized
INFO - 2025-05-04 07:13:19 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:13:19 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:13:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:13:19 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 07:13:19 --> Final output sent to browser
DEBUG - 2025-05-04 07:13:19 --> Total execution time: 0.0769
INFO - 2025-05-04 07:13:24 --> Config Class Initialized
INFO - 2025-05-04 07:13:24 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:13:24 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:13:24 --> Utf8 Class Initialized
INFO - 2025-05-04 07:13:24 --> URI Class Initialized
INFO - 2025-05-04 07:13:24 --> Router Class Initialized
INFO - 2025-05-04 07:13:24 --> Output Class Initialized
INFO - 2025-05-04 07:13:24 --> Security Class Initialized
DEBUG - 2025-05-04 07:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:13:24 --> Input Class Initialized
INFO - 2025-05-04 07:13:24 --> Language Class Initialized
INFO - 2025-05-04 07:13:24 --> Loader Class Initialized
INFO - 2025-05-04 07:13:24 --> Helper loaded: form_helper
INFO - 2025-05-04 07:13:24 --> Helper loaded: url_helper
INFO - 2025-05-04 07:13:24 --> Database Driver Class Initialized
INFO - 2025-05-04 07:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:13:24 --> Form Validation Class Initialized
INFO - 2025-05-04 07:13:24 --> Controller Class Initialized
INFO - 2025-05-04 07:13:24 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:13:24 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:13:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:13:24 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 07:13:24 --> Final output sent to browser
DEBUG - 2025-05-04 07:13:24 --> Total execution time: 0.0803
INFO - 2025-05-04 07:13:27 --> Config Class Initialized
INFO - 2025-05-04 07:13:27 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:13:27 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:13:27 --> Utf8 Class Initialized
INFO - 2025-05-04 07:13:27 --> URI Class Initialized
INFO - 2025-05-04 07:13:27 --> Router Class Initialized
INFO - 2025-05-04 07:13:27 --> Output Class Initialized
INFO - 2025-05-04 07:13:27 --> Security Class Initialized
DEBUG - 2025-05-04 07:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:13:27 --> Input Class Initialized
INFO - 2025-05-04 07:13:27 --> Language Class Initialized
INFO - 2025-05-04 07:13:27 --> Loader Class Initialized
INFO - 2025-05-04 07:13:27 --> Helper loaded: form_helper
INFO - 2025-05-04 07:13:27 --> Helper loaded: url_helper
INFO - 2025-05-04 07:13:27 --> Database Driver Class Initialized
INFO - 2025-05-04 07:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:13:27 --> Form Validation Class Initialized
INFO - 2025-05-04 07:13:27 --> Controller Class Initialized
INFO - 2025-05-04 07:13:27 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:13:27 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:13:27 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-04 07:13:27 --> Final output sent to browser
DEBUG - 2025-05-04 07:13:27 --> Total execution time: 0.0671
INFO - 2025-05-04 07:14:23 --> Config Class Initialized
INFO - 2025-05-04 07:14:23 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:14:23 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:14:23 --> Utf8 Class Initialized
INFO - 2025-05-04 07:14:23 --> URI Class Initialized
INFO - 2025-05-04 07:14:23 --> Router Class Initialized
INFO - 2025-05-04 07:14:23 --> Output Class Initialized
INFO - 2025-05-04 07:14:23 --> Security Class Initialized
DEBUG - 2025-05-04 07:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:14:23 --> Input Class Initialized
INFO - 2025-05-04 07:14:23 --> Language Class Initialized
INFO - 2025-05-04 07:14:23 --> Loader Class Initialized
INFO - 2025-05-04 07:14:23 --> Helper loaded: form_helper
INFO - 2025-05-04 07:14:23 --> Helper loaded: url_helper
INFO - 2025-05-04 07:14:23 --> Database Driver Class Initialized
INFO - 2025-05-04 07:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:14:23 --> Form Validation Class Initialized
INFO - 2025-05-04 07:14:23 --> Controller Class Initialized
INFO - 2025-05-04 07:14:23 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:14:23 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:14:23 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-04 07:14:23 --> Final output sent to browser
DEBUG - 2025-05-04 07:14:23 --> Total execution time: 0.0327
INFO - 2025-05-04 07:15:48 --> Config Class Initialized
INFO - 2025-05-04 07:15:48 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:15:48 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:15:48 --> Utf8 Class Initialized
INFO - 2025-05-04 07:15:48 --> URI Class Initialized
INFO - 2025-05-04 07:15:48 --> Router Class Initialized
INFO - 2025-05-04 07:15:48 --> Output Class Initialized
INFO - 2025-05-04 07:15:48 --> Security Class Initialized
DEBUG - 2025-05-04 07:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:15:48 --> Input Class Initialized
INFO - 2025-05-04 07:15:48 --> Language Class Initialized
INFO - 2025-05-04 07:15:48 --> Loader Class Initialized
INFO - 2025-05-04 07:15:48 --> Helper loaded: form_helper
INFO - 2025-05-04 07:15:48 --> Helper loaded: url_helper
INFO - 2025-05-04 07:15:48 --> Database Driver Class Initialized
INFO - 2025-05-04 07:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:15:48 --> Form Validation Class Initialized
INFO - 2025-05-04 07:15:48 --> Controller Class Initialized
INFO - 2025-05-04 07:15:48 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:15:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:15:48 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:15:48 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:15:48 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/edit_peserta_daftar_ulang.php
INFO - 2025-05-04 07:15:48 --> Final output sent to browser
DEBUG - 2025-05-04 07:15:48 --> Total execution time: 0.0353
INFO - 2025-05-04 07:15:50 --> Config Class Initialized
INFO - 2025-05-04 07:15:50 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:15:50 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:15:50 --> Utf8 Class Initialized
INFO - 2025-05-04 07:15:50 --> URI Class Initialized
INFO - 2025-05-04 07:15:50 --> Router Class Initialized
INFO - 2025-05-04 07:15:50 --> Output Class Initialized
INFO - 2025-05-04 07:15:50 --> Security Class Initialized
DEBUG - 2025-05-04 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:15:50 --> Input Class Initialized
INFO - 2025-05-04 07:15:50 --> Language Class Initialized
INFO - 2025-05-04 07:15:50 --> Loader Class Initialized
INFO - 2025-05-04 07:15:50 --> Helper loaded: form_helper
INFO - 2025-05-04 07:15:50 --> Helper loaded: url_helper
INFO - 2025-05-04 07:15:50 --> Database Driver Class Initialized
INFO - 2025-05-04 07:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:15:50 --> Form Validation Class Initialized
INFO - 2025-05-04 07:15:50 --> Controller Class Initialized
INFO - 2025-05-04 07:15:50 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:15:50 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:15:50 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:15:50 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 07:15:50 --> Final output sent to browser
DEBUG - 2025-05-04 07:15:50 --> Total execution time: 0.0340
INFO - 2025-05-04 07:15:52 --> Config Class Initialized
INFO - 2025-05-04 07:15:52 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:15:52 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:15:52 --> Utf8 Class Initialized
INFO - 2025-05-04 07:15:52 --> URI Class Initialized
INFO - 2025-05-04 07:15:52 --> Router Class Initialized
INFO - 2025-05-04 07:15:52 --> Output Class Initialized
INFO - 2025-05-04 07:15:52 --> Security Class Initialized
DEBUG - 2025-05-04 07:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:15:52 --> Input Class Initialized
INFO - 2025-05-04 07:15:52 --> Language Class Initialized
INFO - 2025-05-04 07:15:52 --> Loader Class Initialized
INFO - 2025-05-04 07:15:52 --> Helper loaded: form_helper
INFO - 2025-05-04 07:15:52 --> Helper loaded: url_helper
INFO - 2025-05-04 07:15:52 --> Database Driver Class Initialized
INFO - 2025-05-04 07:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:15:52 --> Form Validation Class Initialized
INFO - 2025-05-04 07:15:52 --> Controller Class Initialized
INFO - 2025-05-04 07:15:52 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:15:52 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:15:52 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:15:52 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar_lengkap.php
INFO - 2025-05-04 07:15:52 --> Final output sent to browser
DEBUG - 2025-05-04 07:15:52 --> Total execution time: 0.0361
INFO - 2025-05-04 07:15:55 --> Config Class Initialized
INFO - 2025-05-04 07:15:55 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:15:55 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:15:55 --> Utf8 Class Initialized
INFO - 2025-05-04 07:15:55 --> URI Class Initialized
INFO - 2025-05-04 07:15:55 --> Router Class Initialized
INFO - 2025-05-04 07:15:55 --> Output Class Initialized
INFO - 2025-05-04 07:15:55 --> Security Class Initialized
DEBUG - 2025-05-04 07:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:15:55 --> Input Class Initialized
INFO - 2025-05-04 07:15:55 --> Language Class Initialized
INFO - 2025-05-04 07:15:55 --> Loader Class Initialized
INFO - 2025-05-04 07:15:55 --> Helper loaded: form_helper
INFO - 2025-05-04 07:15:55 --> Helper loaded: url_helper
INFO - 2025-05-04 07:15:55 --> Database Driver Class Initialized
INFO - 2025-05-04 07:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:15:55 --> Form Validation Class Initialized
INFO - 2025-05-04 07:15:55 --> Controller Class Initialized
INFO - 2025-05-04 07:15:55 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:15:55 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:15:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:15:55 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-04 07:15:55 --> Final output sent to browser
DEBUG - 2025-05-04 07:15:55 --> Total execution time: 0.0354
INFO - 2025-05-04 07:15:57 --> Config Class Initialized
INFO - 2025-05-04 07:15:57 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:15:57 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:15:57 --> Utf8 Class Initialized
INFO - 2025-05-04 07:15:57 --> URI Class Initialized
INFO - 2025-05-04 07:15:57 --> Router Class Initialized
INFO - 2025-05-04 07:15:57 --> Output Class Initialized
INFO - 2025-05-04 07:15:57 --> Security Class Initialized
DEBUG - 2025-05-04 07:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:15:57 --> Input Class Initialized
INFO - 2025-05-04 07:15:57 --> Language Class Initialized
INFO - 2025-05-04 07:15:57 --> Loader Class Initialized
INFO - 2025-05-04 07:15:57 --> Helper loaded: form_helper
INFO - 2025-05-04 07:15:57 --> Helper loaded: url_helper
INFO - 2025-05-04 07:15:57 --> Database Driver Class Initialized
INFO - 2025-05-04 07:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:15:57 --> Form Validation Class Initialized
INFO - 2025-05-04 07:15:57 --> Controller Class Initialized
INFO - 2025-05-04 07:15:57 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:15:57 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:15:57 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-04 07:15:57 --> Final output sent to browser
DEBUG - 2025-05-04 07:15:57 --> Total execution time: 0.0321
INFO - 2025-05-04 07:16:13 --> Config Class Initialized
INFO - 2025-05-04 07:16:13 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:16:13 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:16:13 --> Utf8 Class Initialized
INFO - 2025-05-04 07:16:13 --> URI Class Initialized
INFO - 2025-05-04 07:16:13 --> Router Class Initialized
INFO - 2025-05-04 07:16:13 --> Output Class Initialized
INFO - 2025-05-04 07:16:13 --> Security Class Initialized
DEBUG - 2025-05-04 07:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:16:13 --> Input Class Initialized
INFO - 2025-05-04 07:16:13 --> Language Class Initialized
INFO - 2025-05-04 07:16:13 --> Loader Class Initialized
INFO - 2025-05-04 07:16:13 --> Helper loaded: form_helper
INFO - 2025-05-04 07:16:13 --> Helper loaded: url_helper
INFO - 2025-05-04 07:16:13 --> Database Driver Class Initialized
INFO - 2025-05-04 07:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:16:13 --> Form Validation Class Initialized
INFO - 2025-05-04 07:16:13 --> Controller Class Initialized
INFO - 2025-05-04 07:16:13 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:16:13 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:16:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:16:13 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 07:16:13 --> Final output sent to browser
DEBUG - 2025-05-04 07:16:13 --> Total execution time: 0.0339
INFO - 2025-05-04 07:16:15 --> Config Class Initialized
INFO - 2025-05-04 07:16:15 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:16:15 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:16:15 --> Utf8 Class Initialized
INFO - 2025-05-04 07:16:15 --> URI Class Initialized
INFO - 2025-05-04 07:16:15 --> Router Class Initialized
INFO - 2025-05-04 07:16:15 --> Output Class Initialized
INFO - 2025-05-04 07:16:15 --> Security Class Initialized
DEBUG - 2025-05-04 07:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:16:15 --> Input Class Initialized
INFO - 2025-05-04 07:16:15 --> Language Class Initialized
INFO - 2025-05-04 07:16:15 --> Loader Class Initialized
INFO - 2025-05-04 07:16:15 --> Helper loaded: form_helper
INFO - 2025-05-04 07:16:15 --> Helper loaded: url_helper
INFO - 2025-05-04 07:16:15 --> Database Driver Class Initialized
INFO - 2025-05-04 07:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:16:15 --> Form Validation Class Initialized
INFO - 2025-05-04 07:16:15 --> Controller Class Initialized
INFO - 2025-05-04 07:16:15 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:16:15 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:16:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:16:15 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 07:16:15 --> Final output sent to browser
DEBUG - 2025-05-04 07:16:15 --> Total execution time: 0.0333
INFO - 2025-05-04 07:16:17 --> Config Class Initialized
INFO - 2025-05-04 07:16:17 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:16:17 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:16:17 --> Utf8 Class Initialized
INFO - 2025-05-04 07:16:17 --> URI Class Initialized
INFO - 2025-05-04 07:16:17 --> Router Class Initialized
INFO - 2025-05-04 07:16:17 --> Output Class Initialized
INFO - 2025-05-04 07:16:17 --> Security Class Initialized
DEBUG - 2025-05-04 07:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:16:17 --> Input Class Initialized
INFO - 2025-05-04 07:16:17 --> Language Class Initialized
INFO - 2025-05-04 07:16:17 --> Loader Class Initialized
INFO - 2025-05-04 07:16:17 --> Helper loaded: form_helper
INFO - 2025-05-04 07:16:17 --> Helper loaded: url_helper
INFO - 2025-05-04 07:16:17 --> Database Driver Class Initialized
INFO - 2025-05-04 07:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:16:17 --> Form Validation Class Initialized
INFO - 2025-05-04 07:16:17 --> Controller Class Initialized
INFO - 2025-05-04 07:16:17 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:16:17 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:16:17 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_bukti_daftar_ulang.php
INFO - 2025-05-04 07:16:17 --> Final output sent to browser
DEBUG - 2025-05-04 07:16:17 --> Total execution time: 0.0314
INFO - 2025-05-04 07:16:29 --> Config Class Initialized
INFO - 2025-05-04 07:16:29 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:16:29 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:16:29 --> Utf8 Class Initialized
INFO - 2025-05-04 07:16:29 --> URI Class Initialized
INFO - 2025-05-04 07:16:29 --> Router Class Initialized
INFO - 2025-05-04 07:16:29 --> Output Class Initialized
INFO - 2025-05-04 07:16:29 --> Security Class Initialized
DEBUG - 2025-05-04 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:16:29 --> Input Class Initialized
INFO - 2025-05-04 07:16:29 --> Language Class Initialized
INFO - 2025-05-04 07:16:29 --> Loader Class Initialized
INFO - 2025-05-04 07:16:29 --> Helper loaded: form_helper
INFO - 2025-05-04 07:16:29 --> Helper loaded: url_helper
INFO - 2025-05-04 07:16:29 --> Database Driver Class Initialized
INFO - 2025-05-04 07:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:16:29 --> Form Validation Class Initialized
INFO - 2025-05-04 07:16:29 --> Controller Class Initialized
INFO - 2025-05-04 07:16:29 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:16:29 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:16:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:16:29 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 07:16:29 --> Final output sent to browser
DEBUG - 2025-05-04 07:16:29 --> Total execution time: 0.0341
INFO - 2025-05-04 07:16:30 --> Config Class Initialized
INFO - 2025-05-04 07:16:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:16:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:16:30 --> Utf8 Class Initialized
INFO - 2025-05-04 07:16:30 --> URI Class Initialized
INFO - 2025-05-04 07:16:30 --> Router Class Initialized
INFO - 2025-05-04 07:16:30 --> Output Class Initialized
INFO - 2025-05-04 07:16:30 --> Security Class Initialized
DEBUG - 2025-05-04 07:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:16:30 --> Input Class Initialized
INFO - 2025-05-04 07:16:30 --> Language Class Initialized
INFO - 2025-05-04 07:16:30 --> Loader Class Initialized
INFO - 2025-05-04 07:16:30 --> Helper loaded: form_helper
INFO - 2025-05-04 07:16:30 --> Helper loaded: url_helper
INFO - 2025-05-04 07:16:30 --> Database Driver Class Initialized
INFO - 2025-05-04 07:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:16:30 --> Form Validation Class Initialized
INFO - 2025-05-04 07:16:30 --> Controller Class Initialized
INFO - 2025-05-04 07:16:30 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:16:30 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:16:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:16:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-04 07:16:30 --> Final output sent to browser
DEBUG - 2025-05-04 07:16:30 --> Total execution time: 0.0344
INFO - 2025-05-04 07:16:31 --> Config Class Initialized
INFO - 2025-05-04 07:16:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:16:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:16:31 --> Utf8 Class Initialized
INFO - 2025-05-04 07:16:31 --> URI Class Initialized
INFO - 2025-05-04 07:16:31 --> Router Class Initialized
INFO - 2025-05-04 07:16:31 --> Output Class Initialized
INFO - 2025-05-04 07:16:31 --> Security Class Initialized
DEBUG - 2025-05-04 07:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:16:31 --> Input Class Initialized
INFO - 2025-05-04 07:16:31 --> Language Class Initialized
INFO - 2025-05-04 07:16:31 --> Loader Class Initialized
INFO - 2025-05-04 07:16:31 --> Helper loaded: form_helper
INFO - 2025-05-04 07:16:31 --> Helper loaded: url_helper
INFO - 2025-05-04 07:16:31 --> Database Driver Class Initialized
INFO - 2025-05-04 07:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:16:31 --> Form Validation Class Initialized
INFO - 2025-05-04 07:16:31 --> Controller Class Initialized
INFO - 2025-05-04 07:16:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:16:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:16:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:16:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/peserta_daftar_ulang.php
INFO - 2025-05-04 07:16:31 --> Final output sent to browser
DEBUG - 2025-05-04 07:16:31 --> Total execution time: 0.0352
INFO - 2025-05-04 07:16:34 --> Config Class Initialized
INFO - 2025-05-04 07:16:34 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:16:34 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:16:34 --> Utf8 Class Initialized
INFO - 2025-05-04 07:16:34 --> URI Class Initialized
INFO - 2025-05-04 07:16:34 --> Router Class Initialized
INFO - 2025-05-04 07:16:34 --> Output Class Initialized
INFO - 2025-05-04 07:16:34 --> Security Class Initialized
DEBUG - 2025-05-04 07:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:16:34 --> Input Class Initialized
INFO - 2025-05-04 07:16:34 --> Language Class Initialized
INFO - 2025-05-04 07:16:34 --> Loader Class Initialized
INFO - 2025-05-04 07:16:34 --> Helper loaded: form_helper
INFO - 2025-05-04 07:16:34 --> Helper loaded: url_helper
INFO - 2025-05-04 07:16:34 --> Database Driver Class Initialized
INFO - 2025-05-04 07:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:16:34 --> Form Validation Class Initialized
INFO - 2025-05-04 07:16:34 --> Controller Class Initialized
INFO - 2025-05-04 07:16:34 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:16:34 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:16:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:16:34 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/data_pendaftar.php
INFO - 2025-05-04 07:16:34 --> Final output sent to browser
DEBUG - 2025-05-04 07:16:34 --> Total execution time: 0.0352
INFO - 2025-05-04 07:16:35 --> Config Class Initialized
INFO - 2025-05-04 07:16:35 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:16:35 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:16:35 --> Utf8 Class Initialized
INFO - 2025-05-04 07:16:35 --> URI Class Initialized
INFO - 2025-05-04 07:16:35 --> Router Class Initialized
INFO - 2025-05-04 07:16:35 --> Output Class Initialized
INFO - 2025-05-04 07:16:35 --> Security Class Initialized
DEBUG - 2025-05-04 07:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:16:35 --> Input Class Initialized
INFO - 2025-05-04 07:16:35 --> Language Class Initialized
INFO - 2025-05-04 07:16:35 --> Loader Class Initialized
INFO - 2025-05-04 07:16:35 --> Helper loaded: form_helper
INFO - 2025-05-04 07:16:35 --> Helper loaded: url_helper
INFO - 2025-05-04 07:16:35 --> Database Driver Class Initialized
INFO - 2025-05-04 07:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:16:35 --> Form Validation Class Initialized
INFO - 2025-05-04 07:16:35 --> Controller Class Initialized
INFO - 2025-05-04 07:16:35 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:16:35 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:16:35 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-04 07:16:35 --> Final output sent to browser
DEBUG - 2025-05-04 07:16:35 --> Total execution time: 0.0318
INFO - 2025-05-04 07:23:39 --> Config Class Initialized
INFO - 2025-05-04 07:23:39 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:23:39 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:23:39 --> Utf8 Class Initialized
INFO - 2025-05-04 07:23:39 --> URI Class Initialized
INFO - 2025-05-04 07:23:39 --> Router Class Initialized
INFO - 2025-05-04 07:23:39 --> Output Class Initialized
INFO - 2025-05-04 07:23:39 --> Security Class Initialized
DEBUG - 2025-05-04 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:23:39 --> Input Class Initialized
INFO - 2025-05-04 07:23:39 --> Language Class Initialized
INFO - 2025-05-04 07:23:39 --> Loader Class Initialized
INFO - 2025-05-04 07:23:39 --> Helper loaded: form_helper
INFO - 2025-05-04 07:23:39 --> Helper loaded: url_helper
INFO - 2025-05-04 07:23:39 --> Database Driver Class Initialized
INFO - 2025-05-04 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:23:39 --> Form Validation Class Initialized
INFO - 2025-05-04 07:23:39 --> Controller Class Initialized
INFO - 2025-05-04 07:23:39 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:23:39 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:23:39 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/cetak_formulir.php
INFO - 2025-05-04 07:23:39 --> Final output sent to browser
DEBUG - 2025-05-04 07:23:39 --> Total execution time: 0.0449
INFO - 2025-05-04 07:24:30 --> Config Class Initialized
INFO - 2025-05-04 07:24:30 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:24:30 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:24:30 --> Utf8 Class Initialized
INFO - 2025-05-04 07:24:30 --> URI Class Initialized
INFO - 2025-05-04 07:24:30 --> Router Class Initialized
INFO - 2025-05-04 07:24:30 --> Output Class Initialized
INFO - 2025-05-04 07:24:30 --> Security Class Initialized
DEBUG - 2025-05-04 07:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:24:30 --> Input Class Initialized
INFO - 2025-05-04 07:24:30 --> Language Class Initialized
INFO - 2025-05-04 07:24:30 --> Loader Class Initialized
INFO - 2025-05-04 07:24:30 --> Helper loaded: form_helper
INFO - 2025-05-04 07:24:30 --> Helper loaded: url_helper
INFO - 2025-05-04 07:24:30 --> Database Driver Class Initialized
INFO - 2025-05-04 07:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:24:30 --> Form Validation Class Initialized
INFO - 2025-05-04 07:24:30 --> Controller Class Initialized
INFO - 2025-05-04 07:24:30 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:24:30 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:24:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:24:30 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/dashboard.php
INFO - 2025-05-04 07:24:30 --> Final output sent to browser
DEBUG - 2025-05-04 07:24:30 --> Total execution time: 0.0325
INFO - 2025-05-04 07:24:31 --> Config Class Initialized
INFO - 2025-05-04 07:24:31 --> Hooks Class Initialized
DEBUG - 2025-05-04 07:24:31 --> UTF-8 Support Enabled
INFO - 2025-05-04 07:24:31 --> Utf8 Class Initialized
INFO - 2025-05-04 07:24:31 --> URI Class Initialized
INFO - 2025-05-04 07:24:31 --> Router Class Initialized
INFO - 2025-05-04 07:24:31 --> Output Class Initialized
INFO - 2025-05-04 07:24:31 --> Security Class Initialized
DEBUG - 2025-05-04 07:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-04 07:24:31 --> Input Class Initialized
INFO - 2025-05-04 07:24:31 --> Language Class Initialized
INFO - 2025-05-04 07:24:31 --> Loader Class Initialized
INFO - 2025-05-04 07:24:31 --> Helper loaded: form_helper
INFO - 2025-05-04 07:24:31 --> Helper loaded: url_helper
INFO - 2025-05-04 07:24:31 --> Database Driver Class Initialized
INFO - 2025-05-04 07:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-04 07:24:31 --> Form Validation Class Initialized
INFO - 2025-05-04 07:24:31 --> Controller Class Initialized
INFO - 2025-05-04 07:24:31 --> Model "Pendaftaran_model" initialized
INFO - 2025-05-04 07:24:31 --> Model "Daftar_ulang_model" initialized
INFO - 2025-05-04 07:24:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/_sidebar.php
INFO - 2025-05-04 07:24:31 --> File loaded: C:\xampp\htdocs\ppdb\application\views\admin/input_daftar_ulang.php
INFO - 2025-05-04 07:24:31 --> Final output sent to browser
DEBUG - 2025-05-04 07:24:31 --> Total execution time: 0.0327
